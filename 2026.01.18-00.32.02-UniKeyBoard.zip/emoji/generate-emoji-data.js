#!/usr/bin/env node
/**
 * Unicode Emoji Data Parser
 * Generates React-compatible emoji data from unicode-emoji-json package
 * Supports: skin tones, search by name, categories, Unicode versions
 */

const fs = require('fs');
const path = require('path');

// Load the emoji data
const emojiByGroup = require('./node_modules/unicode-emoji-json/data-by-group.json');
const emojiByEmoji = require('./node_modules/unicode-emoji-json/data-by-emoji.json');

// Map group names to our category slugs
const categoryMapping = {
  'Smileys & Emotion': 'smileys',
  'People & Body': 'people', 
  'Animals & Nature': 'animals',
  'Food & Drink': 'food',
  'Travel & Places': 'travel',
  'Activities': 'activities',
  'Objects': 'objects',
  'Symbols': 'symbols',
  'Flags': 'flags',
  'Component': 'components' // skin tone modifiers, etc.
};

// Category icons
const categoryIcons = {
  smileys: '😀',
  people: '👋',
  animals: '🐶',
  food: '🍎',
  travel: '✈️',
  activities: '⚽',
  objects: '💡',
  symbols: '❤️',
  flags: '🏳️',
  components: '🏻',
  recent: '🕐'
};

// Build skin tone support set
const skinToneSupportSet = new Set();

// Process all emojis
const emojiData = {};
let totalCount = 0;
let skinToneCount = 0;

emojiByGroup.forEach(group => {
  const categorySlug = categoryMapping[group.name] || group.slug.toLowerCase().replace(/[^a-z]/g, '_');
  
  if (!emojiData[categorySlug]) {
    emojiData[categorySlug] = [];
  }
  
  group.emojis.forEach(emoji => {
    // Only include base emojis (no skin tone variants)
    // Skip if it's a skin tone variant (contains skin tone modifier)
    const skinToneModifiers = ['\u{1F3FB}', '\u{1F3FC}', '\u{1F3FD}', '\u{1F3FE}', '\u{1F3FF}'];
    const hasSkinToneModifier = skinToneModifiers.some(mod => emoji.emoji.includes(mod));
    
    if (hasSkinToneModifier) {
      return; // Skip skin tone variants
    }
    
    emojiData[categorySlug].push({
      e: emoji.emoji,
      n: emoji.name,
      s: emoji.skin_tone_support,
      v: emoji.emoji_version
    });
    
    if (emoji.skin_tone_support) {
      skinToneSupportSet.add(emoji.emoji);
      skinToneCount++;
    }
    
    totalCount++;
  });
});

// Generate the output
const output = {
  metadata: {
    version: '16.0',
    totalEmojis: totalCount,
    skinToneSupported: skinToneCount,
    generatedAt: new Date().toISOString(),
    source: 'unicode-emoji-json (Unicode CLDR)'
  },
  skinTones: [
    { code: '', label: 'Default', color: '#FFCC4D' },
    { code: '\u{1F3FB}', label: 'Light', color: '#FFDAB8' },
    { code: '\u{1F3FC}', label: 'Medium-Light', color: '#E0BB95' },
    { code: '\u{1F3FD}', label: 'Medium', color: '#BF8F68' },
    { code: '\u{1F3FE}', label: 'Medium-Dark', color: '#9B643D' },
    { code: '\u{1F3FF}', label: 'Dark', color: '#594539' }
  ],
  categories: Object.entries(categoryMapping)
    .filter(([name, slug]) => slug !== 'components')
    .map(([name, slug]) => ({
      id: slug,
      name: name,
      icon: categoryIcons[slug]
    })),
  skinToneSupportedEmojis: Array.from(skinToneSupportSet),
  emojis: emojiData
};

// Remove components category from emojis (just skin tone modifiers)
delete output.emojis.components;

// Write compact JSON
const compactJson = JSON.stringify(output);
fs.writeFileSync('emoji-data.json', compactJson);

// Write formatted JSON for inspection
fs.writeFileSync('emoji-data-formatted.json', JSON.stringify(output, null, 2));

// Generate React-compatible JavaScript module
const jsModule = `// Auto-generated Unicode Emoji Data v16.0
// Source: unicode-emoji-json (Unicode CLDR)
// Total emojis: ${totalCount} | Skin tone support: ${skinToneCount}
// Generated: ${new Date().toISOString()}

export const EMOJI_METADATA = {
  version: '16.0',
  totalEmojis: ${totalCount},
  skinToneSupported: ${skinToneCount}
};

export const skinTones = ${JSON.stringify(output.skinTones, null, 2)};

export const emojiCategories = {
  recent: { icon: '🕐', name: 'Recent' },
${Object.entries(categoryMapping)
  .filter(([name, slug]) => slug !== 'components')
  .map(([name, slug]) => `  ${slug}: { icon: '${categoryIcons[slug]}', name: '${name}' }`)
  .join(',\n')}
};

// Set of emojis that support skin tone modifiers
export const skinToneSupportedEmojis = new Set(${JSON.stringify(Array.from(skinToneSupportSet))});

// Check if emoji supports skin tones
export function supportsSkinTone(emoji) {
  const base = [...emoji][0];
  return skinToneSupportedEmojis.has(base) || skinToneSupportedEmojis.has(emoji);
}

// Apply skin tone modifier to emoji
export function applySkinTone(emoji, skinToneCode) {
  if (!skinToneCode) return emoji;
  const chars = [...emoji];
  if (chars.length === 0) return emoji;
  return chars[0] + skinToneCode + chars.slice(1).join('');
}

// Emoji data by category
// Format: { e: emoji, n: name, s: skinToneSupport, v: emojiVersion }
export const emojiData = ${JSON.stringify(emojiData, null, 2)};

// Flatten all emojis for search
export const allEmojis = Object.values(emojiData).flat();

// Search emojis by name
export function searchEmojis(query, limit = 100) {
  if (!query || !query.trim()) return [];
  const q = query.toLowerCase().trim();
  return allEmojis
    .filter(e => e.n.toLowerCase().includes(q))
    .slice(0, limit);
}
`;

fs.writeFileSync('emoji-data.js', jsModule);

// Print stats
console.log('=== Unicode Emoji Data Generator ===');
console.log(`Total emojis: ${totalCount}`);
console.log(`Skin tone supported: ${skinToneCount}`);
console.log('\nBy category:');
Object.entries(emojiData).forEach(([cat, emojis]) => {
  console.log(`  ${cat}: ${emojis.length}`);
});
console.log('\nGenerated files:');
console.log('  - emoji-data.json (compact)');
console.log('  - emoji-data-formatted.json (readable)');
console.log('  - emoji-data.js (React module)');
