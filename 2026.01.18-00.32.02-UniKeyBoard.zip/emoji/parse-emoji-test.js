#!/usr/bin/env node
/**
 * Unicode emoji-test.txt Parser
 * Parses the official Unicode emoji-test.txt file format
 * Source: https://www.unicode.org/Public/emoji/latest/emoji-test.txt
 * 
 * Format:
 *   # group: Group Name
 *   # subgroup: subgroup-name  
 *   CODE_POINTS ; STATUS # EMOJI EVERSION NAME
 *   
 * Example:
 *   1F600 ; fully-qualified # 😀 E1.0 grinning face
 */

const fs = require('fs');
const https = require('https');

const EMOJI_TEST_URL = 'https://www.unicode.org/Public/emoji/latest/emoji-test.txt';

// Skin tone modifiers (Fitzpatrick scale)
const SKIN_TONE_CODES = ['1F3FB', '1F3FC', '1F3FD', '1F3FE', '1F3FF'];

// Map Unicode group names to our category slugs
const GROUP_MAP = {
  'Smileys & Emotion': 'smileys',
  'People & Body': 'people',
  'Animals & Nature': 'animals',
  'Food & Drink': 'food',
  'Travel & Places': 'travel',
  'Activities': 'activities',
  'Objects': 'objects',
  'Symbols': 'symbols',
  'Flags': 'flags',
  'Component': 'components'
};

// Category icons for keyboard display
const CATEGORY_ICONS = {
  recent: '🕐',
  smileys: '😀',
  people: '👋',
  animals: '🐶',
  food: '🍎',
  travel: '✈️',
  activities: '⚽',
  objects: '💡',
  symbols: '❤️',
  flags: '🏳️'
};

/**
 * Parse emoji-test.txt content
 */
function parseEmojiTestTxt(content) {
  const lines = content.split('\n');
  const result = {
    version: null,
    date: null,
    groups: {},
    skinToneEmojis: new Set(),
    stats: { total: 0, withSkinTone: 0 }
  };
  
  let currentGroup = null;
  let currentSubgroup = null;
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    // Extract version from header
    if (trimmed.startsWith('# Version:')) {
      result.version = trimmed.replace('# Version:', '').trim();
      continue;
    }
    
    // Extract date from header
    if (trimmed.startsWith('# Date:')) {
      result.date = trimmed.replace('# Date:', '').trim();
      continue;
    }
    
    // Group header: # group: Name
    if (trimmed.startsWith('# group:')) {
      const groupName = trimmed.replace('# group:', '').trim();
      const groupSlug = GROUP_MAP[groupName] || groupName.toLowerCase().replace(/[^a-z]/g, '_');
      currentGroup = groupSlug;
      if (!result.groups[currentGroup]) {
        result.groups[currentGroup] = {
          name: groupName,
          subgroups: {},
          emojis: []
        };
      }
      continue;
    }
    
    // Subgroup header: # subgroup: name
    if (trimmed.startsWith('# subgroup:')) {
      currentSubgroup = trimmed.replace('# subgroup:', '').trim();
      continue;
    }
    
    // Skip empty lines and other comments
    if (!trimmed || trimmed.startsWith('#')) {
      continue;
    }
    
    // Parse emoji line: CODE_POINTS ; STATUS # EMOJI EVERSION NAME
    const match = trimmed.match(/^([0-9A-F ]+)\s*;\s*(\S+)\s*#\s*(\S+)\s+E([\d.]+)\s+(.+)$/i);
    if (!match) continue;
    
    const [, codePoints, status, emoji, emojiVersion, name] = match;
    const codes = codePoints.trim().split(/\s+/);
    
    // Only include fully-qualified emojis
    if (status !== 'fully-qualified') continue;
    
    // Check if this is a skin tone variant
    const hasSkinTone = codes.some(code => SKIN_TONE_CODES.includes(code));
    
    // Check if base emoji supports skin tones (has a variant with skin tone)
    const isBaseThatSupportsSkinTone = !hasSkinTone && 
      codes.length === 1 && 
      SKIN_TONE_CODES.some(st => 
        lines.some(l => l.includes(`${codes[0]} ${st}`) && l.includes('fully-qualified'))
      );
    
    // Skip skin tone variants (we only want base emojis)
    if (hasSkinTone) continue;
    
    if (!currentGroup) continue;
    
    const emojiData = {
      e: emoji,
      n: name,
      v: parseFloat(emojiVersion)
    };
    
    // Mark if supports skin tones
    if (isBaseThatSupportsSkinTone) {
      emojiData.s = true;
      result.skinToneEmojis.add(emoji);
      result.stats.withSkinTone++;
    }
    
    result.groups[currentGroup].emojis.push(emojiData);
    result.stats.total++;
  }
  
  return result;
}

/**
 * Second pass to properly detect skin tone support
 */
function detectSkinToneSupport(content, result) {
  const lines = content.split('\n');
  
  // Build a set of all base code points that have skin tone variants
  const basesWithSkinTones = new Set();
  
  for (const line of lines) {
    if (!line.includes('fully-qualified')) continue;
    
    const match = line.match(/^([0-9A-F ]+)\s*;/i);
    if (!match) continue;
    
    const codes = match[1].trim().split(/\s+/);
    
    // If line contains a skin tone modifier, record the base
    for (const skinTone of SKIN_TONE_CODES) {
      const idx = codes.indexOf(skinTone);
      if (idx > 0) {
        // The code point before the skin tone is the base
        basesWithSkinTones.add(codes[0]);
        break;
      }
    }
  }
  
  // Now mark emojis that support skin tones
  result.stats.withSkinTone = 0;
  result.skinToneEmojis = new Set();
  
  for (const group of Object.values(result.groups)) {
    for (const emoji of group.emojis) {
      // Convert emoji to code points
      const codePoints = [...emoji.e].map(c => c.codePointAt(0).toString(16).toUpperCase());
      
      if (basesWithSkinTones.has(codePoints[0])) {
        emoji.s = true;
        result.skinToneEmojis.add(emoji.e);
        result.stats.withSkinTone++;
      }
    }
  }
  
  return result;
}

/**
 * Generate JavaScript output
 */
function generateJS(result) {
  const skinToneArray = Array.from(result.skinToneEmojis);
  
  let js = `// Unicode Emoji Data v${result.version}
// Parsed from: ${EMOJI_TEST_URL}
// Date: ${result.date}
// Total: ${result.stats.total} emojis | Skin tone support: ${result.stats.withSkinTone}

const skinTones = [
  { code: "", label: "Default", color: "#FFCC4D" },
  { code: "\\u{1F3FB}", label: "Light", color: "#FFDAB8" },
  { code: "\\u{1F3FC}", label: "Medium-Light", color: "#E0BB95" },
  { code: "\\u{1F3FD}", label: "Medium", color: "#BF8F68" },
  { code: "\\u{1F3FE}", label: "Medium-Dark", color: "#9B643D" },
  { code: "\\u{1F3FF}", label: "Dark", color: "#594539" }
];

const emojiFontStack = "'Noto Color Emoji', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Android Emoji', sans-serif";

const emojiCategories = {
  recent: { icon: "🕐", name: "Recent" },
${Object.entries(result.groups)
  .filter(([slug]) => slug !== 'components')
  .map(([slug, data]) => `  ${slug}: { icon: "${CATEGORY_ICONS[slug] || '📁'}", name: "${data.name}" }`)
  .join(',\n')}
};

// Emojis that support skin tone modifiers
const skinToneSupportedEmojis = new Set(${JSON.stringify(skinToneArray)});

function supportsSkinTone(emoji) {
  return skinToneSupportedEmojis.has(emoji) || skinToneSupportedEmojis.has([...emoji][0]);
}

function applySkinTone(emoji, skinToneCode) {
  if (!skinToneCode) return emoji;
  const chars = [...emoji];
  if (chars.length === 0) return emoji;
  return chars[0] + skinToneCode + chars.slice(1).join('');
}

// Emoji data by category
// Format: { e: emoji, n: name, s?: skinToneSupport, v: emojiVersion }
const emojiData = {
${Object.entries(result.groups)
  .filter(([slug]) => slug !== 'components')
  .map(([slug, data]) => {
    const emojis = data.emojis.map(em => {
      const parts = [`e:"${em.e}"`, `n:"${em.n.replace(/"/g, '\\"')}"`];
      if (em.s) parts.push('s:1');
      return `{${parts.join(',')}}`;
    });
    return `  ${slug}: [\n    ${emojis.join(',\n    ')}\n  ]`;
  })
  .join(',\n')}
};
`;

  return js;
}

/**
 * Generate compact JSON
 */
function generateJSON(result) {
  const output = {
    version: result.version,
    date: result.date,
    stats: result.stats,
    skinToneSupported: Array.from(result.skinToneEmojis),
    categories: Object.entries(result.groups)
      .filter(([slug]) => slug !== 'components')
      .map(([slug, data]) => ({
        id: slug,
        name: data.name,
        icon: CATEGORY_ICONS[slug],
        count: data.emojis.length
      })),
    emojis: {}
  };
  
  for (const [slug, data] of Object.entries(result.groups)) {
    if (slug === 'components') continue;
    output.emojis[slug] = data.emojis.map(em => {
      const arr = [em.e, em.n];
      if (em.s) arr.push(1);
      return arr;
    });
  }
  
  return output;
}

// Main execution
async function main() {
  let content;
  
  // Check if file provided as argument
  if (process.argv[2]) {
    console.log(`Reading from file: ${process.argv[2]}`);
    content = fs.readFileSync(process.argv[2], 'utf8');
  } else {
    console.log(`Fetching from: ${EMOJI_TEST_URL}`);
    content = await new Promise((resolve, reject) => {
      https.get(EMOJI_TEST_URL, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve(data));
        res.on('error', reject);
      }).on('error', reject);
    });
  }
  
  console.log('Parsing emoji-test.txt...');
  let result = parseEmojiTestTxt(content);
  result = detectSkinToneSupport(content, result);
  
  console.log(`\n=== Unicode Emoji v${result.version} ===`);
  console.log(`Date: ${result.date}`);
  console.log(`Total emojis: ${result.stats.total}`);
  console.log(`Skin tone support: ${result.stats.withSkinTone}`);
  console.log('\nBy category:');
  for (const [slug, data] of Object.entries(result.groups)) {
    if (slug === 'components') continue;
    console.log(`  ${slug}: ${data.emojis.length}`);
  }
  
  // Generate outputs
  const js = generateJS(result);
  const json = generateJSON(result);
  
  fs.writeFileSync('emoji-data-v17.js', js);
  fs.writeFileSync('emoji-data-v17.json', JSON.stringify(json, null, 2));
  fs.writeFileSync('emoji-data-v17-compact.json', JSON.stringify(json));
  
  console.log('\nGenerated files:');
  console.log(`  emoji-data-v17.js (${(Buffer.byteLength(js) / 1024).toFixed(1)}KB)`);
  console.log(`  emoji-data-v17.json (formatted)`);
  console.log(`  emoji-data-v17-compact.json (${(Buffer.byteLength(JSON.stringify(json)) / 1024).toFixed(1)}KB)`);
}

// Run if called directly
if (require.main === module) {
  main().catch(console.error);
}

module.exports = { parseEmojiTestTxt, detectSkinToneSupport, generateJS, generateJSON };
