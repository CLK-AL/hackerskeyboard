#!/usr/bin/env node
/**
 * Generate Unicode emoji-test.txt compatible Hebrew Nikud data files
 * 
 * Format matches: https://www.unicode.org/Public/17.0.0/emoji/emoji-test.txt
 * 
 * CODEPOINTS                                             ; STATUS              # CHAR VERSION NAME
 */

const fs = require('fs');

// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW UNICODE DATA
// ═══════════════════════════════════════════════════════════════════════════════

const VOWELS = {
  'big-vowels': [
    { char: '\u05B7', code: '05B7', name: 'patach', ipa: 'a' },
    { char: '\u05B8', code: '05B8', name: 'kamatz', ipa: 'ɑ' },
    { char: '\u05B6', code: '05B6', name: 'segol', ipa: 'ɛ' },
    { char: '\u05B5', code: '05B5', name: 'tzere', ipa: 'e' },
    { char: '\u05B4', code: '05B4', name: 'chirik', ipa: 'i' },
    { char: '\u05B9', code: '05B9', name: 'cholam', ipa: 'o' },
    { char: '\u05BB', code: '05BB', name: 'kubutz', ipa: 'u' },
    { char: '\u05B0', code: '05B0', name: 'shva', ipa: 'ə' },
  ],
  'hataf-vowels': [
    { char: '\u05B2', code: '05B2', name: 'hataf-patach', ipa: 'ă' },
    { char: '\u05B1', code: '05B1', name: 'hataf-segol', ipa: 'ĕ' },
    { char: '\u05B3', code: '05B3', name: 'hataf-kamatz', ipa: 'ŏ' },
  ],
  'modifiers': [
    { char: '\u05BC', code: '05BC', name: 'dagesh', ipa: null },
    { char: '\u05C1', code: '05C1', name: 'shin-dot', ipa: null },
    { char: '\u05C2', code: '05C2', name: 'sin-dot', ipa: null },
    { char: '\u05BF', code: '05BF', name: 'rafe', ipa: null },
    { char: '\u05BD', code: '05BD', name: 'meteg', ipa: null },
  ],
};

const CONSONANTS = {
  'letters': [
    { char: 'א', code: '05D0', name: 'alef', ipa: 'ʔ' },
    { char: 'ב', code: '05D1', name: 'bet', ipa: 'v', dagesh_ipa: 'b' },
    { char: 'ג', code: '05D2', name: 'gimel', ipa: 'g' },
    { char: 'ד', code: '05D3', name: 'dalet', ipa: 'd' },
    { char: 'ה', code: '05D4', name: 'he', ipa: 'h' },
    { char: 'ו', code: '05D5', name: 'vav', ipa: 'v' },
    { char: 'ז', code: '05D6', name: 'zayin', ipa: 'z' },
    { char: 'ח', code: '05D7', name: 'chet', ipa: 'x' },
    { char: 'ט', code: '05D8', name: 'tet', ipa: 't' },
    { char: 'י', code: '05D9', name: 'yod', ipa: 'j' },
    { char: 'כ', code: '05DB', name: 'kaf', ipa: 'x', dagesh_ipa: 'k' },
    { char: 'ל', code: '05DC', name: 'lamed', ipa: 'l' },
    { char: 'מ', code: '05DE', name: 'mem', ipa: 'm' },
    { char: 'נ', code: '05E0', name: 'nun', ipa: 'n' },
    { char: 'ס', code: '05E1', name: 'samekh', ipa: 's' },
    { char: 'ע', code: '05E2', name: 'ayin', ipa: 'ʕ' },
    { char: 'פ', code: '05E4', name: 'pe', ipa: 'f', dagesh_ipa: 'p' },
    { char: 'צ', code: '05E6', name: 'tsadi', ipa: 'ts' },
    { char: 'ק', code: '05E7', name: 'qof', ipa: 'k' },
    { char: 'ר', code: '05E8', name: 'resh', ipa: 'ʁ' },
    { char: 'ש', code: '05E9', name: 'shin', ipa: 'ʃ', sin_ipa: 's' },
    { char: 'ת', code: '05EA', name: 'tav', ipa: 't' },
  ],
  'final-letters': [
    { char: 'ך', code: '05DA', name: 'final-kaf', ipa: 'x' },
    { char: 'ם', code: '05DD', name: 'final-mem', ipa: 'm' },
    { char: 'ן', code: '05DF', name: 'final-nun', ipa: 'n' },
    { char: 'ף', code: '05E3', name: 'final-pe', ipa: 'f' },
    { char: 'ץ', code: '05E5', name: 'final-tsadi', ipa: 'ts' },
  ],
};

const MALE = {
  'cholam-male': [
    { codes: ['05D5', '05B9'], name: 'cholam-male', ipa: 'o' },
  ],
  'shuruk': [
    { codes: ['05D5', '05BC'], name: 'shuruk', ipa: 'u' },
  ],
  'chirik-male': [
    { codes: ['05D9', '05B4'], name: 'chirik-male', ipa: 'i' },
  ],
  'tzere-male': [
    { codes: ['05D9', '05B5'], name: 'tzere-male', ipa: 'e' },
  ],
};

// Begedkefet letters that change with dagesh
const BEGEDKEFET = {
  '05D1': { without: 'v', with: 'b' },  // bet
  '05D2': { without: 'g', with: 'g' },  // gimel (same in modern)
  '05D3': { without: 'd', with: 'd' },  // dalet (same in modern)
  '05DB': { without: 'x', with: 'k' },  // kaf
  '05E4': { without: 'f', with: 'p' },  // pe
  '05EA': { without: 't', with: 't' },  // tav (same in modern)
};

// ═══════════════════════════════════════════════════════════════════════════════
// FORMATTING HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

function padCodepoints(codes, width = 50) {
  const str = codes.join(' ');
  return str.padEnd(width);
}

function padStatus(status, width = 20) {
  return ('; ' + status).padEnd(width);
}

function formatLine(codes, status, char, version, name) {
  const codesStr = padCodepoints(Array.isArray(codes) ? codes : [codes]);
  const statusStr = padStatus(status);
  return `${codesStr}${statusStr}# ${char} ${version} ${name}`;
}

function toCodepoints(str) {
  return [...str].map(c => c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'));
}

// ═══════════════════════════════════════════════════════════════════════════════
// GENERATE FILES
// ═══════════════════════════════════════════════════════════════════════════════

function generateVowelsFile() {
  const lines = [
    '# he-vowels.txt',
    '# Hebrew Vowel Points (Nikud) - Unicode Format',
    '# Version: 1.0',
    `# Date: ${new Date().toISOString().split('T')[0]}`,
    '#',
    '# Format: CODEPOINTS ; STATUS # CHAR VERSION NAME',
    '#',
    '',
    '# group: Vowels',
    '',
  ];

  for (const [subgroup, vowels] of Object.entries(VOWELS)) {
    lines.push(`# subgroup: ${subgroup}`);
    for (const v of vowels) {
      const ipaStr = v.ipa ? ` [${v.ipa}]` : '';
      lines.push(formatLine(v.code, 'component', v.char, 'H1.0', v.name + ipaStr));
    }
    lines.push('');
  }

  const stats = Object.values(VOWELS).flat().length;
  lines.push(`# Vowels subtotal:\t\t${stats}`);
  
  return lines.join('\n');
}

function generateConsonantsFile() {
  const lines = [
    '# he-consonants.txt',
    '# Hebrew Consonants - Unicode Format',
    '# Version: 1.0',
    `# Date: ${new Date().toISOString().split('T')[0]}`,
    '#',
    '# Format: CODEPOINTS ; STATUS # CHAR VERSION NAME',
    '#',
    '',
    '# group: Consonants',
    '',
  ];

  for (const [subgroup, consonants] of Object.entries(CONSONANTS)) {
    lines.push(`# subgroup: ${subgroup}`);
    for (const c of consonants) {
      const ipaStr = c.ipa ? ` [${c.ipa}]` : '';
      lines.push(formatLine(c.code, 'base', c.char, 'H1.0', c.name + ipaStr));
    }
    lines.push('');
  }

  const stats = Object.values(CONSONANTS).flat().length;
  lines.push(`# Consonants subtotal:\t\t${stats}`);
  
  return lines.join('\n');
}

function generateSyllablesFile() {
  const lines = [
    '# he-syllables.txt',
    '# Hebrew Syllables (Consonant + Vowel combinations) - Unicode Format',
    '# Version: 1.0',
    `# Date: ${new Date().toISOString().split('T')[0]}`,
    '#',
    '# Format: CODEPOINTS ; STATUS # CHAR VERSION NAME',
    '#',
    '# Skin tones are to emoji what nikud is to Hebrew:',
    '#   👋 + 🏻 = 👋🏻   (1F44B 1F3FB)',
    '#   ב + ַ = בַ     (05D1 05B7)',
    '#',
    '',
    '# group: Syllables',
    '',
  ];

  const vowelList = VOWELS['big-vowels'];
  const consonantList = CONSONANTS['letters'];
  let total = 0;
  
  // Generate for each consonant
  for (const cons of consonantList) {
    lines.push(`# subgroup: ${cons.name}-vowels`);
    
    // Base consonant
    lines.push(formatLine(cons.code, 'base', cons.char, 'H1.0', cons.name));
    
    // With dagesh (if begedkefet)
    const beged = BEGEDKEFET[cons.code];
    if (beged) {
      const charWithDagesh = cons.char + '\u05BC';
      const codes = [cons.code, '05BC'];
      const ipa = beged.with;
      lines.push(formatLine(codes, 'base', charWithDagesh, 'H1.0', `${cons.name}: dagesh [${ipa}]`));
    }
    
    // Consonant + each vowel
    for (const vowel of vowelList) {
      const charCV = cons.char + vowel.char;
      const codes = [cons.code, vowel.code];
      const ipa = (cons.ipa || '') + (vowel.ipa || '');
      lines.push(formatLine(codes, 'cv', charCV, 'H1.0', `${cons.name}: ${vowel.name} [${ipa}]`));
      total++;
      
      // With dagesh + vowel (if begedkefet)
      if (beged) {
        const charDV = cons.char + '\u05BC' + vowel.char;
        const codesDV = [cons.code, '05BC', vowel.code];
        const ipaDV = beged.with + (vowel.ipa || '');
        lines.push(formatLine(codesDV, 'cv', charDV, 'H1.0', `${cons.name}: dagesh ${vowel.name} [${ipaDV}]`));
        total++;
      }
    }
    lines.push('');
  }

  // Shin/Sin special handling
  lines.push('# subgroup: shin-sin-vowels');
  const shin = CONSONANTS['letters'].find(c => c.code === '05E9');
  
  // Shin with shin-dot
  lines.push(formatLine(['05E9', '05C1'], 'base', 'שׁ', 'H1.0', 'shin: shin-dot [ʃ]'));
  for (const vowel of vowelList) {
    const charShinV = 'ש' + '\u05C1' + vowel.char;
    const codes = ['05E9', '05C1', vowel.code];
    const ipa = 'ʃ' + (vowel.ipa || '');
    lines.push(formatLine(codes, 'cv', charShinV, 'H1.0', `shin: shin-dot ${vowel.name} [${ipa}]`));
    total++;
  }
  lines.push('');
  
  // Sin with sin-dot
  lines.push(formatLine(['05E9', '05C2'], 'base', 'שׂ', 'H1.0', 'sin: sin-dot [s]'));
  for (const vowel of vowelList) {
    const charSinV = 'ש' + '\u05C2' + vowel.char;
    const codes = ['05E9', '05C2', vowel.code];
    const ipa = 's' + (vowel.ipa || '');
    lines.push(formatLine(codes, 'cv', charSinV, 'H1.0', `sin: sin-dot ${vowel.name} [${ipa}]`));
    total++;
  }
  lines.push('');

  lines.push(`# Syllables subtotal:\t\t${total}`);
  lines.push(`# Syllables subtotal:\t\t${total}\tw/o modifiers`);
  
  return lines.join('\n');
}

function generateMaleFile() {
  const lines = [
    '# he-male.txt',
    '# Hebrew Matres Lectionis (Vowel Letters) - Unicode Format',
    '# Version: 1.0',
    `# Date: ${new Date().toISOString().split('T')[0]}`,
    '#',
    '# Format: CODEPOINTS ; STATUS # CHAR VERSION NAME',
    '#',
    '# Male vowels use letters (vav, yod) to indicate long vowels',
    '#',
    '',
    '# group: Matres Lectionis',
    '',
  ];

  let total = 0;
  
  for (const [subgroup, males] of Object.entries(MALE)) {
    lines.push(`# subgroup: ${subgroup}`);
    for (const m of males) {
      const char = m.codes.map(c => String.fromCodePoint(parseInt(c, 16))).join('');
      const ipaStr = m.ipa ? ` [${m.ipa}]` : '';
      lines.push(formatLine(m.codes, 'male', char, 'H1.0', m.name + ipaStr));
      total++;
    }
    lines.push('');
  }

  // Generate consonant + male combinations for bet as example
  lines.push('# subgroup: bet-male-examples');
  const bet = '05D1';
  const dagesh = '05BC';
  
  // בּוֹ (bet-dagesh + cholam-male)
  lines.push(formatLine([bet, dagesh, '05D5', '05B9'], 'cvc', 'בּוֹ', 'H1.0', 'bet: dagesh cholam-male [bo]'));
  // בּוּ (bet-dagesh + shuruk)  
  lines.push(formatLine([bet, dagesh, '05D5', '05BC'], 'cvc', 'בּוּ', 'H1.0', 'bet: dagesh shuruk [bu]'));
  // בִּי (bet-dagesh + chirik-male)
  lines.push(formatLine([bet, dagesh, '05B4', '05D9'], 'cvc', 'בִּי', 'H1.0', 'bet: dagesh chirik-male [bi]'));
  // בֵּי (bet-dagesh + tzere-male)
  lines.push(formatLine([bet, dagesh, '05B5', '05D9'], 'cvc', 'בֵּי', 'H1.0', 'bet: dagesh tzere-male [be]'));
  
  total += 4;
  lines.push('');

  lines.push(`# Matres Lectionis subtotal:\t\t${total}`);
  
  return lines.join('\n');
}

function generateHatafFile() {
  const lines = [
    '# he-hataf.txt',
    '# Hebrew Hataf Vowels (for gutturals) - Unicode Format',
    '# Version: 1.0',
    `# Date: ${new Date().toISOString().split('T')[0]}`,
    '#',
    '# Format: CODEPOINTS ; STATUS # CHAR VERSION NAME',
    '#',
    '# Hataf vowels are ultra-short vowels used with guttural letters:',
    '# א (alef), ה (he), ח (chet), ע (ayin)',
    '#',
    '',
    '# group: Hataf Vowels',
    '',
  ];

  const gutturals = [
    { char: 'א', code: '05D0', name: 'alef' },
    { char: 'ה', code: '05D4', name: 'he' },
    { char: 'ח', code: '05D7', name: 'chet' },
    { char: 'ע', code: '05E2', name: 'ayin' },
  ];
  
  const hatafVowels = VOWELS['hataf-vowels'];
  let total = 0;

  for (const guttural of gutturals) {
    lines.push(`# subgroup: ${guttural.name}-hataf`);
    
    for (const hataf of hatafVowels) {
      const char = guttural.char + hataf.char;
      const codes = [guttural.code, hataf.code];
      const ipaStr = hataf.ipa ? ` [${hataf.ipa}]` : '';
      lines.push(formatLine(codes, 'hataf', char, 'H1.0', `${guttural.name}: ${hataf.name}${ipaStr}`));
      total++;
    }
    lines.push('');
  }

  lines.push(`# Hataf subtotal:\t\t${total}`);
  
  return lines.join('\n');
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════════════════════

function main() {
  const outputDir = '/home/claude/hebrew-data';
  
  // Create output directory
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  // Generate files
  const files = [
    { name: 'he-vowels.txt', content: generateVowelsFile() },
    { name: 'he-consonants.txt', content: generateConsonantsFile() },
    { name: 'he-syllables.txt', content: generateSyllablesFile() },
    { name: 'he-male.txt', content: generateMaleFile() },
    { name: 'he-hataf.txt', content: generateHatafFile() },
  ];

  console.log('═══════════════════════════════════════════════════════════════════');
  console.log(' Hebrew Nikud Data Generator (Unicode emoji-test.txt format)');
  console.log('═══════════════════════════════════════════════════════════════════');
  console.log('');

  for (const file of files) {
    const path = `${outputDir}/${file.name}`;
    fs.writeFileSync(path, file.content);
    const lines = file.content.split('\n').filter(l => l && !l.startsWith('#')).length;
    console.log(`  ✓ ${file.name.padEnd(20)} (${lines} entries)`);
  }

  console.log('');
  console.log(`Output directory: ${outputDir}`);
  console.log('');
}

main();
