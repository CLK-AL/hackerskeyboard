#!/usr/bin/env node
/**
 * Optimized Unicode Emoji Data Generator
 * Creates compact inline-able data for React components
 */

const fs = require('fs');
const emojiByGroup = require('./node_modules/unicode-emoji-json/data-by-group.json');

const categoryMapping = {
  'Smileys & Emotion': 'smileys',
  'People & Body': 'people', 
  'Animals & Nature': 'animals',
  'Food & Drink': 'food',
  'Travel & Places': 'travel',
  'Activities': 'activities',
  'Objects': 'objects',
  'Symbols': 'symbols',
  'Flags': 'flags'
};

const skinToneModifiers = ['\u{1F3FB}', '\u{1F3FC}', '\u{1F3FD}', '\u{1F3FE}', '\u{1F3FF}'];
const skinToneSupportSet = new Set();
const emojiData = {};
let totalCount = 0;

emojiByGroup.forEach(group => {
  const cat = categoryMapping[group.name];
  if (!cat) return;
  
  if (!emojiData[cat]) emojiData[cat] = [];
  
  group.emojis.forEach(emoji => {
    // Skip skin tone variants
    if (skinToneModifiers.some(mod => emoji.emoji.includes(mod))) return;
    
    // Compact format: [emoji, name, hasSkinTone]
    emojiData[cat].push([emoji.emoji, emoji.name, emoji.skin_tone_support ? 1 : 0]);
    
    if (emoji.skin_tone_support) {
      skinToneSupportSet.add(emoji.emoji);
    }
    totalCount++;
  });
});

// Generate compact inline JavaScript
const skinToneArray = Array.from(skinToneSupportSet);

const compactJS = `// Unicode Emoji Data v16.0 - ${totalCount} emojis, ${skinToneArray.length} with skin tones
// Format: [emoji, name, hasSkinTone (0/1)]

const _st = new Set(${JSON.stringify(skinToneArray)});
const _ed = ${JSON.stringify(emojiData)};

// Convert to object format on first access
const emojiData = {};
Object.entries(_ed).forEach(([cat, arr]) => {
  emojiData[cat] = arr.map(([e, n, s]) => ({ e, n, s: !!s }));
});

const skinToneSupportedEmojis = _st;
`;

fs.writeFileSync('emoji-data-compact.js', compactJS);

// Also generate as pure JSON for external loading
fs.writeFileSync('emoji-data-compact.json', JSON.stringify({
  skinToneSupported: skinToneArray,
  emojis: emojiData
}));

console.log('Generated compact emoji data:');
console.log(`  Total: ${totalCount} emojis`);
console.log(`  Skin tone supported: ${skinToneArray.length}`);
console.log(`  File size: ${Buffer.byteLength(compactJS)} bytes`);

// Generate the full inline version for React
const fullInlineJS = `// Auto-generated Unicode Emoji Data v16.0
// Total: ${totalCount} emojis | Skin tone supported: ${skinToneArray.length}

const skinTones = [
  { code: "", label: "Default", color: "#FFCC4D" },
  { code: "\\u{1F3FB}", label: "Light", color: "#FFDAB8" },
  { code: "\\u{1F3FC}", label: "Medium-Light", color: "#E0BB95" },
  { code: "\\u{1F3FD}", label: "Medium", color: "#BF8F68" },
  { code: "\\u{1F3FE}", label: "Medium-Dark", color: "#9B643D" },
  { code: "\\u{1F3FF}", label: "Dark", color: "#594539" }
];

const emojiFontStack = "'Noto Color Emoji', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Android Emoji', sans-serif";

const emojiCategories = {
  recent: { icon: "🕐", name: "Recent" },
  smileys: { icon: "😀", name: "Smileys & Emotion" },
  people: { icon: "👋", name: "People & Body" },
  animals: { icon: "🐶", name: "Animals & Nature" },
  food: { icon: "🍎", name: "Food & Drink" },
  travel: { icon: "✈️", name: "Travel & Places" },
  activities: { icon: "⚽", name: "Activities" },
  objects: { icon: "💡", name: "Objects" },
  symbols: { icon: "❤️", name: "Symbols" },
  flags: { icon: "🏳️", name: "Flags" }
};

// Skin tone supported emojis set
const skinToneSupportedEmojis = new Set(${JSON.stringify(skinToneArray)});

function supportsSkinTone(emoji) {
  return skinToneSupportedEmojis.has(emoji) || skinToneSupportedEmojis.has([...emoji][0]);
}

function applySkinTone(emoji, skinToneCode) {
  if (!skinToneCode) return emoji;
  const chars = [...emoji];
  if (chars.length === 0) return emoji;
  return chars[0] + skinToneCode + chars.slice(1).join('');
}

// Emoji data - Format: { e: emoji, n: name, s: skinToneSupport }
const emojiData = {
${Object.entries(emojiData).map(([cat, emojis]) => 
  `  ${cat}: [\n    ${emojis.map(([e, n, s]) => `{e:"${e}",n:"${n.replace(/"/g, '\\"')}"${s ? ',s:1' : ''}}`).join(',\n    ')}\n  ]`
).join(',\n')}
};
`;

fs.writeFileSync('emoji-data-inline.js', fullInlineJS);
console.log(`  Inline JS size: ${Buffer.byteLength(fullInlineJS)} bytes (${Math.round(Buffer.byteLength(fullInlineJS)/1024)}KB)`);
