import React, { useState, useRef, useEffect, useCallback } from "react";

const ExternalScripts = () => (
  <>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Rubik+Mono+One&family=Rubik+Burned&family=Rubik+Bubbles&family=Rubik+Glitch&family=Rubik+Vinyl&family=Rubik+Wet+Paint&family=Rubik+Marker+Hatch&family=Rubik+Iso&family=Rubik+Distressed&family=Rubik+Broken+Fax&family=Rubik+Doodle+Shadow&family=Rubik+Spray+Paint&family=Rubik+Storm&family=Rubik+Pixels&family=Rubik+Gemstones&family=Rubik+Puddles&family=Rubik+Maze&family=Rubik+Microbe&family=Rubik+Glitch+Pop&family=Rubik+Maps&family=Rubik+Lines&family=Rubik+Scribble&family=Rubik+80s+Fade&family=Noto+Color+Emoji&display=swap" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/ace.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/mode-html.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/mode-markdown.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/theme-tomorrow_night.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/marked/11.1.1/marked.min.js"></script>
  </>
);

const layouts = {
  hebrew: {
    qwerty: {
      default: {
        function: ["{esc}", "{f1} {f2} {f3} {f4}", "{f5} {f6} {f7} {f8}", "{f9} {f10} {f11} {f12}", "{prtsc} {scrlk} {pause}"],
        main: [
          "{bksp} = - 0 9 8 7 6 5 4 3 2 1 ;",
          "\\ [ ] פ ם ן ו ט א ר ק ' / {tab}",
          "{enter} , ף ך ל ח י ע כ ג ד ש {caps}",
          "{shiftr} . ץ ת צ מ נ ה ב ס ז \\ {shiftl}",
          "{ctrlr} {menu} {winr} {altr} {space} {altl} {winl} {ctrll}"
        ],
        nav: ["{ins} {home} {pgup}", "{del} {end} {pgdn}", "", "{up}", "{left} {down} {right}"],
        numpad: ["{numlock} {numdiv} {nummult} {numsub}", "{num7} {num8} {num9} {numadd}", "{num4} {num5} {num6}", "{num1} {num2} {num3} {numenter}", "{num0} {numdec}"]
      }
    }
  },
  english: {
    qwerty: {
      default: {
        function: ["{esc}", "{f1} {f2} {f3} {f4}", "{f5} {f6} {f7} {f8}", "{f9} {f10} {f11} {f12}", "{prtsc} {scrlk} {pause}"],
        main: [
          "` 1 2 3 4 5 6 7 8 9 0 - = {bksp}",
          "{tab} q w e r t y u i o p [ ] \\",
          "{caps} a s d f g h j k l ; ' {enter}",
          "{shiftl} z x c v b n m , . / {shiftr}",
          "{ctrll} {winl} {altl} {space} {altr} {winr} {menu} {ctrlr}"
        ],
        nav: ["{ins} {home} {pgup}", "{del} {end} {pgdn}", "", "{up}", "{left} {down} {right}"],
        numpad: ["{numlock} {numdiv} {nummult} {numsub}", "{num7} {num8} {num9} {numadd}", "{num4} {num5} {num6}", "{num1} {num2} {num3} {numenter}", "{num0} {numdec}"]
      }
    }
  }
};

const hebrewLetters = "אבגדהוזחטיכךלמםנןסעפףצץקרשת";

const nikudMarks = [
  { name: "שווא", mark: "\u05B0", cat: "vowel" },
  { name: "חטף סגול", mark: "\u05B1", cat: "vowel" },
  { name: "חטף פתח", mark: "\u05B2", cat: "vowel" },
  { name: "חטף קמץ", mark: "\u05B3", cat: "vowel" },
  { name: "חיריק", mark: "\u05B4", cat: "vowel" },
  { name: "צירה", mark: "\u05B5", cat: "vowel" },
  { name: "סגול", mark: "\u05B6", cat: "vowel" },
  { name: "פתח", mark: "\u05B7", cat: "vowel" },
  { name: "קמץ", mark: "\u05B8", cat: "vowel" },
  { name: "חולם", mark: "\u05B9", cat: "vowel" },
  { name: "חולם חסר", mark: "\u05BA", cat: "vowel" },
  { name: "קובוץ", mark: "\u05BB", cat: "vowel" },
  { name: "דגש/מפיק", mark: "\u05BC", cat: "accent" },
  { name: "מטג", mark: "\u05BD", cat: "accent" },
  { name: "מקף", mark: "\u05BE", cat: "punct" },
  { name: "רפה", mark: "\u05BF", cat: "accent" },
  { name: "פסק", mark: "\u05C0", cat: "punct" },
  { name: "שין ימנית", mark: "\u05C1", cat: "accent" },
  { name: "שין שמאלית", mark: "\u05C2", cat: "accent" },
  { name: "סוף פסוק", mark: "\u05C3", cat: "punct" },
  { name: "נקודה עליונה", mark: "\u05C4", cat: "accent" },
  { name: "נקודה תחתונה", mark: "\u05C5", cat: "accent" },
  { name: "נון הפוכה", mark: "\u05C6", cat: "punct" },
  { name: "קמץ קטן", mark: "\u05C7", cat: "vowel" },
];

const teamim = [
  { name: "אתנח", mark: "\u0591", cat: "common" },
  { name: "סגול", mark: "\u0592", cat: "emet" },
  { name: "שלשלת", mark: "\u0593", cat: "common" },
  { name: "זקף קטן", mark: "\u0594", cat: "prose" },
  { name: "זקף גדול", mark: "\u0595", cat: "prose" },
  { name: "טפחא", mark: "\u0596", cat: "common" },
  { name: "רביע", mark: "\u0597", cat: "prose" },
  { name: "צינור", mark: "\u0598", cat: "emet" },
  { name: "פשטא", mark: "\u0599", cat: "common" },
  { name: "ירח בן יומו", mark: "\u05AA", cat: "common" },
  { name: "עולה", mark: "\u05AB", cat: "emet" },
  { name: "עילוי", mark: "\u05AC", cat: "emet" },
  { name: "דחי", mark: "\u05AD", cat: "emet" },
  { name: "צנית", mark: "\u05AE", cat: "emet" },
  { name: "ספרא", mark: "\u05AF", cat: "common" },
  { name: "זרקא", mark: "\u059B", cat: "prose" },
  { name: "גרש", mark: "\u059C", cat: "prose" },
  { name: "קרני פרה", mark: "\u059D", cat: "prose" },
  { name: "גרשיים", mark: "\u059E", cat: "prose" },
  { name: "פזר", mark: "\u059F", cat: "prose" },
  { name: "תליש גדולה", mark: "\u05A0", cat: "prose" },
  { name: "סגולתא", mark: "\u05A1", cat: "prose" },
  { name: "מונח", mark: "\u05A3", cat: "common" },
  { name: "מהפך", mark: "\u05A4", cat: "common" },
  { name: "מרכא", mark: "\u05A5", cat: "common" },
  { name: "מרכא כפולה", mark: "\u05A6", cat: "prose" },
  { name: "דרגא", mark: "\u05A7", cat: "prose" },
  { name: "קדמא", mark: "\u05A8", cat: "common" },
  { name: "תביר", mark: "\u05A9", cat: "prose" },
];

const hebrewNikudContexts = {
  "א": ["אָ", "אַ", "אֲ", "אֵ", "אֶ", "אִ", "אֹ", "אֻ", "אְ", "אֱ", "אֳ", "אּ"],
  "ב": ["בָ", "בַ", "בֶ", "בֵ", "בִ", "בֹ", "בֻ", "בּ", "בְ", "בֲ", "בֳ", "בֿ"],
  "ג": ["גָ", "גַ", "גֶ", "גֵ", "גִ", "גֹ", "גֻ", "גּ", "גְ", "גֲ", "גֳ", "גֿ"],
  "ד": ["דָ", "דַ", "דֶ", "דֵ", "דִ", "דֹ", "דֻ", "דּ", "דְ", "דֲ", "דֳ", "דֿ"],
  "ה": ["הָ", "הַ", "הֶ", "הֵ", "הִ", "הֹ", "הֻ", "הּ", "הְ", "הֲ", "הֳ", "הֿ"],
  "ו": ["וֹ", "וּ", "וָ", "וַ", "וֶ", "וֵ", "וִ", "וְ", "וֻ", "וֲ", "וֳ", "וֿ"],
  "ז": ["זָ", "זַ", "זֶ", "זֵ", "זִ", "זֹ", "זֻ", "זּ", "זְ", "זֲ", "זֳ", "זֿ"],
  "ח": ["חָ", "חַ", "חֶ", "חֵ", "חִ", "חֹ", "חֻ", "חְ", "חֲ", "חֳ", "חֱ"],
  "ט": ["טָ", "טַ", "טֶ", "טֵ", "טִ", "טֹ", "טֻ", "טּ", "טְ", "טֲ", "טֳ"],
  "י": ["יָ", "יַ", "יֶ", "יֵ", "יִ", "יֹ", "יֻ", "יּ", "יְ", "יֲ", "יֳ"],
  "כ": ["כָ", "כַ", "כֶ", "כֵ", "כִ", "כֹ", "כֻ", "כּ", "כְ", "כֲ", "כֳ", "כֿ"],
  "ך": ["ךָ", "ךַ", "ךֶ", "ךֵ", "ךְ", "ךּ", "ךֿ"],
  "ל": ["לָ", "לַ", "לֶ", "לֵ", "לִ", "לֹ", "לֻ", "לּ", "לְ", "לֲ", "לֳ"],
  "מ": ["מָ", "מַ", "מֶ", "מֵ", "מִ", "מֹ", "מֻ", "מּ", "מְ", "מֲ", "מֳ"],
  "ם": ["םָ", "םַ", "םֶ", "םּ"],
  "נ": ["נָ", "נַ", "נֶ", "נֵ", "נִ", "נֹ", "נֻ", "נּ", "נְ", "נֲ", "נֳ"],
  "ן": ["ןָ", "ןַ", "ןֶ", "ןּ"],
  "ס": ["סָ", "סַ", "סֶ", "סֵ", "סִ", "סֹ", "סֻ", "סּ", "סְ", "סֲ", "סֳ"],
  "ע": ["עָ", "עַ", "עֶ", "עֵ", "עִ", "עֹ", "עֻ", "עְ", "עֲ", "עֳ", "עֱ"],
  "פ": ["פָ", "פַ", "פֶ", "פֵ", "פִ", "פֹ", "פֻ", "פּ", "פְ", "פֲ", "פֳ", "פֿ"],
  "ף": ["ףָ", "ףַ", "ףּ", "ףֿ"],
  "צ": ["צָ", "צַ", "צֶ", "צֵ", "צִ", "צֹ", "צֻ", "צּ", "צְ", "צֲ", "צֳ"],
  "ץ": ["ץָ", "ץַ", "ץּ"],
  "ק": ["קָ", "קַ", "קֶ", "קֵ", "קִ", "קֹ", "קֻ", "קּ", "קְ", "קֲ", "קֳ"],
  "ר": ["רָ", "רַ", "רֶ", "רֵ", "רִ", "רֹ", "רֻ", "רְ", "רֲ", "רֳ", "רֱ"],
  "ש": ["שָׁ", "שַׁ", "שֶׁ", "שֵׁ", "שִׁ", "שׁ", "שָׂ", "שַׂ", "שֶׂ", "שֵׂ", "שִׂ", "שׂ", "שּׁ", "שּׂ", "שְׁ", "שְׂ"],
  "ת": ["תָ", "תַ", "תֶ", "תֵ", "תִ", "תֹ", "תֻ", "תּ", "תְ", "תֲ", "תֳ"],
};

const display = {
  "{bksp}": "⌫", "{enter}": "↵", "{shiftl}": "⇧", "{shiftr}": "⇧", "{tab}": "⇥", "{caps}": "⇪",
  "{space}": " ", "{ctrll}": "Ctrl", "{ctrlr}": "Ctrl", "{altl}": "Alt", "{altr}": "AltGr",
  "{winl}": "⊞", "{winr}": "⊞", "{menu}": "☰", "{esc}": "Esc",
  "{f1}": "F1", "{f2}": "F2", "{f3}": "F3", "{f4}": "F4", "{f5}": "F5", "{f6}": "F6",
  "{f7}": "F7", "{f8}": "F8", "{f9}": "F9", "{f10}": "F10", "{f11}": "F11", "{f12}": "F12",
  "{prtsc}": "Prt", "{scrlk}": "Scr", "{pause}": "Pse", "{ins}": "Ins", "{home}": "Hm",
  "{pgup}": "PU", "{del}": "Del", "{end}": "End", "{pgdn}": "PD",
  "{up}": "▲", "{down}": "▼", "{left}": "◀", "{right}": "▶",
  "{numlock}": "Num", "{numdiv}": "/", "{nummult}": "*", "{numsub}": "-",
  "{numadd}": "+", "{numenter}": "↵", "{numdec}": ".",
  "{num0}": "0", "{num1}": "1", "{num2}": "2", "{num3}": "3",
  "{num4}": "4", "{num5}": "5", "{num6}": "6", "{num7}": "7", "{num8}": "8", "{num9}": "9"
};

const fontFamilies = [
  { value: "'Heebo', sans-serif", label: "Heebo" },
  { value: "'Rubik', sans-serif", label: "Rubik" },
  { value: "'Rubik Mono One', sans-serif", label: "Rubik Mono One" },
  { value: "'Rubik Burned', system-ui", label: "Rubik Burned" },
  { value: "'Rubik Bubbles', system-ui", label: "Rubik Bubbles" },
  { value: "'Rubik Glitch', system-ui", label: "Rubik Glitch" },
  { value: "'Rubik Vinyl', system-ui", label: "Rubik Vinyl" },
  { value: "'Rubik Wet Paint', system-ui", label: "Rubik Wet Paint" },
  { value: "'Rubik Pixels', system-ui", label: "Rubik Pixels" },
  { value: "'Rubik Storm', system-ui", label: "Rubik Storm" },
  { value: "'Rubik Spray Paint', system-ui", label: "Rubik Spray Paint" },
  { value: "'Rubik 80s Fade', system-ui", label: "Rubik 80s Fade" },
  { value: "'Rubik Glitch Pop', system-ui", label: "Rubik Glitch Pop" },
  { value: "'Rubik Maze', system-ui", label: "Rubik Maze" },
  { value: "'Rubik Scribble', system-ui", label: "Rubik Scribble" },
  { value: "Arial, sans-serif", label: "Arial" },
  { value: "Times New Roman, serif", label: "Times New Roman" },
  { value: "Georgia, serif", label: "Georgia" },
  { value: "Courier New, monospace", label: "Courier New" },
  { value: "Verdana, sans-serif", label: "Verdana" },
  { value: "Impact, sans-serif", label: "Impact" },
];

const editorFontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 32, 36, 40, 48, 54, 60, 72, 80, 96, 120];

const colors = [
  "#000000", "#434343", "#666666", "#999999", "#b7b7b7", "#cccccc", "#d9d9d9", "#efefef", "#f3f3f3", "#ffffff",
  "#980000", "#ff0000", "#ff9900", "#ffff00", "#00ff00", "#00ffff", "#4a86e8", "#0000ff", "#9900ff", "#ff00ff",
  "#e6b8af", "#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#c9daf8", "#cfe2f3", "#d9d2e9", "#ead1dc",
  "#dd7e6b", "#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#a4c2f4", "#9fc5e8", "#b4a7d6", "#d5a6bd",
];

// Skin tone modifiers (Fitzpatrick scale)
const skinTones = [
  { code: "", label: "Default", color: "#FFCC4D" },
  { code: "\u{1F3FB}", label: "Light", color: "#FFDAB8" },
  { code: "\u{1F3FC}", label: "Medium-Light", color: "#E0BB95" },
  { code: "\u{1F3FD}", label: "Medium", color: "#BF8F68" },
  { code: "\u{1F3FE}", label: "Medium-Dark", color: "#9B643D" },
  { code: "\u{1F3FF}", label: "Dark", color: "#594539" }
];

const emojiFontStack = "'Noto Color Emoji', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Android Emoji', sans-serif";

const emojiCategories = {
  recent: { icon: "🕐", name: "Recent" },
  smileys: { icon: "😀", name: "Smileys & Emotion" },
  people: { icon: "👋", name: "People & Body" },
  animals: { icon: "🐶", name: "Animals & Nature" },
  food: { icon: "🍎", name: "Food & Drink" },
  travel: { icon: "✈️", name: "Travel & Places" },
  activities: { icon: "⚽", name: "Activities" },
  objects: { icon: "💡", name: "Objects" },
  symbols: { icon: "❤️", name: "Symbols" },
  flags: { icon: "🏳️", name: "Flags" }
};

// Skin tone supported emojis set
const skinToneSupportedEmojis = new Set(["👋","🤚","🖐️","✋","🖖","🫱","🫲","🫳","🫴","🫷","🫸","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","🖕","👇","☝️","🫵","👍","👎","✊","👊","🤛","🤜","👏","🙌","🫶","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦵","🦶","👂","🦻","👃","👶","🧒","👦","👧","🧑","👱","👨","🧔","🧔‍♂️","🧔‍♀️","👨‍🦰","👨‍🦱","👨‍🦳","👨‍🦲","👩","👩‍🦰","🧑‍🦰","👩‍🦱","🧑‍🦱","👩‍🦳","🧑‍🦳","👩‍🦲","🧑‍🦲","👱‍♀️","👱‍♂️","🧓","👴","👵","🙍","🙍‍♂️","🙍‍♀️","🙎","🙎‍♂️","🙎‍♀️","🙅","🙅‍♂️","🙅‍♀️","🙆","🙆‍♂️","🙆‍♀️","💁","💁‍♂️","💁‍♀️","🙋","🙋‍♂️","🙋‍♀️","🧏","🧏‍♂️","🧏‍♀️","🙇","🙇‍♂️","🙇‍♀️","🤦","🤦‍♂️","🤦‍♀️","🤷","🤷‍♂️","🤷‍♀️","🧑‍⚕️","👨‍⚕️","👩‍⚕️","🧑‍🎓","👨‍🎓","👩‍🎓","🧑‍🏫","👨‍🏫","👩‍🏫","🧑‍⚖️","👨‍⚖️","👩‍⚖️","🧑‍🌾","👨‍🌾","👩‍🌾","🧑‍🍳","👨‍🍳","👩‍🍳","🧑‍🔧","👨‍🔧","👩‍🔧","🧑‍🏭","👨‍🏭","👩‍🏭","🧑‍💼","👨‍💼","👩‍💼","🧑‍🔬","👨‍🔬","👩‍🔬","🧑‍💻","👨‍💻","👩‍💻","🧑‍🎤","👨‍🎤","👩‍🎤","🧑‍🎨","👨‍🎨","👩‍🎨","🧑‍✈️","👨‍✈️","👩‍✈️","🧑‍🚀","👨‍🚀","👩‍🚀","🧑‍🚒","👨‍🚒","👩‍🚒","👮","👮‍♂️","👮‍♀️","🕵️","🕵️‍♂️","🕵️‍♀️","💂","💂‍♂️","💂‍♀️","🥷","👷","👷‍♂️","👷‍♀️","🫅","🤴","👸","👳","👳‍♂️","👳‍♀️","👲","🧕","🤵","🤵‍♂️","🤵‍♀️","👰","👰‍♂️","👰‍♀️","🤰","🫃","🫄","🤱","👩‍🍼","👨‍🍼","🧑‍🍼","👼","🎅","🤶","🧑‍🎄","🦸","🦸‍♂️","🦸‍♀️","🦹","🦹‍♂️","🦹‍♀️","🧙","🧙‍♂️","🧙‍♀️","🧚","🧚‍♂️","🧚‍♀️","🧛","🧛‍♂️","🧛‍♀️","🧜","🧜‍♂️","🧜‍♀️","🧝","🧝‍♂️","🧝‍♀️","💆","💆‍♂️","💆‍♀️","💇","💇‍♂️","💇‍♀️","🚶","🚶‍♂️","🚶‍♀️","🚶‍➡️","🚶‍♀️‍➡️","🚶‍♂️‍➡️","🧍","🧍‍♂️","🧍‍♀️","🧎","🧎‍♂️","🧎‍♀️","🧎‍➡️","🧎‍♀️‍➡️","🧎‍♂️‍➡️","🧑‍🦯","🧑‍🦯‍➡️","👨‍🦯","👨‍🦯‍➡️","👩‍🦯","👩‍🦯‍➡️","🧑‍🦼","🧑‍🦼‍➡️","👨‍🦼","👨‍🦼‍➡️","👩‍🦼","👩‍🦼‍➡️","🧑‍🦽","🧑‍🦽‍➡️","👨‍🦽","👨‍🦽‍➡️","👩‍🦽","👩‍🦽‍➡️","🏃","🏃‍♂️","🏃‍♀️","🏃‍➡️","🏃‍♀️‍➡️","🏃‍♂️‍➡️","💃","🕺","🕴️","🧖","🧖‍♂️","🧖‍♀️","🧗","🧗‍♂️","🧗‍♀️","🏇","🏂","🏌️","🏌️‍♂️","🏌️‍♀️","🏄","🏄‍♂️","🏄‍♀️","🚣","🚣‍♂️","🚣‍♀️","🏊","🏊‍♂️","🏊‍♀️","⛹️","⛹️‍♂️","⛹️‍♀️","🏋️","🏋️‍♂️","🏋️‍♀️","🚴","🚴‍♂️","🚴‍♀️","🚵","🚵‍♂️","🚵‍♀️","🤸","🤸‍♂️","🤸‍♀️","🤽","🤽‍♂️","🤽‍♀️","🤾","🤾‍♂️","🤾‍♀️","🤹","🤹‍♂️","🤹‍♀️","🧘","🧘‍♂️","🧘‍♀️","🛀","🛌","🧑‍🤝‍🧑","👭","👫","👬","💏","👩‍❤️‍💋‍👨","👨‍❤️‍💋‍👨","👩‍❤️‍💋‍👩","💑","👩‍❤️‍👨","👨‍❤️‍👨","👩‍❤️‍👩"]);

function supportsSkinTone(emoji) {
  return skinToneSupportedEmojis.has(emoji) || skinToneSupportedEmojis.has([...emoji][0]);
}

function applySkinTone(emoji, skinToneCode) {
  if (!skinToneCode) return emoji;
  const chars = [...emoji];
  if (chars.length === 0) return emoji;
  return chars[0] + skinToneCode + chars.slice(1).join('');
}

// Emoji data - Format: { e: emoji, n: name, s: skinToneSupport }
const emojiData = {
  smileys: [
    {e:"😀",n:"grinning face"},
    {e:"😃",n:"grinning face with big eyes"},
    {e:"😁",n:"beaming face with smiling eyes"},
    {e:"😆",n:"grinning squinting face"},
    {e:"😅",n:"grinning face with sweat"},
    {e:"🤣",n:"rolling on the floor laughing"},
    {e:"😂",n:"face with tears of joy"},
    {e:"🙂",n:"slightly smiling face"},
    {e:"🙃",n:"upside-down face"},
    {e:"🫠",n:"melting face"},
    {e:"😉",n:"winking face"},
    {e:"😊",n:"smiling face with smiling eyes"},
    {e:"😇",n:"smiling face with halo"},
    {e:"🥰",n:"smiling face with hearts"},
    {e:"😍",n:"smiling face with heart-eyes"},
    {e:"🤩",n:"star-struck"},
    {e:"😘",n:"face blowing a kiss"},
    {e:"😗",n:"kissing face"},
    {e:"☺️",n:"smiling face"},
    {e:"😚",n:"kissing face with closed eyes"},
    {e:"😙",n:"kissing face with smiling eyes"},
    {e:"🥲",n:"smiling face with tear"},
    {e:"😋",n:"face savoring food"},
    {e:"😛",n:"face with tongue"},
    {e:"😜",n:"winking face with tongue"},
    {e:"🤪",n:"zany face"},
    {e:"😝",n:"squinting face with tongue"},
    {e:"🤑",n:"money-mouth face"},
    {e:"🤗",n:"smiling face with open hands"},
    {e:"🤭",n:"face with hand over mouth"},
    {e:"🫢",n:"face with open eyes and hand over mouth"},
    {e:"🫣",n:"face with peeking eye"},
    {e:"🤫",n:"shushing face"},
    {e:"🤔",n:"thinking face"},
    {e:"🫡",n:"saluting face"},
    {e:"🤐",n:"zipper-mouth face"},
    {e:"🤨",n:"face with raised eyebrow"},
    {e:"😐",n:"neutral face"},
    {e:"😑",n:"expressionless face"},
    {e:"😶",n:"face without mouth"},
    {e:"🫥",n:"dotted line face"},
    {e:"😶‍🌫️",n:"face in clouds"},
    {e:"😏",n:"smirking face"},
    {e:"😒",n:"unamused face"},
    {e:"🙄",n:"face with rolling eyes"},
    {e:"😬",n:"grimacing face"},
    {e:"😮‍💨",n:"face exhaling"},
    {e:"🤥",n:"lying face"},
    {e:"🫨",n:"shaking face"},
    {e:"🙂‍↔️",n:"head shaking horizontally"},
    {e:"🙂‍↕️",n:"head shaking vertically"},
    {e:"😌",n:"relieved face"},
    {e:"😔",n:"pensive face"},
    {e:"😪",n:"sleepy face"},
    {e:"🤤",n:"drooling face"},
    {e:"😴",n:"sleeping face"},
    {e:"🫩",n:"face with bags under eyes"},
    {e:"😷",n:"face with medical mask"},
    {e:"🤒",n:"face with thermometer"},
    {e:"🤕",n:"face with head-bandage"},
    {e:"🤢",n:"nauseated face"},
    {e:"🤮",n:"face vomiting"},
    {e:"🤧",n:"sneezing face"},
    {e:"🥵",n:"hot face"},
    {e:"🥶",n:"cold face"},
    {e:"🥴",n:"woozy face"},
    {e:"😵",n:"face with crossed-out eyes"},
    {e:"😵‍💫",n:"face with spiral eyes"},
    {e:"🤯",n:"exploding head"},
    {e:"🤠",n:"cowboy hat face"},
    {e:"🥳",n:"partying face"},
    {e:"🥸",n:"disguised face"},
    {e:"😎",n:"smiling face with sunglasses"},
    {e:"🤓",n:"nerd face"},
    {e:"🧐",n:"face with monocle"},
    {e:"😕",n:"confused face"},
    {e:"🫤",n:"face with diagonal mouth"},
    {e:"😟",n:"worried face"},
    {e:"🙁",n:"slightly frowning face"},
    {e:"☹️",n:"frowning face"},
    {e:"😮",n:"face with open mouth"},
    {e:"😯",n:"hushed face"},
    {e:"😲",n:"astonished face"},
    {e:"😳",n:"flushed face"},
    {e:"🥺",n:"pleading face"},
    {e:"🥹",n:"face holding back tears"},
    {e:"😦",n:"frowning face with open mouth"},
    {e:"😧",n:"anguished face"},
    {e:"😨",n:"fearful face"},
    {e:"😰",n:"anxious face with sweat"},
    {e:"😥",n:"sad but relieved face"},
    {e:"😢",n:"crying face"},
    {e:"😭",n:"loudly crying face"},
    {e:"😱",n:"face screaming in fear"},
    {e:"😖",n:"confounded face"},
    {e:"😣",n:"persevering face"},
    {e:"😞",n:"disappointed face"},
    {e:"😓",n:"downcast face with sweat"},
    {e:"😩",n:"weary face"},
    {e:"😫",n:"tired face"},
    {e:"🥱",n:"yawning face"},
    {e:"😤",n:"face with steam from nose"},
    {e:"😡",n:"enraged face"},
    {e:"😠",n:"angry face"},
    {e:"🤬",n:"face with symbols on mouth"},
    {e:"😈",n:"smiling face with horns"},
    {e:"👿",n:"angry face with horns"},
    {e:"💀",n:"skull"},
    {e:"☠️",n:"skull and crossbones"},
    {e:"💩",n:"pile of poo"},
    {e:"🤡",n:"clown face"},
    {e:"👹",n:"ogre"},
    {e:"👺",n:"goblin"},
    {e:"👻",n:"ghost"},
    {e:"👽",n:"alien"},
    {e:"👾",n:"alien monster"},
    {e:"🤖",n:"robot"},
    {e:"😺",n:"grinning cat"},
    {e:"😸",n:"grinning cat with smiling eyes"},
    {e:"😹",n:"cat with tears of joy"},
    {e:"😻",n:"smiling cat with heart-eyes"},
    {e:"😼",n:"cat with wry smile"},
    {e:"😽",n:"kissing cat"},
    {e:"🙀",n:"weary cat"},
    {e:"😿",n:"crying cat"},
    {e:"😾",n:"pouting cat"},
    {e:"🙈",n:"see-no-evil monkey"},
    {e:"🙉",n:"hear-no-evil monkey"},
    {e:"🙊",n:"speak-no-evil monkey"},
    {e:"💌",n:"love letter"},
    {e:"💘",n:"heart with arrow"},
    {e:"💝",n:"heart with ribbon"},
    {e:"💖",n:"sparkling heart"},
    {e:"💗",n:"growing heart"},
    {e:"💓",n:"beating heart"},
    {e:"💞",n:"revolving hearts"},
    {e:"💕",n:"two hearts"},
    {e:"💟",n:"heart decoration"},
    {e:"❣️",n:"heart exclamation"},
    {e:"💔",n:"broken heart"},
    {e:"❤️‍🔥",n:"heart on fire"},
    {e:"❤️‍🩹",n:"mending heart"},
    {e:"❤️",n:"red heart"},
    {e:"🩷",n:"pink heart"},
    {e:"🧡",n:"orange heart"},
    {e:"💛",n:"yellow heart"},
    {e:"💚",n:"green heart"},
    {e:"💙",n:"blue heart"},
    {e:"🩵",n:"light blue heart"},
    {e:"💜",n:"purple heart"},
    {e:"🤎",n:"brown heart"},
    {e:"🖤",n:"black heart"},
    {e:"🩶",n:"grey heart"},
    {e:"🤍",n:"white heart"},
    {e:"💋",n:"kiss mark"},
    {e:"💯",n:"hundred points"},
    {e:"💢",n:"anger symbol"},
    {e:"💥",n:"collision"},
    {e:"💫",n:"dizzy"},
    {e:"💦",n:"sweat droplets"},
    {e:"💨",n:"dashing away"},
    {e:"🕳️",n:"hole"},
    {e:"💬",n:"speech balloon"},
    {e:"👁️‍🗨️",n:"eye in speech bubble"},
    {e:"🗨️",n:"left speech bubble"},
    {e:"🗯️",n:"right anger bubble"},
    {e:"💭",n:"thought balloon"},
    {e:"💤",n:"ZZZ"}
  ],
  people: [
    {e:"👋",n:"waving hand",s:1},
    {e:"🤚",n:"raised back of hand",s:1},
    {e:"🖐️",n:"hand with fingers splayed",s:1},
    {e:"✋",n:"raised hand",s:1},
    {e:"🖖",n:"vulcan salute",s:1},
    {e:"🫱",n:"rightwards hand",s:1},
    {e:"🫲",n:"leftwards hand",s:1},
    {e:"🫳",n:"palm down hand",s:1},
    {e:"🫴",n:"palm up hand",s:1},
    {e:"🫷",n:"leftwards pushing hand",s:1},
    {e:"🫸",n:"rightwards pushing hand",s:1},
    {e:"👌",n:"OK hand",s:1},
    {e:"🤌",n:"pinched fingers",s:1},
    {e:"🤏",n:"pinching hand",s:1},
    {e:"✌️",n:"victory hand",s:1},
    {e:"🤞",n:"crossed fingers",s:1},
    {e:"🫰",n:"hand with index finger and thumb crossed",s:1},
    {e:"🤟",n:"love-you gesture",s:1},
    {e:"🤘",n:"sign of the horns",s:1},
    {e:"🤙",n:"call me hand",s:1},
    {e:"👈",n:"backhand index pointing left",s:1},
    {e:"👉",n:"backhand index pointing right",s:1},
    {e:"👆",n:"backhand index pointing up",s:1},
    {e:"🖕",n:"middle finger",s:1},
    {e:"👇",n:"backhand index pointing down",s:1},
    {e:"☝️",n:"index pointing up",s:1},
    {e:"🫵",n:"index pointing at the viewer",s:1},
    {e:"👍",n:"thumbs up",s:1},
    {e:"👎",n:"thumbs down",s:1},
    {e:"✊",n:"raised fist",s:1},
    {e:"👊",n:"oncoming fist",s:1},
    {e:"🤛",n:"left-facing fist",s:1},
    {e:"🤜",n:"right-facing fist",s:1},
    {e:"👏",n:"clapping hands",s:1},
    {e:"🙌",n:"raising hands",s:1},
    {e:"🫶",n:"heart hands",s:1},
    {e:"👐",n:"open hands",s:1},
    {e:"🤲",n:"palms up together",s:1},
    {e:"🤝",n:"handshake",s:1},
    {e:"🙏",n:"folded hands",s:1},
    {e:"✍️",n:"writing hand",s:1},
    {e:"💅",n:"nail polish",s:1},
    {e:"🤳",n:"selfie",s:1},
    {e:"💪",n:"flexed biceps",s:1},
    {e:"🦾",n:"mechanical arm"},
    {e:"🦿",n:"mechanical leg"},
    {e:"🦵",n:"leg",s:1},
    {e:"🦶",n:"foot",s:1},
    {e:"👂",n:"ear",s:1},
    {e:"🦻",n:"ear with hearing aid",s:1},
    {e:"👃",n:"nose",s:1},
    {e:"🧠",n:"brain"},
    {e:"🫀",n:"anatomical heart"},
    {e:"🫁",n:"lungs"},
    {e:"🦷",n:"tooth"},
    {e:"🦴",n:"bone"},
    {e:"👀",n:"eyes"},
    {e:"👁️",n:"eye"},
    {e:"👅",n:"tongue"},
    {e:"👄",n:"mouth"},
    {e:"🫦",n:"biting lip"},
    {e:"👶",n:"baby",s:1},
    {e:"🧒",n:"child",s:1},
    {e:"👦",n:"boy",s:1},
    {e:"👧",n:"girl",s:1},
    {e:"🧑",n:"person",s:1},
    {e:"👱",n:"person blond hair",s:1},
    {e:"👨",n:"man",s:1},
    {e:"🧔",n:"person beard",s:1},
    {e:"🧔‍♂️",n:"man beard",s:1},
    {e:"🧔‍♀️",n:"woman beard",s:1},
    {e:"👨‍🦰",n:"man red hair",s:1},
    {e:"👨‍🦱",n:"man curly hair",s:1},
    {e:"👨‍🦳",n:"man white hair",s:1},
    {e:"👨‍🦲",n:"man bald",s:1},
    {e:"👩",n:"woman",s:1},
    {e:"👩‍🦰",n:"woman red hair",s:1},
    {e:"🧑‍🦰",n:"person red hair",s:1},
    {e:"👩‍🦱",n:"woman curly hair",s:1},
    {e:"🧑‍🦱",n:"person curly hair",s:1},
    {e:"👩‍🦳",n:"woman white hair",s:1},
    {e:"🧑‍🦳",n:"person white hair",s:1},
    {e:"👩‍🦲",n:"woman bald",s:1},
    {e:"🧑‍🦲",n:"person bald",s:1},
    {e:"👱‍♀️",n:"woman blond hair",s:1},
    {e:"👱‍♂️",n:"man blond hair",s:1},
    {e:"🧓",n:"older person",s:1},
    {e:"👴",n:"old man",s:1},
    {e:"👵",n:"old woman",s:1},
    {e:"🙍",n:"person frowning",s:1},
    {e:"🙍‍♂️",n:"man frowning",s:1},
    {e:"🙍‍♀️",n:"woman frowning",s:1},
    {e:"🙎",n:"person pouting",s:1},
    {e:"🙎‍♂️",n:"man pouting",s:1},
    {e:"🙎‍♀️",n:"woman pouting",s:1},
    {e:"🙅",n:"person gesturing NO",s:1},
    {e:"🙅‍♂️",n:"man gesturing NO",s:1},
    {e:"🙅‍♀️",n:"woman gesturing NO",s:1},
    {e:"🙆",n:"person gesturing OK",s:1},
    {e:"🙆‍♂️",n:"man gesturing OK",s:1},
    {e:"🙆‍♀️",n:"woman gesturing OK",s:1},
    {e:"💁",n:"person tipping hand",s:1},
    {e:"💁‍♂️",n:"man tipping hand",s:1},
    {e:"💁‍♀️",n:"woman tipping hand",s:1},
    {e:"🙋",n:"person raising hand",s:1},
    {e:"🙋‍♂️",n:"man raising hand",s:1},
    {e:"🙋‍♀️",n:"woman raising hand",s:1},
    {e:"🧏",n:"deaf person",s:1},
    {e:"🧏‍♂️",n:"deaf man",s:1},
    {e:"🧏‍♀️",n:"deaf woman",s:1},
    {e:"🙇",n:"person bowing",s:1},
    {e:"🙇‍♂️",n:"man bowing",s:1},
    {e:"🙇‍♀️",n:"woman bowing",s:1},
    {e:"🤦",n:"person facepalming",s:1},
    {e:"🤦‍♂️",n:"man facepalming",s:1},
    {e:"🤦‍♀️",n:"woman facepalming",s:1},
    {e:"🤷",n:"person shrugging",s:1},
    {e:"🤷‍♂️",n:"man shrugging",s:1},
    {e:"🤷‍♀️",n:"woman shrugging",s:1},
    {e:"🧑‍⚕️",n:"health worker",s:1},
    {e:"👨‍⚕️",n:"man health worker",s:1},
    {e:"👩‍⚕️",n:"woman health worker",s:1},
    {e:"🧑‍🎓",n:"student",s:1},
    {e:"👨‍🎓",n:"man student",s:1},
    {e:"👩‍🎓",n:"woman student",s:1},
    {e:"🧑‍🏫",n:"teacher",s:1},
    {e:"👨‍🏫",n:"man teacher",s:1},
    {e:"👩‍🏫",n:"woman teacher",s:1},
    {e:"🧑‍⚖️",n:"judge",s:1},
    {e:"👨‍⚖️",n:"man judge",s:1},
    {e:"👩‍⚖️",n:"woman judge",s:1},
    {e:"🧑‍🌾",n:"farmer",s:1},
    {e:"👨‍🌾",n:"man farmer",s:1},
    {e:"👩‍🌾",n:"woman farmer",s:1},
    {e:"🧑‍🍳",n:"cook",s:1},
    {e:"👨‍🍳",n:"man cook",s:1},
    {e:"👩‍🍳",n:"woman cook",s:1},
    {e:"🧑‍🔧",n:"mechanic",s:1},
    {e:"👨‍🔧",n:"man mechanic",s:1},
    {e:"👩‍🔧",n:"woman mechanic",s:1},
    {e:"🧑‍🏭",n:"factory worker",s:1},
    {e:"👨‍🏭",n:"man factory worker",s:1},
    {e:"👩‍🏭",n:"woman factory worker",s:1},
    {e:"🧑‍💼",n:"office worker",s:1},
    {e:"👨‍💼",n:"man office worker",s:1},
    {e:"👩‍💼",n:"woman office worker",s:1},
    {e:"🧑‍🔬",n:"scientist",s:1},
    {e:"👨‍🔬",n:"man scientist",s:1},
    {e:"👩‍🔬",n:"woman scientist",s:1},
    {e:"🧑‍💻",n:"technologist",s:1},
    {e:"👨‍💻",n:"man technologist",s:1},
    {e:"👩‍💻",n:"woman technologist",s:1},
    {e:"🧑‍🎤",n:"singer",s:1},
    {e:"👨‍🎤",n:"man singer",s:1},
    {e:"👩‍🎤",n:"woman singer",s:1},
    {e:"🧑‍🎨",n:"artist",s:1},
    {e:"👨‍🎨",n:"man artist",s:1},
    {e:"👩‍🎨",n:"woman artist",s:1},
    {e:"🧑‍✈️",n:"pilot",s:1},
    {e:"👨‍✈️",n:"man pilot",s:1},
    {e:"👩‍✈️",n:"woman pilot",s:1},
    {e:"🧑‍🚀",n:"astronaut",s:1},
    {e:"👨‍🚀",n:"man astronaut",s:1},
    {e:"👩‍🚀",n:"woman astronaut",s:1},
    {e:"🧑‍🚒",n:"firefighter",s:1},
    {e:"👨‍🚒",n:"man firefighter",s:1},
    {e:"👩‍🚒",n:"woman firefighter",s:1},
    {e:"👮",n:"police officer",s:1},
    {e:"👮‍♂️",n:"man police officer",s:1},
    {e:"👮‍♀️",n:"woman police officer",s:1},
    {e:"🕵️",n:"detective",s:1},
    {e:"🕵️‍♂️",n:"man detective",s:1},
    {e:"🕵️‍♀️",n:"woman detective",s:1},
    {e:"💂",n:"guard",s:1},
    {e:"💂‍♂️",n:"man guard",s:1},
    {e:"💂‍♀️",n:"woman guard",s:1},
    {e:"🥷",n:"ninja",s:1},
    {e:"👷",n:"construction worker",s:1},
    {e:"👷‍♂️",n:"man construction worker",s:1},
    {e:"👷‍♀️",n:"woman construction worker",s:1},
    {e:"🫅",n:"person with crown",s:1},
    {e:"🤴",n:"prince",s:1},
    {e:"👸",n:"princess",s:1},
    {e:"👳",n:"person wearing turban",s:1},
    {e:"👳‍♂️",n:"man wearing turban",s:1},
    {e:"👳‍♀️",n:"woman wearing turban",s:1},
    {e:"👲",n:"person with skullcap",s:1},
    {e:"🧕",n:"woman with headscarf",s:1},
    {e:"🤵",n:"person in tuxedo",s:1},
    {e:"🤵‍♂️",n:"man in tuxedo",s:1},
    {e:"🤵‍♀️",n:"woman in tuxedo",s:1},
    {e:"👰",n:"person with veil",s:1},
    {e:"👰‍♂️",n:"man with veil",s:1},
    {e:"👰‍♀️",n:"woman with veil",s:1},
    {e:"🤰",n:"pregnant woman",s:1},
    {e:"🫃",n:"pregnant man",s:1},
    {e:"🫄",n:"pregnant person",s:1},
    {e:"🤱",n:"breast-feeding",s:1},
    {e:"👩‍🍼",n:"woman feeding baby",s:1},
    {e:"👨‍🍼",n:"man feeding baby",s:1},
    {e:"🧑‍🍼",n:"person feeding baby",s:1},
    {e:"👼",n:"baby angel",s:1},
    {e:"🎅",n:"Santa Claus",s:1},
    {e:"🤶",n:"Mrs. Claus",s:1},
    {e:"🧑‍🎄",n:"Mx Claus",s:1},
    {e:"🦸",n:"superhero",s:1},
    {e:"🦸‍♂️",n:"man superhero",s:1},
    {e:"🦸‍♀️",n:"woman superhero",s:1},
    {e:"🦹",n:"supervillain",s:1},
    {e:"🦹‍♂️",n:"man supervillain",s:1},
    {e:"🦹‍♀️",n:"woman supervillain",s:1},
    {e:"🧙",n:"mage",s:1},
    {e:"🧙‍♂️",n:"man mage",s:1},
    {e:"🧙‍♀️",n:"woman mage",s:1},
    {e:"🧚",n:"fairy",s:1},
    {e:"🧚‍♂️",n:"man fairy",s:1},
    {e:"🧚‍♀️",n:"woman fairy",s:1},
    {e:"🧛",n:"vampire",s:1},
    {e:"🧛‍♂️",n:"man vampire",s:1},
    {e:"🧛‍♀️",n:"woman vampire",s:1},
    {e:"🧜",n:"merperson",s:1},
    {e:"🧜‍♂️",n:"merman",s:1},
    {e:"🧜‍♀️",n:"mermaid",s:1},
    {e:"🧝",n:"elf",s:1},
    {e:"🧝‍♂️",n:"man elf",s:1},
    {e:"🧝‍♀️",n:"woman elf",s:1},
    {e:"🧞",n:"genie"},
    {e:"🧞‍♂️",n:"man genie"},
    {e:"🧞‍♀️",n:"woman genie"},
    {e:"🧟",n:"zombie"},
    {e:"🧟‍♂️",n:"man zombie"},
    {e:"🧟‍♀️",n:"woman zombie"},
    {e:"🧌",n:"troll"},
    {e:"💆",n:"person getting massage",s:1},
    {e:"💆‍♂️",n:"man getting massage",s:1},
    {e:"💆‍♀️",n:"woman getting massage",s:1},
    {e:"💇",n:"person getting haircut",s:1},
    {e:"💇‍♂️",n:"man getting haircut",s:1},
    {e:"💇‍♀️",n:"woman getting haircut",s:1},
    {e:"🚶",n:"person walking",s:1},
    {e:"🚶‍♂️",n:"man walking",s:1},
    {e:"🚶‍♀️",n:"woman walking",s:1},
    {e:"🚶‍➡️",n:"person walking facing right",s:1},
    {e:"🚶‍♀️‍➡️",n:"woman walking facing right",s:1},
    {e:"🚶‍♂️‍➡️",n:"man walking facing right",s:1},
    {e:"🧍",n:"person standing",s:1},
    {e:"🧍‍♂️",n:"man standing",s:1},
    {e:"🧍‍♀️",n:"woman standing",s:1},
    {e:"🧎",n:"person kneeling",s:1},
    {e:"🧎‍♂️",n:"man kneeling",s:1},
    {e:"🧎‍♀️",n:"woman kneeling",s:1},
    {e:"🧎‍➡️",n:"person kneeling facing right",s:1},
    {e:"🧎‍♀️‍➡️",n:"woman kneeling facing right",s:1},
    {e:"🧎‍♂️‍➡️",n:"man kneeling facing right",s:1},
    {e:"🧑‍🦯",n:"person with white cane",s:1},
    {e:"🧑‍🦯‍➡️",n:"person with white cane facing right",s:1},
    {e:"👨‍🦯",n:"man with white cane",s:1},
    {e:"👨‍🦯‍➡️",n:"man with white cane facing right",s:1},
    {e:"👩‍🦯",n:"woman with white cane",s:1},
    {e:"👩‍🦯‍➡️",n:"woman with white cane facing right",s:1},
    {e:"🧑‍🦼",n:"person in motorized wheelchair",s:1},
    {e:"🧑‍🦼‍➡️",n:"person in motorized wheelchair facing right",s:1},
    {e:"👨‍🦼",n:"man in motorized wheelchair",s:1},
    {e:"👨‍🦼‍➡️",n:"man in motorized wheelchair facing right",s:1},
    {e:"👩‍🦼",n:"woman in motorized wheelchair",s:1},
    {e:"👩‍🦼‍➡️",n:"woman in motorized wheelchair facing right",s:1},
    {e:"🧑‍🦽",n:"person in manual wheelchair",s:1},
    {e:"🧑‍🦽‍➡️",n:"person in manual wheelchair facing right",s:1},
    {e:"👨‍🦽",n:"man in manual wheelchair",s:1},
    {e:"👨‍🦽‍➡️",n:"man in manual wheelchair facing right",s:1},
    {e:"👩‍🦽",n:"woman in manual wheelchair",s:1},
    {e:"👩‍🦽‍➡️",n:"woman in manual wheelchair facing right",s:1},
    {e:"🏃",n:"person running",s:1},
    {e:"🏃‍♂️",n:"man running",s:1},
    {e:"🏃‍♀️",n:"woman running",s:1},
    {e:"🏃‍➡️",n:"person running facing right",s:1},
    {e:"🏃‍♀️‍➡️",n:"woman running facing right",s:1},
    {e:"🏃‍♂️‍➡️",n:"man running facing right",s:1},
    {e:"💃",n:"woman dancing",s:1},
    {e:"🕺",n:"man dancing",s:1},
    {e:"🕴️",n:"person in suit levitating",s:1},
    {e:"👯",n:"people with bunny ears"},
    {e:"👯‍♂️",n:"men with bunny ears"},
    {e:"👯‍♀️",n:"women with bunny ears"},
    {e:"🧖",n:"person in steamy room",s:1},
    {e:"🧖‍♂️",n:"man in steamy room",s:1},
    {e:"🧖‍♀️",n:"woman in steamy room",s:1},
    {e:"🧗",n:"person climbing",s:1},
    {e:"🧗‍♂️",n:"man climbing",s:1},
    {e:"🧗‍♀️",n:"woman climbing",s:1},
    {e:"🤺",n:"person fencing"},
    {e:"🏇",n:"horse racing",s:1},
    {e:"⛷️",n:"skier"},
    {e:"🏂",n:"snowboarder",s:1},
    {e:"🏌️",n:"person golfing",s:1},
    {e:"🏌️‍♂️",n:"man golfing",s:1},
    {e:"🏌️‍♀️",n:"woman golfing",s:1},
    {e:"🏄",n:"person surfing",s:1},
    {e:"🏄‍♂️",n:"man surfing",s:1},
    {e:"🏄‍♀️",n:"woman surfing",s:1},
    {e:"🚣",n:"person rowing boat",s:1},
    {e:"🚣‍♂️",n:"man rowing boat",s:1},
    {e:"🚣‍♀️",n:"woman rowing boat",s:1},
    {e:"🏊",n:"person swimming",s:1},
    {e:"🏊‍♂️",n:"man swimming",s:1},
    {e:"🏊‍♀️",n:"woman swimming",s:1},
    {e:"⛹️",n:"person bouncing ball",s:1},
    {e:"⛹️‍♂️",n:"man bouncing ball",s:1},
    {e:"⛹️‍♀️",n:"woman bouncing ball",s:1},
    {e:"🏋️",n:"person lifting weights",s:1},
    {e:"🏋️‍♂️",n:"man lifting weights",s:1},
    {e:"🏋️‍♀️",n:"woman lifting weights",s:1},
    {e:"🚴",n:"person biking",s:1},
    {e:"🚴‍♂️",n:"man biking",s:1},
    {e:"🚴‍♀️",n:"woman biking",s:1},
    {e:"🚵",n:"person mountain biking",s:1},
    {e:"🚵‍♂️",n:"man mountain biking",s:1},
    {e:"🚵‍♀️",n:"woman mountain biking",s:1},
    {e:"🤸",n:"person cartwheeling",s:1},
    {e:"🤸‍♂️",n:"man cartwheeling",s:1},
    {e:"🤸‍♀️",n:"woman cartwheeling",s:1},
    {e:"🤼",n:"people wrestling"},
    {e:"🤼‍♂️",n:"men wrestling"},
    {e:"🤼‍♀️",n:"women wrestling"},
    {e:"🤽",n:"person playing water polo",s:1},
    {e:"🤽‍♂️",n:"man playing water polo",s:1},
    {e:"🤽‍♀️",n:"woman playing water polo",s:1},
    {e:"🤾",n:"person playing handball",s:1},
    {e:"🤾‍♂️",n:"man playing handball",s:1},
    {e:"🤾‍♀️",n:"woman playing handball",s:1},
    {e:"🤹",n:"person juggling",s:1},
    {e:"🤹‍♂️",n:"man juggling",s:1},
    {e:"🤹‍♀️",n:"woman juggling",s:1},
    {e:"🧘",n:"person in lotus position",s:1},
    {e:"🧘‍♂️",n:"man in lotus position",s:1},
    {e:"🧘‍♀️",n:"woman in lotus position",s:1},
    {e:"🛀",n:"person taking bath",s:1},
    {e:"🛌",n:"person in bed",s:1},
    {e:"🧑‍🤝‍🧑",n:"people holding hands",s:1},
    {e:"👭",n:"women holding hands",s:1},
    {e:"👫",n:"woman and man holding hands",s:1},
    {e:"👬",n:"men holding hands",s:1},
    {e:"💏",n:"kiss",s:1},
    {e:"👩‍❤️‍💋‍👨",n:"kiss woman, man",s:1},
    {e:"👨‍❤️‍💋‍👨",n:"kiss man, man",s:1},
    {e:"👩‍❤️‍💋‍👩",n:"kiss woman, woman",s:1},
    {e:"💑",n:"couple with heart",s:1},
    {e:"👩‍❤️‍👨",n:"couple with heart woman, man",s:1},
    {e:"👨‍❤️‍👨",n:"couple with heart man, man",s:1},
    {e:"👩‍❤️‍👩",n:"couple with heart woman, woman",s:1},
    {e:"👨‍👩‍👦",n:"family man, woman, boy"},
    {e:"👨‍👩‍👧",n:"family man, woman, girl"},
    {e:"👨‍👩‍👧‍👦",n:"family man, woman, girl, boy"},
    {e:"👨‍👩‍👦‍👦",n:"family man, woman, boy, boy"},
    {e:"👨‍👩‍👧‍👧",n:"family man, woman, girl, girl"},
    {e:"👨‍👨‍👦",n:"family man, man, boy"},
    {e:"👨‍👨‍👧",n:"family man, man, girl"},
    {e:"👨‍👨‍👧‍👦",n:"family man, man, girl, boy"},
    {e:"👨‍👨‍👦‍👦",n:"family man, man, boy, boy"},
    {e:"👨‍👨‍👧‍👧",n:"family man, man, girl, girl"},
    {e:"👩‍👩‍👦",n:"family woman, woman, boy"},
    {e:"👩‍👩‍👧",n:"family woman, woman, girl"},
    {e:"👩‍👩‍👧‍👦",n:"family woman, woman, girl, boy"},
    {e:"👩‍👩‍👦‍👦",n:"family woman, woman, boy, boy"},
    {e:"👩‍👩‍👧‍👧",n:"family woman, woman, girl, girl"},
    {e:"👨‍👦",n:"family man, boy"},
    {e:"👨‍👦‍👦",n:"family man, boy, boy"},
    {e:"👨‍👧",n:"family man, girl"},
    {e:"👨‍👧‍👦",n:"family man, girl, boy"},
    {e:"👨‍👧‍👧",n:"family man, girl, girl"},
    {e:"👩‍👦",n:"family woman, boy"},
    {e:"👩‍👦‍👦",n:"family woman, boy, boy"},
    {e:"👩‍👧",n:"family woman, girl"},
    {e:"👩‍👧‍👦",n:"family woman, girl, boy"},
    {e:"👩‍👧‍👧",n:"family woman, girl, girl"},
    {e:"🗣️",n:"speaking head"},
    {e:"👤",n:"bust in silhouette"},
    {e:"👥",n:"busts in silhouette"},
    {e:"🫂",n:"people hugging"},
    {e:"👪",n:"family"},
    {e:"🧑‍🧑‍🧒",n:"family adult, adult, child"},
    {e:"🧑‍🧑‍🧒‍🧒",n:"family adult, adult, child, child"},
    {e:"🧑‍🧒",n:"family adult, child"},
    {e:"🧑‍🧒‍🧒",n:"family adult, child, child"},
    {e:"👣",n:"footprints"},
    {e:"🫆",n:"fingerprint"}
  ],
  animals: [
    {e:"🐵",n:"monkey face"},
    {e:"🐒",n:"monkey"},
    {e:"🦍",n:"gorilla"},
    {e:"🦧",n:"orangutan"},
    {e:"🐶",n:"dog face"},
    {e:"🐕",n:"dog"},
    {e:"🦮",n:"guide dog"},
    {e:"🐕‍🦺",n:"service dog"},
    {e:"🐩",n:"poodle"},
    {e:"🐺",n:"wolf"},
    {e:"🦊",n:"fox"},
    {e:"🦝",n:"raccoon"},
    {e:"🐱",n:"cat face"},
    {e:"🐈",n:"cat"},
    {e:"🐈‍⬛",n:"black cat"},
    {e:"🦁",n:"lion"},
    {e:"🐯",n:"tiger face"},
    {e:"🐅",n:"tiger"},
    {e:"🐆",n:"leopard"},
    {e:"🐴",n:"horse face"},
    {e:"🫎",n:"moose"},
    {e:"🫏",n:"donkey"},
    {e:"🐎",n:"horse"},
    {e:"🦄",n:"unicorn"},
    {e:"🦓",n:"zebra"},
    {e:"🦌",n:"deer"},
    {e:"🦬",n:"bison"},
    {e:"🐮",n:"cow face"},
    {e:"🐂",n:"ox"},
    {e:"🐃",n:"water buffalo"},
    {e:"🐄",n:"cow"},
    {e:"🐷",n:"pig face"},
    {e:"🐖",n:"pig"},
    {e:"🐗",n:"boar"},
    {e:"🐽",n:"pig nose"},
    {e:"🐏",n:"ram"},
    {e:"🐑",n:"ewe"},
    {e:"🐐",n:"goat"},
    {e:"🐪",n:"camel"},
    {e:"🐫",n:"two-hump camel"},
    {e:"🦙",n:"llama"},
    {e:"🦒",n:"giraffe"},
    {e:"🐘",n:"elephant"},
    {e:"🦣",n:"mammoth"},
    {e:"🦏",n:"rhinoceros"},
    {e:"🦛",n:"hippopotamus"},
    {e:"🐭",n:"mouse face"},
    {e:"🐁",n:"mouse"},
    {e:"🐀",n:"rat"},
    {e:"🐹",n:"hamster"},
    {e:"🐰",n:"rabbit face"},
    {e:"🐇",n:"rabbit"},
    {e:"🐿️",n:"chipmunk"},
    {e:"🦫",n:"beaver"},
    {e:"🦔",n:"hedgehog"},
    {e:"🦇",n:"bat"},
    {e:"🐻",n:"bear"},
    {e:"🐻‍❄️",n:"polar bear"},
    {e:"🐨",n:"koala"},
    {e:"🐼",n:"panda"},
    {e:"🦥",n:"sloth"},
    {e:"🦦",n:"otter"},
    {e:"🦨",n:"skunk"},
    {e:"🦘",n:"kangaroo"},
    {e:"🦡",n:"badger"},
    {e:"🐾",n:"paw prints"},
    {e:"🦃",n:"turkey"},
    {e:"🐔",n:"chicken"},
    {e:"🐓",n:"rooster"},
    {e:"🐣",n:"hatching chick"},
    {e:"🐤",n:"baby chick"},
    {e:"🐥",n:"front-facing baby chick"},
    {e:"🐦",n:"bird"},
    {e:"🐧",n:"penguin"},
    {e:"🕊️",n:"dove"},
    {e:"🦅",n:"eagle"},
    {e:"🦆",n:"duck"},
    {e:"🦢",n:"swan"},
    {e:"🦉",n:"owl"},
    {e:"🦤",n:"dodo"},
    {e:"🪶",n:"feather"},
    {e:"🦩",n:"flamingo"},
    {e:"🦚",n:"peacock"},
    {e:"🦜",n:"parrot"},
    {e:"🪽",n:"wing"},
    {e:"🐦‍⬛",n:"black bird"},
    {e:"🪿",n:"goose"},
    {e:"🐦‍🔥",n:"phoenix"},
    {e:"🐸",n:"frog"},
    {e:"🐊",n:"crocodile"},
    {e:"🐢",n:"turtle"},
    {e:"🦎",n:"lizard"},
    {e:"🐍",n:"snake"},
    {e:"🐲",n:"dragon face"},
    {e:"🐉",n:"dragon"},
    {e:"🦕",n:"sauropod"},
    {e:"🦖",n:"T-Rex"},
    {e:"🐳",n:"spouting whale"},
    {e:"🐋",n:"whale"},
    {e:"🐬",n:"dolphin"},
    {e:"🦭",n:"seal"},
    {e:"🐟",n:"fish"},
    {e:"🐠",n:"tropical fish"},
    {e:"🐡",n:"blowfish"},
    {e:"🦈",n:"shark"},
    {e:"🐙",n:"octopus"},
    {e:"🐚",n:"spiral shell"},
    {e:"🪸",n:"coral"},
    {e:"🪼",n:"jellyfish"},
    {e:"🦀",n:"crab"},
    {e:"🦞",n:"lobster"},
    {e:"🦐",n:"shrimp"},
    {e:"🦑",n:"squid"},
    {e:"🦪",n:"oyster"},
    {e:"🐌",n:"snail"},
    {e:"🦋",n:"butterfly"},
    {e:"🐛",n:"bug"},
    {e:"🐜",n:"ant"},
    {e:"🐝",n:"honeybee"},
    {e:"🪲",n:"beetle"},
    {e:"🐞",n:"lady beetle"},
    {e:"🦗",n:"cricket"},
    {e:"🪳",n:"cockroach"},
    {e:"🕷️",n:"spider"},
    {e:"🕸️",n:"spider web"},
    {e:"🦂",n:"scorpion"},
    {e:"🦟",n:"mosquito"},
    {e:"🪰",n:"fly"},
    {e:"🪱",n:"worm"},
    {e:"🦠",n:"microbe"},
    {e:"💐",n:"bouquet"},
    {e:"🌸",n:"cherry blossom"},
    {e:"💮",n:"white flower"},
    {e:"🪷",n:"lotus"},
    {e:"🏵️",n:"rosette"},
    {e:"🌹",n:"rose"},
    {e:"🥀",n:"wilted flower"},
    {e:"🌺",n:"hibiscus"},
    {e:"🌻",n:"sunflower"},
    {e:"🌼",n:"blossom"},
    {e:"🌷",n:"tulip"},
    {e:"🪻",n:"hyacinth"},
    {e:"🌱",n:"seedling"},
    {e:"🪴",n:"potted plant"},
    {e:"🌲",n:"evergreen tree"},
    {e:"🌳",n:"deciduous tree"},
    {e:"🌴",n:"palm tree"},
    {e:"🌵",n:"cactus"},
    {e:"🌾",n:"sheaf of rice"},
    {e:"🌿",n:"herb"},
    {e:"☘️",n:"shamrock"},
    {e:"🍀",n:"four leaf clover"},
    {e:"🍁",n:"maple leaf"},
    {e:"🍂",n:"fallen leaf"},
    {e:"🍃",n:"leaf fluttering in wind"},
    {e:"🪹",n:"empty nest"},
    {e:"🪺",n:"nest with eggs"},
    {e:"🍄",n:"mushroom"},
    {e:"🪾",n:"leafless tree"}
  ],
  food: [
    {e:"🍇",n:"grapes"},
    {e:"🍈",n:"melon"},
    {e:"🍉",n:"watermelon"},
    {e:"🍊",n:"tangerine"},
    {e:"🍋",n:"lemon"},
    {e:"🍋‍🟩",n:"lime"},
    {e:"🍌",n:"banana"},
    {e:"🍍",n:"pineapple"},
    {e:"🥭",n:"mango"},
    {e:"🍎",n:"red apple"},
    {e:"🍏",n:"green apple"},
    {e:"🍐",n:"pear"},
    {e:"🍑",n:"peach"},
    {e:"🍒",n:"cherries"},
    {e:"🍓",n:"strawberry"},
    {e:"🫐",n:"blueberries"},
    {e:"🥝",n:"kiwi fruit"},
    {e:"🍅",n:"tomato"},
    {e:"🫒",n:"olive"},
    {e:"🥥",n:"coconut"},
    {e:"🥑",n:"avocado"},
    {e:"🍆",n:"eggplant"},
    {e:"🥔",n:"potato"},
    {e:"🥕",n:"carrot"},
    {e:"🌽",n:"ear of corn"},
    {e:"🌶️",n:"hot pepper"},
    {e:"🫑",n:"bell pepper"},
    {e:"🥒",n:"cucumber"},
    {e:"🥬",n:"leafy green"},
    {e:"🥦",n:"broccoli"},
    {e:"🧄",n:"garlic"},
    {e:"🧅",n:"onion"},
    {e:"🥜",n:"peanuts"},
    {e:"🫘",n:"beans"},
    {e:"🌰",n:"chestnut"},
    {e:"🫚",n:"ginger root"},
    {e:"🫛",n:"pea pod"},
    {e:"🍄‍🟫",n:"brown mushroom"},
    {e:"🫜",n:"root vegetable"},
    {e:"🍞",n:"bread"},
    {e:"🥐",n:"croissant"},
    {e:"🥖",n:"baguette bread"},
    {e:"🫓",n:"flatbread"},
    {e:"🥨",n:"pretzel"},
    {e:"🥯",n:"bagel"},
    {e:"🥞",n:"pancakes"},
    {e:"🧇",n:"waffle"},
    {e:"🧀",n:"cheese wedge"},
    {e:"🍖",n:"meat on bone"},
    {e:"🍗",n:"poultry leg"},
    {e:"🥩",n:"cut of meat"},
    {e:"🥓",n:"bacon"},
    {e:"🍔",n:"hamburger"},
    {e:"🍟",n:"french fries"},
    {e:"🍕",n:"pizza"},
    {e:"🌭",n:"hot dog"},
    {e:"🥪",n:"sandwich"},
    {e:"🌮",n:"taco"},
    {e:"🌯",n:"burrito"},
    {e:"🫔",n:"tamale"},
    {e:"🥙",n:"stuffed flatbread"},
    {e:"🧆",n:"falafel"},
    {e:"🥚",n:"egg"},
    {e:"🍳",n:"cooking"},
    {e:"🥘",n:"shallow pan of food"},
    {e:"🍲",n:"pot of food"},
    {e:"🫕",n:"fondue"},
    {e:"🥣",n:"bowl with spoon"},
    {e:"🥗",n:"green salad"},
    {e:"🍿",n:"popcorn"},
    {e:"🧈",n:"butter"},
    {e:"🧂",n:"salt"},
    {e:"🥫",n:"canned food"},
    {e:"🍱",n:"bento box"},
    {e:"🍘",n:"rice cracker"},
    {e:"🍙",n:"rice ball"},
    {e:"🍚",n:"cooked rice"},
    {e:"🍛",n:"curry rice"},
    {e:"🍜",n:"steaming bowl"},
    {e:"🍝",n:"spaghetti"},
    {e:"🍠",n:"roasted sweet potato"},
    {e:"🍢",n:"oden"},
    {e:"🍣",n:"sushi"},
    {e:"🍤",n:"fried shrimp"},
    {e:"🍥",n:"fish cake with swirl"},
    {e:"🥮",n:"moon cake"},
    {e:"🍡",n:"dango"},
    {e:"🥟",n:"dumpling"},
    {e:"🥠",n:"fortune cookie"},
    {e:"🥡",n:"takeout box"},
    {e:"🍦",n:"soft ice cream"},
    {e:"🍧",n:"shaved ice"},
    {e:"🍨",n:"ice cream"},
    {e:"🍩",n:"doughnut"},
    {e:"🍪",n:"cookie"},
    {e:"🎂",n:"birthday cake"},
    {e:"🍰",n:"shortcake"},
    {e:"🧁",n:"cupcake"},
    {e:"🥧",n:"pie"},
    {e:"🍫",n:"chocolate bar"},
    {e:"🍬",n:"candy"},
    {e:"🍭",n:"lollipop"},
    {e:"🍮",n:"custard"},
    {e:"🍯",n:"honey pot"},
    {e:"🍼",n:"baby bottle"},
    {e:"🥛",n:"glass of milk"},
    {e:"☕",n:"hot beverage"},
    {e:"🫖",n:"teapot"},
    {e:"🍵",n:"teacup without handle"},
    {e:"🍶",n:"sake"},
    {e:"🍾",n:"bottle with popping cork"},
    {e:"🍷",n:"wine glass"},
    {e:"🍸",n:"cocktail glass"},
    {e:"🍹",n:"tropical drink"},
    {e:"🍺",n:"beer mug"},
    {e:"🍻",n:"clinking beer mugs"},
    {e:"🥂",n:"clinking glasses"},
    {e:"🥃",n:"tumbler glass"},
    {e:"🫗",n:"pouring liquid"},
    {e:"🥤",n:"cup with straw"},
    {e:"🧋",n:"bubble tea"},
    {e:"🧃",n:"beverage box"},
    {e:"🧉",n:"mate"},
    {e:"🧊",n:"ice"},
    {e:"🥢",n:"chopsticks"},
    {e:"🍽️",n:"fork and knife with plate"},
    {e:"🍴",n:"fork and knife"},
    {e:"🥄",n:"spoon"},
    {e:"🔪",n:"kitchen knife"},
    {e:"🫙",n:"jar"},
    {e:"🏺",n:"amphora"}
  ],
  travel: [
    {e:"🌍",n:"globe showing Europe-Africa"},
    {e:"🌎",n:"globe showing Americas"},
    {e:"🌏",n:"globe showing Asia-Australia"},
    {e:"🌐",n:"globe with meridians"},
    {e:"🗺️",n:"world map"},
    {e:"🗾",n:"map of Japan"},
    {e:"🧭",n:"compass"},
    {e:"🏔️",n:"snow-capped mountain"},
    {e:"⛰️",n:"mountain"},
    {e:"🌋",n:"volcano"},
    {e:"🗻",n:"mount fuji"},
    {e:"🏕️",n:"camping"},
    {e:"🏖️",n:"beach with umbrella"},
    {e:"🏜️",n:"desert"},
    {e:"🏝️",n:"desert island"},
    {e:"🏞️",n:"national park"},
    {e:"🏟️",n:"stadium"},
    {e:"🏛️",n:"classical building"},
    {e:"🏗️",n:"building construction"},
    {e:"🧱",n:"brick"},
    {e:"🪨",n:"rock"},
    {e:"🪵",n:"wood"},
    {e:"🛖",n:"hut"},
    {e:"🏘️",n:"houses"},
    {e:"🏚️",n:"derelict house"},
    {e:"🏠",n:"house"},
    {e:"🏡",n:"house with garden"},
    {e:"🏢",n:"office building"},
    {e:"🏣",n:"Japanese post office"},
    {e:"🏤",n:"post office"},
    {e:"🏥",n:"hospital"},
    {e:"🏦",n:"bank"},
    {e:"🏨",n:"hotel"},
    {e:"🏩",n:"love hotel"},
    {e:"🏪",n:"convenience store"},
    {e:"🏫",n:"school"},
    {e:"🏬",n:"department store"},
    {e:"🏭",n:"factory"},
    {e:"🏯",n:"Japanese castle"},
    {e:"🏰",n:"castle"},
    {e:"💒",n:"wedding"},
    {e:"🗼",n:"Tokyo tower"},
    {e:"🗽",n:"Statue of Liberty"},
    {e:"⛪",n:"church"},
    {e:"🕌",n:"mosque"},
    {e:"🛕",n:"hindu temple"},
    {e:"🕍",n:"synagogue"},
    {e:"⛩️",n:"shinto shrine"},
    {e:"🕋",n:"kaaba"},
    {e:"⛲",n:"fountain"},
    {e:"⛺",n:"tent"},
    {e:"🌁",n:"foggy"},
    {e:"🌃",n:"night with stars"},
    {e:"🏙️",n:"cityscape"},
    {e:"🌄",n:"sunrise over mountains"},
    {e:"🌅",n:"sunrise"},
    {e:"🌆",n:"cityscape at dusk"},
    {e:"🌇",n:"sunset"},
    {e:"🌉",n:"bridge at night"},
    {e:"♨️",n:"hot springs"},
    {e:"🎠",n:"carousel horse"},
    {e:"🛝",n:"playground slide"},
    {e:"🎡",n:"ferris wheel"},
    {e:"🎢",n:"roller coaster"},
    {e:"💈",n:"barber pole"},
    {e:"🎪",n:"circus tent"},
    {e:"🚂",n:"locomotive"},
    {e:"🚃",n:"railway car"},
    {e:"🚄",n:"high-speed train"},
    {e:"🚅",n:"bullet train"},
    {e:"🚆",n:"train"},
    {e:"🚇",n:"metro"},
    {e:"🚈",n:"light rail"},
    {e:"🚉",n:"station"},
    {e:"🚊",n:"tram"},
    {e:"🚝",n:"monorail"},
    {e:"🚞",n:"mountain railway"},
    {e:"🚋",n:"tram car"},
    {e:"🚌",n:"bus"},
    {e:"🚍",n:"oncoming bus"},
    {e:"🚎",n:"trolleybus"},
    {e:"🚐",n:"minibus"},
    {e:"🚑",n:"ambulance"},
    {e:"🚒",n:"fire engine"},
    {e:"🚓",n:"police car"},
    {e:"🚔",n:"oncoming police car"},
    {e:"🚕",n:"taxi"},
    {e:"🚖",n:"oncoming taxi"},
    {e:"🚗",n:"automobile"},
    {e:"🚘",n:"oncoming automobile"},
    {e:"🚙",n:"sport utility vehicle"},
    {e:"🛻",n:"pickup truck"},
    {e:"🚚",n:"delivery truck"},
    {e:"🚛",n:"articulated lorry"},
    {e:"🚜",n:"tractor"},
    {e:"🏎️",n:"racing car"},
    {e:"🏍️",n:"motorcycle"},
    {e:"🛵",n:"motor scooter"},
    {e:"🦽",n:"manual wheelchair"},
    {e:"🦼",n:"motorized wheelchair"},
    {e:"🛺",n:"auto rickshaw"},
    {e:"🚲",n:"bicycle"},
    {e:"🛴",n:"kick scooter"},
    {e:"🛹",n:"skateboard"},
    {e:"🛼",n:"roller skate"},
    {e:"🚏",n:"bus stop"},
    {e:"🛣️",n:"motorway"},
    {e:"🛤️",n:"railway track"},
    {e:"🛢️",n:"oil drum"},
    {e:"⛽",n:"fuel pump"},
    {e:"🛞",n:"wheel"},
    {e:"🚨",n:"police car light"},
    {e:"🚥",n:"horizontal traffic light"},
    {e:"🚦",n:"vertical traffic light"},
    {e:"🛑",n:"stop sign"},
    {e:"🚧",n:"construction"},
    {e:"⚓",n:"anchor"},
    {e:"🛟",n:"ring buoy"},
    {e:"⛵",n:"sailboat"},
    {e:"🛶",n:"canoe"},
    {e:"🚤",n:"speedboat"},
    {e:"🛳️",n:"passenger ship"},
    {e:"⛴️",n:"ferry"},
    {e:"🛥️",n:"motor boat"},
    {e:"🚢",n:"ship"},
    {e:"✈️",n:"airplane"},
    {e:"🛩️",n:"small airplane"},
    {e:"🛫",n:"airplane departure"},
    {e:"🛬",n:"airplane arrival"},
    {e:"🪂",n:"parachute"},
    {e:"💺",n:"seat"},
    {e:"🚁",n:"helicopter"},
    {e:"🚟",n:"suspension railway"},
    {e:"🚠",n:"mountain cableway"},
    {e:"🚡",n:"aerial tramway"},
    {e:"🛰️",n:"satellite"},
    {e:"🚀",n:"rocket"},
    {e:"🛸",n:"flying saucer"},
    {e:"🛎️",n:"bellhop bell"},
    {e:"🧳",n:"luggage"},
    {e:"⌛",n:"hourglass done"},
    {e:"⏳",n:"hourglass not done"},
    {e:"⌚",n:"watch"},
    {e:"⏰",n:"alarm clock"},
    {e:"⏱️",n:"stopwatch"},
    {e:"⏲️",n:"timer clock"},
    {e:"🕰️",n:"mantelpiece clock"},
    {e:"🕛",n:"twelve o’clock"},
    {e:"🕧",n:"twelve-thirty"},
    {e:"🕐",n:"one o’clock"},
    {e:"🕜",n:"one-thirty"},
    {e:"🕑",n:"two o’clock"},
    {e:"🕝",n:"two-thirty"},
    {e:"🕒",n:"three o’clock"},
    {e:"🕞",n:"three-thirty"},
    {e:"🕓",n:"four o’clock"},
    {e:"🕟",n:"four-thirty"},
    {e:"🕔",n:"five o’clock"},
    {e:"🕠",n:"five-thirty"},
    {e:"🕕",n:"six o’clock"},
    {e:"🕡",n:"six-thirty"},
    {e:"🕖",n:"seven o’clock"},
    {e:"🕢",n:"seven-thirty"},
    {e:"🕗",n:"eight o’clock"},
    {e:"🕣",n:"eight-thirty"},
    {e:"🕘",n:"nine o’clock"},
    {e:"🕤",n:"nine-thirty"},
    {e:"🕙",n:"ten o’clock"},
    {e:"🕥",n:"ten-thirty"},
    {e:"🕚",n:"eleven o’clock"},
    {e:"🕦",n:"eleven-thirty"},
    {e:"🌑",n:"new moon"},
    {e:"🌒",n:"waxing crescent moon"},
    {e:"🌓",n:"first quarter moon"},
    {e:"🌔",n:"waxing gibbous moon"},
    {e:"🌕",n:"full moon"},
    {e:"🌖",n:"waning gibbous moon"},
    {e:"🌗",n:"last quarter moon"},
    {e:"🌘",n:"waning crescent moon"},
    {e:"🌙",n:"crescent moon"},
    {e:"🌚",n:"new moon face"},
    {e:"🌛",n:"first quarter moon face"},
    {e:"🌜",n:"last quarter moon face"},
    {e:"🌡️",n:"thermometer"},
    {e:"☀️",n:"sun"},
    {e:"🌝",n:"full moon face"},
    {e:"🌞",n:"sun with face"},
    {e:"🪐",n:"ringed planet"},
    {e:"⭐",n:"star"},
    {e:"🌟",n:"glowing star"},
    {e:"🌠",n:"shooting star"},
    {e:"🌌",n:"milky way"},
    {e:"☁️",n:"cloud"},
    {e:"⛅",n:"sun behind cloud"},
    {e:"⛈️",n:"cloud with lightning and rain"},
    {e:"🌤️",n:"sun behind small cloud"},
    {e:"🌥️",n:"sun behind large cloud"},
    {e:"🌦️",n:"sun behind rain cloud"},
    {e:"🌧️",n:"cloud with rain"},
    {e:"🌨️",n:"cloud with snow"},
    {e:"🌩️",n:"cloud with lightning"},
    {e:"🌪️",n:"tornado"},
    {e:"🌫️",n:"fog"},
    {e:"🌬️",n:"wind face"},
    {e:"🌀",n:"cyclone"},
    {e:"🌈",n:"rainbow"},
    {e:"🌂",n:"closed umbrella"},
    {e:"☂️",n:"umbrella"},
    {e:"☔",n:"umbrella with rain drops"},
    {e:"⛱️",n:"umbrella on ground"},
    {e:"⚡",n:"high voltage"},
    {e:"❄️",n:"snowflake"},
    {e:"☃️",n:"snowman"},
    {e:"⛄",n:"snowman without snow"},
    {e:"☄️",n:"comet"},
    {e:"🔥",n:"fire"},
    {e:"💧",n:"droplet"},
    {e:"🌊",n:"water wave"}
  ],
  activities: [
    {e:"🎃",n:"jack-o-lantern"},
    {e:"🎄",n:"Christmas tree"},
    {e:"🎆",n:"fireworks"},
    {e:"🎇",n:"sparkler"},
    {e:"🧨",n:"firecracker"},
    {e:"✨",n:"sparkles"},
    {e:"🎈",n:"balloon"},
    {e:"🎉",n:"party popper"},
    {e:"🎊",n:"confetti ball"},
    {e:"🎋",n:"tanabata tree"},
    {e:"🎍",n:"pine decoration"},
    {e:"🎎",n:"Japanese dolls"},
    {e:"🎏",n:"carp streamer"},
    {e:"🎐",n:"wind chime"},
    {e:"🎑",n:"moon viewing ceremony"},
    {e:"🧧",n:"red envelope"},
    {e:"🎀",n:"ribbon"},
    {e:"🎁",n:"wrapped gift"},
    {e:"🎗️",n:"reminder ribbon"},
    {e:"🎟️",n:"admission tickets"},
    {e:"🎫",n:"ticket"},
    {e:"🎖️",n:"military medal"},
    {e:"🏆",n:"trophy"},
    {e:"🏅",n:"sports medal"},
    {e:"🥇",n:"1st place medal"},
    {e:"🥈",n:"2nd place medal"},
    {e:"🥉",n:"3rd place medal"},
    {e:"⚽",n:"soccer ball"},
    {e:"⚾",n:"baseball"},
    {e:"🥎",n:"softball"},
    {e:"🏀",n:"basketball"},
    {e:"🏐",n:"volleyball"},
    {e:"🏈",n:"american football"},
    {e:"🏉",n:"rugby football"},
    {e:"🎾",n:"tennis"},
    {e:"🥏",n:"flying disc"},
    {e:"🎳",n:"bowling"},
    {e:"🏏",n:"cricket game"},
    {e:"🏑",n:"field hockey"},
    {e:"🏒",n:"ice hockey"},
    {e:"🥍",n:"lacrosse"},
    {e:"🏓",n:"ping pong"},
    {e:"🏸",n:"badminton"},
    {e:"🥊",n:"boxing glove"},
    {e:"🥋",n:"martial arts uniform"},
    {e:"🥅",n:"goal net"},
    {e:"⛳",n:"flag in hole"},
    {e:"⛸️",n:"ice skate"},
    {e:"🎣",n:"fishing pole"},
    {e:"🤿",n:"diving mask"},
    {e:"🎽",n:"running shirt"},
    {e:"🎿",n:"skis"},
    {e:"🛷",n:"sled"},
    {e:"🥌",n:"curling stone"},
    {e:"🎯",n:"bullseye"},
    {e:"🪀",n:"yo-yo"},
    {e:"🪁",n:"kite"},
    {e:"🔫",n:"water pistol"},
    {e:"🎱",n:"pool 8 ball"},
    {e:"🔮",n:"crystal ball"},
    {e:"🪄",n:"magic wand"},
    {e:"🎮",n:"video game"},
    {e:"🕹️",n:"joystick"},
    {e:"🎰",n:"slot machine"},
    {e:"🎲",n:"game die"},
    {e:"🧩",n:"puzzle piece"},
    {e:"🧸",n:"teddy bear"},
    {e:"🪅",n:"piñata"},
    {e:"🪩",n:"mirror ball"},
    {e:"🪆",n:"nesting dolls"},
    {e:"♠️",n:"spade suit"},
    {e:"♥️",n:"heart suit"},
    {e:"♦️",n:"diamond suit"},
    {e:"♣️",n:"club suit"},
    {e:"♟️",n:"chess pawn"},
    {e:"🃏",n:"joker"},
    {e:"🀄",n:"mahjong red dragon"},
    {e:"🎴",n:"flower playing cards"},
    {e:"🎭",n:"performing arts"},
    {e:"🖼️",n:"framed picture"},
    {e:"🎨",n:"artist palette"},
    {e:"🧵",n:"thread"},
    {e:"🪡",n:"sewing needle"},
    {e:"🧶",n:"yarn"},
    {e:"🪢",n:"knot"}
  ],
  objects: [
    {e:"👓",n:"glasses"},
    {e:"🕶️",n:"sunglasses"},
    {e:"🥽",n:"goggles"},
    {e:"🥼",n:"lab coat"},
    {e:"🦺",n:"safety vest"},
    {e:"👔",n:"necktie"},
    {e:"👕",n:"t-shirt"},
    {e:"👖",n:"jeans"},
    {e:"🧣",n:"scarf"},
    {e:"🧤",n:"gloves"},
    {e:"🧥",n:"coat"},
    {e:"🧦",n:"socks"},
    {e:"👗",n:"dress"},
    {e:"👘",n:"kimono"},
    {e:"🥻",n:"sari"},
    {e:"🩱",n:"one-piece swimsuit"},
    {e:"🩲",n:"briefs"},
    {e:"🩳",n:"shorts"},
    {e:"👙",n:"bikini"},
    {e:"👚",n:"woman’s clothes"},
    {e:"🪭",n:"folding hand fan"},
    {e:"👛",n:"purse"},
    {e:"👜",n:"handbag"},
    {e:"👝",n:"clutch bag"},
    {e:"🛍️",n:"shopping bags"},
    {e:"🎒",n:"backpack"},
    {e:"🩴",n:"thong sandal"},
    {e:"👞",n:"man’s shoe"},
    {e:"👟",n:"running shoe"},
    {e:"🥾",n:"hiking boot"},
    {e:"🥿",n:"flat shoe"},
    {e:"👠",n:"high-heeled shoe"},
    {e:"👡",n:"woman’s sandal"},
    {e:"🩰",n:"ballet shoes"},
    {e:"👢",n:"woman’s boot"},
    {e:"🪮",n:"hair pick"},
    {e:"👑",n:"crown"},
    {e:"👒",n:"woman’s hat"},
    {e:"🎩",n:"top hat"},
    {e:"🎓",n:"graduation cap"},
    {e:"🧢",n:"billed cap"},
    {e:"🪖",n:"military helmet"},
    {e:"⛑️",n:"rescue worker’s helmet"},
    {e:"📿",n:"prayer beads"},
    {e:"💄",n:"lipstick"},
    {e:"💍",n:"ring"},
    {e:"💎",n:"gem stone"},
    {e:"🔇",n:"muted speaker"},
    {e:"🔈",n:"speaker low volume"},
    {e:"🔉",n:"speaker medium volume"},
    {e:"🔊",n:"speaker high volume"},
    {e:"📢",n:"loudspeaker"},
    {e:"📣",n:"megaphone"},
    {e:"📯",n:"postal horn"},
    {e:"🔔",n:"bell"},
    {e:"🔕",n:"bell with slash"},
    {e:"🎼",n:"musical score"},
    {e:"🎵",n:"musical note"},
    {e:"🎶",n:"musical notes"},
    {e:"🎙️",n:"studio microphone"},
    {e:"🎚️",n:"level slider"},
    {e:"🎛️",n:"control knobs"},
    {e:"🎤",n:"microphone"},
    {e:"🎧",n:"headphone"},
    {e:"📻",n:"radio"},
    {e:"🎷",n:"saxophone"},
    {e:"🪗",n:"accordion"},
    {e:"🎸",n:"guitar"},
    {e:"🎹",n:"musical keyboard"},
    {e:"🎺",n:"trumpet"},
    {e:"🎻",n:"violin"},
    {e:"🪕",n:"banjo"},
    {e:"🥁",n:"drum"},
    {e:"🪘",n:"long drum"},
    {e:"🪇",n:"maracas"},
    {e:"🪈",n:"flute"},
    {e:"🪉",n:"harp"},
    {e:"📱",n:"mobile phone"},
    {e:"📲",n:"mobile phone with arrow"},
    {e:"☎️",n:"telephone"},
    {e:"📞",n:"telephone receiver"},
    {e:"📟",n:"pager"},
    {e:"📠",n:"fax machine"},
    {e:"🔋",n:"battery"},
    {e:"🪫",n:"low battery"},
    {e:"🔌",n:"electric plug"},
    {e:"💻",n:"laptop"},
    {e:"🖥️",n:"desktop computer"},
    {e:"🖨️",n:"printer"},
    {e:"⌨️",n:"keyboard"},
    {e:"🖱️",n:"computer mouse"},
    {e:"🖲️",n:"trackball"},
    {e:"💽",n:"computer disk"},
    {e:"💾",n:"floppy disk"},
    {e:"💿",n:"optical disk"},
    {e:"📀",n:"dvd"},
    {e:"🧮",n:"abacus"},
    {e:"🎥",n:"movie camera"},
    {e:"🎞️",n:"film frames"},
    {e:"📽️",n:"film projector"},
    {e:"🎬",n:"clapper board"},
    {e:"📺",n:"television"},
    {e:"📷",n:"camera"},
    {e:"📸",n:"camera with flash"},
    {e:"📹",n:"video camera"},
    {e:"📼",n:"videocassette"},
    {e:"🔍",n:"magnifying glass tilted left"},
    {e:"🔎",n:"magnifying glass tilted right"},
    {e:"🕯️",n:"candle"},
    {e:"💡",n:"light bulb"},
    {e:"🔦",n:"flashlight"},
    {e:"🏮",n:"red paper lantern"},
    {e:"🪔",n:"diya lamp"},
    {e:"📔",n:"notebook with decorative cover"},
    {e:"📕",n:"closed book"},
    {e:"📖",n:"open book"},
    {e:"📗",n:"green book"},
    {e:"📘",n:"blue book"},
    {e:"📙",n:"orange book"},
    {e:"📚",n:"books"},
    {e:"📓",n:"notebook"},
    {e:"📒",n:"ledger"},
    {e:"📃",n:"page with curl"},
    {e:"📜",n:"scroll"},
    {e:"📄",n:"page facing up"},
    {e:"📰",n:"newspaper"},
    {e:"🗞️",n:"rolled-up newspaper"},
    {e:"📑",n:"bookmark tabs"},
    {e:"🔖",n:"bookmark"},
    {e:"🏷️",n:"label"},
    {e:"💰",n:"money bag"},
    {e:"🪙",n:"coin"},
    {e:"💴",n:"yen banknote"},
    {e:"💵",n:"dollar banknote"},
    {e:"💶",n:"euro banknote"},
    {e:"💷",n:"pound banknote"},
    {e:"💸",n:"money with wings"},
    {e:"💳",n:"credit card"},
    {e:"🧾",n:"receipt"},
    {e:"💹",n:"chart increasing with yen"},
    {e:"✉️",n:"envelope"},
    {e:"📧",n:"e-mail"},
    {e:"📨",n:"incoming envelope"},
    {e:"📩",n:"envelope with arrow"},
    {e:"📤",n:"outbox tray"},
    {e:"📥",n:"inbox tray"},
    {e:"📦",n:"package"},
    {e:"📫",n:"closed mailbox with raised flag"},
    {e:"📪",n:"closed mailbox with lowered flag"},
    {e:"📬",n:"open mailbox with raised flag"},
    {e:"📭",n:"open mailbox with lowered flag"},
    {e:"📮",n:"postbox"},
    {e:"🗳️",n:"ballot box with ballot"},
    {e:"✏️",n:"pencil"},
    {e:"✒️",n:"black nib"},
    {e:"🖋️",n:"fountain pen"},
    {e:"🖊️",n:"pen"},
    {e:"🖌️",n:"paintbrush"},
    {e:"🖍️",n:"crayon"},
    {e:"📝",n:"memo"},
    {e:"💼",n:"briefcase"},
    {e:"📁",n:"file folder"},
    {e:"📂",n:"open file folder"},
    {e:"🗂️",n:"card index dividers"},
    {e:"📅",n:"calendar"},
    {e:"📆",n:"tear-off calendar"},
    {e:"🗒️",n:"spiral notepad"},
    {e:"🗓️",n:"spiral calendar"},
    {e:"📇",n:"card index"},
    {e:"📈",n:"chart increasing"},
    {e:"📉",n:"chart decreasing"},
    {e:"📊",n:"bar chart"},
    {e:"📋",n:"clipboard"},
    {e:"📌",n:"pushpin"},
    {e:"📍",n:"round pushpin"},
    {e:"📎",n:"paperclip"},
    {e:"🖇️",n:"linked paperclips"},
    {e:"📏",n:"straight ruler"},
    {e:"📐",n:"triangular ruler"},
    {e:"✂️",n:"scissors"},
    {e:"🗃️",n:"card file box"},
    {e:"🗄️",n:"file cabinet"},
    {e:"🗑️",n:"wastebasket"},
    {e:"🔒",n:"locked"},
    {e:"🔓",n:"unlocked"},
    {e:"🔏",n:"locked with pen"},
    {e:"🔐",n:"locked with key"},
    {e:"🔑",n:"key"},
    {e:"🗝️",n:"old key"},
    {e:"🔨",n:"hammer"},
    {e:"🪓",n:"axe"},
    {e:"⛏️",n:"pick"},
    {e:"⚒️",n:"hammer and pick"},
    {e:"🛠️",n:"hammer and wrench"},
    {e:"🗡️",n:"dagger"},
    {e:"⚔️",n:"crossed swords"},
    {e:"💣",n:"bomb"},
    {e:"🪃",n:"boomerang"},
    {e:"🏹",n:"bow and arrow"},
    {e:"🛡️",n:"shield"},
    {e:"🪚",n:"carpentry saw"},
    {e:"🔧",n:"wrench"},
    {e:"🪛",n:"screwdriver"},
    {e:"🔩",n:"nut and bolt"},
    {e:"⚙️",n:"gear"},
    {e:"🗜️",n:"clamp"},
    {e:"⚖️",n:"balance scale"},
    {e:"🦯",n:"white cane"},
    {e:"🔗",n:"link"},
    {e:"⛓️‍💥",n:"broken chain"},
    {e:"⛓️",n:"chains"},
    {e:"🪝",n:"hook"},
    {e:"🧰",n:"toolbox"},
    {e:"🧲",n:"magnet"},
    {e:"🪜",n:"ladder"},
    {e:"🪏",n:"shovel"},
    {e:"⚗️",n:"alembic"},
    {e:"🧪",n:"test tube"},
    {e:"🧫",n:"petri dish"},
    {e:"🧬",n:"dna"},
    {e:"🔬",n:"microscope"},
    {e:"🔭",n:"telescope"},
    {e:"📡",n:"satellite antenna"},
    {e:"💉",n:"syringe"},
    {e:"🩸",n:"drop of blood"},
    {e:"💊",n:"pill"},
    {e:"🩹",n:"adhesive bandage"},
    {e:"🩼",n:"crutch"},
    {e:"🩺",n:"stethoscope"},
    {e:"🩻",n:"x-ray"},
    {e:"🚪",n:"door"},
    {e:"🛗",n:"elevator"},
    {e:"🪞",n:"mirror"},
    {e:"🪟",n:"window"},
    {e:"🛏️",n:"bed"},
    {e:"🛋️",n:"couch and lamp"},
    {e:"🪑",n:"chair"},
    {e:"🚽",n:"toilet"},
    {e:"🪠",n:"plunger"},
    {e:"🚿",n:"shower"},
    {e:"🛁",n:"bathtub"},
    {e:"🪤",n:"mouse trap"},
    {e:"🪒",n:"razor"},
    {e:"🧴",n:"lotion bottle"},
    {e:"🧷",n:"safety pin"},
    {e:"🧹",n:"broom"},
    {e:"🧺",n:"basket"},
    {e:"🧻",n:"roll of paper"},
    {e:"🪣",n:"bucket"},
    {e:"🧼",n:"soap"},
    {e:"🫧",n:"bubbles"},
    {e:"🪥",n:"toothbrush"},
    {e:"🧽",n:"sponge"},
    {e:"🧯",n:"fire extinguisher"},
    {e:"🛒",n:"shopping cart"},
    {e:"🚬",n:"cigarette"},
    {e:"⚰️",n:"coffin"},
    {e:"🪦",n:"headstone"},
    {e:"⚱️",n:"funeral urn"},
    {e:"🧿",n:"nazar amulet"},
    {e:"🪬",n:"hamsa"},
    {e:"🗿",n:"moai"},
    {e:"🪧",n:"placard"},
    {e:"🪪",n:"identification card"}
  ],
  symbols: [
    {e:"🏧",n:"ATM sign"},
    {e:"🚮",n:"litter in bin sign"},
    {e:"🚰",n:"potable water"},
    {e:"♿",n:"wheelchair symbol"},
    {e:"🚹",n:"men’s room"},
    {e:"🚺",n:"women’s room"},
    {e:"🚻",n:"restroom"},
    {e:"🚼",n:"baby symbol"},
    {e:"🚾",n:"water closet"},
    {e:"🛂",n:"passport control"},
    {e:"🛃",n:"customs"},
    {e:"🛄",n:"baggage claim"},
    {e:"🛅",n:"left luggage"},
    {e:"⚠️",n:"warning"},
    {e:"🚸",n:"children crossing"},
    {e:"⛔",n:"no entry"},
    {e:"🚫",n:"prohibited"},
    {e:"🚳",n:"no bicycles"},
    {e:"🚭",n:"no smoking"},
    {e:"🚯",n:"no littering"},
    {e:"🚱",n:"non-potable water"},
    {e:"🚷",n:"no pedestrians"},
    {e:"📵",n:"no mobile phones"},
    {e:"🔞",n:"no one under eighteen"},
    {e:"☢️",n:"radioactive"},
    {e:"☣️",n:"biohazard"},
    {e:"⬆️",n:"up arrow"},
    {e:"↗️",n:"up-right arrow"},
    {e:"➡️",n:"right arrow"},
    {e:"↘️",n:"down-right arrow"},
    {e:"⬇️",n:"down arrow"},
    {e:"↙️",n:"down-left arrow"},
    {e:"⬅️",n:"left arrow"},
    {e:"↖️",n:"up-left arrow"},
    {e:"↕️",n:"up-down arrow"},
    {e:"↔️",n:"left-right arrow"},
    {e:"↩️",n:"right arrow curving left"},
    {e:"↪️",n:"left arrow curving right"},
    {e:"⤴️",n:"right arrow curving up"},
    {e:"⤵️",n:"right arrow curving down"},
    {e:"🔃",n:"clockwise vertical arrows"},
    {e:"🔄",n:"counterclockwise arrows button"},
    {e:"🔙",n:"BACK arrow"},
    {e:"🔚",n:"END arrow"},
    {e:"🔛",n:"ON! arrow"},
    {e:"🔜",n:"SOON arrow"},
    {e:"🔝",n:"TOP arrow"},
    {e:"🛐",n:"place of worship"},
    {e:"⚛️",n:"atom symbol"},
    {e:"🕉️",n:"om"},
    {e:"✡️",n:"star of David"},
    {e:"☸️",n:"wheel of dharma"},
    {e:"☯️",n:"yin yang"},
    {e:"✝️",n:"latin cross"},
    {e:"☦️",n:"orthodox cross"},
    {e:"☪️",n:"star and crescent"},
    {e:"☮️",n:"peace symbol"},
    {e:"🕎",n:"menorah"},
    {e:"🔯",n:"dotted six-pointed star"},
    {e:"🪯",n:"khanda"},
    {e:"♈",n:"Aries"},
    {e:"♉",n:"Taurus"},
    {e:"♊",n:"Gemini"},
    {e:"♋",n:"Cancer"},
    {e:"♌",n:"Leo"},
    {e:"♍",n:"Virgo"},
    {e:"♎",n:"Libra"},
    {e:"♏",n:"Scorpio"},
    {e:"♐",n:"Sagittarius"},
    {e:"♑",n:"Capricorn"},
    {e:"♒",n:"Aquarius"},
    {e:"♓",n:"Pisces"},
    {e:"⛎",n:"Ophiuchus"},
    {e:"🔀",n:"shuffle tracks button"},
    {e:"🔁",n:"repeat button"},
    {e:"🔂",n:"repeat single button"},
    {e:"▶️",n:"play button"},
    {e:"⏩",n:"fast-forward button"},
    {e:"⏭️",n:"next track button"},
    {e:"⏯️",n:"play or pause button"},
    {e:"◀️",n:"reverse button"},
    {e:"⏪",n:"fast reverse button"},
    {e:"⏮️",n:"last track button"},
    {e:"🔼",n:"upwards button"},
    {e:"⏫",n:"fast up button"},
    {e:"🔽",n:"downwards button"},
    {e:"⏬",n:"fast down button"},
    {e:"⏸️",n:"pause button"},
    {e:"⏹️",n:"stop button"},
    {e:"⏺️",n:"record button"},
    {e:"⏏️",n:"eject button"},
    {e:"🎦",n:"cinema"},
    {e:"🔅",n:"dim button"},
    {e:"🔆",n:"bright button"},
    {e:"📶",n:"antenna bars"},
    {e:"🛜",n:"wireless"},
    {e:"📳",n:"vibration mode"},
    {e:"📴",n:"mobile phone off"},
    {e:"♀️",n:"female sign"},
    {e:"♂️",n:"male sign"},
    {e:"⚧️",n:"transgender symbol"},
    {e:"✖️",n:"multiply"},
    {e:"➕",n:"plus"},
    {e:"➖",n:"minus"},
    {e:"➗",n:"divide"},
    {e:"🟰",n:"heavy equals sign"},
    {e:"♾️",n:"infinity"},
    {e:"‼️",n:"double exclamation mark"},
    {e:"⁉️",n:"exclamation question mark"},
    {e:"❓",n:"red question mark"},
    {e:"❔",n:"white question mark"},
    {e:"❕",n:"white exclamation mark"},
    {e:"❗",n:"red exclamation mark"},
    {e:"〰️",n:"wavy dash"},
    {e:"💱",n:"currency exchange"},
    {e:"💲",n:"heavy dollar sign"},
    {e:"⚕️",n:"medical symbol"},
    {e:"♻️",n:"recycling symbol"},
    {e:"⚜️",n:"fleur-de-lis"},
    {e:"🔱",n:"trident emblem"},
    {e:"📛",n:"name badge"},
    {e:"🔰",n:"Japanese symbol for beginner"},
    {e:"⭕",n:"hollow red circle"},
    {e:"✅",n:"check mark button"},
    {e:"☑️",n:"check box with check"},
    {e:"✔️",n:"check mark"},
    {e:"❌",n:"cross mark"},
    {e:"❎",n:"cross mark button"},
    {e:"➰",n:"curly loop"},
    {e:"➿",n:"double curly loop"},
    {e:"〽️",n:"part alternation mark"},
    {e:"✳️",n:"eight-spoked asterisk"},
    {e:"✴️",n:"eight-pointed star"},
    {e:"❇️",n:"sparkle"},
    {e:"©️",n:"copyright"},
    {e:"®️",n:"registered"},
    {e:"™️",n:"trade mark"},
    {e:"🫟",n:"splatter"},
    {e:"#️⃣",n:"keycap #"},
    {e:"*️⃣",n:"keycap *"},
    {e:"0️⃣",n:"keycap 0"},
    {e:"1️⃣",n:"keycap 1"},
    {e:"2️⃣",n:"keycap 2"},
    {e:"3️⃣",n:"keycap 3"},
    {e:"4️⃣",n:"keycap 4"},
    {e:"5️⃣",n:"keycap 5"},
    {e:"6️⃣",n:"keycap 6"},
    {e:"7️⃣",n:"keycap 7"},
    {e:"8️⃣",n:"keycap 8"},
    {e:"9️⃣",n:"keycap 9"},
    {e:"🔟",n:"keycap 10"},
    {e:"🔠",n:"input latin uppercase"},
    {e:"🔡",n:"input latin lowercase"},
    {e:"🔢",n:"input numbers"},
    {e:"🔣",n:"input symbols"},
    {e:"🔤",n:"input latin letters"},
    {e:"🅰️",n:"A button (blood type)"},
    {e:"🆎",n:"AB button (blood type)"},
    {e:"🅱️",n:"B button (blood type)"},
    {e:"🆑",n:"CL button"},
    {e:"🆒",n:"COOL button"},
    {e:"🆓",n:"FREE button"},
    {e:"ℹ️",n:"information"},
    {e:"🆔",n:"ID button"},
    {e:"Ⓜ️",n:"circled M"},
    {e:"🆕",n:"NEW button"},
    {e:"🆖",n:"NG button"},
    {e:"🅾️",n:"O button (blood type)"},
    {e:"🆗",n:"OK button"},
    {e:"🅿️",n:"P button"},
    {e:"🆘",n:"SOS button"},
    {e:"🆙",n:"UP! button"},
    {e:"🆚",n:"VS button"},
    {e:"🈁",n:"Japanese “here” button"},
    {e:"🈂️",n:"Japanese “service charge” button"},
    {e:"🈷️",n:"Japanese “monthly amount” button"},
    {e:"🈶",n:"Japanese “not free of charge” button"},
    {e:"🈯",n:"Japanese “reserved” button"},
    {e:"🉐",n:"Japanese “bargain” button"},
    {e:"🈹",n:"Japanese “discount” button"},
    {e:"🈚",n:"Japanese “free of charge” button"},
    {e:"🈲",n:"Japanese “prohibited” button"},
    {e:"🉑",n:"Japanese “acceptable” button"},
    {e:"🈸",n:"Japanese “application” button"},
    {e:"🈴",n:"Japanese “passing grade” button"},
    {e:"🈳",n:"Japanese “vacancy” button"},
    {e:"㊗️",n:"Japanese “congratulations” button"},
    {e:"㊙️",n:"Japanese “secret” button"},
    {e:"🈺",n:"Japanese “open for business” button"},
    {e:"🈵",n:"Japanese “no vacancy” button"},
    {e:"🔴",n:"red circle"},
    {e:"🟠",n:"orange circle"},
    {e:"🟡",n:"yellow circle"},
    {e:"🟢",n:"green circle"},
    {e:"🔵",n:"blue circle"},
    {e:"🟣",n:"purple circle"},
    {e:"🟤",n:"brown circle"},
    {e:"⚫",n:"black circle"},
    {e:"⚪",n:"white circle"},
    {e:"🟥",n:"red square"},
    {e:"🟧",n:"orange square"},
    {e:"🟨",n:"yellow square"},
    {e:"🟩",n:"green square"},
    {e:"🟦",n:"blue square"},
    {e:"🟪",n:"purple square"},
    {e:"🟫",n:"brown square"},
    {e:"⬛",n:"black large square"},
    {e:"⬜",n:"white large square"},
    {e:"◼️",n:"black medium square"},
    {e:"◻️",n:"white medium square"},
    {e:"◾",n:"black medium-small square"},
    {e:"◽",n:"white medium-small square"},
    {e:"▪️",n:"black small square"},
    {e:"▫️",n:"white small square"},
    {e:"🔶",n:"large orange diamond"},
    {e:"🔷",n:"large blue diamond"},
    {e:"🔸",n:"small orange diamond"},
    {e:"🔹",n:"small blue diamond"},
    {e:"🔺",n:"red triangle pointed up"},
    {e:"🔻",n:"red triangle pointed down"},
    {e:"💠",n:"diamond with a dot"},
    {e:"🔘",n:"radio button"},
    {e:"🔳",n:"white square button"},
    {e:"🔲",n:"black square button"}
  ],
  flags: [
    {e:"🏁",n:"chequered flag"},
    {e:"🚩",n:"triangular flag"},
    {e:"🎌",n:"crossed flags"},
    {e:"🏴",n:"black flag"},
    {e:"🏳️",n:"white flag"},
    {e:"🏳️‍🌈",n:"rainbow flag"},
    {e:"🏳️‍⚧️",n:"transgender flag"},
    {e:"🏴‍☠️",n:"pirate flag"},
    {e:"🇦🇨",n:"flag Ascension Island"},
    {e:"🇦🇩",n:"flag Andorra"},
    {e:"🇦🇪",n:"flag United Arab Emirates"},
    {e:"🇦🇫",n:"flag Afghanistan"},
    {e:"🇦🇬",n:"flag Antigua & Barbuda"},
    {e:"🇦🇮",n:"flag Anguilla"},
    {e:"🇦🇱",n:"flag Albania"},
    {e:"🇦🇲",n:"flag Armenia"},
    {e:"🇦🇴",n:"flag Angola"},
    {e:"🇦🇶",n:"flag Antarctica"},
    {e:"🇦🇷",n:"flag Argentina"},
    {e:"🇦🇸",n:"flag American Samoa"},
    {e:"🇦🇹",n:"flag Austria"},
    {e:"🇦🇺",n:"flag Australia"},
    {e:"🇦🇼",n:"flag Aruba"},
    {e:"🇦🇽",n:"flag Åland Islands"},
    {e:"🇦🇿",n:"flag Azerbaijan"},
    {e:"🇧🇦",n:"flag Bosnia & Herzegovina"},
    {e:"🇧🇧",n:"flag Barbados"},
    {e:"🇧🇩",n:"flag Bangladesh"},
    {e:"🇧🇪",n:"flag Belgium"},
    {e:"🇧🇫",n:"flag Burkina Faso"},
    {e:"🇧🇬",n:"flag Bulgaria"},
    {e:"🇧🇭",n:"flag Bahrain"},
    {e:"🇧🇮",n:"flag Burundi"},
    {e:"🇧🇯",n:"flag Benin"},
    {e:"🇧🇱",n:"flag St. Barthélemy"},
    {e:"🇧🇲",n:"flag Bermuda"},
    {e:"🇧🇳",n:"flag Brunei"},
    {e:"🇧🇴",n:"flag Bolivia"},
    {e:"🇧🇶",n:"flag Caribbean Netherlands"},
    {e:"🇧🇷",n:"flag Brazil"},
    {e:"🇧🇸",n:"flag Bahamas"},
    {e:"🇧🇹",n:"flag Bhutan"},
    {e:"🇧🇻",n:"flag Bouvet Island"},
    {e:"🇧🇼",n:"flag Botswana"},
    {e:"🇧🇾",n:"flag Belarus"},
    {e:"🇧🇿",n:"flag Belize"},
    {e:"🇨🇦",n:"flag Canada"},
    {e:"🇨🇨",n:"flag Cocos (Keeling) Islands"},
    {e:"🇨🇩",n:"flag Congo - Kinshasa"},
    {e:"🇨🇫",n:"flag Central African Republic"},
    {e:"🇨🇬",n:"flag Congo - Brazzaville"},
    {e:"🇨🇭",n:"flag Switzerland"},
    {e:"🇨🇮",n:"flag Côte d’Ivoire"},
    {e:"🇨🇰",n:"flag Cook Islands"},
    {e:"🇨🇱",n:"flag Chile"},
    {e:"🇨🇲",n:"flag Cameroon"},
    {e:"🇨🇳",n:"flag China"},
    {e:"🇨🇴",n:"flag Colombia"},
    {e:"🇨🇵",n:"flag Clipperton Island"},
    {e:"🇨🇶",n:"flag Sark"},
    {e:"🇨🇷",n:"flag Costa Rica"},
    {e:"🇨🇺",n:"flag Cuba"},
    {e:"🇨🇻",n:"flag Cape Verde"},
    {e:"🇨🇼",n:"flag Curaçao"},
    {e:"🇨🇽",n:"flag Christmas Island"},
    {e:"🇨🇾",n:"flag Cyprus"},
    {e:"🇨🇿",n:"flag Czechia"},
    {e:"🇩🇪",n:"flag Germany"},
    {e:"🇩🇬",n:"flag Diego Garcia"},
    {e:"🇩🇯",n:"flag Djibouti"},
    {e:"🇩🇰",n:"flag Denmark"},
    {e:"🇩🇲",n:"flag Dominica"},
    {e:"🇩🇴",n:"flag Dominican Republic"},
    {e:"🇩🇿",n:"flag Algeria"},
    {e:"🇪🇦",n:"flag Ceuta & Melilla"},
    {e:"🇪🇨",n:"flag Ecuador"},
    {e:"🇪🇪",n:"flag Estonia"},
    {e:"🇪🇬",n:"flag Egypt"},
    {e:"🇪🇭",n:"flag Western Sahara"},
    {e:"🇪🇷",n:"flag Eritrea"},
    {e:"🇪🇸",n:"flag Spain"},
    {e:"🇪🇹",n:"flag Ethiopia"},
    {e:"🇪🇺",n:"flag European Union"},
    {e:"🇫🇮",n:"flag Finland"},
    {e:"🇫🇯",n:"flag Fiji"},
    {e:"🇫🇰",n:"flag Falkland Islands"},
    {e:"🇫🇲",n:"flag Micronesia"},
    {e:"🇫🇴",n:"flag Faroe Islands"},
    {e:"🇫🇷",n:"flag France"},
    {e:"🇬🇦",n:"flag Gabon"},
    {e:"🇬🇧",n:"flag United Kingdom"},
    {e:"🇬🇩",n:"flag Grenada"},
    {e:"🇬🇪",n:"flag Georgia"},
    {e:"🇬🇫",n:"flag French Guiana"},
    {e:"🇬🇬",n:"flag Guernsey"},
    {e:"🇬🇭",n:"flag Ghana"},
    {e:"🇬🇮",n:"flag Gibraltar"},
    {e:"🇬🇱",n:"flag Greenland"},
    {e:"🇬🇲",n:"flag Gambia"},
    {e:"🇬🇳",n:"flag Guinea"},
    {e:"🇬🇵",n:"flag Guadeloupe"},
    {e:"🇬🇶",n:"flag Equatorial Guinea"},
    {e:"🇬🇷",n:"flag Greece"},
    {e:"🇬🇸",n:"flag South Georgia & South Sandwich Islands"},
    {e:"🇬🇹",n:"flag Guatemala"},
    {e:"🇬🇺",n:"flag Guam"},
    {e:"🇬🇼",n:"flag Guinea-Bissau"},
    {e:"🇬🇾",n:"flag Guyana"},
    {e:"🇭🇰",n:"flag Hong Kong SAR China"},
    {e:"🇭🇲",n:"flag Heard & McDonald Islands"},
    {e:"🇭🇳",n:"flag Honduras"},
    {e:"🇭🇷",n:"flag Croatia"},
    {e:"🇭🇹",n:"flag Haiti"},
    {e:"🇭🇺",n:"flag Hungary"},
    {e:"🇮🇨",n:"flag Canary Islands"},
    {e:"🇮🇩",n:"flag Indonesia"},
    {e:"🇮🇪",n:"flag Ireland"},
    {e:"🇮🇱",n:"flag Israel"},
    {e:"🇮🇲",n:"flag Isle of Man"},
    {e:"🇮🇳",n:"flag India"},
    {e:"🇮🇴",n:"flag British Indian Ocean Territory"},
    {e:"🇮🇶",n:"flag Iraq"},
    {e:"🇮🇷",n:"flag Iran"},
    {e:"🇮🇸",n:"flag Iceland"},
    {e:"🇮🇹",n:"flag Italy"},
    {e:"🇯🇪",n:"flag Jersey"},
    {e:"🇯🇲",n:"flag Jamaica"},
    {e:"🇯🇴",n:"flag Jordan"},
    {e:"🇯🇵",n:"flag Japan"},
    {e:"🇰🇪",n:"flag Kenya"},
    {e:"🇰🇬",n:"flag Kyrgyzstan"},
    {e:"🇰🇭",n:"flag Cambodia"},
    {e:"🇰🇮",n:"flag Kiribati"},
    {e:"🇰🇲",n:"flag Comoros"},
    {e:"🇰🇳",n:"flag St. Kitts & Nevis"},
    {e:"🇰🇵",n:"flag North Korea"},
    {e:"🇰🇷",n:"flag South Korea"},
    {e:"🇰🇼",n:"flag Kuwait"},
    {e:"🇰🇾",n:"flag Cayman Islands"},
    {e:"🇰🇿",n:"flag Kazakhstan"},
    {e:"🇱🇦",n:"flag Laos"},
    {e:"🇱🇧",n:"flag Lebanon"},
    {e:"🇱🇨",n:"flag St. Lucia"},
    {e:"🇱🇮",n:"flag Liechtenstein"},
    {e:"🇱🇰",n:"flag Sri Lanka"},
    {e:"🇱🇷",n:"flag Liberia"},
    {e:"🇱🇸",n:"flag Lesotho"},
    {e:"🇱🇹",n:"flag Lithuania"},
    {e:"🇱🇺",n:"flag Luxembourg"},
    {e:"🇱🇻",n:"flag Latvia"},
    {e:"🇱🇾",n:"flag Libya"},
    {e:"🇲🇦",n:"flag Morocco"},
    {e:"🇲🇨",n:"flag Monaco"},
    {e:"🇲🇩",n:"flag Moldova"},
    {e:"🇲🇪",n:"flag Montenegro"},
    {e:"🇲🇫",n:"flag St. Martin"},
    {e:"🇲🇬",n:"flag Madagascar"},
    {e:"🇲🇭",n:"flag Marshall Islands"},
    {e:"🇲🇰",n:"flag North Macedonia"},
    {e:"🇲🇱",n:"flag Mali"},
    {e:"🇲🇲",n:"flag Myanmar (Burma)"},
    {e:"🇲🇳",n:"flag Mongolia"},
    {e:"🇲🇴",n:"flag Macao SAR China"},
    {e:"🇲🇵",n:"flag Northern Mariana Islands"},
    {e:"🇲🇶",n:"flag Martinique"},
    {e:"🇲🇷",n:"flag Mauritania"},
    {e:"🇲🇸",n:"flag Montserrat"},
    {e:"🇲🇹",n:"flag Malta"},
    {e:"🇲🇺",n:"flag Mauritius"},
    {e:"🇲🇻",n:"flag Maldives"},
    {e:"🇲🇼",n:"flag Malawi"},
    {e:"🇲🇽",n:"flag Mexico"},
    {e:"🇲🇾",n:"flag Malaysia"},
    {e:"🇲🇿",n:"flag Mozambique"},
    {e:"🇳🇦",n:"flag Namibia"},
    {e:"🇳🇨",n:"flag New Caledonia"},
    {e:"🇳🇪",n:"flag Niger"},
    {e:"🇳🇫",n:"flag Norfolk Island"},
    {e:"🇳🇬",n:"flag Nigeria"},
    {e:"🇳🇮",n:"flag Nicaragua"},
    {e:"🇳🇱",n:"flag Netherlands"},
    {e:"🇳🇴",n:"flag Norway"},
    {e:"🇳🇵",n:"flag Nepal"},
    {e:"🇳🇷",n:"flag Nauru"},
    {e:"🇳🇺",n:"flag Niue"},
    {e:"🇳🇿",n:"flag New Zealand"},
    {e:"🇴🇲",n:"flag Oman"},
    {e:"🇵🇦",n:"flag Panama"},
    {e:"🇵🇪",n:"flag Peru"},
    {e:"🇵🇫",n:"flag French Polynesia"},
    {e:"🇵🇬",n:"flag Papua New Guinea"},
    {e:"🇵🇭",n:"flag Philippines"},
    {e:"🇵🇰",n:"flag Pakistan"},
    {e:"🇵🇱",n:"flag Poland"},
    {e:"🇵🇲",n:"flag St. Pierre & Miquelon"},
    {e:"🇵🇳",n:"flag Pitcairn Islands"},
    {e:"🇵🇷",n:"flag Puerto Rico"},
    {e:"🇵🇸",n:"flag Palestinian Territories"},
    {e:"🇵🇹",n:"flag Portugal"},
    {e:"🇵🇼",n:"flag Palau"},
    {e:"🇵🇾",n:"flag Paraguay"},
    {e:"🇶🇦",n:"flag Qatar"},
    {e:"🇷🇪",n:"flag Réunion"},
    {e:"🇷🇴",n:"flag Romania"},
    {e:"🇷🇸",n:"flag Serbia"},
    {e:"🇷🇺",n:"flag Russia"},
    {e:"🇷🇼",n:"flag Rwanda"},
    {e:"🇸🇦",n:"flag Saudi Arabia"},
    {e:"🇸🇧",n:"flag Solomon Islands"},
    {e:"🇸🇨",n:"flag Seychelles"},
    {e:"🇸🇩",n:"flag Sudan"},
    {e:"🇸🇪",n:"flag Sweden"},
    {e:"🇸🇬",n:"flag Singapore"},
    {e:"🇸🇭",n:"flag St. Helena"},
    {e:"🇸🇮",n:"flag Slovenia"},
    {e:"🇸🇯",n:"flag Svalbard & Jan Mayen"},
    {e:"🇸🇰",n:"flag Slovakia"},
    {e:"🇸🇱",n:"flag Sierra Leone"},
    {e:"🇸🇲",n:"flag San Marino"},
    {e:"🇸🇳",n:"flag Senegal"},
    {e:"🇸🇴",n:"flag Somalia"},
    {e:"🇸🇷",n:"flag Suriname"},
    {e:"🇸🇸",n:"flag South Sudan"},
    {e:"🇸🇹",n:"flag São Tomé & Príncipe"},
    {e:"🇸🇻",n:"flag El Salvador"},
    {e:"🇸🇽",n:"flag Sint Maarten"},
    {e:"🇸🇾",n:"flag Syria"},
    {e:"🇸🇿",n:"flag Eswatini"},
    {e:"🇹🇦",n:"flag Tristan da Cunha"},
    {e:"🇹🇨",n:"flag Turks & Caicos Islands"},
    {e:"🇹🇩",n:"flag Chad"},
    {e:"🇹🇫",n:"flag French Southern Territories"},
    {e:"🇹🇬",n:"flag Togo"},
    {e:"🇹🇭",n:"flag Thailand"},
    {e:"🇹🇯",n:"flag Tajikistan"},
    {e:"🇹🇰",n:"flag Tokelau"},
    {e:"🇹🇱",n:"flag Timor-Leste"},
    {e:"🇹🇲",n:"flag Turkmenistan"},
    {e:"🇹🇳",n:"flag Tunisia"},
    {e:"🇹🇴",n:"flag Tonga"},
    {e:"🇹🇷",n:"flag Türkiye"},
    {e:"🇹🇹",n:"flag Trinidad & Tobago"},
    {e:"🇹🇻",n:"flag Tuvalu"},
    {e:"🇹🇼",n:"flag Taiwan"},
    {e:"🇹🇿",n:"flag Tanzania"},
    {e:"🇺🇦",n:"flag Ukraine"},
    {e:"🇺🇬",n:"flag Uganda"},
    {e:"🇺🇲",n:"flag U.S. Outlying Islands"},
    {e:"🇺🇳",n:"flag United Nations"},
    {e:"🇺🇸",n:"flag United States"},
    {e:"🇺🇾",n:"flag Uruguay"},
    {e:"🇺🇿",n:"flag Uzbekistan"},
    {e:"🇻🇦",n:"flag Vatican City"},
    {e:"🇻🇨",n:"flag St. Vincent & Grenadines"},
    {e:"🇻🇪",n:"flag Venezuela"},
    {e:"🇻🇬",n:"flag British Virgin Islands"},
    {e:"🇻🇮",n:"flag U.S. Virgin Islands"},
    {e:"🇻🇳",n:"flag Vietnam"},
    {e:"🇻🇺",n:"flag Vanuatu"},
    {e:"🇼🇫",n:"flag Wallis & Futuna"},
    {e:"🇼🇸",n:"flag Samoa"},
    {e:"🇽🇰",n:"flag Kosovo"},
    {e:"🇾🇪",n:"flag Yemen"},
    {e:"🇾🇹",n:"flag Mayotte"},
    {e:"🇿🇦",n:"flag South Africa"},
    {e:"🇿🇲",n:"flag Zambia"},
    {e:"🇿🇼",n:"flag Zimbabwe"},
    {e:"🏴󠁧󠁢󠁥󠁮󠁧󠁿",n:"flag England"},
    {e:"🏴󠁧󠁢󠁳󠁣󠁴󠁿",n:"flag Scotland"},
    {e:"🏴󠁧󠁢󠁷󠁬󠁳󠁿",n:"flag Wales"}
  ]
};
function EmojiPicker({ onSelect }) {
  const [isOpen, setIsOpen] = useState(false);
  const [category, setCategory] = useState("smileys");
  const [search, setSearch] = useState("");
  const [selectedSkinTone, setSelectedSkinTone] = useState(0);
  const [skinTonePopup, setSkinTonePopup] = useState(null);
  const [recentEmojis, setRecentEmojis] = useState(() => {
    try { return JSON.parse(localStorage.getItem('recentEmojis') || '[]').slice(0, 32); } catch { return []; }
  });
  const searchRef = useRef(null);
  
  const handleSelect = (emoji) => {
    // Apply skin tone if supported
    const finalEmoji = supportsSkinTone(emoji) ? applySkinTone(emoji, skinTones[selectedSkinTone].code) : emoji;
    onSelect(finalEmoji);
    // Add to recent
    const newRecent = [emoji, ...recentEmojis.filter(e => e !== emoji)].slice(0, 32);
    setRecentEmojis(newRecent);
    try { localStorage.setItem('recentEmojis', JSON.stringify(newRecent)); } catch {}
    setIsOpen(false);
  };
  
  const handleLongPress = (emoji, e) => {
    if (supportsSkinTone(emoji)) {
      e.preventDefault();
      setSkinTonePopup({ emoji, x: e.clientX, y: e.clientY });
    }
  };
  
  const selectWithSkinTone = (emoji, toneIndex) => {
    const finalEmoji = applySkinTone(emoji, skinTones[toneIndex].code);
    onSelect(finalEmoji);
    setSkinTonePopup(null);
    setIsOpen(false);
  };
  
  // Filter emojis by search
  const getFilteredEmojis = () => {
    if (!search.trim()) {
      if (category === "recent") return recentEmojis.map(e => ({e, n: "recent"}));
      return emojiData[category] || [];
    }
    const q = search.toLowerCase();
    const results = [];
    Object.values(emojiData).forEach(arr => {
      arr.forEach(item => {
        if (item.n && item.n.toLowerCase().includes(q)) results.push(item);
      });
    });
    return results.slice(0, 100);
  };
  
  const filteredEmojis = getFilteredEmojis();
  const categories = Object.keys(emojiCategories);
  
  return (
    <div className="relative">
      <button 
        type="button"
        onClick={() => { setIsOpen(!isOpen); setTimeout(() => searchRef.current?.focus(), 50); }} 
        className="px-1 py-0.5 bg-gray-600 hover:bg-gray-500 rounded text-[9px]" 
        title="Emoji Keyboard"
        style={{ fontFamily: emojiFontStack }}
      >
        😀
      </button>
      {isOpen && (
        <>
          <div className="fixed inset-0 z-[100]" onClick={() => { setIsOpen(false); setSkinTonePopup(null); }} />
          <div className="absolute top-full left-0 mt-1 bg-gray-800 rounded-lg shadow-2xl z-[101] w-[320px] border border-gray-600">
            {/* Search & Skin Tone */}
            <div className="flex items-center gap-1 p-2 border-b border-gray-700">
              <input
                ref={searchRef}
                type="text"
                placeholder="Search emoji..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 px-2 py-1 bg-gray-700 text-white text-xs rounded border border-gray-600 outline-none focus:border-blue-500"
              />
              {/* Skin tone selector */}
              <div className="relative group">
                <button
                  type="button"
                  className="w-6 h-6 rounded-full border-2 border-gray-500 hover:border-blue-400"
                  style={{ backgroundColor: skinTones[selectedSkinTone].color }}
                  title="Skin Tone"
                />
                <div className="absolute right-0 top-full mt-1 p-1 bg-gray-700 rounded shadow-lg hidden group-hover:flex gap-1 z-[102]">
                  {skinTones.map((tone, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setSelectedSkinTone(i)}
                      className={`w-5 h-5 rounded-full border-2 ${selectedSkinTone === i ? 'border-blue-400' : 'border-gray-500'}`}
                      style={{ backgroundColor: tone.color }}
                      title={tone.label}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            {/* Category tabs */}
            <div className="flex p-1 border-b border-gray-700 gap-0.5 overflow-x-auto">
              {categories.map((cat) => (
                <button 
                  key={cat} 
                  type="button"
                  onClick={() => { setCategory(cat); setSearch(""); }}
                  className={`px-1.5 py-1 rounded text-base flex-shrink-0 transition-colors ${category === cat ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}
                  style={{ fontFamily: emojiFontStack }}
                  title={emojiCategories[cat].name}
                >
                  {emojiCategories[cat].icon}
                </button>
              ))}
            </div>
            
            {/* Emoji grid (keyboard style) */}
            <div className="p-2 grid grid-cols-8 gap-0.5 max-h-[220px] overflow-y-auto">
              {filteredEmojis.length === 0 && (
                <div className="col-span-8 text-center text-gray-400 text-xs py-4">
                  {category === "recent" ? "No recent emojis" : "No emojis found"}
                </div>
              )}
              {filteredEmojis.map((item, i) => {
                const emoji = item.e || item;
                const name = item.n || "";
                const hasSkinTone = supportsSkinTone(emoji);
                const displayEmoji = hasSkinTone ? applySkinTone(emoji, skinTones[selectedSkinTone].code) : emoji;
                
                return (
                  <button 
                    key={i} 
                    type="button"
                    onClick={() => handleSelect(emoji)}
                    onContextMenu={(e) => handleLongPress(emoji, e)}
                    className={`w-8 h-8 flex items-center justify-center text-xl hover:bg-gray-600 rounded cursor-pointer relative ${hasSkinTone ? 'ring-1 ring-yellow-500/30' : ''}`}
                    style={{ fontFamily: emojiFontStack }}
                    title={name + (hasSkinTone ? " (right-click for skin tones)" : "")}
                  >
                    {displayEmoji}
                    {hasSkinTone && <span className="absolute bottom-0 right-0 w-1.5 h-1.5 bg-yellow-500 rounded-full" />}
                  </button>
                );
              })}
            </div>
            
            {/* Footer with count */}
            <div className="px-2 py-1 border-t border-gray-700 text-[10px] text-gray-500">
              {search ? `${filteredEmojis.length} results` : `${emojiCategories[category]?.name || category}`}
              {" • "}Right-click emoji with 🟡 dot for skin tones
            </div>
          </div>
          
          {/* Skin tone popup */}
          {skinTonePopup && (
            <div 
              className="fixed bg-gray-800 rounded-lg shadow-2xl p-2 z-[103] border border-gray-600"
              style={{ left: skinTonePopup.x, top: skinTonePopup.y }}
            >
              <div className="flex gap-1">
                {skinTones.map((tone, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => selectWithSkinTone(skinTonePopup.emoji, i)}
                    className="w-8 h-8 flex items-center justify-center text-xl hover:bg-gray-600 rounded"
                    style={{ fontFamily: emojiFontStack }}
                    title={tone.label}
                  >
                    {applySkinTone(skinTonePopup.emoji, tone.code)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// === EMOJI KEYBOARD MODE (live Unicode parsing) ===

// Map Unicode groups to our categories
const groupToCategory = {
  "Smileys & Emotion": "smileys",
  "People & Body": "people", 
  "Component": null,
  "Animals & Nature": "animals",
  "Food & Drink": "food",
  "Travel & Places": "travel",
  "Activities": "activities",
  "Objects": "objects",
  "Symbols": "symbols",
  "Flags": "flags"
};

// Skin tone code points
const skinToneCodes = new Set(["1F3FB", "1F3FC", "1F3FD", "1F3FE", "1F3FF"]);

// Parse Unicode emoji-test.txt format
function parseEmojiTestData(text) {
  const categories = { smileys: [], people: [], animals: [], food: [], travel: [], activities: [], objects: [], symbols: [], flags: [] };
  const skinToneVariants = new Map();
  const lines = text.split('\n');
  let currentGroup = null;
  const allEmojis = [];
  
  for (const line of lines) {
    if (line.startsWith('# group:')) { currentGroup = line.slice(9).trim(); continue; }
    if (!line.trim() || line.startsWith('#')) continue;
    const match = line.match(/^([0-9A-F\s]+)\s*;\s*([\w-]+)\s*#\s*(.+)$/i);
    if (!match) continue;
    const [, codePointsStr, status, rest] = match;
    if (status !== 'fully-qualified') continue;
    const codePoints = codePointsStr.trim().split(/\s+/);
    const hasSkinTone = codePoints.some(cp => skinToneCodes.has(cp.toUpperCase()));
    if (hasSkinTone) { skinToneVariants.set(codePoints[0], true); continue; }
    const restMatch = rest.match(/^(\S+)\s+E[\d.]+\s+(.+)$/);
    if (!restMatch) continue;
    const [, emoji, name] = restMatch;
    const category = groupToCategory[currentGroup];
    if (category) allEmojis.push({ emoji, name, category, baseCodePoint: codePoints[0] });
  }
  
  const skinToneSupported = new Set();
  for (const item of allEmojis) {
    if (skinToneVariants.has(item.baseCodePoint)) skinToneSupported.add(item.emoji);
    categories[item.category].push({ e: item.emoji, n: item.name, s: skinToneVariants.has(item.baseCodePoint) ? 1 : undefined });
  }
  return { categories, skinToneSupported };
}

// Emoji Keyboard Component - FULL keyboard mode (not toolbar popup)
function EmojiKeyboard({ onSelect, keyboardStyle }) {
  const [liveEmojiData, setLiveEmojiData] = useState(null);
  const [skinToneSet, setSkinToneSet] = useState(skinToneSupportedEmojis);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [category, setCategory] = useState("smileys");
  const [search, setSearch] = useState("");
  const [selectedSkinTone, setSelectedSkinTone] = useState(0);
  const [skinTonePopup, setSkinTonePopup] = useState(null);
  const [recentEmojis, setRecentEmojis] = useState(() => {
    try { return JSON.parse(localStorage.getItem('recentEmojis') || '[]').slice(0, 32); } catch { return []; }
  });

  useEffect(() => {
    async function loadEmojis() {
      try {
        setLoading(true);
        const response = await fetch('https://www.unicode.org/Public/emoji/latest/emoji-test.txt');
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const text = await response.text();
        const { categories, skinToneSupported } = parseEmojiTestData(text);
        setLiveEmojiData(categories);
        setSkinToneSet(skinToneSupported);
        setError(null);
      } catch (e) {
        console.warn('Using fallback emoji data:', e.message);
        setLiveEmojiData(emojiData);
        setSkinToneSet(skinToneSupportedEmojis);
        setError('Using offline data');
      } finally { setLoading(false); }
    }
    loadEmojis();
  }, []);

  const localSupportsSkinTone = (emoji) => skinToneSet.has(emoji) || skinToneSet.has([...emoji][0]);
  const handleSelect = (emoji) => {
    const finalEmoji = localSupportsSkinTone(emoji) ? applySkinTone(emoji, skinTones[selectedSkinTone].code) : emoji;
    onSelect(finalEmoji);
    const newRecent = [emoji, ...recentEmojis.filter(e => e !== emoji)].slice(0, 32);
    setRecentEmojis(newRecent);
    try { localStorage.setItem('recentEmojis', JSON.stringify(newRecent)); } catch {}
  };
  const handleLongPress = (emoji, e) => {
    if (localSupportsSkinTone(emoji)) {
      e.preventDefault();
      const rect = e.target.getBoundingClientRect();
      setSkinTonePopup({ emoji, x: rect.left, y: rect.bottom + 5 });
    }
  };
  const selectWithSkinTone = (emoji, toneIndex) => {
    const finalEmoji = applySkinTone(emoji, skinTones[toneIndex].code);
    onSelect(finalEmoji);
    setSkinTonePopup(null);
    const newRecent = [emoji, ...recentEmojis.filter(e => e !== emoji)].slice(0, 32);
    setRecentEmojis(newRecent);
    try { localStorage.setItem('recentEmojis', JSON.stringify(newRecent)); } catch {}
  };
  const getFilteredEmojis = () => {
    const data = liveEmojiData || emojiData;
    if (!search.trim()) {
      if (category === "recent") return recentEmojis.map(e => ({e, n: "recent"}));
      return data[category] || [];
    }
    const q = search.toLowerCase();
    const results = [];
    Object.values(data).forEach(arr => arr.forEach(item => { if (item.n?.toLowerCase().includes(q)) results.push(item); }));
    return results.slice(0, 200);
  };

  const filteredEmojis = getFilteredEmojis();
  const data = liveEmojiData || emojiData;
  const totalEmojis = Object.values(data).reduce((sum, arr) => sum + arr.length, 0);
  const skinToneCount = skinToneSet.size;

  return (
    <div className="bg-gray-800 rounded-lg p-2" style={keyboardStyle} onClick={() => setSkinTonePopup(null)}>
      <div className="flex items-center justify-between mb-2 text-[9px] text-gray-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-yellow-400">⌨️ Emoji Keyboard Mode</span>
          {loading && <span className="text-blue-400">Loading from Unicode...</span>}
          {error && <span className="text-orange-400">{error}</span>}
        </div>
        <div className="flex items-center gap-3">
          <span>{totalEmojis} base emojis</span>
          <span className="text-yellow-300">{skinToneCount} with skin tones (s:1)</span>
        </div>
      </div>
      <div className="flex items-center gap-2 mb-2">
        <input type="text" placeholder="🔍 Search emojis..." value={search} onChange={(e) => setSearch(e.target.value)}
          className="flex-1 px-3 py-1.5 bg-gray-700 text-white text-xs rounded-lg border border-gray-600 outline-none focus:border-blue-500" />
        <div className="flex items-center gap-1 px-2 py-1 bg-gray-700 rounded-lg border border-gray-600">
          <span className="text-[8px] text-gray-400 mr-1">Skin:</span>
          {skinTones.map((tone, i) => (
            <button key={i} type="button" onClick={() => setSelectedSkinTone(i)}
              className={`w-5 h-5 rounded-full border-2 transition-all ${selectedSkinTone === i ? 'border-blue-400 scale-110' : 'border-gray-500'}`}
              style={{ backgroundColor: tone.color }} title={tone.label} />
          ))}
        </div>
      </div>
      <div className="flex gap-1 mb-2 p-1 bg-gray-900 rounded-lg overflow-x-auto">
        {Object.keys(emojiCategories).map(cat => (
          <button key={cat} type="button" onClick={() => { setCategory(cat); setSearch(""); }}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-md text-xs whitespace-nowrap transition-all
              ${category === cat ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            style={{ fontFamily: emojiFontStack }}>
            <span>{emojiCategories[cat].icon}</span>
            <span className="text-[9px]">{emojiCategories[cat].name}</span>
            <span className="text-[8px] opacity-70">({cat === "recent" ? recentEmojis.length : (data[cat]?.length || 0)})</span>
          </button>
        ))}
      </div>
      <div className="h-[280px] overflow-y-auto bg-gray-900 rounded-lg p-2">
        {loading ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center"><div className="text-2xl mb-2">⏳</div><div className="text-xs">Fetching from unicode.org/Public/emoji/latest/emoji-test.txt</div></div>
          </div>
        ) : filteredEmojis.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center"><div className="text-2xl mb-2">🔍</div><div className="text-xs">{search ? `No results for "${search}"` : "No emojis"}</div></div>
          </div>
        ) : (
          <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(36px, 1fr))' }}>
            {filteredEmojis.map((item, i) => {
              const emoji = item.e;
              const hasSkinTone = localSupportsSkinTone(emoji);
              const displayEmoji = hasSkinTone ? applySkinTone(emoji, skinTones[selectedSkinTone].code) : emoji;
              return (
                <button key={`${emoji}-${i}`} type="button" onClick={() => handleSelect(emoji)}
                  onContextMenu={(e) => handleLongPress(emoji, e)}
                  title={`${item.n}${hasSkinTone ? ' (right-click for skin tones)' : ''}`}
                  className={`relative flex items-center justify-center w-9 h-9 rounded-md transition-all bg-gray-700 hover:bg-gray-600 hover:scale-110 active:scale-95
                    ${hasSkinTone ? 'ring-1 ring-yellow-500/30' : ''}`}
                  style={{ fontFamily: emojiFontStack, fontSize: '1.4rem' }}>
                  {displayEmoji}
                  {hasSkinTone && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-yellow-400 rounded-full" />}
                </button>
              );
            })}
          </div>
        )}
      </div>
      {skinTonePopup && (
        <div className="fixed z-50 p-1 bg-gray-700 rounded-lg shadow-xl flex gap-1 border border-gray-500"
          style={{ left: skinTonePopup.x, top: skinTonePopup.y }} onClick={(e) => e.stopPropagation()}>
          {skinTones.map((tone, i) => (
            <button key={i} type="button" onClick={() => selectWithSkinTone(skinTonePopup.emoji, i)}
              className="w-8 h-8 flex items-center justify-center rounded hover:bg-gray-600"
              style={{ fontFamily: emojiFontStack, fontSize: '1.3rem' }} title={tone.label}>
              {applySkinTone(skinTonePopup.emoji, tone.code)}
            </button>
          ))}
        </div>
      )}
      <div className="mt-2 text-[8px] text-gray-500 text-center">
        Click to insert • Right-click for skin tones on marked emojis (🟡) • Source: Unicode emoji-test.txt
      </div>
    </div>
  );
}

// === END EMOJI KEYBOARD MODE ===

function htmlToMarkdown(html) {
  let md = html;
  md = md.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n');
  md = md.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n');
  md = md.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n');
  md = md.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
  md = md.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
  md = md.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
  md = md.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
  md = md.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
  md = md.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
  md = md.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n');
  md = md.replace(/<hr\s*\/?>/gi, '\n---\n');
  md = md.replace(/<br\s*\/?>/gi, '\n');
  md = md.replace(/<p[^>]*>(.*?)<\/p>/gis, '$1\n\n');
  md = md.replace(/<div[^>]*>(.*?)<\/div>/gis, '$1\n');
  md = md.replace(/<[^>]+>/g, '');
  md = md.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  md = md.replace(/\n{3,}/g, '\n\n');
  return md.trim();
}

function ToolbarButton({ onClick, active, title, children }) {
  return (
    <button onMouseDown={(e) => { e.preventDefault(); onClick(); }}
      className={`px-1 py-0.5 rounded text-[9px] transition-colors ${active ? 'bg-blue-600 text-white' : 'bg-gray-600 hover:bg-gray-500 text-gray-200'}`}
      title={title}>{children}</button>
  );
}

function ColorPicker({ onSelect, title, icon }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="relative">
      <button onMouseDown={(e) => { e.preventDefault(); setIsOpen(!isOpen); }} className="px-1 py-0.5 bg-gray-600 hover:bg-gray-500 rounded text-[9px] text-gray-200" title={title}>{icon}</button>
      {isOpen && (
        <>
          <div className="fixed inset-0 z-[100]" onClick={() => setIsOpen(false)} />
          <div className="absolute top-full left-0 mt-1 p-1 bg-gray-700 rounded shadow-xl z-[101] grid grid-cols-10 gap-px w-[180px]">
            {colors.map((color) => (
              <button key={color} onMouseDown={(e) => { e.preventDefault(); onSelect(color); setIsOpen(false); }}
                className="w-4 h-4 rounded border border-gray-500 hover:scale-125 transition-transform" style={{ backgroundColor: color }} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function HebrewNikudOverlay({ letter, onSelect, onClose }) {
  const [tab, setTab] = useState("common");
  const nikudOptions = hebrewNikudContexts[letter] || [];
  
  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const vowelMarks = nikudMarks.filter(n => n.cat === "vowel");
  const accentMarks = nikudMarks.filter(n => n.cat === "accent");
  const punctMarks = nikudMarks.filter(n => n.cat === "punct");
  const commonTeamim = teamim.filter(t => t.cat === "common");
  const proseTeamim = teamim.filter(t => t.cat === "prose");
  const emetTeamim = teamim.filter(t => t.cat === "emet");

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60" onClick={onClose}>
      <div className="bg-gray-800 rounded-lg p-3 shadow-2xl border border-gray-600 max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="text-center mb-2">
          <span className="text-5xl font-bold text-white">{letter}</span>
          <p className="text-[10px] text-gray-400 mt-1">בחר ניקוד או טעם עבור האות</p>
        </div>
        
        <div className="flex gap-1 mb-2 justify-center">
          {[{id:"common",label:"נפוצים"},{id:"nikud",label:"ניקוד מלא"},{id:"teamim",label:"טעמים"}].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-2 py-1 rounded text-[10px] ${tab === t.id ? 'bg-indigo-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {tab === "common" && (
          <>
            <div className="mb-2">
              <button onClick={() => { onSelect(letter); onClose(); }} 
                className="w-full py-2 bg-blue-700 hover:bg-blue-600 rounded text-xl text-white border-2 border-blue-400">
                {letter} <span className="text-[10px] text-blue-200">(ללא ניקוד)</span>
              </button>
            </div>
            <div className="grid grid-cols-6 gap-1.5 mb-2">
              {nikudOptions.map((combo, i) => (
                <button key={i} onClick={() => { onSelect(combo); onClose(); }}
                  className="w-10 h-10 bg-gray-700 hover:bg-indigo-600 rounded text-xl text-white flex items-center justify-center transition-colors border border-gray-600 hover:border-indigo-400">
                  {combo}
                </button>
              ))}
            </div>
          </>
        )}

        {tab === "nikud" && (
          <>
            <p className="text-[9px] text-indigo-400 mb-1">תנועות:</p>
            <div className="grid grid-cols-8 gap-1 mb-2">
              {vowelMarks.map((n, i) => (
                <button key={i} onClick={() => { onSelect(letter + n.mark); onClose(); }}
                  className="w-8 h-8 bg-gray-700 hover:bg-green-600 rounded text-sm text-white flex items-center justify-center" title={n.name}>
                  {letter}{n.mark}
                </button>
              ))}
            </div>
            <p className="text-[9px] text-yellow-400 mb-1">דגש/רפה/שין:</p>
            <div className="grid grid-cols-8 gap-1 mb-2">
              {accentMarks.map((n, i) => (
                <button key={i} onClick={() => { onSelect(letter + n.mark); onClose(); }}
                  className="w-8 h-8 bg-gray-700 hover:bg-yellow-600 rounded text-sm text-white flex items-center justify-center" title={n.name}>
                  {letter}{n.mark}
                </button>
              ))}
            </div>
            <p className="text-[9px] text-orange-400 mb-1">סימני פיסוק:</p>
            <div className="grid grid-cols-8 gap-1">
              {punctMarks.map((n, i) => (
                <button key={i} onClick={() => { onSelect(letter + n.mark); onClose(); }}
                  className="w-8 h-8 bg-gray-700 hover:bg-orange-600 rounded text-sm text-white flex items-center justify-center" title={n.name}>
                  {letter}{n.mark}
                </button>
              ))}
            </div>
          </>
        )}

        {tab === "teamim" && (
          <>
            <p className="text-[9px] text-cyan-400 mb-1">טעמים נפוצים:</p>
            <div className="grid grid-cols-6 gap-1 mb-2">
              {commonTeamim.map((t, i) => (
                <button key={i} onClick={() => { onSelect(letter + t.mark); onClose(); }}
                  className="w-10 h-10 bg-gray-700 hover:bg-cyan-600 rounded text-sm text-white flex flex-col items-center justify-center" title={t.name}>
                  <span className="text-lg">{letter}{t.mark}</span>
                </button>
              ))}
            </div>
            <p className="text-[9px] text-purple-400 mb-1">טעמי כ״א ספרים:</p>
            <div className="grid grid-cols-6 gap-1 mb-2">
              {proseTeamim.map((t, i) => (
                <button key={i} onClick={() => { onSelect(letter + t.mark); onClose(); }}
                  className="w-10 h-10 bg-gray-700 hover:bg-purple-600 rounded text-sm text-white flex items-center justify-center" title={t.name}>
                  {letter}{t.mark}
                </button>
              ))}
            </div>
            <p className="text-[9px] text-pink-400 mb-1">טעמי אמ״ת:</p>
            <div className="grid grid-cols-6 gap-1">
              {emetTeamim.map((t, i) => (
                <button key={i} onClick={() => { onSelect(letter + t.mark); onClose(); }}
                  className="w-10 h-10 bg-gray-700 hover:bg-pink-600 rounded text-sm text-white flex items-center justify-center" title={t.name}>
                  {letter}{t.mark}
                </button>
              ))}
            </div>
          </>
        )}

        <button onClick={onClose} className="mt-3 w-full py-1.5 bg-red-600 hover:bg-red-500 rounded text-white text-xs">ביטול (Esc)</button>
      </div>
    </div>
  );
}

function AceEditor({ mode, value, onChange }) {
  const editorRef = useRef(null);
  const aceRef = useRef(null);
  const skipUpdate = useRef(false);

  useEffect(() => {
    const init = () => {
      if (window.ace && editorRef.current && !aceRef.current) {
        aceRef.current = window.ace.edit(editorRef.current);
        aceRef.current.setTheme("ace/theme/tomorrow_night");
        aceRef.current.session.setMode(`ace/mode/${mode}`);
        aceRef.current.setOptions({ fontSize: "11px", showPrintMargin: false, wrap: true });
        aceRef.current.setValue(value || "", -1);
        aceRef.current.on('change', () => {
          if (!skipUpdate.current && onChange) onChange(aceRef.current.getValue());
        });
      }
    };
    const t = setTimeout(init, 100);
    return () => { clearTimeout(t); if (aceRef.current) { aceRef.current.destroy(); aceRef.current = null; } };
  }, []);

  useEffect(() => {
    if (aceRef.current && value !== undefined && aceRef.current.getValue() !== value) {
      skipUpdate.current = true;
      const pos = aceRef.current.getCursorPosition();
      aceRef.current.setValue(value, -1);
      aceRef.current.moveCursorToPosition(pos);
      skipUpdate.current = false;
    }
  }, [value]);

  return <div ref={editorRef} className="w-full h-full min-h-[120px]" />;
}

function EditorToolbar({ execCommand, insertAtCursor, applyFont, applyFontSize, wrapSelection, activeFormats, isRTL }) {
  return (
    <>
      <div className="flex flex-wrap gap-0.5 p-1 bg-gray-700 border-b border-gray-600 items-center">
        <select onChange={(e) => applyFont(e.target.value)} className="px-0.5 py-0.5 bg-gray-600 text-gray-200 text-[8px] rounded border-none outline-none w-[70px]" title="Font">
          <option value="">Font...</option>
          {fontFamilies.map((f) => (<option key={f.label} value={f.value}>{f.label}</option>))}
        </select>
        <select onChange={(e) => applyFontSize(e.target.value)} className="px-0.5 py-0.5 bg-gray-600 text-gray-200 text-[8px] rounded border-none outline-none w-[35px]" title="Size">
          {editorFontSizes.map((s) => (<option key={s} value={s}>{s}</option>))}
        </select>
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ToolbarButton onClick={() => execCommand('bold')} active={activeFormats.bold} title="Bold"><b>B</b></ToolbarButton>
        <ToolbarButton onClick={() => execCommand('italic')} active={activeFormats.italic} title="Italic"><i>I</i></ToolbarButton>
        <ToolbarButton onClick={() => execCommand('underline')} active={activeFormats.underline} title="Underline"><u>U</u></ToolbarButton>
        <ToolbarButton onClick={() => execCommand('strikeThrough')} title="Strike"><s>S</s></ToolbarButton>
        <ToolbarButton onClick={() => execCommand('subscript')} title="Sub">x₂</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('superscript')} title="Sup">x²</ToolbarButton>
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ColorPicker onSelect={(c) => execCommand('foreColor', c)} title="Text Color" icon={<span style={{ borderBottom: '2px solid #f00' }}>A</span>} />
        <ColorPicker onSelect={(c) => execCommand('hiliteColor', c)} title="Highlight" icon={<span className="bg-yellow-300 text-black px-0.5 text-[7px]">H</span>} />
        <EmojiPicker onSelect={(emoji) => insertAtCursor(emoji)} />
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ToolbarButton onClick={() => execCommand('removeFormat')} title="Clear">✕</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('undo')} title="Undo">↶</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('redo')} title="Redo">↷</ToolbarButton>
        {isRTL && <span className="text-[8px] text-blue-400 ml-auto">RTL</span>}
      </div>
      <div className="flex flex-wrap gap-0.5 p-1 bg-gray-700 border-b border-gray-600 items-center">
        {['h1','h2','h3','h4','h5','h6'].map(h => (<ToolbarButton key={h} onClick={() => execCommand('formatBlock', h)} title={h.toUpperCase()}>{h.toUpperCase()}</ToolbarButton>))}
        <ToolbarButton onClick={() => execCommand('formatBlock', 'p')} title="P">¶</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('formatBlock', 'blockquote')} title="Quote">❝</ToolbarButton>
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ToolbarButton onClick={() => execCommand('justifyLeft')} active={activeFormats.justifyLeft} title="Left">⬅</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('justifyCenter')} active={activeFormats.justifyCenter} title="Center">⬌</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('justifyRight')} active={activeFormats.justifyRight} title="Right">➡</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('justifyFull')} title="Justify">☰</ToolbarButton>
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ToolbarButton onClick={() => execCommand('insertUnorderedList')} title="Bullets">•―</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('insertOrderedList')} title="Numbers">1.</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('indent')} title="Indent">→]</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('outdent')} title="Outdent">[←</ToolbarButton>
      </div>
      <div className="flex flex-wrap gap-0.5 p-1 bg-gray-700 border-b border-gray-600 items-center">
        <ToolbarButton onClick={() => { const u = prompt('URL:', 'https://'); if (u) execCommand('createLink', u); }} title="Link">🔗</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('unlink')} title="Unlink">🔗̸</ToolbarButton>
        <ToolbarButton onClick={() => { const u = prompt('Image URL:'); if (u) execCommand('insertImage', u); }} title="Image">🖼</ToolbarButton>
        <ToolbarButton onClick={() => execCommand('insertHorizontalRule')} title="HR">―</ToolbarButton>
        <div className="w-px h-4 bg-gray-500 mx-0.5" />
        <ToolbarButton onClick={() => wrapSelection('abbr', { title: prompt('Title:') })} title="Abbr">abbr</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('code')} title="Code">&lt;/&gt;</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('kbd')} title="Kbd">kbd</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('mark')} title="Mark">mark</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('ins')} title="Ins">ins</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('del')} title="Del">del</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('bdo', { dir: 'rtl' })} title="RTL">bdo→</ToolbarButton>
        <ToolbarButton onClick={() => wrapSelection('bdo', { dir: 'ltr' })} title="LTR">←bdo</ToolbarButton>
      </div>
    </>
  );
}

export default function FullKeyboard() {
  const [language, setLanguage] = useState("hebrew");
  const [nikudMode, setNikudMode] = useState(false);
  const [emojiMode, setEmojiMode] = useState(false); // Emoji keyboard mode
  const [capsLock, setCapsLock] = useState(false);
  const [numLock, setNumLock] = useState(true);
  const [showSections, setShowSections] = useState({ function: true, main: true, nav: true, numpad: true });
  const [showPanels, setShowPanels] = useState({ editor: true, html: false, markdown: false });
  const [htmlContent, setHtmlContent] = useState("");
  const [mdContent, setMdContent] = useState("");
  const [activeFormats, setActiveFormats] = useState({});
  const [nikudOverlay, setNikudOverlay] = useState(null);
  
  // Track sync source to prevent loops
  const syncSourceRef = useRef(null);
  
  // Keyboard style controls (mm units) - all up to 5mm
  const [keyFontSize, setKeyFontSize] = useState(2.5);
  const [keyMargin, setKeyMargin] = useState(0.3);
  const [keyPadding, setKeyPadding] = useState(0.5);
  const [keyboardFont, setKeyboardFont] = useState("'Heebo', sans-serif");
  const [keyBorderRadius, setKeyBorderRadius] = useState(0.8);
  const [keyBgColor, setKeyBgColor] = useState("#374151");
  const [keyTextColor, setKeyTextColor] = useState("#ffffff");
  const [keyBorderWidth, setKeyBorderWidth] = useState(0);
  const [keyBorderColor, setKeyBorderColor] = useState("#4b5563");
  
  const editorRef = useRef(null);
  const currentLayout = layouts[language]?.qwerty || layouts.english.qwerty;
  const isRTL = language === "hebrew";

  const checkFormats = useCallback(() => {
    setActiveFormats({
      bold: document.queryCommandState('bold'), italic: document.queryCommandState('italic'),
      underline: document.queryCommandState('underline'),
      justifyLeft: document.queryCommandState('justifyLeft'), justifyCenter: document.queryCommandState('justifyCenter'),
      justifyRight: document.queryCommandState('justifyRight'),
    });
  }, []);

  // Sync from visual editor to HTML and MD
  const syncFromEditor = useCallback(() => {
    if (syncSourceRef.current === 'html' || syncSourceRef.current === 'md') {
      syncSourceRef.current = null;
      return;
    }
    const html = editorRef.current?.innerHTML || '';
    setHtmlContent(html);
    setMdContent(htmlToMarkdown(html));
    checkFormats();
  }, [checkFormats]);

  // Sync from HTML editor to visual and MD
  const handleHtmlChange = useCallback((html) => {
    syncSourceRef.current = 'html';
    setHtmlContent(html);
    setMdContent(htmlToMarkdown(html));
    if (editorRef.current) {
      editorRef.current.innerHTML = html;
    }
    setTimeout(() => { syncSourceRef.current = null; }, 50);
  }, []);

  // Sync from MD editor to visual and HTML
  const handleMdChange = useCallback((md) => {
    syncSourceRef.current = 'md';
    setMdContent(md);
    try {
      const html = window.marked ? window.marked.parse(md) : md;
      setHtmlContent(html);
      if (editorRef.current) {
        editorRef.current.innerHTML = html;
      }
    } catch (e) {
      console.error('Markdown parse error:', e);
    }
    setTimeout(() => { syncSourceRef.current = null; }, 50);
  }, []);

  const execCommand = (cmd, val = null) => { 
    document.execCommand(cmd, false, val); 
    editorRef.current?.focus(); 
    syncFromEditor(); 
  };

  const insertAtCursor = useCallback((text) => {
    const editor = editorRef.current;
    if (!editor) return;
    editor.focus();
    
    const sel = window.getSelection();
    if (sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      const textNode = document.createTextNode(text);
      range.insertNode(textNode);
      range.setStartAfter(textNode);
      range.setEndAfter(textNode);
      sel.removeAllRanges();
      sel.addRange(range);
    } else {
      editor.innerHTML += text;
    }
    syncFromEditor();
  }, [syncFromEditor]);

  const applyFontSize = (size) => {
    const sel = window.getSelection();
    if (sel.rangeCount > 0 && !sel.isCollapsed) {
      const range = sel.getRangeAt(0);
      const span = document.createElement('span');
      span.style.fontSize = `${size}px`;
      try { range.surroundContents(span); } catch { const c = range.extractContents(); span.appendChild(c); range.insertNode(span); }
      editorRef.current?.focus(); 
      syncFromEditor();
    }
  };

  const applyFont = (fontValue) => {
    if (!fontValue) return;
    const sel = window.getSelection();
    if (sel.rangeCount > 0 && !sel.isCollapsed) {
      const range = sel.getRangeAt(0);
      const span = document.createElement('span');
      span.style.fontFamily = fontValue;
      try { range.surroundContents(span); } catch { const c = range.extractContents(); span.appendChild(c); range.insertNode(span); }
      editorRef.current?.focus(); 
      syncFromEditor();
    }
  };

  const wrapSelection = (tag, attrs = {}) => {
    const sel = window.getSelection();
    if (sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      const el = document.createElement(tag);
      Object.entries(attrs).forEach(([k, v]) => { if (v) el.setAttribute(k, v); });
      try { range.surroundContents(el); } catch { const c = range.extractContents(); el.appendChild(c); range.insertNode(el); }
      editorRef.current?.focus(); 
      syncFromEditor();
    }
  };

  const handleKeyPress = (key) => {
    if (key === "{shiftl}" || key === "{shiftr}") { 
      setNikudMode(prev => !prev); 
      return; 
    }
    if (key === "{caps}") { setCapsLock(prev => !prev); return; }
    if (key === "{numlock}") { setNumLock(prev => !prev); return; }
    if (key.match(/^\{(esc|f\d+|prtsc|scrlk|pause|ctrll|ctrlr|altl|altr|winl|winr|menu)\}$/)) return;
    
    const editor = editorRef.current;
    if (!editor) return;
    editor.focus();
    
    if (key === "{bksp}") { document.execCommand('delete', false); syncFromEditor(); }
    else if (key === "{del}") { document.execCommand('forwardDelete', false); syncFromEditor(); }
    else if (key === "{enter}" || key === "{numenter}") { document.execCommand('insertParagraph', false); syncFromEditor(); }
    else if (key === "{space}") insertAtCursor(" ");
    else if (key === "{tab}") insertAtCursor("\t");
    else if (key.match(/^\{(ins|home|end|pgup|pgdn|up|down|left|right)\}$/)) return;
    else if (key.match(/^\{num(\d)\}$/)) { if (numLock) insertAtCursor(key.match(/^\{num(\d)\}$/)[1]); }
    else if (key === "{numdec}" && numLock) insertAtCursor(".");
    else if (key === "{numdiv}") insertAtCursor("/");
    else if (key === "{nummult}") insertAtCursor("*");
    else if (key === "{numsub}") insertAtCursor("-");
    else if (key === "{numadd}") insertAtCursor("+");
    else {
      if (language === "hebrew" && nikudMode && hebrewLetters.includes(key)) {
        setNikudOverlay(key);
        return;
      }
      
      let char = key;
      if (capsLock && char.length === 1 && char.match(/[a-z]/i)) {
        char = char.toUpperCase();
      }
      insertAtCursor(char);
    }
  };

  const handleNikudSelect = (text) => {
    insertAtCursor(text);
    setNikudMode(false);
  };

  const renderKey = (key) => {
    const isSpecial = key.startsWith("{");
    const displayKey = display[key] || key;
    const isShiftKey = key === "{shiftl}" || key === "{shiftr}";
    const isActive = (isShiftKey && nikudMode) || (key === "{caps}" && capsLock) || (key === "{numlock}" && numLock);
    const isHebrewLetter = language === "hebrew" && hebrewLetters.includes(key);
    const showNikudBadge = isHebrewLetter && nikudMode;

    let widthClass = "w-[var(--key-w)]";
    let heightClass = "h-[var(--key-h)]";
    if (key === "{bksp}") widthClass = "w-[calc(var(--key-w)*1.7)]";
    else if (key === "{tab}") widthClass = "w-[calc(var(--key-w)*1.4)]";
    else if (key === "{caps}") widthClass = "w-[calc(var(--key-w)*1.6)]";
    else if (key === "{enter}") widthClass = "w-[calc(var(--key-w)*1.6)]";
    else if (key === "{shiftl}" || key === "{shiftr}") widthClass = "w-[calc(var(--key-w)*1.7)]";
    else if (key === "{space}") widthClass = "w-[calc(var(--key-w)*5.7)]";
    else if (key === "{ctrll}" || key === "{ctrlr}" || key === "{altl}" || key === "{altr}") widthClass = "w-[calc(var(--key-w)*1.3)]";
    else if (key === "{numadd}" || key === "{numenter}") { widthClass = "w-[var(--key-w)]"; heightClass = "h-[calc(var(--key-h)*2.15)]"; }
    else if (key === "{num0}") widthClass = "w-[calc(var(--key-w)*2.15)]";
    
    const keyStyle = {
      margin: `var(--key-margin)`,
      padding: `var(--key-padding)`,
      fontSize: `var(--key-font-size)`,
      fontFamily: `var(--key-font-family)`,
      borderRadius: `var(--key-border-radius)`,
      backgroundColor: isActive ? '#2563eb' : (isSpecial ? '#4b5563' : `var(--key-bg-color)`),
      color: `var(--key-text-color)`,
      borderWidth: `var(--key-border-width)`,
      borderColor: `var(--key-border-color)`,
      borderStyle: 'solid',
    };

    return (
      <button key={key} onClick={() => handleKeyPress(key)}
        style={keyStyle}
        className={`relative font-medium transition-all duration-75 select-none flex items-center justify-center ${widthClass} ${heightClass}
          ${showNikudBadge ? "ring-2 ring-indigo-400 !bg-indigo-700" : ""}
          hover:brightness-110 active:brightness-90 active:translate-y-px
          shadow-[0_1px_0_0_rgba(0,0,0,0.4)] active:shadow-none`}>
        {isShiftKey && language === "hebrew" ? (nikudMode ? "נִ" : "⇧") : displayKey}
        {showNikudBadge && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-yellow-400 rounded-full text-[5px] flex items-center justify-center text-black font-bold">נ</span>}
      </button>
    );
  };

  const renderRow = (rowString, index) => {
    if (!rowString) return <div key={index} style={{ height: 'var(--key-h)' }} />;
    return <div key={index} className="flex justify-center">{rowString.split(" ").map(renderKey)}</div>;
  };

  const currentLayerLayout = currentLayout.default;
  const toolbarProps = { execCommand, insertAtCursor, applyFont, applyFontSize, wrapSelection, activeFormats, isRTL };
  const visiblePanels = Object.entries(showPanels).filter(([_, v]) => v).length;

  const keyboardStyle = {
    '--key-w': '7.5mm',
    '--key-h': '7.5mm',
    '--key-margin': `${keyMargin}mm`,
    '--key-padding': `${keyPadding}mm`,
    '--key-font-size': `${keyFontSize}mm`,
    '--key-font-family': keyboardFont,
    '--key-border-radius': `${keyBorderRadius}mm`,
    '--key-bg-color': keyBgColor,
    '--key-text-color': keyTextColor,
    '--key-border-width': `${keyBorderWidth}mm`,
    '--key-border-color': keyBorderColor,
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-2 text-xs">
      <ExternalScripts />
      <div className="max-w-6xl mx-auto">
        <h1 className="text-base font-bold mb-2 text-center" style={{ fontFamily: "'Rubik', sans-serif" }}>Virtual Keyboard Studio</h1>

        {/* Controls Row 1 - Keyboard Mode Toggle */}
        <div className="flex flex-wrap gap-1 mb-2">
          <div className="p-1 bg-gray-800 rounded flex items-center gap-1.5">
            <span className="text-[8px] text-gray-400">Mode:</span>
            <button onClick={() => { setEmojiMode(false); setNikudMode(false); }}
              className={`px-2 py-0.5 rounded text-[9px] font-medium transition-colors ${!emojiMode ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400 hover:bg-gray-600'}`}>
              ⌨️ Standard
            </button>
            <button onClick={() => { setEmojiMode(true); setNikudMode(false); }}
              className={`px-2 py-0.5 rounded text-[9px] font-medium transition-colors ${emojiMode ? 'bg-yellow-600 text-white' : 'bg-gray-700 text-gray-400 hover:bg-gray-600'}`}
              style={{ fontFamily: emojiFontStack }}>
              😀 Emoji
            </button>
          </div>
          {!emojiMode && (
            <>
              <div className="p-1 bg-gray-800 rounded flex items-center gap-1.5">
                <span className="text-[8px] text-gray-400">Lang:</span>
                {Object.keys(layouts).map((lang) => (
                  <label key={lang} className="flex items-center gap-0.5 cursor-pointer text-[9px]">
                    <input type="radio" name="lang" value={lang} checked={language === lang} onChange={(e) => setLanguage(e.target.value)} className="w-2 h-2 accent-blue-500" />
                    {lang}
                  </label>
                ))}
              </div>
              {language === "hebrew" && (
                <div className="p-1 bg-gray-800 rounded flex items-center gap-1.5">
                  <label className="flex items-center gap-1 cursor-pointer text-[9px]">
                    <input type="checkbox" checked={nikudMode} onChange={(e) => setNikudMode(e.target.checked)} className="w-2 h-2 accent-indigo-500" />
                    <span className={nikudMode ? "text-indigo-400" : "text-gray-400"}>מצב ניקוד</span>
                  </label>
                </div>
              )}
              <div className="p-1 bg-gray-800 rounded flex items-center gap-1.5">
                <span className="text-[8px] text-gray-400">Show:</span>
                {Object.keys(showSections).map((s) => (
                  <label key={s} className="flex items-center gap-0.5 cursor-pointer text-[9px]">
                    <input type="checkbox" checked={showSections[s]} onChange={(e) => setShowSections(prev => ({ ...prev, [s]: e.target.checked }))} className="w-2 h-2 accent-purple-500" />
                    {s.slice(0,3)}
                  </label>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Style Controls - Sliders Row (only in standard mode) */}
        {!emojiMode && (
          <div className="flex flex-wrap gap-2 mb-1 p-2 bg-gray-800 rounded">
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400 w-10">Font:</label>
              <input type="range" min="0" max="5" step="0.1" value={keyFontSize} onChange={(e) => setKeyFontSize(+e.target.value)} className="w-16 h-1 accent-blue-500" />
              <span className="text-[8px] text-blue-400 w-8">{keyFontSize.toFixed(1)}mm</span>
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400 w-10">Margin:</label>
              <input type="range" min="0" max="5" step="0.1" value={keyMargin} onChange={(e) => setKeyMargin(+e.target.value)} className="w-16 h-1 accent-green-500" />
              <span className="text-[8px] text-green-400 w-8">{keyMargin.toFixed(1)}mm</span>
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400 w-10">Padding:</label>
              <input type="range" min="0" max="5" step="0.1" value={keyPadding} onChange={(e) => setKeyPadding(+e.target.value)} className="w-16 h-1 accent-yellow-500" />
              <span className="text-[8px] text-yellow-400 w-8">{keyPadding.toFixed(1)}mm</span>
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400 w-10">Radius:</label>
              <input type="range" min="0" max="5" step="0.1" value={keyBorderRadius} onChange={(e) => setKeyBorderRadius(+e.target.value)} className="w-16 h-1 accent-purple-500" />
              <span className="text-[8px] text-purple-400 w-8">{keyBorderRadius.toFixed(1)}mm</span>
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400 w-10">Border:</label>
              <input type="range" min="0" max="5" step="0.1" value={keyBorderWidth} onChange={(e) => setKeyBorderWidth(+e.target.value)} className="w-16 h-1 accent-cyan-500" />
              <span className="text-[8px] text-cyan-400 w-8">{keyBorderWidth.toFixed(1)}mm</span>
            </div>
          </div>
        )}

        {/* Style Controls - Colors Row (only in standard mode) */}
        {!emojiMode && (
          <div className="flex flex-wrap gap-2 mb-2 p-2 bg-gray-800 rounded items-center">
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400">Font:</label>
              <select value={keyboardFont} onChange={(e) => setKeyboardFont(e.target.value)}
                className="px-1 py-0.5 bg-gray-700 text-gray-200 text-[8px] rounded border-none outline-none w-[80px]">
                {fontFamilies.map((f) => (<option key={f.label} value={f.value}>{f.label}</option>))}
              </select>
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400">BG:</label>
              <input type="color" value={keyBgColor} onChange={(e) => setKeyBgColor(e.target.value)} className="w-5 h-5 rounded border-none cursor-pointer" />
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400">Text:</label>
              <input type="color" value={keyTextColor} onChange={(e) => setKeyTextColor(e.target.value)} className="w-5 h-5 rounded border-none cursor-pointer" />
            </div>
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-gray-400">Border:</label>
              <input type="color" value={keyBorderColor} onChange={(e) => setKeyBorderColor(e.target.value)} className="w-5 h-5 rounded border-none cursor-pointer" />
            </div>
            <button onClick={() => { setKeyFontSize(2.5); setKeyMargin(0.3); setKeyPadding(0.5); setKeyBorderRadius(0.8); setKeyBorderWidth(0); setKeyBgColor("#374151"); setKeyTextColor("#ffffff"); setKeyBorderColor("#4b5563"); setKeyboardFont("'Heebo', sans-serif"); }}
              className="px-1.5 py-0.5 bg-red-700 hover:bg-red-600 rounded text-[8px] text-white">Reset</button>
          </div>
        )}

        {/* Panel Toggles */}
        <div className="flex gap-1 mb-2">
          <button onClick={() => setShowPanels(p => ({ ...p, editor: !p.editor }))}
            className={`px-2 py-1 rounded text-[9px] font-medium ${showPanels.editor ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
            📝 Editor {showPanels.editor ? '✓' : ''}
          </button>
          <button onClick={() => setShowPanels(p => ({ ...p, html: !p.html }))}
            className={`px-2 py-1 rounded text-[9px] font-medium ${showPanels.html ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
            &lt;/&gt; HTML {showPanels.html ? '✓' : ''}
          </button>
          <button onClick={() => setShowPanels(p => ({ ...p, markdown: !p.markdown }))}
            className={`px-2 py-1 rounded text-[9px] font-medium ${showPanels.markdown ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
            📄 Markdown {showPanels.markdown ? '✓' : ''}
          </button>
        </div>

        {/* Toolbar */}
        <div className="rounded-t-lg overflow-hidden border border-gray-600 border-b-0">
          <EditorToolbar {...toolbarProps} />
        </div>

        {/* Panels */}
        <div className={`flex gap-2 mb-2 ${visiblePanels === 0 ? 'hidden' : ''}`} style={{ minHeight: visiblePanels > 0 ? '150px' : '0' }}>
          {showPanels.editor && (
            <div className={`rounded-lg overflow-hidden border border-gray-600 flex flex-col ${visiblePanels === 1 ? 'flex-1' : visiblePanels === 2 ? 'w-1/2' : 'w-1/3'}`}>
              <div className="p-1 bg-blue-700 text-[9px] font-semibold text-white flex justify-between items-center">
                <span>📝 Visual Editor</span>
                <button onClick={() => setShowPanels(p => ({ ...p, editor: false }))} className="text-white/70 hover:text-white">✕</button>
              </div>
              <div className="relative flex-1 bg-gray-800 overflow-auto min-h-[120px]">
                <div ref={editorRef} contentEditable dir={isRTL ? "rtl" : "ltr"} 
                  onInput={syncFromEditor} onKeyUp={checkFormats} onMouseUp={checkFormats}
                  className="min-h-full p-2 text-sm text-white outline-none" 
                  style={{ wordBreak: 'break-word', fontFamily: keyboardFont }} />
              </div>
            </div>
          )}

          {showPanels.html && (
            <div className={`rounded-lg overflow-hidden border border-gray-600 flex flex-col ${visiblePanels === 1 ? 'flex-1' : visiblePanels === 2 ? 'w-1/2' : 'w-1/3'}`}>
              <div className="p-1 bg-green-700 text-[9px] font-semibold text-white flex justify-between items-center">
                <span>&lt;/&gt; HTML</span>
                <button onClick={() => setShowPanels(p => ({ ...p, html: false }))} className="text-white/70 hover:text-white">✕</button>
              </div>
              <div className="flex-1 min-h-[120px]">
                <AceEditor mode="html" value={htmlContent} onChange={handleHtmlChange} />
              </div>
            </div>
          )}

          {showPanels.markdown && (
            <div className={`rounded-lg overflow-hidden border border-gray-600 flex flex-col ${visiblePanels === 1 ? 'flex-1' : visiblePanels === 2 ? 'w-1/2' : 'w-1/3'}`}>
              <div className="p-1 bg-purple-700 text-[9px] font-semibold text-white flex justify-between items-center">
                <span>📄 Markdown</span>
                <button onClick={() => setShowPanels(p => ({ ...p, markdown: false }))} className="text-white/70 hover:text-white">✕</button>
              </div>
              <div className="flex-1 min-h-[120px]">
                <AceEditor mode="markdown" value={mdContent} onChange={handleMdChange} />
              </div>
            </div>
          )}
        </div>

        {/* Hebrew Nikud Info - only show in standard mode */}
        {!emojiMode && language === "hebrew" && (
          <div className={`mb-2 p-1.5 rounded border text-[9px] ${nikudMode ? 'bg-indigo-900/70 border-indigo-400 text-indigo-200' : 'bg-gray-800 border-gray-600 text-gray-400'}`}>
            {nikudMode 
              ? "💡 מצב ניקוד פעיל - לחץ על אות לבחירת ניקוד או טעם" 
              : "💡 לחץ Shift או סמן 'מצב ניקוד' להקלדת ניקוד וטעמים"}
          </div>
        )}

        {/* Keyboard - show emoji or standard based on mode */}
        {emojiMode ? (
          <EmojiKeyboard onSelect={insertAtCursor} keyboardStyle={keyboardStyle} />
        ) : (
          <div className="p-1.5 bg-gray-800 rounded-lg overflow-x-auto" style={keyboardStyle}>
            <div className="flex gap-1.5 min-w-max">
              <div className="flex flex-col">
                {showSections.function && <div className="flex gap-1 mb-1">{currentLayerLayout.function.map((g, i) => <div key={i} className="flex">{g.split(" ").map(renderKey)}</div>)}</div>}
                {showSections.main && (
                  <div className="flex flex-col" dir={isRTL ? "rtl" : "ltr"}>
                    {currentLayerLayout.main.map((row, i) => renderRow(row, `main-${i}`))}
                  </div>
                )}
              </div>
              {showSections.nav && (
                <div className="flex flex-col gap-1.5 mt-[2rem]">
                  <div className="flex flex-col">{currentLayerLayout.nav.slice(0, 2).map((row, i) => renderRow(row, `nav-${i}`))}</div>
                  <div className="flex flex-col mt-0.5">{currentLayerLayout.nav.slice(2).map((row, i) => renderRow(row, `nav-${i + 2}`))}</div>
                </div>
              )}
              {showSections.numpad && (
                <div className="flex flex-col mt-[2rem]">
                  <div className="flex">{currentLayerLayout.numpad[0].split(" ").map(renderKey)}</div>
                  <div className="flex">
                    <div className="flex flex-col">
                      <div className="flex">{currentLayerLayout.numpad[1].split(" ").slice(0, 3).map(renderKey)}</div>
                      <div className="flex">{currentLayerLayout.numpad[2].split(" ").map(renderKey)}</div>
                    </div>
                    {renderKey("{numadd}")}
                  </div>
                  <div className="flex">
                    <div className="flex flex-col">
                      <div className="flex">{currentLayerLayout.numpad[3].split(" ").slice(0, 3).map(renderKey)}</div>
                      <div className="flex">{currentLayerLayout.numpad[4].split(" ").map(renderKey)}</div>
                    </div>
                    {renderKey("{numenter}")}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Nikud Overlay - only in standard mode */}
        {!emojiMode && nikudOverlay && (
          <HebrewNikudOverlay 
            letter={nikudOverlay} 
            onSelect={handleNikudSelect} 
            onClose={() => { setNikudOverlay(null); setNikudMode(false); }} 
          />
        )}

        {/* CSS Variables Display - only in standard mode */}
        {!emojiMode && (
          <div className="mt-1 p-1.5 bg-gray-800 rounded text-[7px] text-gray-500 font-mono">
            <span className="text-gray-400">CSS:</span> {`--key-font-size:${keyFontSize}mm; --key-margin:${keyMargin}mm; --key-padding:${keyPadding}mm; --key-border-radius:${keyBorderRadius}mm; --key-border-width:${keyBorderWidth}mm; --key-bg-color:${keyBgColor}; --key-text-color:${keyTextColor};`}
          </div>
        )}
      </div>

      <style>{`
        [contenteditable] { line-height: 1.5; }
        [contenteditable] h1 { font-size: 2em; font-weight: bold; margin: 0.4em 0; }
        [contenteditable] h2 { font-size: 1.5em; font-weight: bold; margin: 0.4em 0; }
        [contenteditable] h3 { font-size: 1.25em; font-weight: bold; margin: 0.4em 0; }
        [contenteditable] ul { list-style: disc; padding-left: 1.5em; }
        [contenteditable] ol { list-style: decimal; padding-left: 1.5em; }
        [contenteditable] blockquote { border-left: 3px solid #4b5563; padding-left: 0.8em; color: #9ca3af; font-style: italic; }
        [contenteditable] code { background: #374151; padding: 0.15em 0.3em; border-radius: 0.2rem; font-family: monospace; }
        [contenteditable] kbd { background: #4b5563; padding: 0.1em 0.3em; border-radius: 0.2rem; font-family: monospace; border: 1px solid #6b7280; }
        [contenteditable] abbr { border-bottom: 1px dotted #9ca3af; cursor: help; }
        [contenteditable] mark { background: #fef08a; color: #000; padding: 0.1em; }
        [contenteditable] ins { text-decoration: underline; background: #d1fae5; color: #065f46; }
        [contenteditable] del { text-decoration: line-through; background: #fee2e2; color: #991b1b; }
        [contenteditable] hr { border: none; border-top: 1px solid #4b5563; margin: 0.8em 0; }
        [contenteditable] a { color: #60a5fa; text-decoration: underline; }
        [contenteditable] table { border-collapse: collapse; width: 100%; }
        [contenteditable] th, [contenteditable] td { border: 1px solid #4b5563; padding: 0.4em; }
        [contenteditable] th { background: #374151; }
        .emoji-font { font-family: 'Noto Color Emoji', 'Segoe UI Emoji', 'Apple Color Emoji', sans-serif; }
      `}</style>
    </div>
  );
}

