import React, { useState, useRef, useEffect } from "react";

// Layout definitions - would be transpiled from AnySoftKeyboard XML
const layouts = {
  hebrew: {
    qwerty: {
      default: [
        "/ ' ק ר א ט ו ן ם פ {bksp}",
        "{tab} ש ד ג כ ע י ח ל ך ף ,",
        "{lock} ז ס ב ה נ מ צ ת ץ {enter}",
        "{shift} . ; , {space} {shift}"
      ],
      shift: [
        "~ ! @ # $ % ^ & * ( ) _ + {bksp}",
        "{tab} Q W E R T Y U I O P { } |",
        "{lock} A S D F G H J K L : \" {enter}",
        "{shift} < > ? {space} {shift}"
      ],
      nikud: [
        "ְ ֱ ֲ ֳ ִ ֵ ֶ ַ ָ ֹ ֻ ּ {bksp}",
        "{tab} שׁ שׂ וֹ וּ אָ אֵ אִ אֲ אֳ אֱ אַ אֶ אֹ",
        "{lock} ׀ ־ ׃ ׆ ׳ ״ {enter}",
        "{default} {space} {default}"
      ]
    },
    standard: {
      default: [
        "; 1 2 3 4 5 6 7 8 9 0 - = {bksp}",
        "{tab} / ' ק ר א ט ו ן ם פ ] [ \\",
        "{lock} ש ד ג כ ע י ח ל ך ף , {enter}",
        "{shift} ז ס ב ה נ מ צ ת ץ . {shift}",
        "{space}"
      ],
      shift: [
        "~ ! @ # $ % ^ & * ( ) _ + {bksp}",
        "{tab} Q W E R T Y U I O P } { |",
        "{lock} A S D F G H J K L : \" {enter}",
        "{shift} Z X C V B N M < > ? {shift}",
        "{space}"
      ]
    }
  },
  english: {
    qwerty: {
      default: [
        "` 1 2 3 4 5 6 7 8 9 0 - = {bksp}",
        "{tab} q w e r t y u i o p [ ] \\",
        "{lock} a s d f g h j k l ; ' {enter}",
        "{shift} z x c v b n m , . / {shift}",
        "{space}"
      ],
      shift: [
        "~ ! @ # $ % ^ & * ( ) _ + {bksp}",
        "{tab} Q W E R T Y U I O P { } |",
        "{lock} A S D F G H J K L : \" {enter}",
        "{shift} Z X C V B N M < > ? {shift}",
        "{space}"
      ]
    },
    dvorak: {
      default: [
        "` 1 2 3 4 5 6 7 8 9 0 [ ] {bksp}",
        "{tab} ' , . p y f g c r l / = \\",
        "{lock} a o e u i d h t n s - {enter}",
        "{shift} ; q j k x b m w v z {shift}",
        "{space}"
      ],
      shift: [
        "~ ! @ # $ % ^ & * ( ) { } {bksp}",
        "{tab} \" < > P Y F G C R L ? + |",
        "{lock} A O E U I D H T N S _ {enter}",
        "{shift} : Q J K X B M W V Z {shift}",
        "{space}"
      ]
    }
  },
  arabic: {
    qwerty: {
      default: [
        "ذ 1 2 3 4 5 6 7 8 9 0 - = {bksp}",
        "{tab} ض ص ث ق ف غ ع ه خ ح ج د \\",
        "{lock} ش س ي ب ل ا ت ن م ك ط {enter}",
        "{shift} ئ ء ؤ ر لا ى ة و ز ظ {shift}",
        "{space}"
      ],
      shift: [
        "ّ ! @ # $ % ^ & * ) ( _ + {bksp}",
        "{tab} َ ً ُ ٌ لإ إ ` ÷ × ؛ > < |",
        "{lock} ِ ٍ ] [ لأ أ ـ ، / : {enter}",
        "{shift} ~ ْ } { لآ آ ' , . ؟ {shift}",
        "{space}"
      ]
    }
  }
};

// Long-press / nikud mappings for Hebrew
const hebrewLongPress = {
  "ש": ["שׁ", "שׂ"],
  "ב": ["בּ", "ב"],
  "כ": ["כּ", "ך", "ךּ"],
  "פ": ["פּ", "ף"],
  "א": ["אָ", "אַ", "אֲ", "אֵ", "אֶ", "אִ", "אֹ", "אֻ", "אּ"],
  "ו": ["וֹ", "וּ", "וָ", "וַ"],
  "י": ["יִ", "יּ"],
  "ה": ["הּ", "הָ", "הַ"],
  "ע": ["עָ", "עַ", "עֲ"],
  "ת": ["תּ"],
  "ד": ["דּ"],
  "ג": ["גּ"],
  "ט": ["טּ"],
  "צ": ["צּ", "ץ"],
  "ל": ["לּ"],
  "מ": ["מּ", "ם"],
  "נ": ["נּ", "ן"],
  "ס": ["סּ"],
  "ז": ["זּ"],
  "ר": ["רּ"],
  "ק": ["קּ"]
};

const display = {
  "{bksp}": "⌫",
  "{enter}": "↵",
  "{shift}": "⇧",
  "{tab}": "⇥",
  "{lock}": "⇪",
  "{space}": " ",
  "{default}": "אבג"
};

export default function KeyboardLayoutSelector() {
  const [language, setLanguage] = useState("hebrew");
  const [layoutType, setLayoutType] = useState("qwerty");
  const [layoutLayer, setLayoutLayer] = useState("default");
  const [inputValue, setInputValue] = useState("");
  const [showLongPress, setShowLongPress] = useState(null);
  const [longPressPosition, setLongPressPosition] = useState({ x: 0, y: 0 });
  const longPressTimer = useRef(null);
  const inputRef = useRef(null);

  const availableLayouts = Object.keys(layouts[language] || {});
  const currentLayout = layouts[language]?.[layoutType] || layouts.english.qwerty;
  const isRTL = language === "hebrew" || language === "arabic";

  // Reset layout type if not available in new language
  useEffect(() => {
    if (!layouts[language]?.[layoutType]) {
      setLayoutType(Object.keys(layouts[language])[0]);
    }
    setLayoutLayer("default");
  }, [language]);

  const handleKeyPress = (key, event) => {
    if (key === "{bksp}") {
      setInputValue(prev => prev.slice(0, -1));
    } else if (key === "{enter}") {
      setInputValue(prev => prev + "\n");
    } else if (key === "{space}") {
      setInputValue(prev => prev + " ");
    } else if (key === "{shift}") {
      setLayoutLayer(prev => prev === "shift" ? "default" : "shift");
    } else if (key === "{tab}") {
      setInputValue(prev => prev + "\t");
    } else if (key === "{lock}") {
      setLayoutLayer(prev => prev === "shift" ? "default" : "shift");
    } else if (key === "{default}") {
      setLayoutLayer("default");
    } else if (key === "{nikud}") {
      setLayoutLayer("nikud");
    } else {
      setInputValue(prev => prev + key);
      if (layoutLayer === "shift") {
        setLayoutLayer("default");
      }
    }
    inputRef.current?.focus();
  };

  const handleKeyMouseDown = (key, event) => {
    if (language === "hebrew" && hebrewLongPress[key]) {
      const rect = event.target.getBoundingClientRect();
      longPressTimer.current = setTimeout(() => {
        setShowLongPress(key);
        setLongPressPosition({ 
          x: rect.left + rect.width / 2, 
          y: rect.top - 10 
        });
      }, 500);
    }
  };

  const handleKeyMouseUp = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handleLongPressSelect = (char) => {
    setInputValue(prev => prev + char);
    setShowLongPress(null);
    inputRef.current?.focus();
  };

  const renderKey = (key) => {
    const isSpecial = key.startsWith("{");
    const displayKey = display[key] || key;
    const hasLongPress = language === "hebrew" && hebrewLongPress[key];
    
    return (
      <button
        key={key}
        onClick={(e) => handleKeyPress(key, e)}
        onMouseDown={(e) => handleKeyMouseDown(key, e)}
        onMouseUp={handleKeyMouseUp}
        onMouseLeave={handleKeyMouseUp}
        onTouchStart={(e) => handleKeyMouseDown(key, e.touches[0])}
        onTouchEnd={handleKeyMouseUp}
        className={`
          relative px-3 py-3 m-0.5 rounded-lg font-medium text-lg
          transition-all duration-150 select-none
          ${isSpecial 
            ? "bg-gray-600 text-gray-200 min-w-[3rem]" 
            : "bg-gray-700 text-white hover:bg-gray-600 active:bg-gray-500"
          }
          ${key === "{space}" ? "flex-grow min-w-[12rem]" : ""}
          ${key === "{enter}" ? "min-w-[4rem]" : ""}
          ${key === "{bksp}" ? "min-w-[3rem]" : ""}
          ${hasLongPress ? "after:content-['•'] after:absolute after:top-1 after:right-1 after:text-xs after:text-blue-400" : ""}
        `}
      >
        {displayKey}
      </button>
    );
  };

  const renderRow = (rowString, index) => {
    const keys = rowString.split(" ");
    return (
      <div key={index} className="flex justify-center">
        {keys.map(renderKey)}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6 text-center">
          Virtual Keyboard Layout Selector
        </h1>

        {/* Language Selection */}
        <div className="mb-6 p-4 bg-gray-800 rounded-lg">
          <h2 className="text-lg font-semibold mb-3 text-gray-300">Language</h2>
          <div className="flex flex-wrap gap-4">
            {Object.keys(layouts).map((lang) => (
              <label 
                key={lang} 
                className="flex items-center gap-2 cursor-pointer"
              >
                <input
                  type="radio"
                  name="language"
                  value={lang}
                  checked={language === lang}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-4 h-4 accent-blue-500"
                />
                <span className="capitalize">{lang}</span>
                <span className="text-gray-500 text-sm">
                  {lang === "hebrew" && "עברית"}
                  {lang === "arabic" && "العربية"}
                </span>
              </label>
            ))}
          </div>
        </div>

        {/* Layout Type Selection */}
        <div className="mb-6 p-4 bg-gray-800 rounded-lg">
          <h2 className="text-lg font-semibold mb-3 text-gray-300">Layout</h2>
          <div className="flex flex-wrap gap-4">
            {availableLayouts.map((layout) => (
              <label 
                key={layout} 
                className="flex items-center gap-2 cursor-pointer"
              >
                <input
                  type="radio"
                  name="layout"
                  value={layout}
                  checked={layoutType === layout}
                  onChange={(e) => setLayoutType(e.target.value)}
                  className="w-4 h-4 accent-blue-500"
                />
                <span className="capitalize">{layout}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Layer Toggle */}
        <div className="mb-6 p-4 bg-gray-800 rounded-lg">
          <h2 className="text-lg font-semibold mb-3 text-gray-300">Layer</h2>
          <div className="flex flex-wrap gap-4">
            {Object.keys(currentLayout).map((layer) => (
              <label 
                key={layer} 
                className="flex items-center gap-2 cursor-pointer"
              >
                <input
                  type="radio"
                  name="layer"
                  value={layer}
                  checked={layoutLayer === layer}
                  onChange={(e) => setLayoutLayer(e.target.value)}
                  className="w-4 h-4 accent-green-500"
                />
                <span className="capitalize">{layer}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Text Input */}
        <div className="mb-6">
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            dir={isRTL ? "rtl" : "ltr"}
            placeholder={isRTL ? "הקלד כאן..." : "Type here..."}
            className="w-full h-32 p-4 bg-gray-800 border border-gray-700 rounded-lg 
                     text-xl resize-none focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Virtual Keyboard */}
        <div 
          className="p-4 bg-gray-800 rounded-lg"
          dir={isRTL ? "rtl" : "ltr"}
        >
          <div className="flex flex-col gap-1">
            {(currentLayout[layoutLayer] || currentLayout.default).map(renderRow)}
          </div>
          
          {/* Nikud toggle button for Hebrew */}
          {language === "hebrew" && currentLayout.nikud && (
            <div className="mt-2 flex justify-center">
              <button
                onClick={() => setLayoutLayer(layoutLayer === "nikud" ? "default" : "nikud")}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  layoutLayer === "nikud" 
                    ? "bg-blue-600 text-white" 
                    : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                }`}
              >
                ניקוד {layoutLayer === "nikud" ? "✓" : ""}
              </button>
            </div>
          )}
        </div>

        {/* Long Press Popup */}
        {showLongPress && hebrewLongPress[showLongPress] && (
          <>
            <div 
              className="fixed inset-0 z-40"
              onClick={() => setShowLongPress(null)}
            />
            <div 
              className="fixed z-50 bg-gray-700 rounded-lg shadow-xl p-2 flex gap-1"
              style={{
                left: longPressPosition.x,
                top: longPressPosition.y,
                transform: "translate(-50%, -100%)"
              }}
            >
              {hebrewLongPress[showLongPress].map((char, i) => (
                <button
                  key={i}
                  onClick={() => handleLongPressSelect(char)}
                  className="px-3 py-2 bg-gray-600 hover:bg-gray-500 rounded text-lg"
                >
                  {char}
                </button>
              ))}
            </div>
          </>
        )}

        {/* Info Panel */}
        <div className="mt-6 p-4 bg-gray-800 rounded-lg text-sm text-gray-400">
          <p>
            <strong className="text-gray-300">Current:</strong> {language} / {layoutType} / {layoutLayer}
          </p>
          {language === "hebrew" && (
            <p className="mt-2">
              <span className="text-blue-400">•</span> = Long press for nikud variants
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
