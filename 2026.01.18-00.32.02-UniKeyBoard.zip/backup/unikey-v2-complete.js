// ═══════════════════════════════════════════════════════════════════════════
// UniKey v2 - Complete OOP Architecture
// ═══════════════════════════════════════════════════════════════════════════
//
// CORE PRINCIPLE: Usage-based, not layout-based
//
// ┌─────────────────────────────────────────────────────────────────────────┐
// │                              IPA (BRIDGE)                               │
// │                                 /a/                                     │
// │                                  │                                      │
// │         ┌────────────────────────┼────────────────────────┐             │
// │         ▼                        ▼                        ▼             │
// │   ┌──────────┐            ┌──────────┐            ┌──────────┐          │
// │   │ Hebrew   │            │ Hebrew   │            │ English  │          │
// │   │ Nikud    │            │ Plain    │            │ Spelling │          │
// │   │ ַ פַּתַח  │            │ א ע      │            │ a, ah    │          │
// │   └──────────┘            └──────────┘            └──────────┘          │
// └─────────────────────────────────────────────────────────────────────────┘
//
// ┌─────────────────────────────────────────────────────────────────────────┐
// │                           NUMBER VARIANTS                               │
// │                                 5                                       │
// │                                 │                                       │
// │    ┌──────┬──────┬──────┬──────┼──────┬──────┬──────┬──────┐            │
// │    ▼      ▼      ▼      ▼      ▼      ▼      ▼      ▼      ▼            │
// │   ⑤     ❺     ⑸     5️⃣    Ⅴ     ⁵     ₅     ㊄    五           │
// │ circled neg  paren emoji roman super  sub   cjk  chinese              │
// └─────────────────────────────────────────────────────────────────────────┘
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// IPA PHONEME DATABASE - The Universal Bridge
// ═══════════════════════════════════════════════════════════════════════════

const IPA_PHONEMES = {
  // ═══════════════════════════════════════════════════════════════════════
  // VOWELS
  // ═══════════════════════════════════════════════════════════════════════
  
  'a': {
    name: 'open front unrounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ַ', name: 'פַּתַח', nameEn: 'patach' },
        { char: 'ֲ', name: 'חֲטַף פַּתַח', nameEn: 'hataf patach' },
      ],
      plain: ['א', 'ע'],
      examples: ['אַב', 'עַל'],
    },
    english: {
      spellings: [
        { pattern: 'a', example: 'father', word: 'אָב' },
        { pattern: 'ah', example: 'bah', word: 'בָּא' },
        { pattern: 'ar', example: 'car', word: 'קַר' },
      ],
    },
  },

  'ɑ': {
    name: 'open back unrounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ָ', name: 'קָמָץ', nameEn: 'kamatz' },
      ],
      plain: ['א', 'ע'],
      examples: ['קָם', 'בָּא'],
    },
    english: {
      spellings: [
        { pattern: 'a', example: 'father', word: 'אָב' },
        { pattern: 'o', example: 'hot', word: 'חַם' },
      ],
    },
  },

  'e': {
    name: 'close-mid front unrounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ֵ', name: 'צֵירֵי', nameEn: 'tsere' },
        { char: 'ֵי', name: 'צֵירֵי מָלֵא', nameEn: 'tsere male' },
      ],
      plain: ['י', 'יי'],
      examples: ['בֵּן', 'שֵׁם'],
    },
    english: {
      spellings: [
        { pattern: 'e', example: 'bed', word: 'מִיטָה' },
        { pattern: 'ay', example: 'day', word: 'יוֹם' },
        { pattern: 'ei', example: 'vein', word: 'וְרִיד' },
        { pattern: 'ey', example: 'they', word: 'הֵם' },
        { pattern: 'ea', example: 'great', word: 'גָּדוֹל' },
      ],
    },
  },

  'ɛ': {
    name: 'open-mid front unrounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ֶ', name: 'סֶגוֹל', nameEn: 'segol' },
        { char: 'ֱ', name: 'חֲטַף סֶגוֹל', nameEn: 'hataf segol' },
      ],
      plain: ['א', 'ע'],
      examples: ['סֶלֶע', 'אֱמֶת'],
    },
    english: {
      spellings: [
        { pattern: 'e', example: 'bed', word: 'מִיטָה' },
        { pattern: 'ea', example: 'bread', word: 'לֶחֶם' },
      ],
    },
  },

  'i': {
    name: 'close front unrounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ִ', name: 'חִירִיק', nameEn: 'hirik' },
        { char: 'ִי', name: 'חִירִיק מָלֵא', nameEn: 'hirik male' },
      ],
      plain: ['י'],
      examples: ['בִּית', 'שִׁיר'],
    },
    english: {
      spellings: [
        { pattern: 'ee', example: 'see', word: 'רָאָה' },
        { pattern: 'ea', example: 'eat', word: 'אָכַל' },
        { pattern: 'i', example: 'ski', word: 'סְקִי' },
        { pattern: 'ie', example: 'field', word: 'שָׂדֶה' },
        { pattern: 'y', example: 'happy', word: 'שָׂמֵחַ' },
      ],
    },
  },

  'o': {
    name: 'close-mid back rounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ֹ', name: 'חוֹלָם', nameEn: 'holam' },
        { char: 'וֹ', name: 'חוֹלָם מָלֵא', nameEn: 'holam male' },
        { char: 'ֳ', name: 'חֲטַף קָמָץ', nameEn: 'hataf kamatz' },
      ],
      plain: ['ו'],
      examples: ['טוֹב', 'שָׁלוֹם'],
    },
    english: {
      spellings: [
        { pattern: 'o', example: 'go', word: 'לָלֶכֶת' },
        { pattern: 'oa', example: 'boat', word: 'סִירָה' },
        { pattern: 'ow', example: 'low', word: 'נָמוּךְ' },
        { pattern: 'oe', example: 'toe', word: 'בֹּהֶן' },
      ],
    },
  },

  'u': {
    name: 'close back rounded vowel',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ֻ', name: 'קֻבּוּץ', nameEn: 'kubutz' },
        { char: 'וּ', name: 'שׁוּרוּק', nameEn: 'shuruk' },
      ],
      plain: ['ו'],
      examples: ['סוּס', 'שׁוּק'],
    },
    english: {
      spellings: [
        { pattern: 'oo', example: 'moon', word: 'יָרֵחַ' },
        { pattern: 'u', example: 'rule', word: 'כְּלָל' },
        { pattern: 'ue', example: 'blue', word: 'כָּחֹל' },
        { pattern: 'ew', example: 'new', word: 'חָדָשׁ' },
      ],
    },
  },

  'ə': {
    name: 'schwa (mid central vowel)',
    type: 'vowel',
    hebrew: {
      nikud: [
        { char: 'ְ', name: 'שְׁוָא', nameEn: 'shva' },
      ],
      plain: [], // No plain representation
      examples: ['בְּרֵאשִׁית', 'שְׁמוֹ'],
    },
    english: {
      spellings: [
        { pattern: 'a', example: 'about', word: 'עַל' },
        { pattern: 'e', example: 'taken', word: 'לָקוּחַ' },
        { pattern: 'i', example: 'pencil', word: 'עִפָּרוֹן' },
        { pattern: 'o', example: 'lemon', word: 'לִימוֹן' },
        { pattern: 'u', example: 'circus', word: 'קִרְקַס' },
      ],
    },
  },

  // ═══════════════════════════════════════════════════════════════════════
  // CONSONANTS
  // ═══════════════════════════════════════════════════════════════════════

  'b': {
    name: 'voiced bilabial plosive',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'בּ', name: 'בית דגושה', nameEn: 'bet' }],
      plain: ['ב'],
    },
    english: {
      spellings: [{ pattern: 'b', example: 'bat' }, { pattern: 'bb', example: 'rabbit' }],
    },
  },

  'v': {
    name: 'voiced labiodental fricative',
    type: 'consonant',
    hebrew: {
      nikud: [
        { char: 'ב', name: 'בית רפה', nameEn: 'vet' },
        { char: 'ו', name: 'וו', nameEn: 'vav' },
      ],
      plain: ['ב', 'ו'],
    },
    english: {
      spellings: [{ pattern: 'v', example: 'van' }],
    },
  },

  'g': {
    name: 'voiced velar plosive',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'גּ', name: 'גימל דגושה', nameEn: 'gimel' }],
      plain: ['ג'],
    },
    english: {
      spellings: [{ pattern: 'g', example: 'go' }, { pattern: 'gg', example: 'egg' }],
    },
  },

  'd': {
    name: 'voiced alveolar plosive',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'דּ', name: 'דלת דגושה', nameEn: 'dalet' }],
      plain: ['ד'],
    },
    english: {
      spellings: [{ pattern: 'd', example: 'dog' }, { pattern: 'dd', example: 'add' }],
    },
  },

  'h': {
    name: 'voiceless glottal fricative',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ה', name: 'הא', nameEn: 'he' }],
      plain: ['ה'],
    },
    english: {
      spellings: [{ pattern: 'h', example: 'hat' }],
    },
  },

  'z': {
    name: 'voiced alveolar fricative',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ז', name: 'זין', nameEn: 'zayin' }],
      plain: ['ז'],
    },
    english: {
      spellings: [{ pattern: 'z', example: 'zoo' }, { pattern: 's', example: 'is' }],
    },
  },

  'x': {
    name: 'voiceless velar fricative',
    type: 'consonant',
    hebrew: {
      nikud: [
        { char: 'כ', name: 'כף רפה', nameEn: 'khaf' },
        { char: 'ח', name: 'חית', nameEn: 'het' },
      ],
      plain: ['כ', 'ח'],
    },
    english: {
      spellings: [{ pattern: 'ch', example: 'Bach (German)' }],
    },
  },

  't': {
    name: 'voiceless alveolar plosive',
    type: 'consonant',
    hebrew: {
      nikud: [
        { char: 'תּ', name: 'תו דגושה', nameEn: 'tav' },
        { char: 'ט', name: 'טית', nameEn: 'tet' },
      ],
      plain: ['ת', 'ט'],
    },
    english: {
      spellings: [{ pattern: 't', example: 'top' }, { pattern: 'tt', example: 'butter' }],
    },
  },

  'j': {
    name: 'palatal approximant',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'י', name: 'יוד', nameEn: 'yod' }],
      plain: ['י'],
    },
    english: {
      spellings: [{ pattern: 'y', example: 'yes' }],
    },
  },

  'k': {
    name: 'voiceless velar plosive',
    type: 'consonant',
    hebrew: {
      nikud: [
        { char: 'כּ', name: 'כף דגושה', nameEn: 'kaf' },
        { char: 'ק', name: 'קוף', nameEn: 'kuf' },
      ],
      plain: ['כ', 'ק'],
    },
    english: {
      spellings: [
        { pattern: 'k', example: 'kit' },
        { pattern: 'c', example: 'cat' },
        { pattern: 'ck', example: 'back' },
      ],
    },
  },

  'l': {
    name: 'alveolar lateral approximant',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ל', name: 'למד', nameEn: 'lamed' }],
      plain: ['ל'],
    },
    english: {
      spellings: [{ pattern: 'l', example: 'let' }, { pattern: 'll', example: 'ball' }],
    },
  },

  'm': {
    name: 'bilabial nasal',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'מ', name: 'מם', nameEn: 'mem' }],
      plain: ['מ', 'ם'],
    },
    english: {
      spellings: [{ pattern: 'm', example: 'man' }, { pattern: 'mm', example: 'summer' }],
    },
  },

  'n': {
    name: 'alveolar nasal',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'נ', name: 'נון', nameEn: 'nun' }],
      plain: ['נ', 'ן'],
    },
    english: {
      spellings: [{ pattern: 'n', example: 'no' }, { pattern: 'nn', example: 'dinner' }],
    },
  },

  's': {
    name: 'voiceless alveolar fricative',
    type: 'consonant',
    hebrew: {
      nikud: [
        { char: 'ס', name: 'סמך', nameEn: 'samekh' },
        { char: 'שׂ', name: 'שין שמאלית', nameEn: 'sin' },
      ],
      plain: ['ס', 'ש'],
    },
    english: {
      spellings: [
        { pattern: 's', example: 'sit' },
        { pattern: 'ss', example: 'miss' },
        { pattern: 'c', example: 'city' },
      ],
    },
  },

  'p': {
    name: 'voiceless bilabial plosive',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'פּ', name: 'פא דגושה', nameEn: 'pe' }],
      plain: ['פ'],
    },
    english: {
      spellings: [{ pattern: 'p', example: 'pat' }, { pattern: 'pp', example: 'happy' }],
    },
  },

  'f': {
    name: 'voiceless labiodental fricative',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'פ', name: 'פא רפה', nameEn: 'fe' }],
      plain: ['פ', 'ף'],
    },
    english: {
      spellings: [
        { pattern: 'f', example: 'fat' },
        { pattern: 'ff', example: 'off' },
        { pattern: 'ph', example: 'phone' },
      ],
    },
  },

  'ts': {
    name: 'voiceless alveolar affricate',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'צ', name: 'צדי', nameEn: 'tsadi' }],
      plain: ['צ', 'ץ'],
    },
    english: {
      spellings: [{ pattern: 'ts', example: 'cats' }, { pattern: 'tz', example: 'pizza' }],
    },
  },

  'r': {
    name: 'alveolar trill/tap',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ר', name: 'ריש', nameEn: 'resh' }],
      plain: ['ר'],
    },
    english: {
      spellings: [{ pattern: 'r', example: 'red' }, { pattern: 'rr', example: 'carry' }],
    },
  },

  'ʃ': {
    name: 'voiceless postalveolar fricative',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'שׁ', name: 'שין ימנית', nameEn: 'shin' }],
      plain: ['ש'],
    },
    english: {
      spellings: [
        { pattern: 'sh', example: 'ship' },
        { pattern: 'ti', example: 'nation' },
        { pattern: 'ci', example: 'special' },
      ],
    },
  },

  'tʃ': {
    name: 'voiceless postalveolar affricate',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: "צ'", name: "צ׳ט", nameEn: 'ch' }],
      plain: ["צ'", "ץ'"],
    },
    english: {
      spellings: [
        { pattern: 'ch', example: 'chat' },
        { pattern: 'tch', example: 'catch' },
      ],
    },
  },

  'dʒ': {
    name: 'voiced postalveolar affricate',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: "ג'", name: "ג׳", nameEn: 'j' }],
      plain: ["ג'"],
    },
    english: {
      spellings: [
        { pattern: 'j', example: 'jam' },
        { pattern: 'g', example: 'gem' },
        { pattern: 'dge', example: 'bridge' },
      ],
    },
  },

  'w': {
    name: 'voiced labial-velar approximant',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ו', name: 'וו שמושית', nameEn: 'vav' }],
      plain: ['ו'],
    },
    english: {
      spellings: [{ pattern: 'w', example: 'wet' }],
    },
  },

  'ʔ': {
    name: 'glottal stop',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'א', name: 'אלף', nameEn: 'alef' }],
      plain: ['א'],
    },
    english: {
      spellings: [], // Rarely written in English
    },
  },

  'ʕ': {
    name: 'voiced pharyngeal fricative',
    type: 'consonant',
    hebrew: {
      nikud: [{ char: 'ע', name: 'עין', nameEn: 'ayin' }],
      plain: ['ע'],
    },
    english: {
      spellings: [], // No English equivalent
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// NUMBER VARIANTS DATABASE
// ═══════════════════════════════════════════════════════════════════════════

const NUMBER_VARIANTS_DATA = {
  '0': {
    basic: '0',
    circled: '⓪',
    negCircled: '⓿',
    emoji: '0️⃣',
    superscript: '⁰',
    subscript: '₀',
    chinese: '〇',
    fullwidth: '０',
  },
  '1': {
    basic: '1',
    circled: '①',
    negCircled: '❶',
    parenthesized: '⑴',
    doubleCircled: '⓵',
    emoji: '1️⃣',
    roman: 'Ⅰ',
    romanSmall: 'ⅰ',
    superscript: '¹',
    subscript: '₁',
    cjkCircled: '㊀',
    chinese: '一',
    fullwidth: '１',
  },
  '2': {
    basic: '2',
    circled: '②',
    negCircled: '❷',
    parenthesized: '⑵',
    doubleCircled: '⓶',
    emoji: '2️⃣',
    roman: 'Ⅱ',
    romanSmall: 'ⅱ',
    superscript: '²',
    subscript: '₂',
    cjkCircled: '㊁',
    chinese: '二',
    fullwidth: '２',
  },
  '3': {
    basic: '3',
    circled: '③',
    negCircled: '❸',
    parenthesized: '⑶',
    doubleCircled: '⓷',
    emoji: '3️⃣',
    roman: 'Ⅲ',
    romanSmall: 'ⅲ',
    superscript: '³',
    subscript: '₃',
    cjkCircled: '㊂',
    chinese: '三',
    fullwidth: '３',
  },
  '4': {
    basic: '4',
    circled: '④',
    negCircled: '❹',
    parenthesized: '⑷',
    doubleCircled: '⓸',
    emoji: '4️⃣',
    roman: 'Ⅳ',
    romanSmall: 'ⅳ',
    superscript: '⁴',
    subscript: '₄',
    cjkCircled: '㊃',
    chinese: '四',
    fullwidth: '４',
  },
  '5': {
    basic: '5',
    circled: '⑤',
    negCircled: '❺',
    parenthesized: '⑸',
    doubleCircled: '⓹',
    emoji: '5️⃣',
    roman: 'Ⅴ',
    romanSmall: 'ⅴ',
    superscript: '⁵',
    subscript: '₅',
    cjkCircled: '㊄',
    chinese: '五',
    fullwidth: '５',
  },
  '6': {
    basic: '6',
    circled: '⑥',
    negCircled: '❻',
    parenthesized: '⑹',
    doubleCircled: '⓺',
    emoji: '6️⃣',
    roman: 'Ⅵ',
    romanSmall: 'ⅵ',
    superscript: '⁶',
    subscript: '₆',
    cjkCircled: '㊅',
    chinese: '六',
    fullwidth: '６',
  },
  '7': {
    basic: '7',
    circled: '⑦',
    negCircled: '❼',
    parenthesized: '⑺',
    doubleCircled: '⓻',
    emoji: '7️⃣',
    roman: 'Ⅶ',
    romanSmall: 'ⅶ',
    superscript: '⁷',
    subscript: '₇',
    cjkCircled: '㊆',
    chinese: '七',
    fullwidth: '７',
  },
  '8': {
    basic: '8',
    circled: '⑧',
    negCircled: '❽',
    parenthesized: '⑻',
    doubleCircled: '⓼',
    emoji: '8️⃣',
    roman: 'Ⅷ',
    romanSmall: 'ⅷ',
    superscript: '⁸',
    subscript: '₈',
    cjkCircled: '㊇',
    chinese: '八',
    fullwidth: '８',
  },
  '9': {
    basic: '9',
    circled: '⑨',
    negCircled: '❾',
    parenthesized: '⑼',
    doubleCircled: '⓽',
    emoji: '9️⃣',
    roman: 'Ⅸ',
    romanSmall: 'ⅸ',
    superscript: '⁹',
    subscript: '₉',
    cjkCircled: '㊈',
    chinese: '九',
    fullwidth: '９',
  },
  '10': {
    circled: '⑩',
    negCircled: '❿',
    parenthesized: '⑽',
    doubleCircled: '⓾',
    emoji: '🔟',
    roman: 'Ⅹ',
    romanSmall: 'ⅹ',
    cjkCircled: '㊉',
    chinese: '十',
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// UNIKEY v2 CLASS
// ═══════════════════════════════════════════════════════════════════════════

class UniKey2 {
  constructor(config) {
    this.id = config.id;
    this.type = config.type || 'letter'; // 'letter', 'number', 'symbol', 'special'
    
    // Display values
    this.en = config.en;
    this.EN = config.EN || config.en?.toUpperCase();
    this.he = config.he;
    this.heShift = config.heShift;
    
    // IPA - the bridge to phonetic data
    this.ipa = config.ipa;
    
    // For numbers: Unicode variants
    this._variants = config.variants || null;
    
    // Multi-gender data
    this.mg = config.mg || null;
    
    // Cache
    this._phoneme = null;
  }
  
  // === PHONEME DATA (from IPA) ===
  
  get phoneme() {
    if (this._phoneme) return this._phoneme;
    if (!this.ipa) return null;
    this._phoneme = IPA_PHONEMES[this.ipa] || null;
    return this._phoneme;
  }
  
  // === HEBREW REPRESENTATIONS ===
  
  getHebrewNikud() {
    if (!this.phoneme) return [];
    return this.phoneme.hebrew?.nikud || [];
  }
  
  getHebrewPlain() {
    if (!this.phoneme) return [];
    return this.phoneme.hebrew?.plain || [];
  }
  
  getHebrewExamples() {
    if (!this.phoneme) return [];
    return this.phoneme.hebrew?.examples || [];
  }
  
  // === ENGLISH REPRESENTATIONS ===
  
  getEnglishSpellings() {
    if (!this.phoneme) return [];
    return this.phoneme.english?.spellings || [];
  }
  
  // === SYLLABLES FOR POPUP ===
  
  getSyllables(mode, withNikud = true) {
    if (mode === 'he') {
      return withNikud ? this.getHebrewNikud() : this.getHebrewPlain();
    }
    return this.getEnglishSpellings();
  }
  
  hasSyllables(mode) {
    return this.getSyllables(mode).length > 0;
  }
  
  // === NUMBER VARIANTS ===
  
  get variants() {
    if (this.type !== 'number') return null;
    if (this._variants) return this._variants;
    return NUMBER_VARIANTS_DATA[this.id] || null;
  }
  
  getVariant(type) {
    if (!this.variants) return null;
    return this.variants[type] || null;
  }
  
  getAllVariants() {
    if (!this.variants) return [];
    return Object.entries(this.variants).map(([type, char]) => ({
      type,
      char,
    }));
  }
  
  // === DISPLAY ===
  
  getDisplay(mode, mods = {}) {
    const { shift, alt, ctrl } = mods;
    
    // Ctrl: Show IPA
    if (ctrl && this.ipa) return this.ipa;
    
    // Alt on numbers: Show circled
    if (alt && this.type === 'number') {
      return this.getVariant('circled') || this.id;
    }
    
    // Alt on letters: Show MG
    if (alt && this.mg) {
      const isEn = mode === 'en' || mode === 'EN';
      return shift 
        ? (isEn ? this.mg.fm_en : this.mg.fm) 
        : (isEn ? this.mg.mf_en : this.mg.mf);
    }
    
    // Shift: syllable indicator or shifted value
    if (shift) {
      if (this.hasSyllables(mode)) {
        return (this[mode] || this.en) + '·';
      }
      if (mode === 'en') return this.EN;
      if (mode === 'he') return this.heShift || this.he;
    }
    
    // Normal
    if (mode === 'en') return this.en;
    if (mode === 'EN') return this.EN;
    if (mode === 'he') return this.he;
    return this.en;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// FACTORY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

function NumberKey(digit, config = {}) {
  return new UniKey2({
    id: digit,
    type: 'number',
    en: digit,
    he: digit,
    ...config,
  });
}

function LetterKey(config) {
  return new UniKey2({
    type: 'letter',
    ...config,
  });
}

function VowelKey(config) {
  return new UniKey2({
    type: 'vowel',
    ...config,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// KEYBOARD REGISTRY
// ═══════════════════════════════════════════════════════════════════════════

const UK2 = {};

// Register numbers
['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].forEach(d => {
  UK2[d] = NumberKey(d);
});

// Register vowels (linked by IPA)
UK2['a'] = VowelKey({ id: 'a', en: 'a', he: 'ש', ipa: 'a' });
UK2['e'] = VowelKey({ id: 'e', en: 'e', he: 'ק', ipa: 'e' });
UK2['i'] = VowelKey({ id: 'i', en: 'i', he: 'ן', ipa: 'i' });
UK2['o'] = VowelKey({ id: 'o', en: 'o', he: 'ם', ipa: 'o' });
UK2['u'] = VowelKey({ id: 'u', en: 'u', he: 'ו', ipa: 'u' });

// Register consonants (linked by IPA)
UK2['b'] = LetterKey({ id: 'b', en: 'b', he: 'נ', ipa: 'b' });
UK2['g'] = LetterKey({ id: 'g', en: 'g', he: 'ע', ipa: 'g' });
UK2['d'] = LetterKey({ id: 'd', en: 'd', he: 'ג', ipa: 'd' });
UK2['h'] = LetterKey({ id: 'h', en: 'h', he: 'י', ipa: 'h' });
UK2['k'] = LetterKey({ id: 'k', en: 'k', he: 'ל', ipa: 'k' });
UK2['l'] = LetterKey({ id: 'l', en: 'l', he: 'כ', ipa: 'l' });
UK2['m'] = LetterKey({ id: 'm', en: 'm', he: 'צ', ipa: 'm' });
UK2['n'] = LetterKey({ id: 'n', en: 'n', he: 'מ', ipa: 'n' });
UK2['p'] = LetterKey({ id: 'p', en: 'p', he: 'פ', ipa: 'p' });
UK2['r'] = LetterKey({ id: 'r', en: 'r', he: 'ר', ipa: 'r' });
UK2['s'] = LetterKey({ id: 's', en: 's', he: 'ד', ipa: 's' });
UK2['t'] = LetterKey({ id: 't', en: 't', he: 'א', ipa: 't' });
UK2['v'] = LetterKey({ id: 'v', en: 'v', he: 'ה', ipa: 'v' });
UK2['z'] = LetterKey({ id: 'z', en: 'z', he: 'ז', ipa: 'z' });

// ═══════════════════════════════════════════════════════════════════════════
// TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UniKey v2 - Complete OOP Architecture');
console.log('═══════════════════════════════════════════════════════════════');
console.log('');

console.log('NUMBER EXAMPLE: 5');
console.log('─────────────────────────────────────────────────────────────────');
const num5 = UK2['5'];
console.log('All variants:', num5.getAllVariants().map(v => `${v.type}: ${v.char}`).join(', '));
console.log('Circled:', num5.getVariant('circled'));
console.log('Roman:', num5.getVariant('roman'));
console.log('');

console.log('VOWEL EXAMPLE: a (IPA /a/)');
console.log('─────────────────────────────────────────────────────────────────');
const vowelA = UK2['a'];
console.log('Hebrew Nikud:', vowelA.getHebrewNikud().map(n => `${n.char} (${n.name})`).join(', '));
console.log('Hebrew Plain:', vowelA.getHebrewPlain().join(', '));
console.log('English Spellings:', vowelA.getEnglishSpellings().map(s => `${s.pattern} (${s.example})`).join(', '));
console.log('');

console.log('CONSONANT EXAMPLE: s (IPA /s/)');
console.log('─────────────────────────────────────────────────────────────────');
const phonemeS = IPA_PHONEMES['s'];
console.log('Hebrew Nikud:', phonemeS.hebrew.nikud.map(n => `${n.char} (${n.name})`).join(', '));
console.log('Hebrew Plain:', phonemeS.hebrew.plain.join(', '));
console.log('English Spellings:', phonemeS.english.spellings.map(s => `${s.pattern} (${s.example})`).join(', '));
console.log('');

console.log('DISPLAY MODES:');
console.log('─────────────────────────────────────────────────────────────────');
console.log('num5.getDisplay("en"):', num5.getDisplay('en'));
console.log('num5.getDisplay("en", {alt: true}):', num5.getDisplay('en', {alt: true}));
console.log('vowelA.getDisplay("en", {ctrl: true}):', vowelA.getDisplay('en', {ctrl: true}));
console.log('vowelA.getDisplay("en", {shift: true}):', vowelA.getDisplay('en', {shift: true}));
console.log('');

console.log('═══════════════════════════════════════════════════════════════');
console.log('Registry size:', Object.keys(UK2).length, 'keys');
console.log('IPA Phonemes:', Object.keys(IPA_PHONEMES).length, 'sounds');
console.log('═══════════════════════════════════════════════════════════════');
