// ═══════════════════════════════════════════════════════════════════════════
// UniKey v2 - OOP Architecture Design
// ═══════════════════════════════════════════════════════════════════════════
// 
// Core Principle: IPA is the universal bridge connecting all representations
// 
// Usage-based, not layout-based:
// - A "number" key knows all its Unicode variants (①, 1️⃣, Ⅰ, ¹, etc.)
// - A "vowel" key knows Hebrew (nikud/plain) and English representations
// - Everything linked by IPA phonetic values
//
// ═══════════════════════════════════════════════════════════════════════════

// === IPA BRIDGE ===
// Maps IPA sounds to their representations in different systems
const IPA_BRIDGE = {
  // Vowels
  'a': {
    name: 'open front unrounded',
    he: {
      nikud: [
        { char: 'ַ', name: 'פַּתַח', type: 'vowel' },
        { char: 'ֲ', name: 'חֲטַף פַּתַח', type: 'hataf' },
      ],
      plain: ['א', 'ע'],
    },
    en: [
      { syl: 'a', ex: 'father', pattern: 'CaC' },
      { syl: 'ah', ex: 'bah', pattern: 'Cah' },
    ],
  },
  'ɑ': {
    name: 'open back unrounded',
    he: {
      nikud: [{ char: 'ָ', name: 'קָמָץ', type: 'vowel' }],
      plain: ['א', 'ע'],
    },
    en: [
      { syl: 'a', ex: 'father', pattern: 'Ca' },
      { syl: 'o', ex: 'hot', pattern: 'Co' },
    ],
  },
  'e': {
    name: 'close-mid front unrounded',
    he: {
      nikud: [
        { char: 'ֵ', name: 'צֵירֵי', type: 'vowel' },
        { char: 'ֵי', name: 'צֵירֵי מָלֵא', type: 'male' },
      ],
      plain: ['י', 'יי'],
    },
    en: [
      { syl: 'e', ex: 'bed', pattern: 'CeC' },
      { syl: 'ay', ex: 'day', pattern: 'Cay' },
      { syl: 'ei', ex: 'vein', pattern: 'Cei' },
    ],
  },
  'i': {
    name: 'close front unrounded',
    he: {
      nikud: [
        { char: 'ִ', name: 'חִירִיק', type: 'vowel' },
        { char: 'ִי', name: 'חִירִיק מָלֵא', type: 'male' },
      ],
      plain: ['י'],
    },
    en: [
      { syl: 'ee', ex: 'see', pattern: 'Cee' },
      { syl: 'ea', ex: 'eat', pattern: 'Cea' },
      { syl: 'i', ex: 'ski', pattern: 'Ci' },
    ],
  },
  'o': {
    name: 'close-mid back rounded',
    he: {
      nikud: [
        { char: 'ֹ', name: 'חוֹלָם', type: 'vowel' },
        { char: 'וֹ', name: 'חוֹלָם מָלֵא', type: 'male' },
        { char: 'ֳ', name: 'חֲטַף קָמָץ', type: 'hataf' },
      ],
      plain: ['ו'],
    },
    en: [
      { syl: 'o', ex: 'go', pattern: 'Co' },
      { syl: 'oa', ex: 'boat', pattern: 'Coa' },
      { syl: 'ow', ex: 'low', pattern: 'Cow' },
    ],
  },
  'u': {
    name: 'close back rounded',
    he: {
      nikud: [
        { char: 'ֻ', name: 'קֻבּוּץ', type: 'vowel' },
        { char: 'וּ', name: 'שׁוּרוּק', type: 'male' },
      ],
      plain: ['ו'],
    },
    en: [
      { syl: 'oo', ex: 'moon', pattern: 'Coo' },
      { syl: 'u', ex: 'rule', pattern: 'Cu' },
      { syl: 'ue', ex: 'blue', pattern: 'Cue' },
    ],
  },
  'ə': {
    name: 'schwa',
    he: {
      nikud: [{ char: 'ְ', name: 'שְׁוָא', type: 'vowel' }],
      plain: [],
    },
    en: [
      { syl: 'a', ex: 'about', pattern: 'ə' },
      { syl: 'e', ex: 'taken', pattern: 'ə' },
    ],
  },
  
  // Consonants
  'b': {
    he: { nikud: [{ char: 'בּ', name: 'בית דגושה' }], plain: ['ב'] },
    en: [{ syl: 'b', ex: 'bat' }],
  },
  'v': {
    he: { nikud: [{ char: 'ב', name: 'בית רפה' }, { char: 'ו', name: 'וו' }], plain: ['ב', 'ו'] },
    en: [{ syl: 'v', ex: 'van' }],
  },
  'g': {
    he: { nikud: [{ char: 'גּ', name: 'גימל דגושה' }], plain: ['ג'] },
    en: [{ syl: 'g', ex: 'go' }],
  },
  'd': {
    he: { nikud: [{ char: 'דּ', name: 'דלת דגושה' }], plain: ['ד'] },
    en: [{ syl: 'd', ex: 'dog' }],
  },
  'k': {
    he: { nikud: [{ char: 'כּ', name: 'כף דגושה' }, { char: 'קּ', name: 'קוף' }], plain: ['כ', 'ק'] },
    en: [{ syl: 'k', ex: 'kit' }, { syl: 'c', ex: 'cat' }],
  },
  'x': {
    name: 'voiceless velar fricative',
    he: { nikud: [{ char: 'כ', name: 'כף רפה' }, { char: 'ח', name: 'חית' }], plain: ['כ', 'ח'] },
    en: [{ syl: 'ch', ex: 'Bach (German)' }],
  },
  'ʃ': {
    name: 'voiceless postalveolar fricative',
    he: { nikud: [{ char: 'שׁ', name: 'שין ימנית' }], plain: ['ש'] },
    en: [{ syl: 'sh', ex: 'ship' }],
  },
  's': {
    he: { nikud: [{ char: 'שׂ', name: 'שין שמאלית' }, { char: 'ס', name: 'סמך' }], plain: ['ש', 'ס'] },
    en: [{ syl: 's', ex: 'sit' }],
  },
  't': {
    he: { nikud: [{ char: 'תּ', name: 'תו דגושה' }, { char: 'ט', name: 'טית' }], plain: ['ת', 'ט'] },
    en: [{ syl: 't', ex: 'top' }],
  },
  // ... more consonants
};

// === UNIKEY v2 CLASS ===
class UniKey2 {
  constructor(config) {
    this.id = config.id;
    this.type = config.type || 'letter'; // letter, number, symbol, special
    
    // Physical key position (for layout)
    this.row = config.row;
    this.col = config.col;
    
    // === DISPLAY VALUES ===
    this.display = {
      en: config.en,
      EN: config.EN || config.en?.toUpperCase(),
      he: config.he,
      heShift: config.heShift,
    };
    
    // === IPA - THE BRIDGE ===
    this.ipa = config.ipa;  // Primary IPA sound
    
    // === FOR NUMBERS: UNICODE VARIANTS ===
    this.variants = config.variants || null;
    // Structure: { basic, circled, emoji, roman, script, cjk, symbol }
    
    // === FOR LETTERS: SYLLABLES (linked by IPA) ===
    // These are auto-populated from IPA_BRIDGE
    this._syllables = null;
    
    // === MULTI-GENDER ===
    this.mg = config.mg || null;
  }
  
  // Get all representations for this key's IPA sound
  get syllables() {
    if (this._syllables) return this._syllables;
    if (!this.ipa) return { he: { nikud: [], plain: [] }, en: [] };
    
    const bridge = IPA_BRIDGE[this.ipa];
    if (!bridge) return { he: { nikud: [], plain: [] }, en: [] };
    
    this._syllables = {
      he: bridge.he || { nikud: [], plain: [] },
      en: bridge.en || [],
    };
    return this._syllables;
  }
  
  // Get display text based on mode and modifiers
  getDisplay(mode, mods = {}) {
    const { shift, alt, ctrl } = mods;
    
    // Ctrl: Show IPA
    if (ctrl && this.ipa) return this.ipa;
    
    // Alt on numbers: Show circled variant
    if (alt && this.type === 'number' && this.variants?.circled) {
      return this.variants.circled[0];
    }
    
    // Alt on letters: Show MG
    if (alt && this.mg) {
      const isEn = mode === 'en' || mode === 'EN';
      return shift ? (isEn ? this.mg.fm_en : this.mg.fm) 
                   : (isEn ? this.mg.mf_en : this.mg.mf);
    }
    
    // Shift: Show syllable indicator or shifted value
    if (shift) {
      if (this.hasSyllables(mode)) {
        return this.display[mode] + '·';
      }
      if (mode === 'en') return this.display.EN || this.display.en?.toUpperCase();
      if (mode === 'he') return this.display.heShift || this.display.he;
    }
    
    return this.display[mode] || this.display.en;
  }
  
  // Check if key has syllables for mode
  hasSyllables(mode) {
    if (mode === 'he') {
      return this.syllables.he.nikud.length > 0 || this.syllables.he.plain.length > 0;
    }
    return this.syllables.en.length > 0;
  }
  
  // Get syllables for popup
  getSyllables(mode, withNikud = true) {
    if (mode === 'he') {
      return withNikud ? this.syllables.he.nikud : this.syllables.he.plain;
    }
    return this.syllables.en;
  }
  
  // Get Unicode variants (for numbers)
  getVariants(category = null) {
    if (!this.variants) return [];
    if (category) return this.variants[category] || [];
    
    // Return all variants flat
    return Object.values(this.variants).flat();
  }
  
  // Get MG options
  getMgOptions(mode, withNikud = true) {
    if (!this.mg) return null;
    // Return from MG_SYL_DATA based on key
    return null; // TODO: link to MG_SYL_DATA
  }
}

// === FACTORY FUNCTIONS ===

// Create a number key with all Unicode variants
function NumberKey(digit, config = {}) {
  return new UniKey2({
    id: digit,
    type: 'number',
    en: digit,
    he: digit,
    variants: {
      basic: [digit],
      circled: getCircledVariant(digit),
      negCircled: getNegCircledVariant(digit),
      parenthesized: getParenthesizedVariant(digit),
      emoji: getEmojiVariant(digit),
      roman: getRomanVariant(digit),
      superscript: getSuperscriptVariant(digit),
      subscript: getSubscriptVariant(digit),
      cjk: getCjkVariant(digit),
    },
    ...config,
  });
}

// Create a letter key linked to IPA
function LetterKey(config) {
  return new UniKey2({
    type: 'letter',
    ...config,
  });
}

// Variant generators
function getCircledVariant(d) {
  const map = { '0': '⓪', '1': '①', '2': '②', '3': '③', '4': '④', '5': '⑤', '6': '⑥', '7': '⑦', '8': '⑧', '9': '⑨' };
  return map[d] ? [map[d]] : [];
}
function getNegCircledVariant(d) {
  const map = { '0': '⓿', '1': '❶', '2': '❷', '3': '❸', '4': '❹', '5': '❺', '6': '❻', '7': '❼', '8': '❽', '9': '❾' };
  return map[d] ? [map[d]] : [];
}
function getParenthesizedVariant(d) {
  const map = { '1': '⑴', '2': '⑵', '3': '⑶', '4': '⑷', '5': '⑸', '6': '⑹', '7': '⑺', '8': '⑻', '9': '⑼' };
  return map[d] ? [map[d]] : [];
}
function getEmojiVariant(d) {
  return [d + '️⃣'];
}
function getRomanVariant(d) {
  const upper = { '1': 'Ⅰ', '2': 'Ⅱ', '3': 'Ⅲ', '4': 'Ⅳ', '5': 'Ⅴ', '6': 'Ⅵ', '7': 'Ⅶ', '8': 'Ⅷ', '9': 'Ⅸ' };
  const lower = { '1': 'ⅰ', '2': 'ⅱ', '3': 'ⅲ', '4': 'ⅳ', '5': 'ⅴ', '6': 'ⅵ', '7': 'ⅶ', '8': 'ⅷ', '9': 'ⅸ' };
  return upper[d] ? [upper[d], lower[d]] : [];
}
function getSuperscriptVariant(d) {
  const map = { '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
  return map[d] ? [map[d]] : [];
}
function getSubscriptVariant(d) {
  const map = { '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉' };
  return map[d] ? [map[d]] : [];
}
function getCjkVariant(d) {
  const circled = { '1': '㊀', '2': '㊁', '3': '㊂', '4': '㊃', '5': '㊄', '6': '㊅', '7': '㊆', '8': '㊇', '9': '㊈' };
  const chinese = { '1': '一', '2': '二', '3': '三', '4': '四', '5': '五', '6': '六', '7': '七', '8': '八', '9': '九', '0': '〇' };
  const result = [];
  if (circled[d]) result.push(circled[d]);
  if (chinese[d]) result.push(chinese[d]);
  return result;
}

// === KEYBOARD REGISTRY ===
// All keys indexed by ID
const UK_REGISTRY = {};

// Register number keys
['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].forEach(d => {
  UK_REGISTRY[d] = NumberKey(d);
});

// Register letter keys (example)
UK_REGISTRY['a'] = LetterKey({
  id: 'a',
  en: 'a',
  EN: 'A',
  he: 'ש',
  ipa: 'a', // Links to IPA_BRIDGE['a']
});

UK_REGISTRY['b'] = LetterKey({
  id: 'b',
  en: 'b',
  EN: 'B',
  he: 'נ',
  ipa: 'b', // Links to IPA_BRIDGE['b']
  mg: {
    m: 'בן', f: 'בת', mf: 'בן/בת',
    m_en: 'son', f_en: 'daughter', mf_en: 'son/daughter',
  },
});

// === EXPORTS ===
console.log('UniKey v2 Design loaded');
console.log('Registry:', Object.keys(UK_REGISTRY).length, 'keys');
console.log('Example - Number 5:', UK_REGISTRY['5'].getVariants());
console.log('Example - Letter a syllables:', UK_REGISTRY['a'].syllables);
