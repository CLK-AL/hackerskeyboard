# Local Fonts Directory

Place your `.woff2` font files here and reference them in `fonts.json`.

## fonts.json Format

```json
{
  "Group Name": [
    {
      "name": "Font Name",
      "source": "https://fonts.google.com/specimen/Font+Name",
      "cdn": "https://fonts.googleapis.com/css2?family=Font+Name:wght@400;700&display=swap",
      "local": "./fonts/font_name-400;700.woff2",
      "weights": [400, 700]
    },
    {
      "name": "Variable Font",
      "source": "https://fonts.google.com/specimen/Variable+Font",
      "cdn": "https://fonts.googleapis.com/css2?family=Variable+Font:wght@100..900&display=swap",
      "local": "./fonts/variable_font-variable.woff2",
      "weights": "100-900",
      "variable": true
    }
  ]
}
```

## Field Reference

| Field | Required | Description |
|-------|----------|-------------|
| `name` | ✅ | Display name of the font |
| `source` | ❌ | URL to font specimen/download page |
| `cdn` | ❌ | Google Fonts CSS URL (fallback if no local) |
| `local` | ❌ | Relative path to local .woff2 file |
| `weights` | ❌ | Array `[400, 700]` or range string `"100-900"` |
| `variable` | ❌ | `true` for variable fonts |

## Loading Priority

1. **Local file** (`local`) - fastest, works offline
2. **CDN** (`cdn`) - fallback if local missing

## Naming Convention

Local files should follow this pattern:
```
fontname-weight1;weight2;weight3.woff2
fontname-variable.woff2  (for variable fonts)
```

### Examples:
- `heebo-400.woff2` - Single weight (regular)
- `rubik-300;400;500;700.woff2` - Multiple weights
- `david_libre-400;700.woff2` - Hebrew font with regular and bold
- `heebo-variable.woff2` - Variable font (all weights)

## Supported Formats
- `.woff2` (recommended)
- `.woff`
- `.ttf`
- `.otf`

## Hebrew Fonts (Google Fonts)

| Font | Style | Weights |
|------|-------|---------|
| Heebo | Sans-serif, Variable | 100-900 |
| Rubik | Sans-serif, Variable | 300-900 |
| Assistant | Sans-serif, Variable | 200-800 |
| David Libre | Serif | 400, 500, 700 |
| Frank Ruhl Libre | Serif, Variable | 300-900 |
| Alef | Sans-serif | 400, 700 |
| Miriam Libre | Sans-serif | 400, 700 |
| Secular One | Display | 400 |
| Suez One | Display | 400 |
| Varela Round | Rounded | 400 |
| Amatic SC | Handwritten | 400, 700 |
| Bellefair | Serif | 400 |
| Karantina | Display | 300, 400, 700 |
| Bona Nova | Serif | 400, 700 |
| Tinos | Serif | 400, 700 |

## Rubik Variants (26 total)

| Font | Style |
|------|-------|
| Rubik Mono One | Monospace |
| Rubik Doodle Shadow | 3D Shadow |
| Rubik Doodle Triangles | Geometric |
| Rubik Bubbles | Bubble |
| Rubik Burned | Distressed |
| Rubik Dirt | Dirty |
| Rubik Distressed | Worn |
| Rubik Glitch | Digital Glitch |
| Rubik Glitch Pop | Glitch + Color |
| Rubik Iso | Isometric 3D |
| Rubik Lines | Line Art |
| Rubik Maps | Map Texture |
| Rubik Marker Hatch | Hatched |
| Rubik Maze | Maze Pattern |
| Rubik Microbe | Organic |
| Rubik Moonrocks | Crater Texture |
| Rubik Pixels | Pixel Art |
| Rubik Puddles | Liquid |
| Rubik Scribble | Hand-drawn |
| Rubik Spray Paint | Graffiti |
| Rubik Storm | Lightning |
| Rubik Vinyl | Retro |
| Rubik Wet Paint | Dripping |
| Rubik 80s Fade | Retro Gradient |
| Rubik Broken Fax | Glitched Print |
| Rubik Gemstones | Crystal |

## Emoji Fonts

### Color Emoji
| Font | Source |
|------|--------|
| Twemoji | Twitter/X |
| Noto Color Emoji | Google |
| Fluent Emoji | Microsoft (via Aurora) |
| OpenMoji | Open source |
| JoyPixels | Commercial |
| Blobmoji | Android 4.4 style |

### Monochrome Emoji
| Font | Source |
|------|--------|
| Noto Emoji | Google (B&W) |
| Symbola | Unicode symbols |

### System Emoji
| Font | Platform |
|------|----------|
| Segoe UI Emoji | Windows |
| Apple Color Emoji | macOS/iOS |
| Segoe UI Symbol | Windows (symbols) |

## Notes
- If both `cdn` and `local` are provided, local takes priority
- Uploaded fonts via UI are stored in memory only (not saved between sessions)
- Local fonts from `fonts.json` persist and are shared across all font selectors
- Variable fonts use weight range notation: `"100-900"` with `variable: true`

## עברית רב-מגדרית (Multi-Gender Hebrew)

**Two Systems:**
1. **Ivrita JS** - Text processing library (slash notation → gendered text)
2. **MGHebrew Fonts** - PUA hybrid glyphs for visual display

---

### Font Downloads (WOFF2)

#### Without Nikud (standard)
| Font | Weight | Download |
|------|--------|----------|
| Alef MultiGender | 400 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/AlefMultiGndr-Regular.woff2) |
| Alef MultiGender Bold | 700 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/AlefMultiGndr-Bold.woff2) |
| Heebo MultiGender | 400 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/HeeboMultiGndr-Regular.woff2) |
| Rubik MultiGender | 400 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/RubikMultiGndr-Regular.woff2) |
| Assistant MultiGender | 400 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/AssistantMultiGndr-Regular.woff2) |

#### With Nikud (supports רֵב vowel swap)
| Font | Weight | Download |
|------|--------|----------|
| Alef MultiGender Nikud | 400 | [⬇ woff2](https://raw.githubusercontent.com/AlefAlefAlef/ivrita/master/fonts/AlefMultiGndr-Nikud.woff2) |

**Sources:**
- [alefalefalef.co.il/ivrita](https://alefalefalef.co.il/ivrita/) (Official)
- [GitHub/AlefAlefAlef/ivrita](https://github.com/AlefAlefAlef/ivrita)
- CDN: `https://ivrita.alefalefalef.co.il/ivrita.min.js`
- npm: `npm install ivrita`

---

### Ivrita JS Syntax Rules (19 Official Rules)

From [alefalefalef.co.il/ivrita](https://alefalefalef.co.il/ivrita/):

| # | Rule | Pattern | Examples | ז | נ |
|---|------|---------|----------|---|---|
| 1 | סיומת ־ה | ו/ה, ו.ה | שלו/ה, חרוץ.ה | שלו, חרוץ | שלה, חרוצה |
| 2 | סיומת ־ות | י/ות, י.ות | עורכי/ות | עורכי | עורכות |
| 3 | סיומת ־י | /י, .י, (י) | משוך.י, ענה/י | משוך, ענה | משכי, עני |
| 4 | סיומת ־ית | /ית, .ית | סטודנט/ית | סטודנט | סטודנטית |
| 5 | סיומת ־ים/ות | ים/ות, יםות | דרושים/ות | דרושים | דרושות |
| 6 | סיומת ־ים/יות | ים/יות | פרילנסרים/יות | פרילנסרים | פרילנסריות |
| 7 | סיומת ־ם/ן | ם/ן, םן | שלכם/ן, בתיכםן | שלכם | שלכן |
| 8 | סיומת ־נה | ו/נה | בקשו/נה | בקשו | בקשנה |
| 9 | סיומת ־ת | /ת, .ת | מעצב/ת | מעצב | מעצבת |
| 10 | סיומת ־תה | ה/תה | בכה/תה | בכה | בכתה |
| 11 | סיומת ־תי | י/תי | יקירי/תי | יקירי | יקירתי |
| 12 | י/ת־ בתחילה | י/ת, ת/י | י/תכתוב | יכתוב | תכתוב |
| 13 | א.נשים | א.נשים | א/נשי | אנשי | נשות |
| 14 | סוגריים (✱) | (letter) | סב(ת)א, עלי(י)ך | סבא, עליך | סבתא, עלייך |
| 15 | מילים שלמות | word/word | בן/בת, היא/הוא | בן, הוא | בת, היא |
| 16 | פיצול כפול | x.y.z | שמור.י.ו | שמור | שמרי |
| 17 | [] מרובעים | [ז│נ│ניטרלי] | [גבר│אישה│אדם] | גבר | אישה |
| 18 | {} מסולסלים | {skip} | {גולשים/ות} | גולשים/ות | גולשים/ות |
| 19 | HTML attributes | data-ivrita-* | (in HTML) | - | - |

---

### 12 MGHebrew PUA Glyphs (Word Endings)

| # | Name | PUA | ז | נ | Example |
|---|------|-----|---|---|---------|
| 1 | יו״ב | E000 | וא | יא | הוא/יא |
| 2 | תי״ם | E001 | ים | ות | מורים/ות |
| 3 | נ״ם | E002 | ם | ן | אתם/ן |
| 4 | ת״ד | E003 | ד | ת | עומד/ת |
| 5 | נ״ת | E004 | נ | ת | ישנ/ת |
| 6 | י״ת | E005 | י | ת | עברי/ת |
| 7 | ה״ת | E006 | ה | ת | יפה/ת |
| 8 | ו״ה | E007 | ו | ה | שלו/ה |
| 9 | א״ן | E008 | א | ∅ | הוא. |
| 10 | ת״ה | E009 | ∅ | ת | רופא/ת |
| 11 | ני״ת | E00A | ן | נית | זמרן/ית |
| 12 | רֵב | E00B | - | - | מוֹר[ֶה│ָה] |

---

### Use Cases by Pattern

#### 1. Pronouns
```
הוא/היא  →  הוא/יא     (יו״ב - E000)
אתם/אתן  →  אתם/ן      (נ״ם - E002)
שלו/שלה  →  שלו/ה      (ו״ה - E007)
```

#### 2. Plural Nouns & Adjectives
```
מורים/מורות    →  מורים/ות     (תי״ם - E001)
סטודנטים/יות  →  סטודנטים/ות  (תי״ם - E001)
```

#### 3. Present Tense Verbs
```
עומד/עומדת   →  עומד/ת    (ת״ד - E003)
יושב/יושבת   →  יושב/ת    (ת״ד - E003)
רץ/רצה       →  רצ/ה      (ו״ה - E007)
```

#### 4. Adjectives
```
יפה/יפה      →  יפה/ת     (ה״ת - E006)
ישן/ישנה     →  ישנ/ת     (נ״ת - E004)
עברי/עברית   →  עברי/ת    (י״ת - E005)
```

#### 5. Professional Nouns
```
רופא/רופאה   →  רופא/ת    (ת״ה - E009)
זמרן/זמרנית  →  זמרן/ית   (ני״ת - E00A)
```

#### 6. With Nikud (Vowel Swap)
```
הַמּוֹרֶה/הַמּוֹרָה  →  הַמּוֹרֶ[|]ה   (רֵב - E00B)
```
The רֵב glyph indicates where vowels should swap between forms.

---

### Nikud Patterns (12 Use Cases with רֵב)

These patterns require the **Nikud version** of the font (AlefMultiGndr-Nikud.woff2).

#### Pronouns & Suffixes
| Pattern | ז (Male) | נ (Female) | Ivrita | Meaning |
|---------|----------|------------|--------|---------|
| את/ה | אַתָּה | אַתְּ | אַת[ָּה│ְּ] | You (singular) |
| לך/ך | לְךָ | לָךְ | ל[ְךָ│ָךְ] | To you |
| בך/ך | בְּךָ | בָּךְ | ב[ְּךָ│ָּךְ] | In you |
| אותך/ך | אוֹתְךָ | אוֹתָךְ | אוֹת[ְךָ│ָךְ] | You (object) |
| שלך/ך | שֶׁלְּךָ | שֶׁלָּךְ | שֶׁל[ְּךָ│ָּךְ] | Yours |
| עליך/ך | עָלֶיךָ | עָלַיִךְ | עָל[ֶיךָ│ַיִךְ] | On you |
| אליך/ך | אֵלֶיךָ | אֵלַיִךְ | אֵל[ֶיךָ│ַיִךְ] | To you |
| ממך/ך | מִמְּךָ | מִמֵּךְ | מִמ[ְּךָ│ֵּךְ] | From you |
| איתך/ך | אִתְּךָ | אִתָּךְ | אִת[ְּךָ│ָּךְ] | With you |

#### Adjectives/Nouns (Same Letters, Different Vowels)
| Pattern | ז (Male) | נ (Female) | Ivrita | Meaning |
|---------|----------|------------|--------|---------|
| מורה/ה | מוֹרֶה | מוֹרָה | מוֹר[ֶה│ָה] | Teacher |
| יפה/ה | יָפֶה | יָפָה | יָפ[ֶה│ָה] | Beautiful |
| קשה/ה | קָשֶׁה | קָשָׁה | קָש[ֶׁה│ָׁה] | Hard/Difficult |

---

### Nikud vs Non-Nikud Summary

| Type | Font Needed | Glyph | Example |
|------|-------------|-------|---------|
| **סיומות שונות** | Regular | תי״ם, ת״ד, etc. | מורים/ות |
| **תנועות שונות** | Nikud | רֵב | אַתָּ[│]ה |

```
בלי ניקוד:  מורים/ות  →  uses תי״ם glyph (E001)
עם ניקוד:   אַתָּ[|]ה  →  uses רֵב glyph (E00B)
```

---

### Ivrita Notation Syntax

| Type | Syntax | Example | Use |
|------|--------|---------|-----|
| **Slash** | מ/ף | סטודנט/ית | Simple ending swap |
| **Dot** | מ. | הוא. | Optional letter (male) |
| **Parens** | (מ/ף) | רופא(ה) | Optional ending |
| **Square** | [מ│ף] | מורֶ[ה│ָה] | Nikud variation |
| **Curly** | {מ/ף} | {איש/אישה} | Different words |

---

### CSS @font-face Example
```css
@font-face {
  font-family: 'AlefMultiGndr';
  src: url('./fonts/AlefMultiGndr-Regular.woff2') format('woff2');
  font-weight: 400;
  font-display: swap;
}

/* Usage */
.inclusive-text {
  font-family: 'AlefMultiGndr', 'Alef', sans-serif;
}
```

---

### JavaScript Conversion (Ivrita → MGHebrew PUA)
```javascript
const ivritaToMGHebrew = {
  'וא/יא': '\uE000',  // יו״ב
  'ים/ות': '\uE001',  // תי״ם
  'ם/ן':   '\uE002',  // נ״ם
  'ד/ת':   '\uE003',  // ת״ד
  'נ/ת':   '\uE004',  // נ״ת
  'י/ת':   '\uE005',  // י״ת
  'ה/ת':   '\uE006',  // ה״ת
  'ו/ה':   '\uE007',  // ו״ה
  'א.':    '\uE008',  // א״ן
  '/ת':    '\uE009',  // ת״ה
  'ן/ית':  '\uE00A',  // ני״ת
  '[|]':   '\uE00B',  // רֵב
};
```
