// ═══════════════════════════════════════════════════════════════════════════
// MG AFFIXES v2 - Final Design
// ═══════════════════════════════════════════════════════════════════════════
//
// Structure:
//   type: 'prefix' | 'middle' | 'suffix'
//   
//   he_m    - Hebrew male affix (plain)
//   he_f    - Hebrew female affix (plain)
//   he_m_n  - Hebrew male affix (nikud)
//   he_f_n  - Hebrew female affix (nikud)
//   
//   en_m    - English male affix
//   en_f    - English female affix
//
// ═══════════════════════════════════════════════════════════════════════════

const MG_AFFIXES = {
  // ═══════════════════════════════════════════════════════════════════════
  // SUFFIX - End changes
  // ═══════════════════════════════════════════════════════════════════════
  
  // Empty → ה : תלמיד → תלמידה
  'ה': {
    type: 'suffix',
    he_m: '', he_f: 'ה',
    he_m_n: '', he_f_n: 'ָה',
    en_m: '', en_f: '',
  },
  
  // Empty → ת : נהג → נהגת  
  'ת': {
    type: 'suffix',
    he_m: '', he_f: 'ת',
    he_m_n: '', he_f_n: 'ֶת',
    en_m: '', en_f: '',
  },
  
  // ן → נית : שחקן → שחקנית
  'ן-נית': {
    type: 'suffix',
    he_m: 'ן', he_f: 'נית',
    he_m_n: 'ָן', he_f_n: 'נִית',
    en_m: '', en_f: '',
  },
  
  // ן → נה : אמן → אמנה (alternate)
  'ן-נה': {
    type: 'suffix',
    he_m: 'ן', he_f: 'נה',
    he_m_n: 'ָן', he_f_n: 'נָה',
    en_m: '', en_f: '',
  },
  
  // ן → ת : בן → בת
  'ן-ת': {
    type: 'suffix',
    he_m: 'ן', he_f: 'ת',
    he_m_n: 'ן', he_f_n: 'ת',
    en_m: '', en_f: '',
  },
  
  // ה → ה (same) : מורה → מורה
  'ה-ה': {
    type: 'suffix',
    he_m: 'ה', he_f: 'ה',
    he_m_n: 'ֶה', he_f_n: 'ָה',
    en_m: '', en_f: '',
  },
  
  // Plural: ים → ות
  'ים-ות': {
    type: 'suffix',
    he_m: 'ים', he_f: 'ות',
    he_m_n: 'ִים', he_f_n: 'וֹת',
    en_m: 's', en_f: 's',
  },
  
  // ו → ה : שלו → שלה
  'ו-ה': {
    type: 'suffix',
    he_m: 'ו', he_f: 'ה',
    he_m_n: 'וֹ', he_f_n: 'ָהּ',
    en_m: 'his', en_f: 'her',
  },
  
  // י → ך : שלי remains, but אתה → את (you)
  'ה-': {
    type: 'suffix',
    he_m: 'ה', he_f: '',
    he_m_n: 'ָה', he_f_n: '',
    en_m: '', en_f: '',
  },
  
  // ═══════════════════════════════════════════════════════════════════════
  // PREFIX - Beginning changes
  // ═══════════════════════════════════════════════════════════════════════
  
  // הוא → היא
  'הוא-היא': {
    type: 'prefix',
    he_m: 'הוא', he_f: 'היא',
    he_m_n: 'הוּא', he_f_n: 'הִיא',
    en_m: 'he', en_f: 'she',
  },
  
  // הם → הן
  'הם-הן': {
    type: 'prefix',
    he_m: 'הם', he_f: 'הן',
    he_m_n: 'הֵם', he_f_n: 'הֵן',
    en_m: 'they(m)', en_f: 'they(f)',
  },
  
  // אתה → את
  'אתה-את': {
    type: 'prefix',
    he_m: 'אתה', he_f: 'את',
    he_m_n: 'אַתָּה', he_f_n: 'אַתְּ',
    en_m: 'you(m)', en_f: 'you(f)',
  },
  
  // אני remains same
  'אני': {
    type: 'prefix',
    he_m: 'אני', he_f: 'אני',
    he_m_n: 'אֲנִי', he_f_n: 'אֲנִי',
    en_m: 'I', en_f: 'I',
  },
  
  // ═══════════════════════════════════════════════════════════════════════
  // MIDDLE - Internal changes (verb conjugations)
  // ═══════════════════════════════════════════════════════════════════════
  
  // Past tense 3rd person: הלך → הלכה
  'past-3': {
    type: 'suffix',
    he_m: '', he_f: 'ה',
    he_m_n: '', he_f_n: 'ָה',
    en_m: '', en_f: '',
  },
  
  // Future tense: יכתוב → תכתוב
  'fut-3': {
    type: 'prefix',
    he_m: 'י', he_f: 'ת',
    he_m_n: 'יִ', he_f_n: 'תִּ',
    en_m: '', en_f: '',
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// MG CLASS - Uses affix patterns
// ═══════════════════════════════════════════════════════════════════════════

class MG {
  constructor(data) {
    this.base = data.base;           // Base without affix: שחק, תלמיד
    this.base_n = data.base_n;       // Base with nikud
    this.pattern = data.pattern;     // Pattern key: 'ן-נית'
    
    // English (often different pattern)
    this.en_m = data.en_m || '';
    this.en_f = data.en_f || '';
  }
  
  get affix() { return MG_AFFIXES[this.pattern]; }
  
  // Hebrew Male
  he_m(nikud = false) {
    const base = nikud && this.base_n ? this.base_n : this.base;
    const suf = nikud ? (this.affix?.he_m_n || '') : (this.affix?.he_m || '');
    return base + suf;
  }
  
  // Hebrew Female
  he_f(nikud = false) {
    const base = nikud && this.base_n ? this.base_n : this.base;
    const suf = nikud ? (this.affix?.he_f_n || '') : (this.affix?.he_f || '');
    return base + suf;
  }
  
  // Combined M/F
  he_mf(nikud = false) { return `${this.he_m(nikud)}/${this.he_f(nikud)}`; }
  he_fm(nikud = false) { return `${this.he_f(nikud)}/${this.he_m(nikud)}`; }
  
  // Ivrita notation: base.suffix
  he_ivrita(nikud = false) {
    const m = this.he_m(nikud);
    const f_suf = nikud ? (this.affix?.he_f_n || '') : (this.affix?.he_f || '');
    const m_suf = nikud ? (this.affix?.he_m_n || '') : (this.affix?.he_m || '');
    
    // If suffix changes, show: base.f_suffix
    if (f_suf !== m_suf) {
      return `${m}.${f_suf}`;
    }
    return m;
  }
  
  // English
  get en_mf() { return this.en_m && this.en_f ? `${this.en_m}/${this.en_f}` : ''; }
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('MG Affixes - Final Design');
console.log('═══════════════════════════════════════════════════════════════\n');

const tests = [
  { name: 'תלמיד/ה', mg: new MG({ base: 'תלמיד', base_n: 'תַּלְמִיד', pattern: 'ה', en_m: 'student', en_f: 'student' }) },
  { name: 'נהג/ת', mg: new MG({ base: 'נהג', base_n: 'נַהָג', pattern: 'ת', en_m: 'driver', en_f: 'driver' }) },
  { name: 'שחקן/ית', mg: new MG({ base: 'שחק', base_n: 'שַׂחְקָ', pattern: 'ן-נית', en_m: 'actor', en_f: 'actress' }) },
  { name: 'בן/בת', mg: new MG({ base: 'ב', base_n: 'בֵּ', pattern: 'ן-ת', en_m: 'son', en_f: 'daughter' }) },
  { name: 'מורה', mg: new MG({ base: 'מור', base_n: 'מוֹר', pattern: 'ה-ה', en_m: 'teacher', en_f: 'teacher' }) },
  { name: 'שלו/ה', mg: new MG({ base: 'של', base_n: 'שֶׁל', pattern: 'ו-ה', en_m: 'his', en_f: 'her' }) },
  { name: 'הוא/היא', mg: new MG({ base: '', pattern: 'הוא-היא', en_m: 'he', en_f: 'she' }) },
  { name: 'תלמידים/ות', mg: new MG({ base: 'תלמיד', pattern: 'ים-ות' }) },
];

tests.forEach(t => {
  console.log(`${t.name}:`);
  console.log(`  Plain:   ${t.mg.he_m()} / ${t.mg.he_f()}`);
  if (t.mg.base_n) {
    console.log(`  Nikud:   ${t.mg.he_m(true)} / ${t.mg.he_f(true)}`);
  }
  console.log(`  Ivrita:  ${t.mg.he_ivrita()}`);
  if (t.mg.en_m) {
    console.log(`  English: ${t.mg.en_mf}`);
  }
  console.log('');
});

console.log('═══════════════════════════════════════════════════════════════');
console.log('Available patterns:', Object.keys(MG_AFFIXES).join(', '));
console.log('═══════════════════════════════════════════════════════════════');
