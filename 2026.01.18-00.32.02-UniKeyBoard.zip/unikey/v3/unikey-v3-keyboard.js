// ═══════════════════════════════════════════════════════════════════════════
// UNIKEY v3 - IPA-Based Unified Keyboard
// ═══════════════════════════════════════════════════════════════════════════
//
// ONE KEY → Multiple layers via modifiers:
//   Normal     → אות (plain)
//   + Nikud    → אות + ניקוד
//   + Shift    → MG pair
//   + Ctrl     → IPA
//
// IPA + Etymology = logical key placement
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// IPA PHONEMES - The universal bridge
// ═══════════════════════════════════════════════════════════════════════════

const IPA = {
  // Vowels
  'a': { en: 'a', he: 'ַ', he_p: 'א', name: 'patach' },
  'ɑ': { en: 'a', he: 'ָ', he_p: 'א', name: 'kamatz' },
  'e': { en: 'e', he: 'ֶ', he_p: 'א', name: 'segol' },
  'ɛ': { en: 'e', he: 'ֵ', he_p: 'א', name: 'tzere' },
  'i': { en: 'i', he: 'ִ', he_p: 'י', name: 'chirik' },
  'o': { en: 'o', he: 'ֹ', he_p: 'ו', name: 'cholam' },
  'u': { en: 'u', he: 'ֻ', he_p: 'ו', name: 'kubutz' },
  'ə': { en: 'e', he: 'ְ', he_p: '',  name: 'shva' },
  
  // Consonants  
  'b': { en: 'b', he: 'בּ', he_p: 'ב' },
  'v': { en: 'v', he: 'ב',  he_p: 'ב' },
  'g': { en: 'g', he: 'גּ', he_p: 'ג' },
  'd': { en: 'd', he: 'ד',  he_p: 'ד' },
  'h': { en: 'h', he: 'ה',  he_p: 'ה' },
  'z': { en: 'z', he: 'ז',  he_p: 'ז' },
  'x': { en: 'ch',he: 'ח',  he_p: 'ח' },
  't': { en: 't', he: 'ת',  he_p: 'ת' },
  'j': { en: 'y', he: 'י',  he_p: 'י' },
  'k': { en: 'k', he: 'כּ', he_p: 'כ' },
  'l': { en: 'l', he: 'ל',  he_p: 'ל' },
  'm': { en: 'm', he: 'מ',  he_p: 'מ' },
  'n': { en: 'n', he: 'נ',  he_p: 'נ' },
  's': { en: 's', he: 'ס',  he_p: 'ס' },
  'p': { en: 'p', he: 'פּ', he_p: 'פ' },
  'f': { en: 'f', he: 'פ',  he_p: 'פ' },
  'ts': { en: 'ts', he: 'צ', he_p: 'צ' },
  'r': { en: 'r', he: 'ר',  he_p: 'ר' },
  'ʃ': { en: 'sh', he: 'שׁ', he_p: 'ש' },
  'ʔ': { en: "'", he: 'א',  he_p: 'א' },
  'ʕ': { en: "'", he: 'ע',  he_p: 'ע' },
};

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLES with MG pairs
// ═══════════════════════════════════════════════════════════════════════════

const SYL = {
  // Possessive/pronoun suffixes
  'ו':  { p:'ו',  n:'וֹ',  ipa:'o',  g:'m', pair:'ה' },
  'ה':  { p:'ה',  n:'ָהּ', ipa:'a',  g:'f', pair:'ו' },
  'ם':  { p:'ם',  n:'ָם',  ipa:'am', g:'m', pair:'ן', num:'pl' },
  'ן':  { p:'ן',  n:'ָן',  ipa:'an', g:'f', pair:'ם', num:'pl' },
  'ים': { p:'ים', n:'ִים', ipa:'im', g:'m', pair:'ות', num:'pl' },
  'ות': { p:'ות', n:'וֹת', ipa:'ot', g:'f', pair:'ים', num:'pl' },
  'ד':  { p:'ד',  n:'ֵד',  ipa:'ed', g:'m', pair:'ת' },
  'ת':  { p:'ת',  n:'ֶת',  ipa:'et', g:'f', pair:'ד' },
  'י':  { p:'י',  n:'יִ',  ipa:'ji', g:'m', pair:'ת2', pos:'pre' },
  'ת2': { p:'ת',  n:'תִּ', ipa:'ti', g:'f', pair:'י', pos:'pre' },
};

// ═══════════════════════════════════════════════════════════════════════════
// KEYBOARD KEYS - IPA-based layout
// ═══════════════════════════════════════════════════════════════════════════

const KEY = {
  // Row 1: Numbers (with MG suffixes on Alt)
  '1': { en:'1', he:'1', ipa:null, mg:'ו' },   // Alt → ו/ה
  '2': { en:'2', he:'2', ipa:null, mg:'ם' },   // Alt → ם/ן
  '3': { en:'3', he:'3', ipa:null, mg:'ים' },  // Alt → ים/ות
  '4': { en:'4', he:'4', ipa:null, mg:'ד' },   // Alt → ד/ת
  '5': { en:'5', he:'5', ipa:null, mg:'י' },   // Alt → י/ת (prefix)
  
  // Row 2: QWERTY with IPA mapping
  'q': { en:'q', he:'ק', ipa:'k', etym:'qoph' },
  'w': { en:'w', he:'ו', ipa:'v', etym:'waw→vav' },
  'e': { en:'e', he:'א', ipa:'e', etym:'vowel' },
  'r': { en:'r', he:'ר', ipa:'r', etym:'resh' },
  't': { en:'t', he:'ת', ipa:'t', etym:'tav' },
  'y': { en:'y', he:'י', ipa:'j', etym:'yod' },
  'u': { en:'u', he:'ו', ipa:'u', etym:'vowel' },
  'i': { en:'i', he:'י', ipa:'i', etym:'vowel' },
  'o': { en:'o', he:'ו', ipa:'o', etym:'vowel' },
  'p': { en:'p', he:'פ', ipa:'p', etym:'pe' },
  
  // Row 3: Home row
  'a': { en:'a', he:'א', ipa:'a', etym:'aleph' },
  's': { en:'s', he:'ס', ipa:'s', etym:'samekh' },
  'd': { en:'d', he:'ד', ipa:'d', etym:'dalet' },
  'f': { en:'f', he:'פ', ipa:'f', etym:'pe(soft)' },
  'g': { en:'g', he:'ג', ipa:'g', etym:'gimel' },
  'h': { en:'h', he:'ה', ipa:'h', etym:'he' },
  'j': { en:'j', he:'י', ipa:'j', etym:'yod' },
  'k': { en:'k', he:'כ', ipa:'k', etym:'kaph' },
  'l': { en:'l', he:'ל', ipa:'l', etym:'lamed' },
  
  // Row 4: Bottom row
  'z': { en:'z', he:'ז', ipa:'z', etym:'zayin' },
  'x': { en:'x', he:'ח', ipa:'x', etym:'chet' },
  'c': { en:'c', he:'צ', ipa:'ts', etym:'tsade' },
  'v': { en:'v', he:'ב', ipa:'v', etym:'bet(soft)' },
  'b': { en:'b', he:'ב', ipa:'b', etym:'bet' },
  'n': { en:'n', he:'נ', ipa:'n', etym:'nun' },
  'm': { en:'m', he:'מ', ipa:'m', etym:'mem' },
};

// ═══════════════════════════════════════════════════════════════════════════
// KEYBOARD LAYERS
// ═══════════════════════════════════════════════════════════════════════════

function getKeyDisplay(key, mode, mods = {}) {
  const k = KEY[key];
  if (!k) return key;
  
  // Ctrl → IPA
  if (mods.ctrl) {
    return k.ipa ? `/${k.ipa}/` : key;
  }
  
  // Alt on number → MG pair
  if (mods.alt && k.mg) {
    const s = SYL[k.mg];
    if (s?.pair) {
      const m = s.g === 'm' ? k.mg : s.pair;
      const f = s.g === 'f' ? k.mg : s.pair;
      return mods.shift 
        ? `${SYL[m].n}/${SYL[f].n}` 
        : `${SYL[m].p}/${SYL[f].p}`;
    }
  }
  
  // Normal mode
  if (mode === 'he') {
    return mods.shift ? k.he.toUpperCase() : k.he;
  }
  return mods.shift ? k.en.toUpperCase() : k.en;
}

// ═══════════════════════════════════════════════════════════════════════════
// DEMO
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIKEY v3 - IPA + Etymology Based Keyboard');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('LAYERS (same physical key, different output):');
console.log('');
console.log('  Normal     →  א ב ג ד (plain Hebrew)');
console.log('  + Nikud    →  אָ בָּ גָּ דָּ (with nikud)');
console.log('  + Alt(num) →  ו/ה ם/ן ים/ות (MG pairs)');
console.log('  + Ctrl     →  /a/ /b/ /g/ /d/ (IPA)');
console.log('');

console.log('───────────────────────────────────────────────────────────────');
console.log('Number keys with MG:');
console.log('───────────────────────────────────────────────────────────────\n');

['1','2','3','4','5'].forEach(n => {
  const k = KEY[n];
  if (k?.mg) {
    const s = SYL[k.mg];
    const m = s.g === 'm' ? k.mg : s.pair;
    const f = s.g === 'f' ? k.mg : s.pair;
    console.log(`  ${n}  →  Normal: ${n}  |  Alt: ${SYL[m].p}/${SYL[f].p}  |  Alt+Shift: ${SYL[m].n}/${SYL[f].n}`);
  }
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('Letter keys with IPA etymology:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('  Key   EN    HE    IPA     Etymology');
console.log('  ───   ──    ──    ───     ─────────');
['q','w','e','r','t','a','s','d','f','g','b','v','n','m'].forEach(key => {
  const k = KEY[key];
  console.log(`  ${key}     ${k.en}     ${k.he}     /${k.ipa}/    ${k.etym || ''}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('ARCHITECTURE:');
console.log('');
console.log('  ┌─────────────────────────────────────────────────────────┐');
console.log('  │                    Physical Key                        │');
console.log('  └────────────────────────┬────────────────────────────────┘');
console.log('                           │');
console.log('            ┌──────────────┼──────────────┐');
console.log('            ▼              ▼              ▼');
console.log('       ┌────────┐    ┌────────┐    ┌────────┐');
console.log('       │ Normal │    │  +Mod  │    │ +Ctrl  │');
console.log('       │   א    │    │  ו/ה   │    │  /a/   │');
console.log('       └────────┘    └────────┘    └────────┘');
console.log('            │              │              │');
console.log('            └──────────────┴──────────────┘');
console.log('                           │');
console.log('                    ┌──────┴──────┐');
console.log('                    │     IPA     │');
console.log('                    │   Bridge    │');
console.log('                    └─────────────┘');
console.log('');
console.log('═══════════════════════════════════════════════════════════════');
