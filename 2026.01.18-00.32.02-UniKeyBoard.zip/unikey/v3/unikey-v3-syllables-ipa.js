// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - SYLLABLES ARE IPA UNIKEYS
// ═══════════════════════════════════════════════════════════════════════════════
//
// KEY INSIGHT: Each common syllable in BOTH languages is an IPA UniKey
// Syllable = Consonant IPA + Vowel IPA = CV combination
// Same IPA syllable maps to different spellings in each language
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW SYLLABLES WITH NIKUD - Each is ONE IPA
// ═══════════════════════════════════════════════════════════════════════════════

const HE_SYLLABLES_NIKUD = {
  // Each row = same vowel IPA across all consonants
  
  // קָמָץ /ɑ/ 
  'ɑ': {
    vowel: { nikud: 'ָ', name: 'קָמָץ', ipa: 'ɑ' },
    syllables: [
      { he: 'בָּ', ipa: 'bɑ' }, { he: 'גָּ', ipa: 'gɑ' }, { he: 'דָּ', ipa: 'dɑ' },
      { he: 'הָ', ipa: 'hɑ' }, { he: 'וָ', ipa: 'vɑ' }, { he: 'זָ', ipa: 'zɑ' },
      { he: 'חָ', ipa: 'xɑ' }, { he: 'טָ', ipa: 'tɑ' }, { he: 'יָ', ipa: 'jɑ' },
      { he: 'כָּ', ipa: 'kɑ' }, { he: 'לָ', ipa: 'lɑ' }, { he: 'מָ', ipa: 'mɑ' },
      { he: 'נָ', ipa: 'nɑ' }, { he: 'סָ', ipa: 'sɑ' }, { he: 'עָ', ipa: 'ʔɑ' },
      { he: 'פָּ', ipa: 'pɑ' }, { he: 'צָ', ipa: 'tsɑ' }, { he: 'קָ', ipa: 'kɑ' },
      { he: 'רָ', ipa: 'ʁɑ' }, { he: 'שָׁ', ipa: 'ʃɑ' }, { he: 'תָּ', ipa: 'tɑ' },
    ],
  },
  
  // פַּתַח /a/
  'a': {
    vowel: { nikud: 'ַ', name: 'פַּתַח', ipa: 'a' },
    syllables: [
      { he: 'בַּ', ipa: 'ba' }, { he: 'גַּ', ipa: 'ga' }, { he: 'דַּ', ipa: 'da' },
      { he: 'הַ', ipa: 'ha' }, { he: 'וַ', ipa: 'va' }, { he: 'זַ', ipa: 'za' },
      { he: 'חַ', ipa: 'xa' }, { he: 'טַ', ipa: 'ta' }, { he: 'יַ', ipa: 'ja' },
      { he: 'כַּ', ipa: 'ka' }, { he: 'לַ', ipa: 'la' }, { he: 'מַ', ipa: 'ma' },
      { he: 'נַ', ipa: 'na' }, { he: 'סַ', ipa: 'sa' }, { he: 'עַ', ipa: 'ʔa' },
      { he: 'פַּ', ipa: 'pa' }, { he: 'צַ', ipa: 'tsa' }, { he: 'קַ', ipa: 'ka' },
      { he: 'רַ', ipa: 'ʁa' }, { he: 'שַׁ', ipa: 'ʃa' }, { he: 'תַּ', ipa: 'ta' },
    ],
  },
  
  // סֶגוֹל /ɛ/
  'ɛ': {
    vowel: { nikud: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
    syllables: [
      { he: 'בֶּ', ipa: 'bɛ' }, { he: 'גֶּ', ipa: 'gɛ' }, { he: 'דֶּ', ipa: 'dɛ' },
      { he: 'הֶ', ipa: 'hɛ' }, { he: 'וֶ', ipa: 'vɛ' }, { he: 'זֶ', ipa: 'zɛ' },
      { he: 'חֶ', ipa: 'xɛ' }, { he: 'טֶ', ipa: 'tɛ' }, { he: 'יֶ', ipa: 'jɛ' },
      { he: 'כֶּ', ipa: 'kɛ' }, { he: 'לֶ', ipa: 'lɛ' }, { he: 'מֶ', ipa: 'mɛ' },
      { he: 'נֶ', ipa: 'nɛ' }, { he: 'סֶ', ipa: 'sɛ' }, { he: 'עֶ', ipa: 'ʔɛ' },
      { he: 'פֶּ', ipa: 'pɛ' }, { he: 'צֶ', ipa: 'tsɛ' }, { he: 'קֶ', ipa: 'kɛ' },
      { he: 'רֶ', ipa: 'ʁɛ' }, { he: 'שֶׁ', ipa: 'ʃɛ' }, { he: 'תֶּ', ipa: 'tɛ' },
    ],
  },
  
  // צֵירֵי /e/
  'e': {
    vowel: { nikud: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
    syllables: [
      { he: 'בֵּ', ipa: 'be' }, { he: 'גֵּ', ipa: 'ge' }, { he: 'דֵּ', ipa: 'de' },
      { he: 'הֵ', ipa: 'he' }, { he: 'וֵ', ipa: 've' }, { he: 'זֵ', ipa: 'ze' },
      { he: 'חֵ', ipa: 'xe' }, { he: 'טֵ', ipa: 'te' }, { he: 'יֵ', ipa: 'je' },
      { he: 'כֵּ', ipa: 'ke' }, { he: 'לֵ', ipa: 'le' }, { he: 'מֵ', ipa: 'me' },
      { he: 'נֵ', ipa: 'ne' }, { he: 'סֵ', ipa: 'se' }, { he: 'עֵ', ipa: 'ʔe' },
      { he: 'פֵּ', ipa: 'pe' }, { he: 'צֵ', ipa: 'tse' }, { he: 'קֵ', ipa: 'ke' },
      { he: 'רֵ', ipa: 'ʁe' }, { he: 'שֵׁ', ipa: 'ʃe' }, { he: 'תֵּ', ipa: 'te' },
    ],
  },
  
  // חִירִיק /i/
  'i': {
    vowel: { nikud: 'ִ', name: 'חִירִיק', ipa: 'i' },
    syllables: [
      { he: 'בִּ', ipa: 'bi' }, { he: 'גִּ', ipa: 'gi' }, { he: 'דִּ', ipa: 'di' },
      { he: 'הִ', ipa: 'hi' }, { he: 'וִ', ipa: 'vi' }, { he: 'זִ', ipa: 'zi' },
      { he: 'חִ', ipa: 'xi' }, { he: 'טִ', ipa: 'ti' }, { he: 'יִ', ipa: 'ji' },
      { he: 'כִּ', ipa: 'ki' }, { he: 'לִ', ipa: 'li' }, { he: 'מִ', ipa: 'mi' },
      { he: 'נִ', ipa: 'ni' }, { he: 'סִ', ipa: 'si' }, { he: 'עִ', ipa: 'ʔi' },
      { he: 'פִּ', ipa: 'pi' }, { he: 'צִ', ipa: 'tsi' }, { he: 'קִ', ipa: 'ki' },
      { he: 'רִ', ipa: 'ʁi' }, { he: 'שִׁ', ipa: 'ʃi' }, { he: 'תִּ', ipa: 'ti' },
    ],
  },
  
  // חוֹלָם /o/
  'o': {
    vowel: { nikud: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
    syllables: [
      { he: 'בֹּ', ipa: 'bo' }, { he: 'גֹּ', ipa: 'go' }, { he: 'דֹּ', ipa: 'do' },
      { he: 'הֹ', ipa: 'ho' }, { he: 'וֹ', ipa: 'vo' }, { he: 'זֹ', ipa: 'zo' },
      { he: 'חֹ', ipa: 'xo' }, { he: 'טֹ', ipa: 'to' }, { he: 'יֹ', ipa: 'jo' },
      { he: 'כֹּ', ipa: 'ko' }, { he: 'לֹ', ipa: 'lo' }, { he: 'מֹ', ipa: 'mo' },
      { he: 'נֹ', ipa: 'no' }, { he: 'סֹ', ipa: 'so' }, { he: 'עֹ', ipa: 'ʔo' },
      { he: 'פֹּ', ipa: 'po' }, { he: 'צֹ', ipa: 'tso' }, { he: 'קֹ', ipa: 'ko' },
      { he: 'רֹ', ipa: 'ʁo' }, { he: 'שֹׁ', ipa: 'ʃo' }, { he: 'תֹּ', ipa: 'to' },
    ],
  },
  
  // קֻבּוּץ /u/
  'u': {
    vowel: { nikud: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
    syllables: [
      { he: 'בֻּ', ipa: 'bu' }, { he: 'גֻּ', ipa: 'gu' }, { he: 'דֻּ', ipa: 'du' },
      { he: 'הֻ', ipa: 'hu' }, { he: 'וֻ', ipa: 'vu' }, { he: 'זֻ', ipa: 'zu' },
      { he: 'חֻ', ipa: 'xu' }, { he: 'טֻ', ipa: 'tu' }, { he: 'יֻ', ipa: 'ju' },
      { he: 'כֻּ', ipa: 'ku' }, { he: 'לֻ', ipa: 'lu' }, { he: 'מֻ', ipa: 'mu' },
      { he: 'נֻ', ipa: 'nu' }, { he: 'סֻ', ipa: 'su' }, { he: 'עֻ', ipa: 'ʔu' },
      { he: 'פֻּ', ipa: 'pu' }, { he: 'צֻ', ipa: 'tsu' }, { he: 'קֻ', ipa: 'ku' },
      { he: 'רֻ', ipa: 'ʁu' }, { he: 'שֻׁ', ipa: 'ʃu' }, { he: 'תֻּ', ipa: 'tu' },
    ],
  },
  
  // שְׁוָא /ə/
  'ə': {
    vowel: { nikud: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
    syllables: [
      { he: 'בְּ', ipa: 'bə' }, { he: 'גְּ', ipa: 'gə' }, { he: 'דְּ', ipa: 'də' },
      { he: 'הְ', ipa: 'hə' }, { he: 'וְ', ipa: 'və' }, { he: 'זְ', ipa: 'zə' },
      { he: 'חְ', ipa: 'xə' }, { he: 'טְ', ipa: 'tə' }, { he: 'יְ', ipa: 'jə' },
      { he: 'כְּ', ipa: 'kə' }, { he: 'לְ', ipa: 'lə' }, { he: 'מְ', ipa: 'mə' },
      { he: 'נְ', ipa: 'nə' }, { he: 'סְ', ipa: 'sə' }, { he: 'עְ', ipa: 'ʔə' },
      { he: 'פְּ', ipa: 'pə' }, { he: 'צְ', ipa: 'tsə' }, { he: 'קְ', ipa: 'kə' },
      { he: 'רְ', ipa: 'ʁə' }, { he: 'שְׁ', ipa: 'ʃə' }, { he: 'תְּ', ipa: 'tə' },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ENGLISH SYLLABLES - Each spelling maps to IPA
// ═══════════════════════════════════════════════════════════════════════════════

const EN_SYLLABLES = {
  // Long vowels
  'iː': {
    vowel: { name: 'long ee', ipa: 'iː' },
    spellings: ['ee', 'ea', 'ie', 'ei', 'ey', 'e_e', 'i_e'],
    syllables: [
      { en: 'bee', ipa: 'biː' }, { en: 'see', ipa: 'siː' }, { en: 'me', ipa: 'miː' },
      { en: 'tea', ipa: 'tiː' }, { en: 'sea', ipa: 'siː' }, { en: 'key', ipa: 'kiː' },
      { en: 'be', ipa: 'biː' }, { en: 'she', ipa: 'ʃiː' }, { en: 'he', ipa: 'hiː' },
    ],
  },
  
  'eɪ': {
    vowel: { name: 'long a', ipa: 'eɪ' },
    spellings: ['a_e', 'ai', 'ay', 'ei', 'ey', 'ea'],
    syllables: [
      { en: 'day', ipa: 'deɪ' }, { en: 'say', ipa: 'seɪ' }, { en: 'may', ipa: 'meɪ' },
      { en: 'rain', ipa: 'reɪn' }, { en: 'main', ipa: 'meɪn' }, { en: 'make', ipa: 'meɪk' },
      { en: 'they', ipa: 'ðeɪ' }, { en: 'play', ipa: 'pleɪ' }, { en: 'way', ipa: 'weɪ' },
    ],
  },
  
  'aɪ': {
    vowel: { name: 'long i', ipa: 'aɪ' },
    spellings: ['i_e', 'igh', 'y', 'ie', 'uy', 'eye'],
    syllables: [
      { en: 'my', ipa: 'maɪ' }, { en: 'by', ipa: 'baɪ' }, { en: 'try', ipa: 'traɪ' },
      { en: 'time', ipa: 'taɪm' }, { en: 'like', ipa: 'laɪk' }, { en: 'high', ipa: 'haɪ' },
      { en: 'fly', ipa: 'flaɪ' }, { en: 'sky', ipa: 'skaɪ' }, { en: 'tie', ipa: 'taɪ' },
    ],
  },
  
  'oʊ': {
    vowel: { name: 'long o', ipa: 'oʊ' },
    spellings: ['o', 'oa', 'ow', 'o_e', 'oe'],
    syllables: [
      { en: 'go', ipa: 'goʊ' }, { en: 'no', ipa: 'noʊ' }, { en: 'so', ipa: 'soʊ' },
      { en: 'boat', ipa: 'boʊt' }, { en: 'road', ipa: 'roʊd' }, { en: 'know', ipa: 'noʊ' },
      { en: 'show', ipa: 'ʃoʊ' }, { en: 'home', ipa: 'hoʊm' }, { en: 'toe', ipa: 'toʊ' },
    ],
  },
  
  'uː': {
    vowel: { name: 'long oo', ipa: 'uː' },
    spellings: ['oo', 'u', 'ue', 'ew', 'o', 'ou'],
    syllables: [
      { en: 'do', ipa: 'duː' }, { en: 'to', ipa: 'tuː' }, { en: 'who', ipa: 'huː' },
      { en: 'moon', ipa: 'muːn' }, { en: 'soon', ipa: 'suːn' }, { en: 'blue', ipa: 'bluː' },
      { en: 'new', ipa: 'nuː' }, { en: 'true', ipa: 'truː' }, { en: 'you', ipa: 'juː' },
    ],
  },
  
  // Short vowels
  'æ': {
    vowel: { name: 'short a', ipa: 'æ' },
    spellings: ['a'],
    syllables: [
      { en: 'cat', ipa: 'kæt' }, { en: 'bat', ipa: 'bæt' }, { en: 'hat', ipa: 'hæt' },
      { en: 'man', ipa: 'mæn' }, { en: 'can', ipa: 'kæn' }, { en: 'bad', ipa: 'bæd' },
      { en: 'sad', ipa: 'sæd' }, { en: 'mad', ipa: 'mæd' }, { en: 'had', ipa: 'hæd' },
    ],
  },
  
  'ɛ': {
    vowel: { name: 'short e', ipa: 'ɛ' },
    spellings: ['e', 'ea', 'ai', 'ie', 'a'],
    syllables: [
      { en: 'bed', ipa: 'bɛd' }, { en: 'red', ipa: 'rɛd' }, { en: 'get', ipa: 'gɛt' },
      { en: 'set', ipa: 'sɛt' }, { en: 'let', ipa: 'lɛt' }, { en: 'met', ipa: 'mɛt' },
      { en: 'said', ipa: 'sɛd' }, { en: 'head', ipa: 'hɛd' }, { en: 'bread', ipa: 'brɛd' },
    ],
  },
  
  'ɪ': {
    vowel: { name: 'short i', ipa: 'ɪ' },
    spellings: ['i', 'y', 'e', 'ui', 'u'],
    syllables: [
      { en: 'sit', ipa: 'sɪt' }, { en: 'bit', ipa: 'bɪt' }, { en: 'hit', ipa: 'hɪt' },
      { en: 'big', ipa: 'bɪg' }, { en: 'pig', ipa: 'pɪg' }, { en: 'dig', ipa: 'dɪg' },
      { en: 'ship', ipa: 'ʃɪp' }, { en: 'tip', ipa: 'tɪp' }, { en: 'lip', ipa: 'lɪp' },
    ],
  },
  
  'ɒ': {
    vowel: { name: 'short o', ipa: 'ɒ' },
    spellings: ['o', 'a', 'au', 'aw'],
    syllables: [
      { en: 'hot', ipa: 'hɒt' }, { en: 'pot', ipa: 'pɒt' }, { en: 'got', ipa: 'gɒt' },
      { en: 'not', ipa: 'nɒt' }, { en: 'lot', ipa: 'lɒt' }, { en: 'top', ipa: 'tɒp' },
      { en: 'stop', ipa: 'stɒp' }, { en: 'shop', ipa: 'ʃɒp' }, { en: 'drop', ipa: 'drɒp' },
    ],
  },
  
  'ʌ': {
    vowel: { name: 'short u', ipa: 'ʌ' },
    spellings: ['u', 'o', 'ou', 'oo'],
    syllables: [
      { en: 'but', ipa: 'bʌt' }, { en: 'cut', ipa: 'kʌt' }, { en: 'sun', ipa: 'sʌn' },
      { en: 'run', ipa: 'rʌn' }, { en: 'fun', ipa: 'fʌn' }, { en: 'cup', ipa: 'kʌp' },
      { en: 'up', ipa: 'ʌp' }, { en: 'son', ipa: 'sʌn' }, { en: 'love', ipa: 'lʌv' },
    ],
  },
  
  // Schwa
  'ə': {
    vowel: { name: 'schwa', ipa: 'ə' },
    spellings: ['a', 'e', 'i', 'o', 'u'],
    syllables: [
      { en: 'the', ipa: 'ðə' }, { en: 'a', ipa: 'ə' }, { en: 'about', ipa: 'əˈbaʊt' },
      { en: 'away', ipa: 'əˈweɪ' }, { en: 'ago', ipa: 'əˈgoʊ' },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// IPA SYLLABLE INDEX - Find syllables by IPA in BOTH languages
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_SYLLABLE_INDEX = {};

// Build index from Hebrew
Object.entries(HE_SYLLABLES_NIKUD).forEach(([vowelIPA, data]) => {
  data.syllables.forEach(syl => {
    if (!IPA_SYLLABLE_INDEX[syl.ipa]) {
      IPA_SYLLABLE_INDEX[syl.ipa] = { he: [], en: [] };
    }
    IPA_SYLLABLE_INDEX[syl.ipa].he.push(syl.he);
  });
});

// Build index from English
Object.entries(EN_SYLLABLES).forEach(([vowelIPA, data]) => {
  data.syllables.forEach(syl => {
    if (!IPA_SYLLABLE_INDEX[syl.ipa]) {
      IPA_SYLLABLE_INDEX[syl.ipa] = { he: [], en: [] };
    }
    IPA_SYLLABLE_INDEX[syl.ipa].en.push(syl.en);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════════════════════════

function getSyllableByIPA(ipa) {
  return IPA_SYLLABLE_INDEX[ipa] || null;
}

function getHeSyllables(vowelIPA) {
  return HE_SYLLABLES_NIKUD[vowelIPA]?.syllables || [];
}

function getEnSyllables(vowelIPA) {
  return EN_SYLLABLES[vowelIPA]?.syllables || [];
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('SYLLABLES ARE IPA UNIKEYS - Same sound in both languages');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Each syllable = Consonant IPA + Vowel IPA\n');

console.log('HEBREW SYLLABLES (with nikud) - organized by vowel IPA:');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(HE_SYLLABLES_NIKUD).slice(0, 4).forEach(([vowelIPA, data]) => {
  const samples = data.syllables.slice(0, 8).map(s => s.he).join(' ');
  console.log(`/${vowelIPA}/ (${data.vowel.name}): ${samples} ...`);
});

console.log('\nENGLISH SYLLABLES - organized by vowel IPA:');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(EN_SYLLABLES).slice(0, 4).forEach(([vowelIPA, data]) => {
  const samples = data.syllables.slice(0, 5).map(s => s.en).join(', ');
  console.log(`/${vowelIPA}/ (${data.vowel.name}): ${samples} ...`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SAME IPA → Different spellings in each language:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const crossLingualExamples = [
  { ipa: 'bi', he: 'בִּ', en: 'bee/be' },
  { ipa: 'mi', he: 'מִ', en: 'me' },
  { ipa: 'ʃi', he: 'שִׁ', en: 'she' },
  { ipa: 'no', he: 'נֹ', en: 'no' },
  { ipa: 'so', he: 'סֹ', en: 'so' },
  { ipa: 'ma', he: 'מַ', en: 'ma' },
  { ipa: 'da', he: 'דַ', en: 'da' },
  { ipa: 'la', he: 'לַ', en: 'la' },
];

console.log('IPA       Hebrew    English');
console.log('─────────────────────────────────');
crossLingualExamples.forEach(ex => {
  console.log(`/${ex.ipa.padEnd(6)}/  ${ex.he.padEnd(8)}  ${ex.en}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('THE KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────────────┐');
console.log('  │                                                                     │');
console.log('  │   IPA Syllable = Universal Sound Unit                               │');
console.log('  │                                                                     │');
console.log('  │   /ʃa/ → Hebrew: שַׁ  |  English: sha  |  French: cha              │');
console.log('  │   /mi/ → Hebrew: מִ  |  English: me   |  Spanish: mi              │');
console.log('  │   /no/ → Hebrew: נֹ  |  English: no   |  Italian: no              │');
console.log('  │                                                                     │');
console.log('  │   כל הברה היא מפתח IPA אוניברסלי                                     │');
console.log('  │   Each syllable is a universal IPA key                              │');
console.log('  │                                                                     │');
console.log('  └─────────────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('Total syllables:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

let heTotal = 0;
Object.values(HE_SYLLABLES_NIKUD).forEach(v => heTotal += v.syllables.length);
let enTotal = 0;
Object.values(EN_SYLLABLES).forEach(v => enTotal += v.syllables.length);

console.log(`Hebrew syllables (nikud): ${heTotal} (8 vowels × ~21 consonants)`);
console.log(`English syllables: ${enTotal}`);
console.log(`Unique IPA combinations: ${Object.keys(IPA_SYLLABLE_INDEX).length}`);
