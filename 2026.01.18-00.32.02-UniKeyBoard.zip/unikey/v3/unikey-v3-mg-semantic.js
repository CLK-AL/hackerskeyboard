// ═══════════════════════════════════════════════════════════════════════════════
// MG KEYS - SEMANTIC TRANSLATIONS (Same meaning in HE and EN)
// ═══════════════════════════════════════════════════════════════════════════════
// Each MG key represents ONE semantic concept with translations in both languages
// The keyboard outputs the appropriate form based on current language mode

const MG_SEMANTIC = {
  // ═══════════════════════════════════════════════════════════════════════════
  // NUMBER ROW - Core MG Suffixes
  // ═══════════════════════════════════════════════════════════════════════════
  
  '1': {
    semantic: 'POSS_3S',           // "his/her" - 3rd person singular possessive
    meaning: 'belonging to him/her',
    he: { m: 'ו', f: 'ה', mf: 'ו/ה', ipa: { m: 'o', f: 'a' } },
    en: { m: 'his', f: 'her', mf: 'his/her', ipa: { m: 'hɪz', f: 'hɜr' } },
    example: { he: 'ספרו/ספרה', en: 'his book/her book' },
  },
  
  '2': {
    semantic: 'POSS_3S_EXT',       // "his/hers" - extended possessive
    meaning: 'of his/of hers (noun suffix)',
    he: { m: 'יו', f: 'יה', mf: 'יו/יה', ipa: { m: 'av', f: 'eha' } },
    en: { m: 'his', f: 'hers', mf: 'his/hers', ipa: { m: 'hɪz', f: 'hɜrz' } },
    example: { he: 'ידיו/ידיה', en: 'his hands/her hands' },
  },
  
  '3': {
    semantic: 'POSS_3P',           // "their" - 3rd person plural possessive suffix
    meaning: 'belonging to them (m/f)',
    he: { m: 'ם', f: 'ן', mf: 'ם/ן', ipa: { m: 'am', f: 'an' } },
    en: { m: 'their', f: 'their', mf: 'their', ipa: { m: 'ðɛr', f: 'ðɛr' } },
    example: { he: 'ביתם/ביתן', en: 'their house' },
  },
  
  '4': {
    semantic: 'PRONOUN_3P',        // "they" - 3rd person plural pronoun
    meaning: 'they (m/f)',
    he: { m: 'הם', f: 'הן', mf: 'הם/הן', ipa: { m: 'hem', f: 'hen' } },
    en: { m: 'they', f: 'they', mf: 'they', ipa: { m: 'ðeɪ', f: 'ðeɪ' } },
    example: { he: 'הם הלכו/הן הלכו', en: 'they went' },
  },
  
  '5': {
    semantic: 'VERB_PRESENT',      // Present tense marker
    meaning: 'present tense (singular)',
    he: { m: 'ד', f: 'ת', mf: 'ד/ת', ipa: { m: 'ed', f: 'et' } },
    en: { m: '-s', f: '-s', mf: '-s', ipa: { m: 'z', f: 'z' } },
    example: { he: 'עומד/עומדת', en: 'stands' },
  },
  
  '6': {
    semantic: 'PLURAL',            // Plural suffix
    meaning: 'plural (m/f)',
    he: { m: 'ים', f: 'ות', mf: 'ים/ות', ipa: { m: 'im', f: 'ot' } },
    en: { m: '-s', f: '-s', mf: '-s', ipa: { m: 'z', f: 'z' } },
    example: { he: 'ילדים/ילדות', en: 'children' },
  },
  
  '7': {
    semantic: 'GENTILIC',          // Nationality/origin suffix
    meaning: 'of/from (nationality)',
    he: { m: 'י', f: 'ית', mf: 'י/ית', ipa: { m: 'i', f: 'it' } },
    en: { m: '-n/-an', f: '-n/-an', mf: '-n/-an', ipa: { m: 'n', f: 'n' } },
    example: { he: 'ישראלי/ישראלית', en: 'Israeli' },
  },
  
  '8': {
    semantic: 'ADJECTIVE',         // Adjective suffix
    meaning: 'adjective ending',
    he: { m: 'ן', f: 'נית', mf: 'ן/נית', ipa: { m: 'an', f: 'anit' } },
    en: { m: '-er', f: '-ess', mf: '-er/-ess', ipa: { m: 'ər', f: 'əs' } },
    example: { he: 'זמרן/זמרנית', en: 'singer' },
  },
  
  '9': {
    semantic: 'PROFESSION',        // Professional suffix
    meaning: 'professional/agent',
    he: { m: 'אי', f: 'אית', mf: 'אי/אית', ipa: { m: 'ai', f: 'ait' } },
    en: { m: '-or/-er', f: '-ress', mf: '-or/-ress', ipa: { m: 'ər', f: 'rəs' } },
    example: { he: 'ספורטאי/ספורטאית', en: 'athlete' },
  },
  
  '0': {
    semantic: 'POSS_2P',           // "your" - 2nd person plural possessive
    meaning: 'belonging to you (plural)',
    he: { m: 'כם', f: 'כן', mf: 'כם/כן', ipa: { m: 'xem', f: 'xen' } },
    en: { m: 'your', f: 'your', mf: 'your', ipa: { m: 'jɔr', f: 'jɔr' } },
    example: { he: 'ביתכם/ביתכן', en: 'your house' },
  },
  
  '-': {
    semantic: 'POSS_3P_EXT',       // Extended 3rd plural possessive
    meaning: 'of theirs (noun suffix)',
    he: { m: 'יהם', f: 'יהן', mf: 'יהם/יהן', ipa: { m: 'ehem', f: 'ehen' } },
    en: { m: 'theirs', f: 'theirs', mf: 'theirs', ipa: { m: 'ðɛrz', f: 'ðɛrz' } },
    example: { he: 'ידיהם/ידיהן', en: 'their hands' },
  },
  
  '=': {
    semantic: 'PRONOUN_3S',        // "he/she" - 3rd person singular pronoun
    meaning: 'he/she',
    he: { m: 'הוא', f: 'היא', mf: 'הוא/היא', ipa: { m: 'hu', f: 'hi' } },
    en: { m: 'he', f: 'she', mf: 'he/she', ipa: { m: 'hi', f: 'ʃi' } },
    example: { he: 'הוא אמר/היא אמרה', en: 'he said/she said' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// EXTENDED SEMANTIC MG - Full words (not just suffixes)
// ═══════════════════════════════════════════════════════════════════════════════

const MG_WORDS = {
  // Family
  'PARENT':   { he: { m: 'אב', f: 'אם' },       en: { m: 'father', f: 'mother' } },
  'CHILD':    { he: { m: 'בן', f: 'בת' },       en: { m: 'son', f: 'daughter' } },
  'SIBLING':  { he: { m: 'אח', f: 'אחות' },    en: { m: 'brother', f: 'sister' } },
  'SPOUSE':   { he: { m: 'בעל', f: 'אישה' },   en: { m: 'husband', f: 'wife' } },
  'PERSON':   { he: { m: 'איש', f: 'אישה' },   en: { m: 'man', f: 'woman' } },
  'YOUTH':    { he: { m: 'ילד', f: 'ילדה' },   en: { m: 'boy', f: 'girl' } },
  
  // Pronouns - Subject
  'I':        { he: { m: 'אני', f: 'אני' },     en: { m: 'I', f: 'I' } },
  'YOU_S':    { he: { m: 'אתה', f: 'את' },     en: { m: 'you', f: 'you' } },
  'HE_SHE':   { he: { m: 'הוא', f: 'היא' },    en: { m: 'he', f: 'she' } },
  'WE':       { he: { m: 'אנחנו', f: 'אנחנו' }, en: { m: 'we', f: 'we' } },
  'YOU_P':    { he: { m: 'אתם', f: 'אתן' },    en: { m: 'you', f: 'you' } },
  'THEY':     { he: { m: 'הם', f: 'הן' },      en: { m: 'they', f: 'they' } },
  
  // Pronouns - Object
  'HIM_HER':  { he: { m: 'אותו', f: 'אותה' },  en: { m: 'him', f: 'her' } },
  'THEM':     { he: { m: 'אותם', f: 'אותן' },  en: { m: 'them', f: 'them' } },
  
  // Pronouns - Reflexive
  'SELF':     { he: { m: 'עצמו', f: 'עצמה' },  en: { m: 'himself', f: 'herself' } },
  
  // Titles
  'TITLE':    { he: { m: 'מר', f: 'גברת' },    en: { m: 'Mr.', f: 'Ms.' } },
  'ROYAL':    { he: { m: 'מלך', f: 'מלכה' },   en: { m: 'king', f: 'queen' } },
  'NOBLE':    { he: { m: 'נסיך', f: 'נסיכה' }, en: { m: 'prince', f: 'princess' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API: Get translation for semantic key
// ═══════════════════════════════════════════════════════════════════════════════

function getMG(key, lang, gender) {
  const mg = MG_SEMANTIC[key] || MG_WORDS[key];
  if (!mg) return null;
  const langData = mg[lang] || mg.he;
  return gender === 'f' ? langData.f : langData.m;
}

function getMGPair(key, lang) {
  const mg = MG_SEMANTIC[key] || MG_WORDS[key];
  if (!mg) return null;
  const langData = mg[lang] || mg.he;
  return langData.mf || `${langData.m}/${langData.f}`;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════');
console.log('MG SEMANTIC TRANSLATIONS - Same meaning in Hebrew and English');
console.log('═══════════════════════════════════════════════════════════════════════════\n');

console.log('Key  SEMANTIC        Meaning                    Hebrew      English');
console.log('─────────────────────────────────────────────────────────────────────────────');

Object.entries(MG_SEMANTIC).forEach(([key, data]) => {
  const sem = data.semantic.padEnd(14);
  const meaning = data.meaning.substring(0, 26).padEnd(26);
  const he = data.he.mf.padEnd(10);
  const en = data.en.mf;
  console.log(`[${key}]  ${sem} ${meaning} ${he} ${en}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════');
console.log('MG WORD PAIRS - Complete word translations');
console.log('═══════════════════════════════════════════════════════════════════════════\n');

Object.entries(MG_WORDS).forEach(([sem, data]) => {
  const hePair = `${data.he.m}/${data.he.f}`.padEnd(14);
  const enPair = `${data.en.m}/${data.en.f}`;
  console.log(`${sem.padEnd(10)} ${hePair} ↔  ${enPair}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════');
console.log('Usage Examples:');
console.log('═══════════════════════════════════════════════════════════════════════════\n');

console.log("getMG('1', 'he', 'm')  →", getMG('1', 'he', 'm'));   // ו
console.log("getMG('1', 'he', 'f')  →", getMG('1', 'he', 'f'));   // ה
console.log("getMG('1', 'en', 'm')  →", getMG('1', 'en', 'm'));   // his
console.log("getMG('1', 'en', 'f')  →", getMG('1', 'en', 'f'));   // her
console.log("getMGPair('1', 'he')   →", getMGPair('1', 'he'));    // ו/ה
console.log("getMGPair('1', 'en')   →", getMGPair('1', 'en'));    // his/her
console.log("getMG('PARENT', 'he', 'm') →", getMG('PARENT', 'he', 'm')); // אב
console.log("getMG('PARENT', 'en', 'f') →", getMG('PARENT', 'en', 'f')); // mother
