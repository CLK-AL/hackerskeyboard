// ═══════════════════════════════════════════════════════════════════════════
// 12 MG KEYS - All You Need
// ═══════════════════════════════════════════════════════════════════════════
//
// 12 PUA = 12 letter PAIRS
// 19 Ivrita = USES of those pairs (context/position)
//
// The 12 pairs are the PRIMITIVES
// The 19 patterns are COMPOSITIONS
//
// ═══════════════════════════════════════════════════════════════════════════

const MG_12 = [
  // The 12 fundamental m/f letter pairs
  { key: 1, m: 'ו', f: 'ה', ipa: 'o/a', ctx: 'suffix 3s' },
  { key: 2, m: 'ם', f: 'ן', ipa: 'm/n', ctx: 'suffix 3p' },
  { key: 3, m: 'ד', f: 'ת', ipa: 'd/t', ctx: 'present' },
  { key: 4, m: 'י', f: 'ת', ipa: 'j/t', ctx: 'future prefix' },
  { key: 5, m: 'ים', f: 'ות', ipa: 'im/ot', ctx: 'plural' },
  { key: 6, m: 'ן', f: 'נית', ipa: 'n/nit', ctx: 'profession' },
  { key: 7, m: 'י', f: 'ית', ipa: 'i/it', ctx: 'gentilic' },
  { key: 8, m: 'יו', f: 'יה', ipa: 'av/a', ctx: 'poss extended' },
  { key: 9, m: 'יהם', f: 'יהן', ipa: 'hem/hen', ctx: 'poss 3p ext' },
  { key: 10, m: 'כם', f: 'כן', ipa: 'xem/xen', ctx: 'poss 2p' },
  { key: 11, m: 'הוא', f: 'היא', ipa: 'hu/hi', ctx: 'pronoun 3s' },
  { key: 12, m: 'אתה', f: 'את', ipa: 'ata/at', ctx: 'pronoun 2s' },
];

console.log('═══════════════════════════════════════════════════════════════');
console.log('12 MG KEYS = Complete Coverage');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('Key   M        F        IPA        Context');
console.log('───   ─        ─        ───        ───────');
MG_12.forEach(p => {
  console.log(`${p.key.toString().padStart(2)}    ${p.m.padEnd(8)} ${p.f.padEnd(8)} ${p.ipa.padEnd(10)} ${p.ctx}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('19 IVRITA = Compositions of the 12');
console.log('═══════════════════════════════════════════════════════════════\n');

const compositions = [
  { ivrita: '.ה', uses: '1 (ו/ה)', note: 'empty m, ה f' },
  { ivrita: '.ת', uses: '3 (ד/ת)', note: 'empty m, ת f' },
  { ivrita: 'ן.ת', uses: '3', note: 'ן base + ת' },
  { ivrita: 'ן.נית', uses: '6', note: 'direct' },
  { ivrita: 'ים.ות', uses: '5', note: 'direct' },
  { ivrita: 'ו.ה', uses: '1', note: 'direct' },
  { ivrita: 'ם.ן', uses: '2', note: 'direct' },
  { ivrita: 'י.ת', uses: '4', note: 'direct' },
  { ivrita: 'ד.ת', uses: '3', note: 'direct' },
  { ivrita: 'הוא.היא', uses: '11', note: 'direct' },
  { ivrita: 'אתה.את', uses: '12', note: 'direct' },
];

console.log('Ivrita Pattern   From Key   Note');
console.log('──────────────   ────────   ────');
compositions.forEach(c => {
  console.log(`${c.ivrita.padEnd(16)} ${c.uses.padEnd(10)} ${c.note}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('KEYBOARD LAYOUT');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  Number row with Alt modifier:
  
  ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
  │  1  │  2  │  3  │  4  │  5  │  6  │  7  │  8  │  9  │  10 │  11 │  12 │
  │ ו/ה │ ם/ן │ ד/ת │ י/ת │ים/ות│ן/נית│ י/ית│יו/יה│יהם/ן│כם/כן│הוא/י│אתה/ת│
  └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘
  
  Alt        = plain (ו/ה)
  Alt+Shift  = nikud (וֹ/ָהּ)
`);

console.log('═══════════════════════════════════════════════════════════════');
console.log('WHY 12 IS ENOUGH');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  12 = The LETTER PAIRS that differ between m/f
  
  19 Ivrita patterns = Different CONTEXTS using the same 12 pairs
  
  Example:
    .ה (תלמיד.ה)   = Key 1, with empty m
    ו.ה (שלו.ה)    = Key 1, both shown
    
  Same pair (ו/ה), different notation!
  
  ═══════════════════════════════════════════════════════════════
  
  12 keys → All letter pairs
  Context → Determined by word/position
  Nikud   → Alt+Shift modifier
  
  SIMPLE. COMPLETE. EFFICIENT.
`);
