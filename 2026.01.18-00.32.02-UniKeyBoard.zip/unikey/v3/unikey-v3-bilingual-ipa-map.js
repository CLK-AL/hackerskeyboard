// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - BILINGUAL IPA MAP
// ═══════════════════════════════════════════════════════════════════════════════
//
// Hebrew: חָסֵר (mark only) vs מָלֵא (mark + letter)
// English: Single letters vs Combinations (digraphs, trigraphs)
// IPA: Universal bridge between both
//
// ═══════════════════════════════════════════════════════════════════════════════

const BILINGUAL_IPA = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VOWELS - IPA as key
  // ═══════════════════════════════════════════════════════════════════════════
  
  vowels: {
    
    // /a/ - Open front
    'a': {
      ipa: 'a',
      he: {
        chaser: { mark: 'ַ', name: 'פַּתַח' },
        male: null, // patach has no male form
      },
      en: {
        single: ['a'],
        combos: [],
        examples: ['cat', 'bat', 'hat'],
      },
    },
    
    // /ɑ/ - Open back
    'ɑ': {
      ipa: 'ɑ',
      he: {
        chaser: { mark: 'ָ', name: 'קָמָץ' },
        male: { mark: 'ָא', name: 'קָמָץ + א', letters: ['א'] },
      },
      en: {
        single: ['a', 'o'],
        combos: ['ar', 'al'],
        examples: ['father', 'car', 'calm'],
      },
    },
    
    // /ă/ - Ultra-short A (Hebrew only, gutturals)
    'ă': {
      ipa: 'ă',
      he: {
        chaser: { mark: 'ֲ', name: 'חֲטַף פַּתַח', guttural_only: true },
        male: null,
      },
      en: {
        single: [],
        combos: [],
        examples: [], // No English equivalent
      },
    },
    
    // /ɛ/ - Open-mid front
    'ɛ': {
      ipa: 'ɛ',
      he: {
        chaser: { mark: 'ֶ', name: 'סֶגוֹל' },
        male: { mark: 'ֶי', name: 'סֶגוֹל + י', letters: ['י'] },
      },
      en: {
        single: ['e'],
        combos: ['ea', 'ai', 'ie'],
        examples: ['bed', 'bread', 'said', 'friend'],
      },
    },
    
    // /e/ - Close-mid front
    'e': {
      ipa: 'e',
      he: {
        chaser: { mark: 'ֵ', name: 'צֵירֵי' },
        male: { mark: 'ֵי', name: 'צֵירֵי + י', letters: ['י'] },
      },
      en: {
        single: [],
        combos: ['ay', 'ai', 'ei', 'ey', 'a_e'],
        examples: ['day', 'rain', 'vein', 'they', 'make'],
        note: 'Usually diphthong /eɪ/ in English',
      },
    },
    
    // /ĕ/ - Ultra-short E (Hebrew only, gutturals)
    'ĕ': {
      ipa: 'ĕ',
      he: {
        chaser: { mark: 'ֱ', name: 'חֲטַף סֶגוֹל', guttural_only: true },
        male: null,
      },
      en: {
        single: [],
        combos: [],
        examples: [],
      },
    },
    
    // /i/ - Close front
    'i': {
      ipa: 'i',
      he: {
        chaser: { mark: 'ִ', name: 'חִירִיק' },
        male: { mark: 'ִי', name: 'חִירִיק מָלֵא', letters: ['י'] },
      },
      en: {
        single: ['i', 'y'],
        combos: ['ee', 'ea', 'ie', 'ei', 'ey'],
        examples: ['see', 'sea', 'field', 'receive', 'key'],
      },
    },
    
    // /o/ - Close-mid back
    'o': {
      ipa: 'o',
      he: {
        chaser: { mark: 'ֹ', name: 'חוֹלָם חָסֵר' },
        male: { mark: 'וֹ', name: 'חוֹלָם מָלֵא', letters: ['ו'] },
      },
      en: {
        single: ['o'],
        combos: ['oa', 'ow', 'o_e', 'oe'],
        examples: ['go', 'boat', 'know', 'home', 'toe'],
      },
    },
    
    // /ɔ/ - Open-mid back
    'ɔ': {
      ipa: 'ɔ',
      he: {
        chaser: { mark: 'ָ', name: 'קָמָץ קָטָן', note: 'Same mark as kamatz!' },
        male: null,
      },
      en: {
        single: ['o'],
        combos: ['aw', 'au', 'al', 'or'],
        examples: ['saw', 'taught', 'all', 'for'],
      },
    },
    
    // /ŏ/ - Ultra-short O (Hebrew only, gutturals)
    'ŏ': {
      ipa: 'ŏ',
      he: {
        chaser: { mark: 'ֳ', name: 'חֲטַף קָמָץ', guttural_only: true },
        male: null,
      },
      en: {
        single: [],
        combos: [],
        examples: [],
      },
    },
    
    // /u/ - Close back
    'u': {
      ipa: 'u',
      he: {
        chaser: { mark: 'ֻ', name: 'קֻבּוּץ' },
        male: { mark: 'וּ', name: 'שׁוּרוּק', letters: ['ו'] },
      },
      en: {
        single: ['u'],
        combos: ['oo', 'ue', 'ew', 'ou'],
        examples: ['moon', 'blue', 'new', 'soup'],
      },
    },
    
    // /ə/ - Schwa
    'ə': {
      ipa: 'ə',
      he: {
        chaser: { mark: 'ְ', name: 'שְׁוָא נָע' },
        male: null,
        silent: { mark: 'ְ', name: 'שְׁוָא נָח', note: 'Same mark, no sound' },
      },
      en: {
        single: ['a', 'e', 'i', 'o', 'u'],
        combos: [],
        examples: ['about', 'silent', 'pencil', 'lemon', 'circus'],
        note: 'Most common vowel in unstressed syllables',
      },
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // ENGLISH-ONLY DIPHTHONGS
    // ═══════════════════════════════════════════════════════════════════════
    
    'eɪ': {
      ipa: 'eɪ',
      he: { chaser: null, male: null, note: 'No Hebrew equivalent' },
      en: {
        single: [],
        combos: ['a_e', 'ai', 'ay', 'ei', 'ey', 'ea'],
        examples: ['make', 'rain', 'day', 'vein', 'they', 'great'],
      },
      diphthong: true,
    },
    
    'aɪ': {
      ipa: 'aɪ',
      he: { chaser: null, male: null, note: 'No Hebrew equivalent' },
      en: {
        single: ['i', 'y'],
        combos: ['i_e', 'igh', 'ie', 'uy', 'eye'],
        examples: ['time', 'high', 'my', 'tie', 'buy', 'eye'],
      },
      diphthong: true,
    },
    
    'ɔɪ': {
      ipa: 'ɔɪ',
      he: { chaser: null, male: null },
      en: {
        single: [],
        combos: ['oi', 'oy'],
        examples: ['oil', 'boy'],
      },
      diphthong: true,
    },
    
    'aʊ': {
      ipa: 'aʊ',
      he: { chaser: null, male: null },
      en: {
        single: [],
        combos: ['ou', 'ow'],
        examples: ['out', 'now'],
      },
      diphthong: true,
    },
    
    'oʊ': {
      ipa: 'oʊ',
      he: { chaser: null, male: null, note: 'Hebrew /o/ is pure, not diphthong' },
      en: {
        single: ['o'],
        combos: ['oa', 'ow', 'o_e', 'oe'],
        examples: ['go', 'boat', 'know', 'home'],
      },
      diphthong: true,
    },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS - IPA as key
  // ═══════════════════════════════════════════════════════════════════════════
  
  consonants: {
    
    'b': {
      ipa: 'b',
      he: {
        letters: [{ char: 'בּ', name: 'בֵּית', dagesh: true }],
      },
      en: {
        single: ['b'],
        combos: ['bb'],
        examples: ['bat', 'rubber'],
      },
    },
    
    'v': {
      ipa: 'v',
      he: {
        letters: [
          { char: 'ב', name: 'בֵית (ללא דגש)', dagesh: false },
          { char: 'ו', name: 'וָו עיצור', note: 'As consonant' },
        ],
      },
      en: {
        single: ['v'],
        combos: ['ve'],
        examples: ['van', 'love'],
      },
    },
    
    'g': {
      ipa: 'g',
      he: {
        letters: [{ char: 'ג', name: 'גִּימֶל' }],
      },
      en: {
        single: ['g'],
        combos: ['gg', 'gh'],
        examples: ['go', 'egg', 'ghost'],
      },
    },
    
    'd': {
      ipa: 'd',
      he: {
        letters: [{ char: 'ד', name: 'דָּלֶת' }],
      },
      en: {
        single: ['d'],
        combos: ['dd', 'ed'],
        examples: ['dog', 'add', 'played'],
      },
    },
    
    'h': {
      ipa: 'h',
      he: {
        letters: [{ char: 'ה', name: 'הֵא' }],
      },
      en: {
        single: ['h'],
        combos: [],
        examples: ['hat', 'hello'],
      },
    },
    
    'z': {
      ipa: 'z',
      he: {
        letters: [{ char: 'ז', name: 'זַיִן' }],
      },
      en: {
        single: ['z', 's'],
        combos: ['zz', 'ze'],
        examples: ['zoo', 'buzz', 'rose', 'is'],
      },
    },
    
    'x': {
      ipa: 'x',
      he: {
        letters: [
          { char: 'ח', name: 'חֵית' },
          { char: 'כ', name: 'כָף (ללא דגש)', dagesh: false },
        ],
      },
      en: {
        single: [],
        combos: ['ch', 'kh'],
        examples: ['loch', 'Bach'],
        note: 'Rare in English, mainly loanwords',
      },
    },
    
    't': {
      ipa: 't',
      he: {
        letters: [
          { char: 'ת', name: 'תָּו' },
          { char: 'ט', name: 'טֵית' },
        ],
      },
      en: {
        single: ['t'],
        combos: ['tt', 'ed'],
        examples: ['top', 'butter', 'walked'],
      },
    },
    
    'j': {
      ipa: 'j',
      he: {
        letters: [{ char: 'י', name: 'יוֹד' }],
      },
      en: {
        single: ['y'],
        combos: [],
        examples: ['yes', 'you'],
      },
    },
    
    'k': {
      ipa: 'k',
      he: {
        letters: [
          { char: 'כּ', name: 'כָּף (עם דגש)', dagesh: true },
          { char: 'ק', name: 'קוֹף' },
        ],
      },
      en: {
        single: ['k', 'c'],
        combos: ['ck', 'cc', 'ch', 'qu'],
        examples: ['kite', 'cat', 'back', 'account', 'school', 'queen'],
      },
    },
    
    'l': {
      ipa: 'l',
      he: {
        letters: [{ char: 'ל', name: 'לָמֶד' }],
      },
      en: {
        single: ['l'],
        combos: ['ll'],
        examples: ['lamp', 'bell'],
      },
    },
    
    'm': {
      ipa: 'm',
      he: {
        letters: [
          { char: 'מ', name: 'מֵם', position: 'initial/medial' },
          { char: 'ם', name: 'מֵם סוֹפִית', position: 'final' },
        ],
      },
      en: {
        single: ['m'],
        combos: ['mm', 'mb', 'mn'],
        examples: ['man', 'hammer', 'lamb', 'autumn'],
      },
    },
    
    'n': {
      ipa: 'n',
      he: {
        letters: [
          { char: 'נ', name: 'נוּן', position: 'initial/medial' },
          { char: 'ן', name: 'נוּן סוֹפִית', position: 'final' },
        ],
      },
      en: {
        single: ['n'],
        combos: ['nn', 'kn', 'gn', 'pn'],
        examples: ['no', 'runner', 'knee', 'gnome', 'pneumonia'],
      },
    },
    
    's': {
      ipa: 's',
      he: {
        letters: [
          { char: 'ס', name: 'סָמֶךְ' },
          { char: 'שׂ', name: 'שִׂין (נקודה שמאלית)', dot: 'left' },
        ],
      },
      en: {
        single: ['s', 'c'],
        combos: ['ss', 'sc', 'ce', 'se'],
        examples: ['sun', 'city', 'pass', 'scene', 'nice', 'horse'],
      },
    },
    
    'ʔ': {
      ipa: 'ʔ',
      he: {
        letters: [
          { char: 'א', name: 'אָלֶף' },
          { char: 'ע', name: 'עַיִן' },
        ],
      },
      en: {
        single: [],
        combos: [],
        examples: ['uh-oh'],
        note: 'Not a phoneme in English, occurs between vowels',
      },
    },
    
    'p': {
      ipa: 'p',
      he: {
        letters: [{ char: 'פּ', name: 'פֵּא (עם דגש)', dagesh: true }],
      },
      en: {
        single: ['p'],
        combos: ['pp'],
        examples: ['pen', 'apple'],
      },
    },
    
    'f': {
      ipa: 'f',
      he: {
        letters: [
          { char: 'פ', name: 'פֵא (ללא דגש)', dagesh: false, position: 'initial/medial' },
          { char: 'ף', name: 'פֵא סוֹפִית', position: 'final' },
        ],
      },
      en: {
        single: ['f'],
        combos: ['ff', 'ph', 'gh'],
        examples: ['fun', 'offer', 'phone', 'laugh'],
      },
    },
    
    'ts': {
      ipa: 'ts',
      he: {
        letters: [
          { char: 'צ', name: 'צָדִי', position: 'initial/medial' },
          { char: 'ץ', name: 'צָדִי סוֹפִית', position: 'final' },
        ],
      },
      en: {
        single: [],
        combos: ['ts', 'tz', 'z'],
        examples: ['cats', 'pizza', 'waltz'],
      },
    },
    
    'ʁ': {
      ipa: 'ʁ',
      he: {
        letters: [{ char: 'ר', name: 'רֵישׁ' }],
        note: 'Uvular in Modern Hebrew',
      },
      en: {
        single: ['r'],
        combos: ['rr', 'wr'],
        examples: ['red', 'carry', 'write'],
        note: 'English /r/ is different (alveolar approximant /ɹ/)',
      },
    },
    
    'ʃ': {
      ipa: 'ʃ',
      he: {
        letters: [{ char: 'שׁ', name: 'שִׁין (נקודה ימנית)', dot: 'right' }],
      },
      en: {
        single: [],
        combos: ['sh', 'ti', 'ci', 'ssi', 'si', 'ch'],
        examples: ['ship', 'nation', 'special', 'mission', 'tension', 'machine'],
      },
    },
    
    // Additional English consonants
    'ð': {
      ipa: 'ð',
      he: { letters: [], note: 'No Hebrew equivalent' },
      en: {
        single: [],
        combos: ['th'],
        examples: ['this', 'the', 'mother'],
      },
    },
    
    'θ': {
      ipa: 'θ',
      he: { letters: [], note: 'No Hebrew equivalent' },
      en: {
        single: [],
        combos: ['th'],
        examples: ['think', 'bath'],
      },
    },
    
    'ŋ': {
      ipa: 'ŋ',
      he: { letters: [], note: 'No Hebrew equivalent' },
      en: {
        single: [],
        combos: ['ng', 'n'],
        examples: ['sing', 'think'],
      },
    },
    
    'w': {
      ipa: 'w',
      he: { 
        letters: [{ char: 'ו', name: 'וָו', note: 'Sometimes' }],
        note: 'Not standard in Hebrew',
      },
      en: {
        single: ['w'],
        combos: ['wh'],
        examples: ['water', 'what'],
      },
    },
    
    'dʒ': {
      ipa: 'dʒ',
      he: { 
        letters: [{ char: "ג'", name: "ג׳ימל (עם גֶּרֶשׁ)" }],
        note: 'Foreign sounds only',
      },
      en: {
        single: ['j'],
        combos: ['dge', 'ge', 'gi'],
        examples: ['job', 'edge', 'page', 'magic'],
      },
    },
    
    'tʃ': {
      ipa: 'tʃ',
      he: { 
        letters: [{ char: "צ'", name: "צָדִי (עם גֶּרֶשׁ)" }],
        note: 'Foreign sounds only',
      },
      en: {
        single: [],
        combos: ['ch', 'tch', 'tu'],
        examples: ['chat', 'watch', 'nature'],
      },
    },
    
    'ʒ': {
      ipa: 'ʒ',
      he: { 
        letters: [{ char: "ז'", name: "זַיִן (עם גֶּרֶשׁ)" }],
        note: 'Foreign sounds only',
      },
      en: {
        single: [],
        combos: ['si', 'su', 'ge'],
        examples: ['vision', 'measure', 'beige'],
      },
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('BILINGUAL IPA MAP - Hebrew (חָסֵר/מָלֵא) ↔ English (Single/Combos)');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('VOWELS:');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('IPA    Hebrew חָסֵר    Hebrew מָלֵא    English Single   English Combos');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

const vowelKeys = ['a', 'ɑ', 'ă', 'ɛ', 'e', 'ĕ', 'i', 'o', 'ɔ', 'ŏ', 'u', 'ə'];
vowelKeys.forEach(ipa => {
  const v = BILINGUAL_IPA.vowels[ipa];
  if (!v) return;
  
  const heChaser = v.he.chaser?.mark || '-';
  const heMale = v.he.male?.mark || '-';
  const enSingle = v.en.single?.join(',') || '-';
  const enCombos = v.en.combos?.slice(0, 3).join(',') || '-';
  
  console.log(`/${ipa.padEnd(4)}/  ${heChaser.padEnd(12)}  ${heMale.padEnd(14)}  ${enSingle.padEnd(15)}  ${enCombos}`);
});

console.log('\nDIPHTHONGS (English only):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
const diphthongs = ['eɪ', 'aɪ', 'ɔɪ', 'aʊ', 'oʊ'];
diphthongs.forEach(ipa => {
  const v = BILINGUAL_IPA.vowels[ipa];
  const combos = v.en.combos?.slice(0, 4).join(', ') || '-';
  console.log(`/${ipa.padEnd(4)}/  (no Hebrew)                           ${combos}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('CONSONANTS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA    Hebrew Letters          English Single   English Combos');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

const consKeys = ['b', 'v', 'g', 'd', 'h', 'z', 'x', 't', 'j', 'k', 'l', 'm', 'n', 's', 'ʔ', 'p', 'f', 'ts', 'ʁ', 'ʃ'];
consKeys.forEach(ipa => {
  const c = BILINGUAL_IPA.consonants[ipa];
  if (!c) return;
  
  const heLetters = c.he.letters?.map(l => l.char).join(' / ') || '-';
  const enSingle = c.en.single?.join(',') || '-';
  const enCombos = c.en.combos?.slice(0, 3).join(',') || '-';
  
  console.log(`/${ipa.padEnd(4)}/  ${heLetters.padEnd(20)}  ${enSingle.padEnd(15)}  ${enCombos}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────────────────────┐');
console.log('  │                                                                             │');
console.log('  │   IPA = Universal Bridge                                                    │');
console.log('  │                                                                             │');
console.log('  │   Hebrew:  חָסֵר (סימן)  ↔  מָלֵא (סימן + אות)                                │');
console.log('  │            ֹ (cholam)  ↔  וֹ (cholam + vav)                                 │');
console.log('  │            ִ (chirik)  ↔  ִי (chirik + yod)                                 │');
console.log('  │                                                                             │');
console.log('  │   English: Single      ↔  Combinations                                      │');
console.log('  │            s           ↔  ss, sc, ce                                        │');
console.log('  │            (none)      ↔  sh, ti, ci, ssi                                   │');
console.log('  │                                                                             │');
console.log('  │   SAME IPA unifies both systems!                                            │');
console.log('  │   אותו IPA מאחד את שתי המערכות!                                               │');
console.log('  │                                                                             │');
console.log('  └─────────────────────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('COMPLETE MAPPING STATISTICS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const vowelCount = Object.keys(BILINGUAL_IPA.vowels).length;
const consCount = Object.keys(BILINGUAL_IPA.consonants).length;

console.log(`Total IPA vowels mapped:      ${vowelCount}`);
console.log(`  - With Hebrew equivalent:   ${vowelKeys.length}`);
console.log(`  - English-only diphthongs:  ${diphthongs.length}`);
console.log(`Total IPA consonants mapped:  ${consCount}`);
console.log(`  - Shared He/En:            ${consKeys.length}`);
console.log(`  - English-only:            ${consCount - consKeys.length}`);
