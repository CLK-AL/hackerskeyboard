// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - IPA MULTILINGUAL KEYBOARD
// ═══════════════════════════════════════════════════════════════════════════════
//
// IPA is UNIVERSAL - the same phonemes exist across ALL languages
// An IPA keyboard is inherently MULTILINGUAL
// Each IPA key opens a door to syllables in ANY language
//
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_MULTILINGUAL = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VOWELS - Universal across languages
  // ═══════════════════════════════════════════════════════════════════════════
  
  'a': {
    name: 'open front unrounded',
    universal: true,
    languages: {
      he: { char: 'ַ', name: 'פַּתַח', example: 'אַב' },
      en: { char: 'a', patterns: ['cat', 'hat'], example: 'cat' },
      es: { char: 'a', example: 'casa' },
      fr: { char: 'a', example: 'chat' },
      de: { char: 'a', example: 'Mann' },
      it: { char: 'a', example: 'casa' },
      ar: { char: 'فَتْحَة', name: 'fatha', example: 'كَتَبَ' },
      ru: { char: 'а', example: 'мама' },
      jp: { char: 'あ/ア', romaji: 'a', example: 'あさ' },
      zh: { char: 'a', pinyin: 'ā á ǎ à', example: '大 dà' },
    },
  },
  
  'i': {
    name: 'close front unrounded',
    universal: true,
    languages: {
      he: { char: 'ִ', name: 'חִירִיק', male: 'ִי', example: 'מִי' },
      en: { char: 'ee/i', patterns: ['see', 'machine'], example: 'see' },
      es: { char: 'i', example: 'mi' },
      fr: { char: 'i', example: 'vie' },
      de: { char: 'i/ie', example: 'Liebe' },
      it: { char: 'i', example: 'vino' },
      ar: { char: 'كَسْرَة', name: 'kasra', example: 'كِتَاب' },
      ru: { char: 'и', example: 'мир' },
      jp: { char: 'い/イ', romaji: 'i', example: 'いち' },
      zh: { char: 'i', pinyin: 'ī í ǐ ì', example: '一 yī' },
    },
  },
  
  'u': {
    name: 'close back rounded',
    universal: true,
    languages: {
      he: { char: 'ֻ', name: 'קֻבּוּץ', male: 'וּ', example: 'הוּא' },
      en: { char: 'oo/u', patterns: ['moon', 'blue'], example: 'moon' },
      es: { char: 'u', example: 'luna' },
      fr: { char: 'ou', example: 'vous' },
      de: { char: 'u', example: 'Uhr' },
      it: { char: 'u', example: 'uno' },
      ar: { char: 'ضَمَّة', name: 'damma', example: 'كُتُب' },
      ru: { char: 'у', example: 'ум' },
      jp: { char: 'う/ウ', romaji: 'u', example: 'うみ' },
      zh: { char: 'u', pinyin: 'ū ú ǔ ù', example: '五 wǔ' },
    },
  },
  
  'o': {
    name: 'close-mid back rounded',
    universal: true,
    languages: {
      he: { char: 'ֹ', name: 'חוֹלָם', male: 'וֹ', example: 'שָׁלוֹם' },
      en: { char: 'o/oa', patterns: ['go', 'boat'], example: 'go' },
      es: { char: 'o', example: 'sol' },
      fr: { char: 'o/au', example: 'beau' },
      de: { char: 'o', example: 'Ohr' },
      it: { char: 'o', example: 'sole' },
      ru: { char: 'о', example: 'он' },
      jp: { char: 'お/オ', romaji: 'o', example: 'おと' },
      zh: { char: 'o', pinyin: 'ō ó ǒ ò', example: '我 wǒ' },
    },
  },
  
  'e': {
    name: 'close-mid front unrounded',
    universal: true,
    languages: {
      he: { char: 'ֵ', name: 'צֵירֵי', example: 'בֵּית' },
      en: { char: 'ay/ei', patterns: ['day', 'vein'], example: 'day' },
      es: { char: 'e', example: 'mesa' },
      fr: { char: 'é/er', example: 'été' },
      de: { char: 'e/ee', example: 'Tee' },
      it: { char: 'e', example: 'bene' },
      ru: { char: 'э', example: 'это' },
      jp: { char: 'え/エ', romaji: 'e', example: 'えき' },
      zh: { char: 'e', pinyin: 'ē é ě è', example: '的 de' },
    },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS - Many are universal, some are language-specific
  // ═══════════════════════════════════════════════════════════════════════════
  
  'ʃ': {
    name: 'voiceless postalveolar fricative',
    universal: true,
    languages: {
      he: { char: 'שׁ', name: 'שִׁין', example: 'שָׁלוֹם' },
      en: { char: 'sh', patterns: ['sh', 'ti', 'ci'], example: 'ship' },
      es: { char: 'ch', note: 'dialectal', example: 'muchacho' },
      fr: { char: 'ch', example: 'chat' },
      de: { char: 'sch', example: 'Schule' },
      it: { char: 'sc', example: 'pesce' },
      ru: { char: 'ш', example: 'шум' },
      jp: { char: 'し/シ', romaji: 'shi', example: 'しろ' },
      zh: { char: 'sh', pinyin: 'sh', example: '是 shì' },
      ar: { char: 'ش', name: 'shin', example: 'شمس' },
    },
  },
  
  's': {
    name: 'voiceless alveolar fricative',
    universal: true,
    languages: {
      he: { chars: ['ס', 'שׂ'], names: ['סָמֶךְ', 'שִׂין'], example: 'סוּס' },
      en: { char: 's', patterns: ['s', 'c', 'ss'], example: 'sun' },
      es: { char: 's', example: 'sol' },
      fr: { char: 's/c', example: 'soleil' },
      de: { char: 's/ß', example: 'Sonne' },
      it: { char: 's', example: 'sole' },
      ru: { char: 'с', example: 'сон' },
      jp: { char: 'さ/サ', romaji: 'sa', example: 'さくら' },
      zh: { char: 's', pinyin: 's', example: '四 sì' },
      ar: { char: 'س', name: 'sin', example: 'سلام' },
    },
  },
  
  'k': {
    name: 'voiceless velar stop',
    universal: true,
    languages: {
      he: { chars: ['כּ', 'ק'], names: ['כָּף', 'קוֹף'], example: 'כֹּל' },
      en: { char: 'k/c', patterns: ['k', 'c', 'ck'], example: 'cat' },
      es: { char: 'c/qu', example: 'casa' },
      fr: { char: 'c/qu', example: 'car' },
      de: { char: 'k', example: 'Katze' },
      it: { char: 'c/ch', example: 'casa' },
      ru: { char: 'к', example: 'кот' },
      jp: { char: 'か/カ', romaji: 'ka', example: 'かさ' },
      zh: { char: 'k/g', pinyin: 'k g', example: '可 kě' },
      ar: { char: 'ك/ق', names: ['kaf', 'qaf'], example: 'كتاب' },
    },
  },
  
  'x': {
    name: 'voiceless velar fricative',
    languages: {
      he: { chars: ['כ', 'ח'], names: ['כָף', 'חֵית'], example: 'חָכָם' },
      en: { char: 'ch/kh', note: 'loanwords only', example: 'loch' },
      es: { char: 'j/g', example: 'jamón' },
      de: { char: 'ch', example: 'Bach' },
      ru: { char: 'х', example: 'хлеб' },
      ar: { char: 'خ', name: 'kha', example: 'خبز' },
      zh: { char: 'h', pinyin: 'h', example: '好 hǎo' },
    },
  },
  
  'ts': {
    name: 'voiceless alveolar affricate',
    languages: {
      he: { char: 'צ', name: 'צָדִי', final: 'ץ', example: 'צִפּוֹר' },
      en: { char: 'ts/tz', example: 'cats' },
      de: { char: 'z/ts', example: 'Zeit' },
      it: { char: 'z', example: 'pizza' },
      ru: { char: 'ц', example: 'царь' },
      jp: { char: 'つ/ツ', romaji: 'tsu', example: 'つき' },
      zh: { char: 'c', pinyin: 'c', example: '次 cì' },
    },
  },
  
  'ʔ': {
    name: 'glottal stop',
    languages: {
      he: { chars: ['א', 'ע'], names: ['אָלֶף', 'עַיִן'], example: 'אָב' },
      en: { note: 'not phonemic, occurs in "uh-oh"' },
      ar: { char: 'ء/ع', names: ['hamza', 'ayn'], example: 'أب' },
      jp: { note: 'occurs between vowels' },
    },
  },
  
  'ʁ': {
    name: 'uvular fricative',
    languages: {
      he: { char: 'ר', name: 'רֵישׁ', example: 'רֹאשׁ' },
      fr: { char: 'r', example: 'rouge' },
      de: { char: 'r', example: 'rot' },
    },
  },
  
  'r': {
    name: 'alveolar trill/tap',
    languages: {
      es: { char: 'r/rr', example: 'perro' },
      it: { char: 'r', example: 'rosso' },
      ru: { char: 'р', example: 'рука' },
      ar: { char: 'ر', name: 'ra', example: 'رأس' },
      jp: { char: 'ら/ラ', romaji: 'ra', example: 'らく' },
    },
  },
  
  'ɹ': {
    name: 'alveolar approximant',
    languages: {
      en: { char: 'r', example: 'red' },
      zh: { char: 'r', pinyin: 'r', example: '人 rén' },
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// SYLLABLE GENERATOR - Create syllables in any language from IPA
// ═══════════════════════════════════════════════════════════════════════════════

function generateSyllables(consonantIPA, vowelIPA, lang) {
  const c = IPA_MULTILINGUAL[consonantIPA];
  const v = IPA_MULTILINGUAL[vowelIPA];
  
  if (!c || !v) return null;
  if (!c.languages[lang] || !v.languages[lang]) return null;
  
  const cData = c.languages[lang];
  const vData = v.languages[lang];
  
  // Generate CV syllable representation
  return {
    ipa: consonantIPA + vowelIPA,
    lang: lang,
    consonant: cData.char || cData.chars?.[0],
    vowel: vData.char,
    example: `${consonantIPA}${vowelIPA}`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA MULTILINGUAL KEYBOARD - One sound, ALL languages');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('The SAME IPA phoneme exists across languages:\n');

const showPhonemes = ['a', 'i', 'ʃ', 's', 'k'];
showPhonemes.forEach(ipa => {
  const data = IPA_MULTILINGUAL[ipa];
  console.log(`/${ipa}/ - ${data.name}`);
  
  const langs = Object.entries(data.languages).slice(0, 6);
  langs.forEach(([lang, info]) => {
    const char = info.char || info.chars?.join('/') || info.note || '-';
    console.log(`  ${lang.toUpperCase().padEnd(3)}: ${char}`);
  });
  console.log('');
});

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('/ʃ/ across writing systems:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const shData = IPA_MULTILINGUAL['ʃ'];
Object.entries(shData.languages).forEach(([lang, info]) => {
  const char = info.char || '-';
  const example = info.example || '';
  console.log(`  ${lang.toUpperCase().padEnd(3)}: ${char.padEnd(6)} → ${example}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('Hebrew + English syllables from SAME IPA:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const consonants = ['ʃ', 's', 'k', 'ts'];
const vowels = ['a', 'i', 'o', 'u'];

console.log('IPA      Hebrew    English');
console.log('─────────────────────────────');
consonants.forEach(c => {
  vowels.forEach(v => {
    const ipa = `/${c}${v}/`.padEnd(8);
    
    // Hebrew representation
    const heC = IPA_MULTILINGUAL[c].languages.he;
    const heV = IPA_MULTILINGUAL[v].languages.he;
    const heSyl = (heC.char || heC.chars?.[0]) + (heV.char || '');
    
    // English representation
    const enC = IPA_MULTILINGUAL[c].languages.en;
    const enV = IPA_MULTILINGUAL[v].languages.en;
    const enSyl = (enC.char || enC.patterns?.[0] || '') + (enV.char?.split('/')[0] || v);
    
    console.log(`${ipa} ${heSyl.padEnd(10)} ${enSyl}`);
  });
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA KEYBOARD = Gateway to ALL languages');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Press IPA /ʃ/ key:');
console.log('  → Hebrew:   שׁ (shin)     שַׁ שָׁ שֶׁ שִׁ שֹׁ שֻׁ');
console.log('  → English:  sh           sha she shi sho shu');
console.log('  → French:   ch           cha che chi cho chu');
console.log('  → German:   sch          scha sche schi scho schu');
console.log('  → Russian:  ш            ша ше ши шо шу');
console.log('  → Japanese: し           しゃ しぇ し しょ しゅ');
console.log('  → Arabic:   ش            شَ شِ شُ');
console.log('  → Chinese:  sh           shā shé shǐ shò shū');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  IPA Key → Sound → Syllables in ALL languages');
console.log('');
console.log('  One keyboard. One sound system. Infinite languages.');
console.log('');
console.log('  המקלדת אחת. מערכת צלילים אחת. שפות אינסופיות.');
