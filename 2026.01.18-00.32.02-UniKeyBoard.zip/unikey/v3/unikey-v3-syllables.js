// ═══════════════════════════════════════════════════════════════════════════
// UNIFIED SYLLABLES DATABASE - Single Source of Truth
// ═══════════════════════════════════════════════════════════════════════════
//
// PRINCIPLE: Every syllable defined ONCE
// MG = just pairs of syllable IDs
//
// ═══════════════════════════════════════════════════════════════════════════

const SYL = {
  // ═══════════════════════════════════════════════════════════════════════
  // HEBREW ENDINGS (סיומות)
  // ═══════════════════════════════════════════════════════════════════════
  
  // Plural
  'ים': { p: 'ים', n: 'ִים', ipa: 'im' },
  'ות': { p: 'ות', n: 'וֹת', ipa: 'ot' },
  'ין': { p: 'ין', n: 'ִין', ipa: 'in' },
  
  // Possessive 3rd singular
  'ו': { p: 'ו', n: 'וֹ', ipa: 'o' },
  'ה': { p: 'ה', n: 'ָהּ', ipa: 'a' },
  
  // Possessive 3rd plural  
  'ם': { p: 'ם', n: 'ָם', ipa: 'am' },
  'ן': { p: 'ן', n: 'ָן', ipa: 'an' },
  
  // Possessive 2nd singular (same plain, different nikud!)
  'ךָ': { p: 'ך', n: 'ְךָ', ipa: 'xa' },
  'ךְ': { p: 'ך', n: 'ֵךְ', ipa: 'ex' },
  
  // Possessive 2nd plural
  'כם': { p: 'כם', n: 'כֶם', ipa: 'xem' },
  'כן': { p: 'כן', n: 'כֶן', ipa: 'xen' },
  
  // Extended possessive
  'יו': { p: 'יו', n: 'ָיו', ipa: 'av' },
  'יה': { p: 'יה', n: 'ֶיהָ', ipa: 'eha' },
  'יהם': { p: 'יהם', n: 'ֵיהֶם', ipa: 'ehem' },
  'יהן': { p: 'יהן', n: 'ֵיהֶן', ipa: 'ehen' },
  
  // Full pronouns (3rd)
  'הם': { p: 'הם', n: 'הֵם', ipa: 'hem' },
  'הן': { p: 'הן', n: 'הֵן', ipa: 'hen' },
  
  // Noun/adj endings
  'ת': { p: 'ת', n: 'ֶת', ipa: 'et' },
  'ד': { p: 'ד', n: 'ֵד', ipa: 'ed' },
  'נית': { p: 'נית', n: 'נִית', ipa: 'nit' },
  'נה': { p: 'נה', n: 'נָה', ipa: 'na' },
  'ית': { p: 'ית', n: 'ִית', ipa: 'it' },
  'י': { p: 'י', n: 'ִי', ipa: 'i' },
  'דה': { p: 'דה', n: 'דָה', ipa: 'da' },
  
  // Person (איש/אישה)
  'יש': { p: 'יש', n: 'יש', ipa: 'ish' },
  'ישה': { p: 'ישה', n: 'ישָׁה', ipa: 'isha' },
  
  // Present tense ה (same plain, different nikud)
  'הֶ': { p: 'ה', n: 'ֶה', ipa: 'e' },
  'הָ': { p: 'ה', n: 'ָה', ipa: 'a' },
  
  // ═══════════════════════════════════════════════════════════════════════
  // HEBREW PRONOUNS
  // ═══════════════════════════════════════════════════════════════════════
  
  'הוא': { p: 'הוא', n: 'הוּא', ipa: 'hu' },
  'היא': { p: 'היא', n: 'הִיא', ipa: 'hi' },
  'אתה': { p: 'אתה', n: 'אַתָּה', ipa: 'ata' },
  'את': { p: 'את', n: 'אַתְּ', ipa: 'at' },
  'אני': { p: 'אני', n: 'אֲנִי', ipa: 'ani' },
  
  // ═══════════════════════════════════════════════════════════════════════
  // HEBREW VERB PREFIXES
  // ═══════════════════════════════════════════════════════════════════════
  
  'י_v': { p: 'י', n: 'יִ', ipa: 'ji' },
  'ת_v': { p: 'ת', n: 'תִּ', ipa: 'ti' },
  'א_v': { p: 'א', n: 'אֲ', ipa: 'e' },
  'נ_v': { p: 'נ', n: 'נִ', ipa: 'ni' },
  
  // ═══════════════════════════════════════════════════════════════════════
  // ENGLISH
  // ═══════════════════════════════════════════════════════════════════════
  
  'he': { p: 'e', n: 'e', ipa: 'i' },
  'she': { p: 'she', n: 'she', ipa: 'ʃi' },
  'his': { p: 'is', n: 'is', ipa: 'ɪz' },
  'her': { p: 'er', n: 'er', ipa: 'ɜr' },
  'him': { p: 'im', n: 'im', ipa: 'ɪm' },
  'they': { p: 'ey', n: 'ey', ipa: 'eɪ' },
  'them': { p: 'em', n: 'em', ipa: 'əm' },
  
  'man': { p: 'an', n: 'an', ipa: 'æn' },
  'woman': { p: 'oman', n: 'oman', ipa: 'ʊmən' },
  'men': { p: 'en', n: 'en', ipa: 'ɛn' },
  'women': { p: 'omen', n: 'omen', ipa: 'ɪmɪn' },
  
  'son': { p: 'on', n: 'on', ipa: 'ʌn' },
  'daughter': { p: 'aughter', n: 'aughter', ipa: 'ɔtər' },
  'boy': { p: 'oy', n: 'oy', ipa: 'ɔɪ' },
  'girl': { p: 'irl', n: 'irl', ipa: 'ɜrl' },
  
  'brother': { p: 'rother', n: 'rother', ipa: 'rʌðər' },
  'sister': { p: 'ister', n: 'ister', ipa: 'ɪstər' },
  'father': { p: 'ather', n: 'ather', ipa: 'æðər' },
  'mother': { p: 'other', n: 'other', ipa: 'ʌðər' },
  
  'king': { p: 'ing', n: 'ing', ipa: 'ɪŋ' },
  'queen': { p: 'ueen', n: 'ueen', ipa: 'in' },
  'mr': { p: 'r.', n: 'r.', ipa: 'r' },
  'ms': { p: 's.', n: 's.', ipa: 's' },
  
  'himself': { p: 'imself', n: 'imself', ipa: 'ɪmsɛlf' },
  'herself': { p: 'erself', n: 'erself', ipa: 'ɜrsɛlf' },
};

// ═══════════════════════════════════════════════════════════════════════════
// MG PAIRS - Just references to SYL
// ═══════════════════════════════════════════════════════════════════════════

const MG = [
  // Hebrew possessive/endings
  { m: 'ו', f: 'ה', ctx: 'poss-3s' },
  { m: 'יו', f: 'יה', ctx: 'poss-3s-ext' },
  { m: 'ם', f: 'ן', ctx: 'poss-3p' },
  { m: 'הם', f: 'הן', ctx: 'poss-3p-full' },
  { m: 'יהם', f: 'יהן', ctx: 'poss-3p-ext' },
  { m: 'ךָ', f: 'ךְ', ctx: 'poss-2s' },
  { m: 'כם', f: 'כן', ctx: 'poss-2p' },
  
  // Hebrew plural
  { m: 'ים', f: 'ות', ctx: 'pl' },
  { m: 'ין', f: 'ות', ctx: 'pl-aram' },
  
  // Hebrew noun/adj
  { m: 'ד', f: 'ת', ctx: 'adj' },
  { m: 'ן', f: 'ת', ctx: 'noun' },
  { m: 'ן', f: 'נית', ctx: 'prof' },
  { m: 'ן', f: 'נה', ctx: 'prof2' },
  { m: 'י', f: 'ית', ctx: 'gent' },
  { m: 'ד', f: 'דה', ctx: 'noun2' },
  { m: 'יש', f: 'ישה', ctx: 'person' },
  
  // Hebrew present (same plain!)
  { m: 'הֶ', f: 'הָ', ctx: 'pres' },
  
  // Hebrew pronouns
  { m: 'הוא', f: 'היא', ctx: 'pron-3s' },
  { m: 'אתה', f: 'את', ctx: 'pron-2s' },
  
  // Hebrew verb prefix
  { m: 'י_v', f: 'ת_v', ctx: 'fut-3' },
  
  // English
  { m: 'he', f: 'she', ctx: 'en-pron' },
  { m: 'his', f: 'her', ctx: 'en-poss' },
  { m: 'him', f: 'her', ctx: 'en-obj' },
  { m: 'they', f: 'them', ctx: 'en-3p' },
  { m: 'man', f: 'woman', ctx: 'en-adult' },
  { m: 'men', f: 'women', ctx: 'en-adults' },
  { m: 'son', f: 'daughter', ctx: 'en-child' },
  { m: 'boy', f: 'girl', ctx: 'en-young' },
  { m: 'brother', f: 'sister', ctx: 'en-sibling' },
  { m: 'father', f: 'mother', ctx: 'en-parent' },
  { m: 'king', f: 'queen', ctx: 'en-royal' },
  { m: 'mr', f: 'ms', ctx: 'en-title' },
  { m: 'himself', f: 'herself', ctx: 'en-self' },
];

// ═══════════════════════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════════════════════

const syl = (id, nikud = false) => {
  const s = SYL[id];
  if (!s) return id;
  return nikud ? s.n : s.p;
};

const syl_ipa = (id) => SYL[id]?.ipa || '';

const mg_get = (pair, nikud = false) => ({
  m: syl(pair.m, nikud),
  f: syl(pair.f, nikud),
  mf: `${syl(pair.m, nikud)}/${syl(pair.f, nikud)}`,
  ipa: `${syl_ipa(pair.m)}/${syl_ipa(pair.f)}`,
});

const mg_ivrita = (pair, nikud = false) => {
  const m = syl(pair.m, nikud);
  const f = syl(pair.f, nikud);
  return m === f ? m : `${m}.${f}`;
};

const mg_by_ctx = (ctx) => MG.filter(p => p.ctx === ctx);

// ═══════════════════════════════════════════════════════════════════════════
// STATS
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIFIED SYLLABLES + MG');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`Syllables: ${Object.keys(SYL).length}`);
console.log(`MG Pairs:  ${MG.length}`);
console.log('');

console.log('───────────────────────────────────────────────────────────────');
console.log('Hebrew MG:');
console.log('───────────────────────────────────────────────────────────────\n');

MG.filter(p => !p.ctx.startsWith('en-')).forEach(p => {
  const plain = mg_get(p);
  const nikud = mg_get(p, true);
  console.log(`${p.ctx.padEnd(12)}: ${plain.mf.padEnd(12)} → ${nikud.mf.padEnd(14)} [${mg_ivrita(p)}]`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('English MG:');
console.log('───────────────────────────────────────────────────────────────\n');

MG.filter(p => p.ctx.startsWith('en-')).forEach(p => {
  const data = mg_get(p);
  console.log(`${p.ctx.padEnd(12)}: ${data.mf.padEnd(20)} [${data.ipa}]`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('NO MORE DUPLICATES! Single source of truth.');
console.log('═══════════════════════════════════════════════════════════════');
