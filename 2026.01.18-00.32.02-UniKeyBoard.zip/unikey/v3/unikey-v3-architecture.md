# UniKey v3 - Complete Architecture

## 🎯 הרעיון המרכזי

**IPA = המפתח האוניברסלי**

```
IPA Syllable → Hebrew (with nikud) → English
     ↓
   carries its own rules
     ↓
   combining = automatic correct result
```

## 📐 The Complete Space

### 19 Ivrita Patterns = ALL Gender Suffixes

| # | M | F | Example | Type |
|---|---|---|---------|------|
| 1 | ∅ | ה | תלמיד.ה | noun-sg |
| 2 | ∅ | ת | נהג.ת | noun-sg |
| 3 | ן | ת | בן.ת | noun |
| 4 | ן | נית | שחקן.ית | profession |
| 5 | ן | נה | אמן.ה | profession |
| 6 | ה | ה | מורֶה.ָה | present (nikud diff) |
| 7 | ים | ות | תלמידים.ות | plural |
| 8 | ין | ות | דין.ות | plural (Aramaic) |
| 9 | ו | ה | שלו.ה | poss-3s |
| 10 | ם | ן | שלהם.ן | poss-3p |
| 11 | ך | ך | שלךָ.ְ | poss-2s (nikud diff) |
| 12 | י | ת | יכתוב.תכתוב | future |
| 13 | ד | ת | עומד.ת | present |
| 14 | הוא | היא | הוא.היא | pronoun |
| 15 | הם | הן | הם.הן | pronoun-pl |
| 16 | אתה | את | אתה.את | pronoun-2s |
| 17 | יו | יה | שליו.יה | poss-3s-ext |
| 18 | יהם | יהן | שליהם.ן | poss-3p-ext |
| 19 | כם | כן | שלכם.ן | poss-2p |

### 12 PUA Glyphs = Visual Representation

The 12 hybrid glyphs from MGHebrew font cover ALL letter combinations for gender marking.

## 🔧 How It Works

### Syllable = Unit with Rules

```javascript
// Each syllable carries:
{
  p: 'תַּ',      // nikud form
  plain: 'ת',   // plain form
  ipa: 'ta',    // pronunciation
  // + optional modifiers:
  gender: 'm',  // if gender suffix
  num: 'pl',    // if number marker
  tense: 'fut', // if verb prefix
}
```

### Building Words

```
IPA sequence:     /ta.ləm.mid/
                      ↓
Syllables:       [ta] [lə] [mi] [d]
                      ↓
Each carries:    תַּ   לְ   מִ   ד
                      ↓
Combined:           תַּלְמִיד

+ Gender suffix:  תַּלְמִיד + .ה → תַּלְמִידָה
+ Plural:         תַּלְמִיד + ים → תַּלְמִידִים
```

### Same Mechanism as English

```
IPA:            /stju.dənt/
                     ↓
Spelling rules:  st-u-d-e-nt
                     ↓
Combined:         student

+ Plural:        student + s → students
```

## 🎹 Keyboard Design

### One Physical Key → Multiple Layers

```
Physical Key [A]
      │
      ├── Normal     →  א (plain)
      ├── + Nikud    →  אָ אַ אֶ (with nikud)
      ├── + Alt      →  ו/ה (MG pair)
      └── + Ctrl     →  /a/ (IPA)
```

### Number Keys = MG Suffixes

```
Key   Normal   Alt      Alt+Shift
───   ──────   ───      ─────────
1     1        ו/ה      וֹ/ָהּ
2     2        ם/ן      ָם/ָן
3     3        ים/ות    ִים/וֹת
4     4        ד/ת      ֵד/ֶת
5     5        י/ת      יִ/תִּ
```

## ✅ Benefits

1. **Single Source of Truth** - IPA connects all forms
2. **No Duplication** - Each syllable defined once
3. **Automatic Nikud** - Syllables carry their rules
4. **Complete Coverage** - 19 patterns cover ALL cases
5. **Familiar Layout** - QWERTY + logical extensions
6. **Scalable** - Works for any length sequence

## 🔑 Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                      THE COMPLETE SYSTEM                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   IPA Phonemes (finite, universal)                             │
│        ↓                                                        │
│   Syllables (each carries nikud/spelling rules)                │
│        ↓                                                        │
│   Gender Suffixes (19 patterns = COMPLETE)                     │
│        ↓                                                        │
│   Visual Glyphs (12 PUA = COMPLETE)                            │
│                                                                 │
│   ═══════════════════════════════════════════════════════════  │
│                                                                 │
│   Keyboard = familiar QWERTY                                   │
│            + IPA bridge                                         │
│            + syllable layers                                    │
│            + 19 gender suffixes on number keys                 │
│                                                                 │
│   Result: Type any IPA sequence → correct Hebrew/English!      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

מקלדת אחת. מערכת שלמה. IPA כגשר.
