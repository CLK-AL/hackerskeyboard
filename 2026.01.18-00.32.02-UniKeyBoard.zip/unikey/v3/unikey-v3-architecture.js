// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V3 ARCHITECTURE
// ═══════════════════════════════════════════════════════════════════════════════
//
// 1. KEYBOARD LAYOUTS - Different per language (physical key position)
// 2. IPA_UNIKEYS - Universal key (sound → all variations in ALL languages)
//
// The KEY insight: IPA is the UNIQUE KEY that bridges languages
// Even though each language has its own layout, IPA unifies them
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// 1. KEYBOARD LAYOUTS - Physical key → letter (DIFFERENT per language)
// ═══════════════════════════════════════════════════════════════════════════════

const LAYOUT_EN = {
  // QWERTY layout - physical key → English letter
  'q': 'q', 'w': 'w', 'e': 'e', 'r': 'r', 't': 't', 'y': 'y', 'u': 'u', 'i': 'i', 'o': 'o', 'p': 'p',
  'a': 'a', 's': 's', 'd': 'd', 'f': 'f', 'g': 'g', 'h': 'h', 'j': 'j', 'k': 'k', 'l': 'l',
  'z': 'z', 'x': 'x', 'c': 'c', 'v': 'v', 'b': 'b', 'n': 'n', 'm': 'm',
};

const LAYOUT_HE = {
  // Israeli Standard layout - physical key → Hebrew letter
  'q': '/', 'w': "'", 'e': 'ק', 'r': 'ר', 't': 'א', 'y': 'ט', 'u': 'ו', 'i': 'ן', 'o': 'ם', 'p': 'פ',
  'a': 'ש', 's': 'ד', 'd': 'ג', 'f': 'כ', 'g': 'ע', 'h': 'י', 'j': 'ח', 'k': 'ל', 'l': 'ך',
  'z': 'ז', 'x': 'ס', 'c': 'ב', 'v': 'ה', 'b': 'נ', 'n': 'מ', 'm': 'צ',
  ';': 'ף', ',': 'ת', '.': 'ץ',
};

// ═══════════════════════════════════════════════════════════════════════════════
// 2. IPA_UNIKEYS - The UNIVERSAL KEY (IPA → all variations in ALL languages)
// ═══════════════════════════════════════════════════════════════════════════════
//
// IPA is UNIQUE KEY - one sound maps to ALL its representations:
//   - All Hebrew letters that make this sound (with their nikud)
//   - All English spellings that make this sound (with patterns)
//   - All syllable combinations in BOTH languages
//
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_UNIKEYS = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VOWELS - IPA → Hebrew nikud + English spellings
  // ═══════════════════════════════════════════════════════════════════════════
  
  'a': {
    type: 'vowel',
    name: 'open front',
    he: { nikud: 'ַ', name: 'פַּתַח', examples: ['אַב', 'מַה'] },
    en: { spellings: ['a', 'ai'], patterns: ['cat', 'plaid'], examples: ['cat', 'hat'] },
  },
  
  'ɑ': {
    type: 'vowel', 
    name: 'open back',
    he: { nikud: 'ָ', name: 'קָמָץ', examples: ['אָב', 'שָׁם'] },
    en: { spellings: ['a', 'o', 'ar'], patterns: ['father', 'hot', 'car'], examples: ['father', 'car'] },
  },
  
  'ɛ': {
    type: 'vowel',
    name: 'open-mid front',
    he: { nikud: 'ֶ', name: 'סֶגוֹל', examples: ['אֶת', 'יֶלֶד'] },
    en: { spellings: ['e', 'ea', 'ai'], patterns: ['bed', 'bread', 'said'], examples: ['bed', 'red'] },
  },
  
  'e': {
    type: 'vowel',
    name: 'close-mid front',
    he: { nikud: 'ֵ', name: 'צֵירֵי', examples: ['בֵּית', 'אֵם'] },
    en: { spellings: ['ay', 'ai', 'ei', 'ey'], patterns: ['day', 'rain', 'vein', 'they'], examples: ['day', 'say'] },
  },
  
  'i': {
    type: 'vowel',
    name: 'close front',
    he: { nikud: 'ִ', name: 'חִירִיק', male: 'ִי', examples: ['מִי', 'שִׁיר'] },
    en: { spellings: ['ee', 'ea', 'i', 'ie', 'y'], patterns: ['see', 'sea', 'ski', 'field', 'happy'], examples: ['see', 'me'] },
  },
  
  'o': {
    type: 'vowel',
    name: 'close-mid back',
    he: { nikud: 'ֹ', name: 'חוֹלָם', male: 'וֹ', examples: ['לֹא', 'שָׁלוֹם'] },
    en: { spellings: ['o', 'oa', 'ow', 'oe'], patterns: ['go', 'boat', 'low', 'toe'], examples: ['go', 'no'] },
  },
  
  'u': {
    type: 'vowel',
    name: 'close back',
    he: { nikud: 'ֻ', name: 'קֻבּוּץ', male: 'וּ', examples: ['הוּא', 'שׁוּק'] },
    en: { spellings: ['oo', 'u', 'ue', 'ew'], patterns: ['moon', 'rule', 'blue', 'new'], examples: ['moon', 'blue'] },
  },
  
  'ə': {
    type: 'vowel',
    name: 'schwa',
    he: { nikud: 'ְ', name: 'שְׁוָא', note: 'נָע/נָח', examples: ['בְּ', 'לְ'] },
    en: { spellings: ['a', 'e', 'i', 'o', 'u'], patterns: ['about', 'taken', 'pencil', 'lemon', 'circus'], examples: ['about', 'the'] },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS - IPA → Hebrew letters + English spellings
  // ═══════════════════════════════════════════════════════════════════════════
  
  'b': {
    type: 'consonant',
    name: 'voiced bilabial stop',
    he: {
      letters: [{ letter: 'בּ', dagesh: true }],
      syllables: ['בַּ', 'בָּ', 'בֶּ', 'בֵּ', 'בִּ', 'בֹּ', 'בֻּ', 'בְּ'],
    },
    en: {
      spellings: ['b', 'bb'],
      syllables: ['ba', 'be', 'bi', 'bo', 'bu'],
    },
  },
  
  'v': {
    type: 'consonant',
    name: 'voiced labiodental fricative',
    he: {
      letters: [
        { letter: 'ב', dagesh: false, name: 'בֵית רָפָה' },
        { letter: 'ו', name: 'וָו עיצורית' },
      ],
      syllables: ['בַ', 'בָ', 'בֶ', 'בֵ', 'בִ', 'בֹ', 'בֻ', 'בְ', 'וַ', 'וָ', 'וֶ', 'וֵ', 'וִ', 'וְ'],
    },
    en: {
      spellings: ['v', 'f'],
      syllables: ['va', 've', 'vi', 'vo', 'vu'],
    },
  },
  
  'k': {
    type: 'consonant',
    name: 'voiceless velar stop',
    he: {
      letters: [
        { letter: 'כּ', dagesh: true, name: 'כָּף דְּגוּשָׁה' },
        { letter: 'ק', name: 'קוֹף' },
      ],
      syllables: ['כַּ', 'כָּ', 'כֶּ', 'כֵּ', 'כִּ', 'כֹּ', 'כֻּ', 'כְּ', 'קַ', 'קָ', 'קֶ', 'קֵ', 'קִ', 'קֹ', 'קֻ', 'קְ'],
    },
    en: {
      spellings: ['k', 'c', 'ck', 'ch', 'q', 'que'],
      syllables: ['ka', 'ke', 'ki', 'ko', 'ku', 'ca', 'co', 'cu'],
    },
  },
  
  'x': {
    type: 'consonant',
    name: 'voiceless velar fricative',
    he: {
      letters: [
        { letter: 'כ', dagesh: false, name: 'כָף רָפָה', final: 'ך' },
        { letter: 'ח', guttural: true, name: 'חֵית' },
      ],
      syllables: ['כַ', 'כָ', 'כֶ', 'כֵ', 'כִ', 'כֹ', 'כֻ', 'כְ', 'חַ', 'חָ', 'חֶ', 'חֵ', 'חִ', 'חֹ', 'חֲ', 'חֱ', 'חֳ'],
      final_syllables: ['ךְ', 'ךָ'],
      furtive_patach: true, // פתח גנובה for ח at word end
    },
    en: {
      spellings: ['ch', 'kh'],
      note: 'Not native to English',
      syllables: [],
    },
  },
  
  's': {
    type: 'consonant',
    name: 'voiceless alveolar fricative',
    he: {
      letters: [
        { letter: 'ס', name: 'סָמֶךְ' },
        { letter: 'שׂ', diacritic: 'ׂ', name: 'שִׂין' }, // Left dot!
      ],
      // BOTH letters produce /s/ - same IPA, different spelling
      samech_syllables: ['סַ', 'סָ', 'סֶ', 'סֵ', 'סִ', 'סֹ', 'סֻ', 'סְ'],
      sin_syllables: ['שַׂ', 'שָׂ', 'שֶׂ', 'שֵׂ', 'שִׂ', 'שֹׂ', 'שֻׂ', 'שְׂ'],
    },
    en: {
      spellings: ['s', 'c', 'ss', 'sc', 'ce'],
      syllables: ['sa', 'se', 'si', 'so', 'su', 'ce', 'ci', 'cy'],
    },
  },
  
  'ʃ': {
    type: 'consonant',
    name: 'voiceless postalveolar fricative',
    he: {
      letters: [
        { letter: 'שׁ', diacritic: 'ׁ', name: 'שִׁין' }, // Right dot!
      ],
      syllables: ['שַׁ', 'שָׁ', 'שֶׁ', 'שֵׁ', 'שִׁ', 'שֹׁ', 'שֻׁ', 'שְׁ'],
    },
    en: {
      spellings: ['sh', 'ti', 'ci', 'ssi', 'si', 'ch'],
      syllables: ['sha', 'she', 'shi', 'sho', 'shu', 'tion', 'sion', 'cial'],
    },
  },
  
  't': {
    type: 'consonant',
    name: 'voiceless alveolar stop',
    he: {
      letters: [
        { letter: 'ת', name: 'תָו' },
        { letter: 'ט', name: 'טֵית' },
      ],
      tav_syllables: ['תַ', 'תָ', 'תֶ', 'תֵ', 'תִ', 'תֹ', 'תֻ', 'תְ'],
      tet_syllables: ['טַ', 'טָ', 'טֶ', 'טֵ', 'טִ', 'טֹ', 'טֻ', 'טְ'],
      endings: ['תִּי', 'תָּ', 'תְּ', 'וֹת'], // verb/noun endings
    },
    en: {
      spellings: ['t', 'tt', 'ed'],
      syllables: ['ta', 'te', 'ti', 'to', 'tu'],
    },
  },
  
  'ts': {
    type: 'consonant',
    name: 'voiceless alveolar affricate',
    he: {
      letters: [
        { letter: 'צ', name: 'צָדִי', final: 'ץ' },
      ],
      syllables: ['צַ', 'צָ', 'צֶ', 'צֵ', 'צִ', 'צֹ', 'צֻ', 'צְ'],
    },
    en: {
      spellings: ['ts', 'tz', 'zz'],
      syllables: ['tsa', 'tse', 'tsi', 'tso', 'tsu'],
    },
  },
  
  'm': {
    type: 'consonant',
    name: 'bilabial nasal',
    he: {
      letters: [
        { letter: 'מ', name: 'מֵם', final: 'ם' },
      ],
      syllables: ['מַ', 'מָ', 'מֶ', 'מֵ', 'מִ', 'מֹ', 'מֻ', 'מְ'],
    },
    en: {
      spellings: ['m', 'mm'],
      syllables: ['ma', 'me', 'mi', 'mo', 'mu'],
    },
  },
  
  'n': {
    type: 'consonant',
    name: 'alveolar nasal',
    he: {
      letters: [
        { letter: 'נ', name: 'נוּן', final: 'ן' },
      ],
      syllables: ['נַ', 'נָ', 'נֶ', 'נֵ', 'נִ', 'נֹ', 'נֻ', 'נְ'],
    },
    en: {
      spellings: ['n', 'nn', 'kn', 'gn'],
      syllables: ['na', 'ne', 'ni', 'no', 'nu'],
    },
  },
  
  'l': {
    type: 'consonant',
    name: 'alveolar lateral',
    he: {
      letters: [
        { letter: 'ל', name: 'לָמֶד' },
      ],
      syllables: ['לַ', 'לָ', 'לֶ', 'לֵ', 'לִ', 'לֹ', 'לֻ', 'לְ'],
    },
    en: {
      spellings: ['l', 'll'],
      syllables: ['la', 'le', 'li', 'lo', 'lu'],
    },
  },
  
  'ʁ': {
    type: 'consonant',
    name: 'uvular fricative',
    he: {
      letters: [
        { letter: 'ר', name: 'רֵישׁ' },
      ],
      syllables: ['רַ', 'רָ', 'רֶ', 'רֵ', 'רִ', 'רֹ', 'רֻ', 'רְ'],
    },
    en: {
      spellings: ['r', 'rr', 'wr'],
      syllables: ['ra', 're', 'ri', 'ro', 'ru'],
      note: 'English /r/ is different (alveolar approximant)',
    },
  },
  
  'ʔ': {
    type: 'consonant',
    name: 'glottal stop',
    he: {
      letters: [
        { letter: 'א', name: 'אָלֶף', guttural: true },
        { letter: 'ע', name: 'עַיִן', guttural: true },
      ],
      alef_syllables: ['אַ', 'אָ', 'אֶ', 'אֵ', 'אִ', 'אֹ', 'אֻ', 'אְ', 'אֲ', 'אֱ', 'אֳ'],
      ayin_syllables: ['עַ', 'עָ', 'עֶ', 'עֵ', 'עִ', 'עֹ', 'עֻ', 'עְ', 'עֲ', 'עֱ', 'עֳ'],
    },
    en: {
      spellings: [],
      note: 'Not a phoneme in English (but occurs in "uh-oh")',
    },
  },
  
  'h': {
    type: 'consonant',
    name: 'voiceless glottal fricative',
    he: {
      letters: [
        { letter: 'ה', name: 'הֵא', guttural: true },
      ],
      syllables: ['הַ', 'הָ', 'הֶ', 'הֵ', 'הִ', 'הֹ', 'הֻ', 'הְ', 'הֲ', 'הֱ', 'הֳ'],
    },
    en: {
      spellings: ['h'],
      syllables: ['ha', 'he', 'hi', 'ho', 'hu'],
    },
  },
  
  'j': {
    type: 'consonant',
    name: 'palatal approximant',
    he: {
      letters: [
        { letter: 'י', name: 'יוֹד' },
      ],
      syllables: ['יַ', 'יָ', 'יֶ', 'יֵ', 'יִ', 'יֹ', 'יֻ', 'יְ'],
    },
    en: {
      spellings: ['y'],
      syllables: ['ya', 'ye', 'yi', 'yo', 'yu'],
    },
  },
  
  'g': {
    type: 'consonant',
    name: 'voiced velar stop',
    he: {
      letters: [
        { letter: 'ג', name: 'גִּימֶל' },
      ],
      syllables: ['גַ', 'גָ', 'גֶ', 'גֵ', 'גִ', 'גֹ', 'גֻ', 'גְ'],
    },
    en: {
      spellings: ['g', 'gg', 'gh'],
      syllables: ['ga', 'ge', 'gi', 'go', 'gu'],
    },
  },
  
  'd': {
    type: 'consonant',
    name: 'voiced alveolar stop',
    he: {
      letters: [
        { letter: 'ד', name: 'דָּלֶת' },
      ],
      syllables: ['דַ', 'דָ', 'דֶ', 'דֵ', 'דִ', 'דֹ', 'דֻ', 'דְ'],
    },
    en: {
      spellings: ['d', 'dd', 'ed'],
      syllables: ['da', 'de', 'di', 'do', 'du'],
    },
  },
  
  'z': {
    type: 'consonant',
    name: 'voiced alveolar fricative',
    he: {
      letters: [
        { letter: 'ז', name: 'זַיִן' },
      ],
      syllables: ['זַ', 'זָ', 'זֶ', 'זֵ', 'זִ', 'זֹ', 'זֻ', 'זְ'],
    },
    en: {
      spellings: ['z', 'zz', 's', 'x'],
      syllables: ['za', 'ze', 'zi', 'zo', 'zu'],
    },
  },
  
  'f': {
    type: 'consonant',
    name: 'voiceless labiodental fricative',
    he: {
      letters: [
        { letter: 'פ', dagesh: false, name: 'פֵא רָפָה', final: 'ף' },
      ],
      syllables: ['פַ', 'פָ', 'פֶ', 'פֵ', 'פִ', 'פֹ', 'פֻ', 'פְ'],
    },
    en: {
      spellings: ['f', 'ff', 'ph', 'gh'],
      syllables: ['fa', 'fe', 'fi', 'fo', 'fu'],
    },
  },
  
  'p': {
    type: 'consonant',
    name: 'voiceless bilabial stop',
    he: {
      letters: [
        { letter: 'פּ', dagesh: true, name: 'פֵּא דְּגוּשָׁה' },
      ],
      syllables: ['פַּ', 'פָּ', 'פֶּ', 'פֵּ', 'פִּ', 'פֹּ', 'פֻּ', 'פְּ'],
    },
    en: {
      spellings: ['p', 'pp'],
      syllables: ['pa', 'pe', 'pi', 'po', 'pu'],
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API: Get all variations for an IPA sound
// ═══════════════════════════════════════════════════════════════════════════════

function getByIPA(ipa) {
  return IPA_UNIKEYS[ipa] || null;
}

function getAllSyllables(ipa, lang) {
  const data = IPA_UNIKEYS[ipa];
  if (!data) return [];
  
  if (lang === 'he') {
    // Collect all Hebrew syllables
    const syllables = [];
    if (data.he.syllables) syllables.push(...data.he.syllables);
    if (data.he.samech_syllables) syllables.push(...data.he.samech_syllables);
    if (data.he.sin_syllables) syllables.push(...data.he.sin_syllables);
    if (data.he.tav_syllables) syllables.push(...data.he.tav_syllables);
    if (data.he.tet_syllables) syllables.push(...data.he.tet_syllables);
    if (data.he.alef_syllables) syllables.push(...data.he.alef_syllables);
    if (data.he.ayin_syllables) syllables.push(...data.he.ayin_syllables);
    return syllables;
  }
  
  if (lang === 'en') {
    return data.en?.syllables || [];
  }
  
  return [];
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY V3 ARCHITECTURE');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('LAYOUT is DIFFERENT per language:');
console.log('  Physical key [a] → EN: "a" | HE: "ש"');
console.log('  Physical key [s] → EN: "s" | HE: "ד"');
console.log('  Physical key [h] → EN: "h" | HE: "י"\n');

console.log('IPA is the UNIQUE KEY that unifies:');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

const examples = ['s', 'ʃ', 'k', 'x', 't', 'b', 'v'];
examples.forEach(ipa => {
  const data = IPA_UNIKEYS[ipa];
  const heLetters = data.he.letters?.map(l => l.letter).join(', ') || '-';
  const enSpellings = data.en.spellings?.join(', ') || '-';
  console.log(`/${ipa}/ → HE: [${heLetters}] | EN: [${enSpellings}]`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA /s/ generates ARRAY of options in BOTH languages:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Hebrew ס (Samech):');
console.log('  ' + IPA_UNIKEYS['s'].he.samech_syllables.join(' '));
console.log('Hebrew שׂ (Sin):');
console.log('  ' + IPA_UNIKEYS['s'].he.sin_syllables.join(' '));
console.log('English:');
console.log('  ' + IPA_UNIKEYS['s'].en.syllables.join(' '));

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('Each letter gets its UNIQUE nikud options based on grammar rules:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Gutturals (א ה ח ע) get HATAF vowels:');
console.log('  ' + IPA_UNIKEYS['ʔ'].he.alef_syllables.join(' '));
console.log('Regular letters get standard nikud:');
console.log('  ' + IPA_UNIKEYS['m'].he.syllables.join(' '));
console.log('Shin שׁ (right dot) vs Sin שׂ (left dot):');
console.log('  שׁ → /ʃ/: ' + IPA_UNIKEYS['ʃ'].he.syllables.slice(0,4).join(' '));
console.log('  שׂ → /s/: ' + IPA_UNIKEYS['s'].he.sin_syllables.slice(0,4).join(' '));
