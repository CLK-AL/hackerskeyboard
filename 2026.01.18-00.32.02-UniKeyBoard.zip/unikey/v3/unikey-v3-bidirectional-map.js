// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - BIDIRECTIONAL IPA MAP (Data Layer)
// ═══════════════════════════════════════════════════════════════════════════════
//
// This is the DATA layer - separate from the graphic engine (HTML)
// Bidirectional: IPA ↔ Hebrew (nikud) ↔ English
//
// Hebrew also has diphthongs! (תנועות כפולות)
//
// ═══════════════════════════════════════════════════════════════════════════════

const UNIKEY_MAP = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VOWELS - Including Hebrew diphthongs!
  // ═══════════════════════════════════════════════════════════════════════════
  
  vowels: {
    
    // === PURE VOWELS (תנועות טהורות) ===
    
    'a': {
      ipa: 'a',
      type: 'pure',
      he: {
        chaser: 'ַ',
        male: null,
        name: 'פַּתַח',
      },
      en: {
        single: ['a'],
        combos: [],
        examples: ['cat', 'hat'],
      },
    },
    
    'ɑ': {
      ipa: 'ɑ',
      type: 'pure',
      he: {
        chaser: 'ָ',
        male: 'ָא',
        name: 'קָמָץ',
      },
      en: {
        single: ['a', 'o'],
        combos: ['ar', 'al'],
        examples: ['father', 'car'],
      },
    },
    
    'ɛ': {
      ipa: 'ɛ',
      type: 'pure',
      he: {
        chaser: 'ֶ',
        male: 'ֶא',
        name: 'סֶגוֹל',
      },
      en: {
        single: ['e'],
        combos: ['ea', 'ai'],
        examples: ['bed', 'bread'],
      },
    },
    
    'e': {
      ipa: 'e',
      type: 'pure',
      he: {
        chaser: 'ֵ',
        male: 'ֵא',
        name: 'צֵירֵי',
      },
      en: {
        single: [],
        combos: ['ay', 'ai', 'ei'],
        examples: ['day', 'rain'],
      },
    },
    
    'i': {
      ipa: 'i',
      type: 'pure',
      he: {
        chaser: 'ִ',
        male: 'ִי',
        name: 'חִירִיק',
      },
      en: {
        single: ['i', 'y'],
        combos: ['ee', 'ea', 'ie'],
        examples: ['see', 'sea'],
      },
    },
    
    'o': {
      ipa: 'o',
      type: 'pure',
      he: {
        chaser: 'ֹ',
        male: 'וֹ',
        name: 'חוֹלָם',
      },
      en: {
        single: ['o'],
        combos: ['oa', 'ow'],
        examples: ['go', 'boat'],
      },
    },
    
    'ɔ': {
      ipa: 'ɔ',
      type: 'pure',
      he: {
        chaser: 'ָ', // Same mark as kamatz!
        male: null,
        name: 'קָמָץ קָטָן',
      },
      en: {
        single: ['o'],
        combos: ['aw', 'au', 'al'],
        examples: ['saw', 'all'],
      },
    },
    
    'u': {
      ipa: 'u',
      type: 'pure',
      he: {
        chaser: 'ֻ',
        male: 'וּ',
        name: 'קֻבּוּץ / שׁוּרוּק',
      },
      en: {
        single: ['u'],
        combos: ['oo', 'ue', 'ew'],
        examples: ['moon', 'blue'],
      },
    },
    
    'ə': {
      ipa: 'ə',
      type: 'reduced',
      he: {
        chaser: 'ְ',
        male: null,
        name: 'שְׁוָא',
        variants: {
          na: { mark: 'ְ', voiced: true },
          nach: { mark: 'ְ', voiced: false },
        },
      },
      en: {
        single: ['a', 'e', 'i', 'o', 'u'],
        combos: [],
        examples: ['about', 'taken'],
      },
    },
    
    // === HATAF VOWELS (חטפים - גרוניות בלבד) ===
    
    'ă': {
      ipa: 'ă',
      type: 'hataf',
      he: {
        chaser: 'ֲ',
        male: null,
        name: 'חֲטַף פַּתַח',
        guttural_only: ['א', 'ה', 'ח', 'ע'],
      },
      en: {
        single: [],
        combos: [],
        examples: [],
      },
    },
    
    'ĕ': {
      ipa: 'ĕ',
      type: 'hataf',
      he: {
        chaser: 'ֱ',
        male: null,
        name: 'חֲטַף סֶגוֹל',
        guttural_only: ['א', 'ה', 'ח', 'ע'],
      },
      en: {
        single: [],
        combos: [],
        examples: [],
      },
    },
    
    'ŏ': {
      ipa: 'ŏ',
      type: 'hataf',
      he: {
        chaser: 'ֳ',
        male: null,
        name: 'חֲטַף קָמָץ',
        guttural_only: ['א', 'ה', 'ח', 'ע'],
      },
      en: {
        single: [],
        combos: [],
        examples: [],
      },
    },
    
    // === HEBREW DIPHTHONGS (תנועות כפולות עבריות) ===
    
    'aj': {
      ipa: 'aj',
      type: 'diphthong',
      he: {
        chaser: 'ַי',
        male: 'ַיְ',
        name: 'פַּתַח + יוֹד',
        examples: ['בַּיִת', 'עַיִן'],
      },
      en: {
        single: ['i', 'y'],
        combos: ['i_e', 'igh', 'ie'],
        examples: ['my', 'high'],
        maps_to: 'aɪ',
      },
    },
    
    'ej': {
      ipa: 'ej',
      type: 'diphthong',
      he: {
        chaser: 'ֵי',
        male: 'ֵיְ',
        name: 'צֵירֵי + יוֹד',
        examples: ['בֵּית', 'עֵינַיִם'],
      },
      en: {
        single: [],
        combos: ['ay', 'ei', 'ey'],
        examples: ['day', 'they'],
        maps_to: 'eɪ',
      },
    },
    
    'aw': {
      ipa: 'aw',
      type: 'diphthong',
      he: {
        chaser: 'ַו',
        male: 'ָו',
        name: 'פַּתַח/קָמָץ + וָו',
        examples: ['יָו', 'תָּו'],
      },
      en: {
        single: [],
        combos: ['ou', 'ow'],
        examples: ['out', 'now'],
        maps_to: 'aʊ',
      },
    },
    
    'oj': {
      ipa: 'oj',
      type: 'diphthong',
      he: {
        chaser: 'ֹי',
        male: 'וֹי',
        name: 'חוֹלָם + יוֹד',
        examples: ['גּוֹי', 'אוֹי'],
      },
      en: {
        single: [],
        combos: ['oi', 'oy'],
        examples: ['boy', 'oil'],
        maps_to: 'ɔɪ',
      },
    },
    
    'uj': {
      ipa: 'uj',
      type: 'diphthong',
      he: {
        chaser: 'וּי',
        male: null,
        name: 'שׁוּרוּק + יוֹד',
        examples: ['גּוּי'],
      },
      en: {
        single: [],
        combos: ['ooey', 'ui'],
        examples: ['gooey', 'ruin'],
      },
    },
    
    // === ENGLISH-ONLY DIPHTHONGS ===
    
    'eɪ': {
      ipa: 'eɪ',
      type: 'diphthong',
      he: {
        chaser: null,
        male: null,
        maps_to: 'ej', // Hebrew equivalent
      },
      en: {
        single: [],
        combos: ['a_e', 'ai', 'ay', 'ei', 'ey'],
        examples: ['make', 'rain', 'day'],
      },
    },
    
    'aɪ': {
      ipa: 'aɪ',
      type: 'diphthong',
      he: {
        chaser: null,
        male: null,
        maps_to: 'aj', // Hebrew equivalent
      },
      en: {
        single: ['i', 'y'],
        combos: ['i_e', 'igh', 'ie', 'uy'],
        examples: ['time', 'high', 'my'],
      },
    },
    
    'ɔɪ': {
      ipa: 'ɔɪ',
      type: 'diphthong',
      he: {
        chaser: null,
        male: null,
        maps_to: 'oj', // Hebrew equivalent
      },
      en: {
        single: [],
        combos: ['oi', 'oy'],
        examples: ['oil', 'boy'],
      },
    },
    
    'aʊ': {
      ipa: 'aʊ',
      type: 'diphthong',
      he: {
        chaser: null,
        male: null,
        maps_to: 'aw', // Hebrew equivalent
      },
      en: {
        single: [],
        combos: ['ou', 'ow'],
        examples: ['out', 'now'],
      },
    },
    
    'oʊ': {
      ipa: 'oʊ',
      type: 'diphthong',
      he: {
        chaser: null,
        male: null,
        note: 'Hebrew /o/ is pure, not diphthong',
      },
      en: {
        single: ['o'],
        combos: ['oa', 'ow', 'o_e'],
        examples: ['go', 'boat', 'home'],
      },
    },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS
  // ═══════════════════════════════════════════════════════════════════════════
  
  consonants: {
    'b':  { ipa: 'b',  he: { letters: ['בּ'], names: ['בֵּית'] }, en: { single: ['b'], combos: ['bb'] } },
    'v':  { ipa: 'v',  he: { letters: ['ב', 'ו'], names: ['בֵית', 'וָו'] }, en: { single: ['v'], combos: ['ve'] } },
    'g':  { ipa: 'g',  he: { letters: ['ג'], names: ['גִּימֶל'] }, en: { single: ['g'], combos: ['gg', 'gh'] } },
    'd':  { ipa: 'd',  he: { letters: ['ד'], names: ['דָּלֶת'] }, en: { single: ['d'], combos: ['dd', 'ed'] } },
    'h':  { ipa: 'h',  he: { letters: ['ה'], names: ['הֵא'] }, en: { single: ['h'], combos: [] } },
    'z':  { ipa: 'z',  he: { letters: ['ז'], names: ['זַיִן'] }, en: { single: ['z', 's'], combos: ['zz'] } },
    'x':  { ipa: 'x',  he: { letters: ['ח', 'כ'], names: ['חֵית', 'כָף'] }, en: { single: [], combos: ['ch', 'kh'] } },
    't':  { ipa: 't',  he: { letters: ['ת', 'ט'], names: ['תָּו', 'טֵית'] }, en: { single: ['t'], combos: ['tt', 'ed'] } },
    'j':  { ipa: 'j',  he: { letters: ['י'], names: ['יוֹד'] }, en: { single: ['y'], combos: [] } },
    'k':  { ipa: 'k',  he: { letters: ['כּ', 'ק'], names: ['כָּף', 'קוֹף'] }, en: { single: ['k', 'c'], combos: ['ck', 'ch', 'qu'] } },
    'l':  { ipa: 'l',  he: { letters: ['ל'], names: ['לָמֶד'] }, en: { single: ['l'], combos: ['ll'] } },
    'm':  { ipa: 'm',  he: { letters: ['מ', 'ם'], names: ['מֵם', 'מֵם סוֹפִית'] }, en: { single: ['m'], combos: ['mm'] } },
    'n':  { ipa: 'n',  he: { letters: ['נ', 'ן'], names: ['נוּן', 'נוּן סוֹפִית'] }, en: { single: ['n'], combos: ['nn', 'kn', 'gn'] } },
    's':  { ipa: 's',  he: { letters: ['ס', 'שׂ'], names: ['סָמֶךְ', 'שִׂין'] }, en: { single: ['s', 'c'], combos: ['ss', 'sc', 'ce'] } },
    'ʔ':  { ipa: 'ʔ',  he: { letters: ['א', 'ע'], names: ['אָלֶף', 'עַיִן'] }, en: { single: [], combos: [] } },
    'p':  { ipa: 'p',  he: { letters: ['פּ'], names: ['פֵּא'] }, en: { single: ['p'], combos: ['pp'] } },
    'f':  { ipa: 'f',  he: { letters: ['פ', 'ף'], names: ['פֵא', 'פֵא סוֹפִית'] }, en: { single: ['f'], combos: ['ff', 'ph', 'gh'] } },
    'ts': { ipa: 'ts', he: { letters: ['צ', 'ץ'], names: ['צָדִי', 'צָדִי סוֹפִית'] }, en: { single: [], combos: ['ts', 'tz', 'z'] } },
    'ʁ':  { ipa: 'ʁ',  he: { letters: ['ר'], names: ['רֵישׁ'] }, en: { single: ['r'], combos: ['rr', 'wr'] } },
    'ʃ':  { ipa: 'ʃ',  he: { letters: ['שׁ'], names: ['שִׁין'] }, en: { single: [], combos: ['sh', 'ti', 'ci', 'ssi'] } },
    
    // English-only
    'ð':  { ipa: 'ð',  he: { letters: [], names: [] }, en: { single: [], combos: ['th'] } },
    'θ':  { ipa: 'θ',  he: { letters: [], names: [] }, en: { single: [], combos: ['th'] } },
    'ŋ':  { ipa: 'ŋ',  he: { letters: [], names: [] }, en: { single: [], combos: ['ng', 'n'] } },
    'w':  { ipa: 'w',  he: { letters: ['ו'], names: ['וָו'] }, en: { single: ['w'], combos: ['wh'] } },
    'dʒ': { ipa: 'dʒ', he: { letters: ["ג'"], names: ["ג׳ימל"] }, en: { single: ['j'], combos: ['dge', 'ge'] } },
    'tʃ': { ipa: 'tʃ', he: { letters: ["צ'"], names: ["צ׳"] }, en: { single: [], combos: ['ch', 'tch'] } },
    'ʒ':  { ipa: 'ʒ',  he: { letters: ["ז'"], names: ["ז׳"] }, en: { single: [], combos: ['si', 'su'] } },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// REVERSE INDEXES - Bidirectional lookup
// ═══════════════════════════════════════════════════════════════════════════════

// Hebrew → IPA
const HE_TO_IPA = {};

// English → IPA
const EN_TO_IPA = {};

// Build reverse indexes
function buildIndexes() {
  // Vowels
  Object.entries(UNIKEY_MAP.vowels).forEach(([ipa, data]) => {
    // Hebrew
    if (data.he.chaser) {
      HE_TO_IPA[data.he.chaser] = ipa;
    }
    if (data.he.male) {
      HE_TO_IPA[data.he.male] = ipa;
    }
    
    // English
    if (data.en.single) {
      data.en.single.forEach(s => {
        if (!EN_TO_IPA[s]) EN_TO_IPA[s] = [];
        EN_TO_IPA[s].push(ipa);
      });
    }
    if (data.en.combos) {
      data.en.combos.forEach(c => {
        if (!EN_TO_IPA[c]) EN_TO_IPA[c] = [];
        EN_TO_IPA[c].push(ipa);
      });
    }
  });
  
  // Consonants
  Object.entries(UNIKEY_MAP.consonants).forEach(([ipa, data]) => {
    // Hebrew
    if (data.he.letters) {
      data.he.letters.forEach(l => {
        HE_TO_IPA[l] = ipa;
      });
    }
    
    // English
    if (data.en.single) {
      data.en.single.forEach(s => {
        if (!EN_TO_IPA[s]) EN_TO_IPA[s] = [];
        EN_TO_IPA[s].push(ipa);
      });
    }
    if (data.en.combos) {
      data.en.combos.forEach(c => {
        if (!EN_TO_IPA[c]) EN_TO_IPA[c] = [];
        EN_TO_IPA[c].push(ipa);
      });
    }
  });
}

buildIndexes();

// ═══════════════════════════════════════════════════════════════════════════════
// API Functions
// ═══════════════════════════════════════════════════════════════════════════════

// IPA → Hebrew
function ipaToHebrew(ipa, options = { male: false }) {
  const vowel = UNIKEY_MAP.vowels[ipa];
  if (vowel) {
    return options.male && vowel.he.male ? vowel.he.male : vowel.he.chaser;
  }
  
  const cons = UNIKEY_MAP.consonants[ipa];
  if (cons) {
    return cons.he.letters[0] || null;
  }
  
  return null;
}

// IPA → English
function ipaToEnglish(ipa, options = { preferCombo: false }) {
  const vowel = UNIKEY_MAP.vowels[ipa];
  if (vowel) {
    if (options.preferCombo && vowel.en.combos.length > 0) {
      return vowel.en.combos[0];
    }
    return vowel.en.single[0] || vowel.en.combos[0] || null;
  }
  
  const cons = UNIKEY_MAP.consonants[ipa];
  if (cons) {
    if (options.preferCombo && cons.en.combos.length > 0) {
      return cons.en.combos[0];
    }
    return cons.en.single[0] || cons.en.combos[0] || null;
  }
  
  return null;
}

// Hebrew → IPA
function hebrewToIPA(he) {
  return HE_TO_IPA[he] || null;
}

// English → IPA
function englishToIPA(en) {
  return EN_TO_IPA[en] || null;
}

// Get all options for IPA
function getAllOptions(ipa) {
  const vowel = UNIKEY_MAP.vowels[ipa];
  if (vowel) return vowel;
  
  const cons = UNIKEY_MAP.consonants[ipa];
  if (cons) return cons;
  
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('BIDIRECTIONAL IPA MAP - Data Layer (Separate from Graphic Engine)');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('HEBREW DIPHTHONGS (תנועות כפולות עבריות):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
const heDiphthongs = ['aj', 'ej', 'aw', 'oj', 'uj'];
heDiphthongs.forEach(ipa => {
  const d = UNIKEY_MAP.vowels[ipa];
  if (d) {
    const chaser = d.he.chaser || '-';
    const male = d.he.male || '-';
    const examples = d.he.examples?.join(', ') || '-';
    const enMaps = d.en.maps_to || d.en.combos?.join(', ') || '-';
    console.log(`/${ipa.padEnd(3)}/ ${d.he.name.padEnd(18)} ${chaser.padEnd(4)} ${male.padEnd(5)} examples: ${examples}`);
    console.log(`       → English equivalent: ${enMaps}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('BIDIRECTIONAL LOOKUP:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA → Hebrew:');
console.log(`  /a/  → ${ipaToHebrew('a')} (chaser) | ${ipaToHebrew('ɑ', {male: true})} (male)`);
console.log(`  /i/  → ${ipaToHebrew('i')} (chaser) | ${ipaToHebrew('i', {male: true})} (male)`);
console.log(`  /o/  → ${ipaToHebrew('o')} (chaser) | ${ipaToHebrew('o', {male: true})} (male)`);
console.log(`  /ʃ/  → ${ipaToHebrew('ʃ')}`);

console.log('\nIPA → English:');
console.log(`  /ʃ/  → ${ipaToEnglish('ʃ', {preferCombo: true})}`);
console.log(`  /s/  → ${ipaToEnglish('s')} | combos: ${UNIKEY_MAP.consonants['s'].en.combos.join(', ')}`);
console.log(`  /i/  → ${ipaToEnglish('i')} | combos: ${UNIKEY_MAP.vowels['i'].en.combos.join(', ')}`);

console.log('\nHebrew → IPA:');
console.log(`  ַ  → /${hebrewToIPA('ַ')}/`);
console.log(`  ָ  → /${hebrewToIPA('ָ')}/`);
console.log(`  שׁ → /${hebrewToIPA('שׁ')}/`);
console.log(`  ס  → /${hebrewToIPA('ס')}/`);

console.log('\nEnglish → IPA:');
console.log(`  sh → /${englishToIPA('sh')}/`);
console.log(`  s  → /${englishToIPA('s')}/`);
console.log(`  ee → /${englishToIPA('ee')}/`);

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('DIPHTHONG MAPPING:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Hebrew          IPA      English         IPA');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('ַי (בַּיִת)      /aj/  ↔  i_e, igh, y    /aɪ/');
console.log('ֵי (בֵּית)       /ej/  ↔  ay, ai, ey     /eɪ/');
console.log('ָו (תָּו)        /aw/  ↔  ou, ow         /aʊ/');
console.log('וֹי (גּוֹי)      /oj/  ↔  oi, oy         /ɔɪ/');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ARCHITECTURE:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────────────────────┐');
console.log('  │                                                                             │');
console.log('  │   DATA LAYER (This file - unikey-v3-bidirectional-map.js)                  │');
console.log('  │   ═══════════════════════════════════════════════════════════              │');
console.log('  │   • UNIKEY_MAP: All IPA → Hebrew/English mappings                          │');
console.log('  │   • HE_TO_IPA: Hebrew → IPA reverse index                                  │');
console.log('  │   • EN_TO_IPA: English → IPA reverse index                                 │');
console.log('  │   • API functions: ipaToHebrew(), ipaToEnglish(), etc.                     │');
console.log('  │                                                                             │');
console.log('  │                              ↕                                              │');
console.log('  │                                                                             │');
console.log('  │   GRAPHIC ENGINE (HTML file - unikeyboard.html)                            │');
console.log('  │   ═══════════════════════════════════════════════════════════              │');
console.log('  │   • Keyboard rendering                                                      │');
console.log('  │   • User interaction                                                        │');
console.log('  │   • Mode switching                                                          │');
console.log('  │   • Visual feedback                                                         │');
console.log('  │                                                                             │');
console.log('  └─────────────────────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('STATISTICS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const pureVowels = Object.values(UNIKEY_MAP.vowels).filter(v => v.type === 'pure').length;
const hatafVowels = Object.values(UNIKEY_MAP.vowels).filter(v => v.type === 'hataf').length;
const diphthongVowels = Object.values(UNIKEY_MAP.vowels).filter(v => v.type === 'diphthong').length;
const consonants = Object.keys(UNIKEY_MAP.consonants).length;

console.log(`Pure vowels:     ${pureVowels}`);
console.log(`Hataf vowels:    ${hatafVowels} (Hebrew gutturals only)`);
console.log(`Diphthongs:      ${diphthongVowels} (Hebrew + English)`);
console.log(`Consonants:      ${consonants}`);
console.log(`Total phonemes:  ${pureVowels + hatafVowels + diphthongVowels + consonants}`);
console.log(`Hebrew → IPA:    ${Object.keys(HE_TO_IPA).length} entries`);
console.log(`English → IPA:   ${Object.keys(EN_TO_IPA).length} entries`);

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    UNIKEY_MAP,
    HE_TO_IPA,
    EN_TO_IPA,
    ipaToHebrew,
    ipaToEnglish,
    hebrewToIPA,
    englishToIPA,
    getAllOptions,
  };
}
