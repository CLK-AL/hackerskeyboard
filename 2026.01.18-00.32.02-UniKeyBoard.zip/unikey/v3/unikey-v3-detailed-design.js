// ═══════════════════════════════════════════════════════════════════════════
//
//  ██╗   ██╗███╗   ██╗██╗██╗  ██╗███████╗██╗   ██╗    ██╗   ██╗██████╗ 
//  ██║   ██║████╗  ██║██║██║ ██╔╝██╔════╝╚██╗ ██╔╝    ██║   ██║╚════██╗
//  ██║   ██║██╔██╗ ██║██║█████╔╝ █████╗   ╚████╔╝     ██║   ██║ █████╔╝
//  ██║   ██║██║╚██╗██║██║██╔═██╗ ██╔══╝    ╚██╔╝      ╚██╗ ██╔╝ ╚═══██╗
//  ╚██████╔╝██║ ╚████║██║██║  ██╗███████╗   ██║        ╚████╔╝ ██████╔╝
//   ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝         ╚═══╝  ╚═════╝ 
//
//  DETAILED DESIGN DOCUMENT
//
// ═══════════════════════════════════════════════════════════════════════════

/*
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║  1. ARCHITECTURE OVERVIEW                                                     ║
║                                                                               ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║  ┌─────────────────────────────────────────────────────────────────────────┐  ║
║  │                         KEYBOARD LAYOUT                                 │  ║
║  │                    Map<PhysicalKey, UniKey>                             │  ║
║  └───────────────────────────────┬─────────────────────────────────────────┘  ║
║                                  │                                            ║
║                                  ▼                                            ║
║  ┌─────────────────────────────────────────────────────────────────────────┐  ║
║  │                            UNIKEY                                       │  ║
║  │            Physical Key → IPA Base + All Permutations                   │  ║
║  └───────────────────────────────┬─────────────────────────────────────────┘  ║
║                                  │                                            ║
║                    ┌─────────────┴─────────────┐                              ║
║                    ▼                           ▼                              ║
║  ┌────────────────────────────┐  ┌────────────────────────────┐              ║
║  │        IPA_KEY             │  │        MG_KEY              │              ║
║  │   Phonetic Interface       │  │   Semantic Interface       │              ║
║  │   /b/ /t/ /m/ /a/ /o/     │  │   poss, plural, pronoun    │              ║
║  └─────────────┬──────────────┘  └─────────────┬──────────────┘              ║
║                │                               │                              ║
║                └───────────────┬───────────────┘                              ║
║                                │                                              ║
║              ┌─────────────────┴─────────────────┐                            ║
║              ▼                                   ▼                            ║
║  ┌────────────────────────┐        ┌────────────────────────┐                ║
║  │    HEBREW IMPL         │        │    ENGLISH IMPL        │                ║
║  │    implements          │        │    implements          │                ║
║  │    IPA_Key, MG_Key     │        │    IPA_Key, MG_Key     │                ║
║  └────────────────────────┘        └────────────────────────┘                ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
*/

// ═══════════════════════════════════════════════════════════════════════════
// 2. INTERFACES
// ═══════════════════════════════════════════════════════════════════════════

/**
 * IPA_Key Interface
 * Defines phonetic mapping for a single IPA phoneme
 */
const IPA_Key = {
  // Required
  ipa: '',        // IPA symbol: '/b/', '/a/', '/ʃ/'
  
  // Language-specific implementations
  // Each language provides its own mapping
};

/**
 * MG_Key Interface  
 * Defines semantic gender pair mapping
 */
const MG_Key = {
  // Required
  semantic: '',   // Semantic role: 'poss-3s', 'plural', 'pronoun-3s'
  ipa_m: '',      // IPA for masculine form
  ipa_f: '',      // IPA for feminine form
  
  // Language-specific implementations provide actual forms
};

/**
 * LangImpl Interface
 * Language-specific implementation of a phoneme/syllable
 */
const LangImpl = {
  plain: '',      // Plain form (no diacritics)
  nikud: '',      // Decorated form (with diacritics) - optional
  final: '',      // Final form (for Hebrew ם ן ך ף ץ) - optional
};

/**
 * UniKey Interface
 * Complete key definition with all permutations
 */
const UniKey = {
  id: '',                 // Physical key identifier: 'B', 'M', '1'
  type: '',               // 'consonant' | 'vowel' | 'mg'
  base_ipa: '',           // Base IPA phoneme
  syllables: {},          // Map<IPA, {he: LangImpl, en: LangImpl}>
  mg: null,               // MG_Key if type === 'mg'
};

// ═══════════════════════════════════════════════════════════════════════════
// 3. IPA PHONEME INVENTORY
// ═══════════════════════════════════════════════════════════════════════════

const IPA = {
  
  // ─────────────────────────────────────────────────────────────────────────
  // VOWELS (12)
  // ─────────────────────────────────────────────────────────────────────────
  
  vowels: {
    'a':  { name: 'open front',      he: 'ַ',  he_name: 'patach',  en: 'a' },
    'ɑ':  { name: 'open back',       he: 'ָ',  he_name: 'kamatz',  en: 'a' },
    'e':  { name: 'mid front',       he: 'ֶ',  he_name: 'segol',   en: 'e' },
    'ɛ':  { name: 'open-mid front',  he: 'ֵ',  he_name: 'tzere',   en: 'e' },
    'i':  { name: 'close front',     he: 'ִ',  he_name: 'chirik',  en: 'i' },
    'o':  { name: 'mid back',        he: 'ֹ',  he_name: 'cholam',  en: 'o' },
    'u':  { name: 'close back',      he: 'ֻ',  he_name: 'kubutz',  en: 'u' },
    'ə':  { name: 'schwa',           he: 'ְ',  he_name: 'shva',    en: 'e' },
    'ɪ':  { name: 'near-close front',he: 'ִ',  he_name: 'chirik',  en: 'i' },
    'ʊ':  { name: 'near-close back', he: 'ֻ',  he_name: 'kubutz',  en: 'u' },
    'æ':  { name: 'near-open front', he: 'ַ',  he_name: 'patach',  en: 'a' },
    'ɔ':  { name: 'open-mid back',   he: 'ָ',  he_name: 'kamatz',  en: 'o' },
  },
  
  // ─────────────────────────────────────────────────────────────────────────
  // CONSONANTS (25)
  // ─────────────────────────────────────────────────────────────────────────
  
  consonants: {
    // Stops
    'b':  { name: 'voiced bilabial stop',     he: 'בּ', he_p: 'ב', en: 'b', he_final: null },
    'p':  { name: 'voiceless bilabial stop',  he: 'פּ', he_p: 'פ', en: 'p', he_final: 'ף' },
    'd':  { name: 'voiced alveolar stop',     he: 'ד',  he_p: 'ד', en: 'd', he_final: null },
    't':  { name: 'voiceless alveolar stop',  he: 'ת',  he_p: 'ת', en: 't', he_final: null },
    'g':  { name: 'voiced velar stop',        he: 'גּ', he_p: 'ג', en: 'g', he_final: null },
    'k':  { name: 'voiceless velar stop',     he: 'כּ', he_p: 'כ', en: 'k', he_final: 'ך' },
    'ʔ':  { name: 'glottal stop',             he: 'א',  he_p: 'א', en: "'", he_final: null },
    
    // Fricatives
    'v':  { name: 'voiced labiodental fric',  he: 'ב',  he_p: 'ב', en: 'v', he_final: null },
    'f':  { name: 'voiceless labiodental',    he: 'פ',  he_p: 'פ', en: 'f', he_final: 'ף' },
    'z':  { name: 'voiced alveolar fric',     he: 'ז',  he_p: 'ז', en: 'z', he_final: null },
    's':  { name: 'voiceless alveolar fric',  he: 'ס',  he_p: 'ס', en: 's', he_final: null },
    'ʃ':  { name: 'voiceless postalveolar',   he: 'שׁ', he_p: 'ש', en: 'sh', he_final: null },
    'ʒ':  { name: 'voiced postalveolar',      he: 'ז׳', he_p: 'ז', en: 'zh', he_final: null },
    'x':  { name: 'voiceless velar fric',     he: 'ח',  he_p: 'ח', en: 'ch', he_final: null },
    'χ':  { name: 'voiceless uvular fric',    he: 'כ',  he_p: 'כ', en: 'ch', he_final: 'ך' },
    'h':  { name: 'voiceless glottal fric',   he: 'ה',  he_p: 'ה', en: 'h', he_final: null },
    'ʕ':  { name: 'voiced pharyngeal fric',   he: 'ע',  he_p: 'ע', en: "'", he_final: null },
    
    // Sonorants
    'm':  { name: 'bilabial nasal',           he: 'מ',  he_p: 'מ', en: 'm', he_final: 'ם' },
    'n':  { name: 'alveolar nasal',           he: 'נ',  he_p: 'נ', en: 'n', he_final: 'ן' },
    'l':  { name: 'alveolar lateral',         he: 'ל',  he_p: 'ל', en: 'l', he_final: null },
    'r':  { name: 'alveolar trill',           he: 'ר',  he_p: 'ר', en: 'r', he_final: null },
    'j':  { name: 'palatal approximant',      he: 'י',  he_p: 'י', en: 'y', he_final: null },
    'w':  { name: 'labio-velar approximant',  he: 'ו',  he_p: 'ו', en: 'w', he_final: null },
    
    // Affricates
    'ts': { name: 'voiceless alveolar affr',  he: 'צ',  he_p: 'צ', en: 'ts', he_final: 'ץ' },
    'tʃ': { name: 'voiceless postalv affr',   he: 'צ׳', he_p: 'צ', en: 'ch', he_final: null },
    'dʒ': { name: 'voiced postalv affr',      he: 'ג׳', he_p: 'ג', en: 'j', he_final: null },
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// 4. MG SEMANTIC PAIRS (12)
// ═══════════════════════════════════════════════════════════════════════════

const MG_PAIRS = {
  
  // ─────────────────────────────────────────────────────────────────────────
  // Hebrew MG Pairs (12)
  // ─────────────────────────────────────────────────────────────────────────
  
  1: {
    semantic: 'poss-3s',
    he: { m: { p: 'ו', n: 'וֹ', ipa: 'o' },     f: { p: 'ה', n: 'ָהּ', ipa: 'a' } },
    en: { m: { p: 'his', ipa: 'hɪz' },          f: { p: 'her', ipa: 'hɜr' } },
  },
  
  2: {
    semantic: 'poss-3p',
    he: { m: { p: 'ם', n: 'ָם', ipa: 'am' },    f: { p: 'ן', n: 'ָן', ipa: 'an' } },
    en: { m: { p: 'their', ipa: 'ðɛr' },        f: { p: 'their', ipa: 'ðɛr' } },
  },
  
  3: {
    semantic: 'present',
    he: { m: { p: 'ד', n: 'ֵד', ipa: 'ed' },    f: { p: 'ת', n: 'ֶת', ipa: 'et' } },
    en: { m: { p: '-', ipa: '' },               f: { p: '-', ipa: '' } },
  },
  
  4: {
    semantic: 'future-prefix',
    he: { m: { p: 'י', n: 'יִ', ipa: 'ji' },    f: { p: 'ת', n: 'תִּ', ipa: 'ti' } },
    en: { m: { p: 'will', ipa: 'wɪl' },         f: { p: 'will', ipa: 'wɪl' } },
  },
  
  5: {
    semantic: 'plural',
    he: { m: { p: 'ים', n: 'ִים', ipa: 'im' },  f: { p: 'ות', n: 'וֹת', ipa: 'ot' } },
    en: { m: { p: 's', ipa: 'z' },              f: { p: 's', ipa: 'z' } },
  },
  
  6: {
    semantic: 'profession',
    he: { m: { p: 'ן', n: 'ָן', ipa: 'an' },    f: { p: 'נית', n: 'נִית', ipa: 'nit' } },
    en: { m: { p: 'or', ipa: 'ər' },            f: { p: 'ress', ipa: 'rəs' } },
  },
  
  7: {
    semantic: 'gentilic',
    he: { m: { p: 'י', n: 'ִי', ipa: 'i' },     f: { p: 'ית', n: 'ִית', ipa: 'it' } },
    en: { m: { p: 'n', ipa: 'n' },              f: { p: 'n', ipa: 'n' } },
  },
  
  8: {
    semantic: 'poss-3s-ext',
    he: { m: { p: 'יו', n: 'ָיו', ipa: 'av' },  f: { p: 'יה', n: 'ֶיהָ', ipa: 'eha' } },
    en: { m: { p: 'his', ipa: 'hɪz' },          f: { p: 'hers', ipa: 'hɜrz' } },
  },
  
  9: {
    semantic: 'poss-3p-ext',
    he: { m: { p: 'יהם', n: 'ֵיהֶם', ipa: 'ehem' }, f: { p: 'יהן', n: 'ֵיהֶן', ipa: 'ehen' } },
    en: { m: { p: 'theirs', ipa: 'ðɛrz' },      f: { p: 'theirs', ipa: 'ðɛrz' } },
  },
  
  10: {
    semantic: 'poss-2p',
    he: { m: { p: 'כם', n: 'כֶם', ipa: 'xem' }, f: { p: 'כן', n: 'כֶן', ipa: 'xen' } },
    en: { m: { p: 'your', ipa: 'jɔr' },         f: { p: 'your', ipa: 'jɔr' } },
  },
  
  11: {
    semantic: 'pronoun-3s',
    he: { m: { p: 'הוא', n: 'הוּא', ipa: 'hu' }, f: { p: 'היא', n: 'הִיא', ipa: 'hi' } },
    en: { m: { p: 'he', ipa: 'hi' },            f: { p: 'she', ipa: 'ʃi' } },
  },
  
  12: {
    semantic: 'pronoun-2s',
    he: { m: { p: 'אתה', n: 'אַתָּה', ipa: 'ata' }, f: { p: 'את', n: 'אַתְּ', ipa: 'at' } },
    en: { m: { p: 'you', ipa: 'ju' },           f: { p: 'you', ipa: 'ju' } },
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// 5. UNIKEY GENERATOR
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Generate all CV syllable permutations for a consonant
 */
function generateSyllables(consonant_ipa) {
  const c = IPA.consonants[consonant_ipa];
  if (!c) return null;
  
  const syllables = {};
  
  Object.entries(IPA.vowels).forEach(([v_ipa, v]) => {
    const syl_ipa = consonant_ipa + v_ipa;
    
    syllables[syl_ipa] = {
      ipa: syl_ipa,
      he: {
        plain: c.he_p,
        nikud: c.he + v.he,
        vowel: v.he_name,
      },
      en: {
        plain: c.en + v.en,
      },
    };
  });
  
  return syllables;
}

/**
 * Create a UniKey for a consonant
 */
function createConsonantUniKey(key_id, consonant_ipa) {
  const c = IPA.consonants[consonant_ipa];
  if (!c) return null;
  
  return {
    id: key_id,
    type: 'consonant',
    base_ipa: consonant_ipa,
    
    // Base consonant
    base: {
      he: { plain: c.he_p, nikud: c.he, final: c.he_final },
      en: { plain: c.en },
    },
    
    // All CV syllables
    syllables: generateSyllables(consonant_ipa),
    
    // Final form if exists
    final: c.he_final ? {
      he: { plain: c.he_final },
    } : null,
  };
}

/**
 * Create a UniKey for MG pair
 */
function createMGUniKey(key_id, mg_id) {
  const mg = MG_PAIRS[mg_id];
  if (!mg) return null;
  
  return {
    id: key_id,
    type: 'mg',
    semantic: mg.semantic,
    
    he: {
      m: mg.he.m,
      f: mg.he.f,
      plain: `${mg.he.m.p}/${mg.he.f.p}`,
      nikud: `${mg.he.m.n}/${mg.he.f.n}`,
    },
    
    en: {
      m: mg.en.m,
      f: mg.en.f,
      plain: `${mg.en.m.p}/${mg.en.f.p}`,
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// 6. KEYBOARD LAYOUT
// ═══════════════════════════════════════════════════════════════════════════

const KEYBOARD_LAYOUT = {
  
  // ─────────────────────────────────────────────────────────────────────────
  // Number Row: MG Pairs (1-12)
  // ─────────────────────────────────────────────────────────────────────────
  
  '1': createMGUniKey('1', 1),   // ו/ה - poss-3s
  '2': createMGUniKey('2', 2),   // ם/ן - poss-3p
  '3': createMGUniKey('3', 3),   // ד/ת - present
  '4': createMGUniKey('4', 4),   // י/ת - future
  '5': createMGUniKey('5', 5),   // ים/ות - plural
  '6': createMGUniKey('6', 6),   // ן/נית - profession
  '7': createMGUniKey('7', 7),   // י/ית - gentilic
  '8': createMGUniKey('8', 8),   // יו/יה - poss-3s-ext
  '9': createMGUniKey('9', 9),   // יהם/יהן - poss-3p-ext
  '0': createMGUniKey('0', 10),  // כם/כן - poss-2p
  '-': createMGUniKey('-', 11),  // הוא/היא - pronoun-3s
  '=': createMGUniKey('=', 12),  // אתה/את - pronoun-2s
  
  // ─────────────────────────────────────────────────────────────────────────
  // Top Row: Q W E R T Y U I O P
  // ─────────────────────────────────────────────────────────────────────────
  
  'Q': createConsonantUniKey('Q', 'k'),   // ק /k/
  'W': createConsonantUniKey('W', 'w'),   // ו /w/
  'E': { id: 'E', type: 'vowel', base_ipa: 'e', he: { plain: 'א', nikud: 'ֶ' }, en: { plain: 'e' } },
  'R': createConsonantUniKey('R', 'r'),   // ר /r/
  'T': createConsonantUniKey('T', 't'),   // ת /t/
  'Y': createConsonantUniKey('Y', 'j'),   // י /j/
  'U': { id: 'U', type: 'vowel', base_ipa: 'u', he: { plain: 'ו', nikud: 'ֻ' }, en: { plain: 'u' } },
  'I': { id: 'I', type: 'vowel', base_ipa: 'i', he: { plain: 'י', nikud: 'ִ' }, en: { plain: 'i' } },
  'O': { id: 'O', type: 'vowel', base_ipa: 'o', he: { plain: 'ו', nikud: 'ֹ' }, en: { plain: 'o' } },
  'P': createConsonantUniKey('P', 'p'),   // פ /p/
  
  // ─────────────────────────────────────────────────────────────────────────
  // Home Row: A S D F G H J K L
  // ─────────────────────────────────────────────────────────────────────────
  
  'A': { id: 'A', type: 'vowel', base_ipa: 'a', he: { plain: 'א', nikud: 'ַ' }, en: { plain: 'a' } },
  'S': createConsonantUniKey('S', 's'),   // ס /s/
  'D': createConsonantUniKey('D', 'd'),   // ד /d/
  'F': createConsonantUniKey('F', 'f'),   // פ /f/
  'G': createConsonantUniKey('G', 'g'),   // ג /g/
  'H': createConsonantUniKey('H', 'h'),   // ה /h/
  'J': createConsonantUniKey('J', 'j'),   // י /j/
  'K': createConsonantUniKey('K', 'k'),   // כ /k/
  'L': createConsonantUniKey('L', 'l'),   // ל /l/
  
  // ─────────────────────────────────────────────────────────────────────────
  // Bottom Row: Z X C V B N M
  // ─────────────────────────────────────────────────────────────────────────
  
  'Z': createConsonantUniKey('Z', 'z'),   // ז /z/
  'X': createConsonantUniKey('X', 'x'),   // ח /x/
  'C': createConsonantUniKey('C', 'ts'),  // צ /ts/
  'V': createConsonantUniKey('V', 'v'),   // ב /v/
  'B': createConsonantUniKey('B', 'b'),   // ב /b/
  'N': createConsonantUniKey('N', 'n'),   // נ /n/
  'M': createConsonantUniKey('M', 'm'),   // מ /m/
  
  // ─────────────────────────────────────────────────────────────────────────
  // Special Keys
  // ─────────────────────────────────────────────────────────────────────────
  
  '[': createConsonantUniKey('[', 'ʔ'),   // א (glottal)
  ']': createConsonantUniKey(']', 'ʕ'),   // ע (pharyngeal)
  ';': createConsonantUniKey(';', 'ʃ'),   // שׁ /ʃ/
  "'": createConsonantUniKey("'", 'χ'),   // כ /χ/
};

// ═══════════════════════════════════════════════════════════════════════════
// 7. UNIKEY API
// ═══════════════════════════════════════════════════════════════════════════

const UniKeyAPI = {
  
  /**
   * Get UniKey by physical key ID
   */
  getKey(keyId) {
    return KEYBOARD_LAYOUT[keyId.toUpperCase()] || null;
  },
  
  /**
   * Get output for key with modifiers
   */
  getOutput(keyId, lang = 'he', mods = {}) {
    const key = this.getKey(keyId);
    if (!key) return null;
    
    // MG key
    if (key.type === 'mg') {
      const langData = key[lang];
      if (mods.shift && mods.alt) {
        return langData.nikud || langData.plain;
      }
      if (mods.gender) {
        const g = langData[mods.gender];
        return mods.nikud ? g.n : g.p;
      }
      return langData.plain;
    }
    
    // Vowel key
    if (key.type === 'vowel') {
      return mods.nikud ? key[lang].nikud : key[lang].plain;
    }
    
    // Consonant key
    if (key.type === 'consonant') {
      // With vowel modifier → syllable
      if (mods.vowel && key.syllables) {
        const syl_ipa = key.base_ipa + mods.vowel;
        const syl = key.syllables[syl_ipa];
        if (syl) {
          return mods.nikud ? syl[lang].nikud : syl[lang].plain;
        }
      }
      // Final position
      if (mods.final && key.final) {
        return key.final[lang].plain;
      }
      // Base consonant
      return mods.nikud ? key.base[lang].nikud : key.base[lang].plain;
    }
    
    return null;
  },
  
  /**
   * Get IPA for key
   */
  getIPA(keyId) {
    const key = this.getKey(keyId);
    return key ? key.base_ipa : null;
  },
  
  /**
   * Get all syllables for consonant key
   */
  getSyllables(keyId) {
    const key = this.getKey(keyId);
    return (key && key.syllables) ? key.syllables : null;
  },
  
  /**
   * Get MG pair data
   */
  getMG(keyId, lang = 'he') {
    const key = this.getKey(keyId);
    if (key && key.type === 'mg') {
      return key[lang];
    }
    return null;
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// 8. OUTPUT & TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIKEY v3 - DETAILED DESIGN');
console.log('═══════════════════════════════════════════════════════════════\n');

// Stats
const consonants = Object.keys(KEYBOARD_LAYOUT).filter(k => KEYBOARD_LAYOUT[k]?.type === 'consonant').length;
const vowels = Object.keys(KEYBOARD_LAYOUT).filter(k => KEYBOARD_LAYOUT[k]?.type === 'vowel').length;
const mg_keys = Object.keys(KEYBOARD_LAYOUT).filter(k => KEYBOARD_LAYOUT[k]?.type === 'mg').length;

console.log('INVENTORY:');
console.log(`  IPA Vowels:      ${Object.keys(IPA.vowels).length}`);
console.log(`  IPA Consonants:  ${Object.keys(IPA.consonants).length}`);
console.log(`  MG Pairs:        ${Object.keys(MG_PAIRS).length}`);
console.log(`  UniKeys Total:   ${Object.keys(KEYBOARD_LAYOUT).length}`);
console.log(`    - Consonants:  ${consonants}`);
console.log(`    - Vowels:      ${vowels}`);
console.log(`    - MG Keys:     ${mg_keys}`);

console.log('\n───────────────────────────────────────────────────────────────');
console.log('KEYBOARD LAYOUT:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('MG Row (1-12):');
['1','2','3','4','5','6','7','8','9','0','-','='].forEach(k => {
  const key = KEYBOARD_LAYOUT[k];
  if (key) console.log(`  [${k}] ${key.he.plain.padEnd(10)} ${key.semantic}`);
});

console.log('\nLetter Rows:');
[
  ['Q','W','E','R','T','Y','U','I','O','P'],
  ['A','S','D','F','G','H','J','K','L'],
  ['Z','X','C','V','B','N','M'],
].forEach(row => {
  const line = row.map(k => {
    const key = KEYBOARD_LAYOUT[k];
    if (!key) return `[${k}]?`;
    const he = key.base?.he?.plain || key.he?.plain || '?';
    return `[${k}]${he}`;
  }).join(' ');
  console.log(`  ${line}`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('API EXAMPLES:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log("UniKeyAPI.getOutput('B', 'he'):", UniKeyAPI.getOutput('B', 'he'));
console.log("UniKeyAPI.getOutput('B', 'he', {nikud:true}):", UniKeyAPI.getOutput('B', 'he', {nikud:true}));
console.log("UniKeyAPI.getOutput('B', 'he', {vowel:'a'}):", UniKeyAPI.getOutput('B', 'he', {vowel:'a'}));
console.log("UniKeyAPI.getOutput('B', 'he', {vowel:'a',nikud:true}):", UniKeyAPI.getOutput('B', 'he', {vowel:'a',nikud:true}));
console.log("UniKeyAPI.getOutput('1', 'he'):", UniKeyAPI.getOutput('1', 'he'));
console.log("UniKeyAPI.getOutput('1', 'he', {gender:'m'}):", UniKeyAPI.getOutput('1', 'he', {gender:'m'}));
console.log("UniKeyAPI.getOutput('1', 'he', {gender:'f'}):", UniKeyAPI.getOutput('1', 'he', {gender:'f'}));
console.log("UniKeyAPI.getOutput('1', 'en'):", UniKeyAPI.getOutput('1', 'en'));

console.log('\n───────────────────────────────────────────────────────────────');
console.log('SYLLABLE EXAMPLE (B key):');
console.log('───────────────────────────────────────────────────────────────\n');

const bSyllables = UniKeyAPI.getSyllables('B');
if (bSyllables) {
  Object.entries(bSyllables).slice(0, 6).forEach(([ipa, syl]) => {
    console.log(`  /${ipa}/ → HE: ${syl.he.nikud} (${syl.he.vowel}) | EN: ${syl.en.plain}`);
  });
}

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('DESIGN COMPLETE');
console.log('═══════════════════════════════════════════════════════════════');
