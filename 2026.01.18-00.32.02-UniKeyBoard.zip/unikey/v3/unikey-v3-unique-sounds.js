// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - UNIQUE SOUNDS (צלילים ייחודיים)
// ═══════════════════════════════════════════════════════════════════════════════
//
// Sounds that exist in one language but NOT in the other
// Marked with GERESH (׳) to indicate foreign/unique sound
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW UNIQUE SOUNDS (צלילים עבריים ייחודיים)
// English approximations marked with '
// ═══════════════════════════════════════════════════════════════════════════════

const HE_UNIQUE = {
  'צ': {
    letter: 'צ',
    ipa: 'ts',
    name: 'צָדִי',
    en_approx: "ts'",
    examples: { he: ['צִפּוֹר', 'אֶרֶץ', 'צֶדֶק'], en: ["ts'ipor", "erets'", "ts'edek"] },
    note: 'Affricate /ts/ - exists in English "cats" but not as single letter',
    warning: "⚠️ Not like English 'z'!",
  },
  'ח': {
    letter: 'ח',
    ipa: 'x',  // or ħ classically
    name: 'חֵית',
    en_approx: "ch'",
    alt_approx: "kh'",
    examples: { he: ['חַיִים', 'לָחַם', 'רוּחַ'], en: ["ch'ayim", "lach'am", "ruach'"] },
    note: 'Voiceless pharyngeal/velar fricative - like German "Bach"',
    warning: "⚠️ NOT like English 'ch' in 'chair'!",
  },
  'כ': {  // כָף רְפוּיָה (without dagesh)
    letter: 'כ',
    ipa: 'x',
    name: 'כָף (רְפוּיָה)',
    en_approx: "kh'",
    examples: { he: ['מֶלֶךְ', 'בָּרוּךְ', 'לָכֶם'], en: ["melekh'", "barukh'", "lakhem"] },
    note: 'Same as ח in modern Hebrew',
    contrast: { 'כּ': { ipa: 'k', en: 'k', note: 'with dagesh = regular k' } },
  },
  'ע': {
    letter: 'ע',
    ipa: 'ʔ',  // or ʕ classically
    name: 'עַיִן',
    en_approx: "'",
    alt_approx: "a'",
    examples: { he: ['עַיִן', 'שָׁמַע', 'יָדַע'], en: ["'ayin", "shama'", "yada'"] },
    note: 'Glottal stop (modern) or voiced pharyngeal (classical)',
    warning: "⚠️ Often silent in casual speech, but distinct letter!",
  },
  'ר': {
    letter: 'ר',
    ipa: 'ʁ',  // or r
    name: 'רֵישׁ',
    en_approx: "r'",
    examples: { he: ['רֹאשׁ', 'דָּבָר', 'עִיר'], en: ["r'osh", "davar'", "ir'"] },
    note: 'Guttural/uvular R - NOT like English R!',
    warning: "⚠️ Hebrew ר is guttural, English R is alveolar!",
  },
  'ק': {
    letter: 'ק',
    ipa: 'k',  // or q classically
    name: 'קוֹף',
    en_approx: "k'",
    examples: { he: ['קוֹל', 'צֶדֶק', 'חָזָק'], en: ["k'ol", "tsedek'", "ch'azak'"] },
    note: 'Emphatic K (classical) - same as כּ in modern Hebrew',
    modern: 'בעברית מודרנית כמו כּ',
  },
  'ה': {  // ה with mappiq
    letter: 'הּ',
    ipa: 'h',
    name: 'הֵא (עם מַפִּיק)',
    en_approx: "h",
    examples: { he: ['גָּבֹהַּ', 'אֱלֹהַּ'], en: ["gavoh'", "eloah'"] },
    note: 'Final ה with mappiq is pronounced, not silent',
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ENGLISH UNIQUE SOUNDS (צלילים אנגליים ייחודיים)
// Hebrew approximations marked with ׳
// ═══════════════════════════════════════════════════════════════════════════════

const EN_UNIQUE = {
  'th_voiced': {
    letters: 'th',
    ipa: 'ð',
    name: 'Voiced TH',
    he_approx: 'ד׳',
    examples: { en: ['the', 'this', 'that', 'there', 'with'], he: ['ד׳ָה', 'ד׳ִיס', 'ד׳ֶט', 'ד׳ֶר', 'ווִיד׳'] },
    warning: '⚠️ לא קיים בעברית! ד׳ = קירוב בלבד',
  },
  'th_voiceless': {
    letters: 'th',
    ipa: 'θ',
    name: 'Voiceless TH',
    he_approx: 'ת׳',
    examples: { en: ['think', 'three', 'bath', 'path', 'with'], he: ['ת׳ִינק', 'ת׳רִי', 'בֶּת׳', 'פֶּת׳'] },
    warning: '⚠️ לא קיים בעברית! ת׳ = קירוב בלבד',
  },
  'w': {
    letters: 'w',
    ipa: 'w',
    name: 'W sound',
    he_approx: 'וו',
    alt_approx: 'ו׳',
    examples: { en: ['water', 'want', 'with', 'away'], he: ['ווֹטֶר', 'ווֹנט', 'ווִיד׳', 'אַווֵיי'] },
    note: 'Hebrew ו is /v/, English W is /w/',
    warning: '⚠️ W ≠ V! צליל שונה!',
  },
  'j': {  // as in "jam"
    letters: 'j',
    ipa: 'dʒ',
    name: 'J sound (jam)',
    he_approx: "ג׳",
    examples: { en: ['jam', 'job', 'judge', 'age'], he: ["ג׳ֶם", "ג׳וֹב", "ג׳אַד׳ג׳", "אֵייג׳"] },
    note: 'Affricate /dʒ/',
    warning: '⚠️ לא כמו י! ג׳ = קירוב',
  },
  'ch': {  // as in "chair"
    letters: 'ch',
    ipa: 'tʃ',
    name: 'CH sound (chair)',
    he_approx: "צ׳",
    examples: { en: ['chair', 'cheese', 'watch', 'match'], he: ["צ׳ֵיר", "צ׳ִיז", "ווֹצ׳", "מֶצ׳"] },
    note: 'Affricate /tʃ/',
    warning: '⚠️ לא כמו ח! צ׳ = קירוב',
  },
  'r': {
    letters: 'r',
    ipa: 'ɹ',
    name: 'English R',
    he_approx: 'ר׳',
    examples: { en: ['red', 'run', 'car', 'more'], he: ["ר׳ֶד", "ר׳אַן", "קָאר׳", "מוֹר׳"] },
    note: 'Alveolar approximant - tongue curls back',
    warning: '⚠️ שונה מ-ר עברית! ר׳ = קירוב',
  },
  'ng': {
    letters: 'ng',
    ipa: 'ŋ',
    name: 'NG sound',
    he_approx: 'נג',
    alt_approx: 'ŋ',
    examples: { en: ['sing', 'ring', 'long', 'thing'], he: ['סִינג', 'ר׳ִינג', 'לוֹנג', 'ת׳ִינג'] },
    note: 'Velar nasal - single sound, not n+g',
    warning: '⚠️ צליל אחד, לא נ+ג!',
  },
  'short_vowels': {
    'æ': { he_approx: 'ֶ/ַ', examples: ['cat→קֶט', 'bat→בֶּט'], warning: '⚠️ קירוב!' },
    'ʌ': { he_approx: 'ַ', examples: ['cup→קַפּ', 'but→בַּט'], warning: '⚠️ קירוב!' },
    'ɒ': { he_approx: 'ָ/ֹ', examples: ['hot→הָט', 'lot→לָט'], warning: '⚠️ קירוב!' },
    'ɪ': { he_approx: 'ִ', examples: ['sit→סִיט', 'bit→בִּיט'], warning: '⚠️ קירוב!' },
    'ʊ': { he_approx: 'ֻ', examples: ['book→בּוּק', 'put→פּוּט'], warning: '⚠️ קירוב!' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// GERESH USAGE SUMMARY
// ═══════════════════════════════════════════════════════════════════════════════

const GERESH_MAP = {
  // Hebrew → English (Hebrew sounds need ' in English)
  he_to_en: {
    'צ': "ts'",
    'ח': "ch'",
    'כ': "kh'",
    'ע': "'",
    'ר': "r'",
    'ק': "k'",
  },
  // English → Hebrew (English sounds need ׳ in Hebrew)
  en_to_he: {
    'th (ð)': 'ד׳',
    'th (θ)': 'ת׳',
    'j': 'ג׳',
    'ch': 'צ׳',
    'w': 'ו׳',
    'r': 'ר׳',
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIQUE SOUNDS - צלילים ייחודיים');
console.log('Marked with GERESH (׳) to indicate foreign/approximated sound');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('HEBREW → ENGLISH (צלילים עבריים ייחודיים):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('Letter   IPA    English    Examples                     Note');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
Object.values(HE_UNIQUE).forEach(s => {
  const approx = s.en_approx.padEnd(10);
  const ex = s.examples.he.slice(0, 2).join(', ').padEnd(28);
  console.log(`  ${s.letter}      /${s.ipa}/    ${approx} ${ex} ${s.warning || ''}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ENGLISH → HEBREW (צלילים אנגליים ייחודיים):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('Letters  IPA    Hebrew     Examples                     Note');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

const enSounds = ['th_voiced', 'th_voiceless', 'w', 'j', 'ch', 'r', 'ng'];
enSounds.forEach(key => {
  const s = EN_UNIQUE[key];
  const letters = s.letters.padEnd(8);
  const approx = s.he_approx.padEnd(10);
  const ex = s.examples.en.slice(0, 3).join(', ').padEnd(28);
  console.log(`  ${letters} /${s.ipa}/    ${approx} ${ex}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('GERESH QUICK REFERENCE:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Hebrew sounds in English transcription (add \'):');
console.log('  צ → ts\'    ציפור → ts\'ipor');
console.log('  ח → ch\'    חיים → ch\'ayim');
console.log('  כ → kh\'    מלך → melekh\'');
console.log('  ע → \'      עין → \'ayin');
console.log('  ר → r\'     ראש → r\'osh (guttural R)');
console.log('  ק → k\'     קול → k\'ol');

console.log('\nEnglish sounds in Hebrew transcription (add ׳):');
console.log('  th /ð/ → ד׳    the → ד׳ָה');
console.log('  th /θ/ → ת׳    think → ת׳ִינק');
console.log('  j      → ג׳    jam → ג׳ֶם');
console.log('  ch     → צ׳    chair → צ׳ֵיר');
console.log('  w      → ו׳/וו  water → ווֹטֶר');
console.log('  r      → ר׳    red → ר׳ֶד (alveolar R)');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('TRANSCRIPTION EXAMPLES:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const examples = [
  { he: 'צִפּוֹר', en: "ts'ipor", note: 'צ = ts\'' },
  { he: 'חַיִים', en: "ch'ayim", note: 'ח = ch\'' },
  { he: 'מֶלֶךְ', en: "melekh'", note: 'ך = kh\'' },
  { he: 'עַיִן', en: "'ayin", note: 'ע = \'' },
  { he: 'רֹאשׁ', en: "r'osh", note: 'ר = r\' (guttural)' },
  { en: 'the', he: 'ד׳ָה', note: 'th /ð/ = ד׳' },
  { en: 'think', he: 'ת׳ִינק', note: 'th /θ/ = ת׳' },
  { en: 'jam', he: 'ג׳ֶם', note: 'j = ג׳' },
  { en: 'chair', he: 'צ׳ֵיר', note: 'ch = צ׳' },
  { en: 'water', he: 'ווֹטֶר', note: 'w = וו' },
];

console.log('Hebrew → English:');
examples.filter(e => e.he && !e.en.startsWith('ד')).slice(0, 5).forEach(e => {
  console.log(`  ${e.he.padEnd(10)} → ${e.en.padEnd(12)} (${e.note})`);
});

console.log('\nEnglish → Hebrew:');
examples.filter(e => e.en && e.he.includes('׳') || e.he.includes('וו')).forEach(e => {
  console.log(`  ${e.en.padEnd(10)} → ${e.he.padEnd(12)} (${e.note})`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SUMMARY TABLE:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log(`
┌──────────────────────────────────────────────────────────────────────────────────┐
│  HEBREW UNIQUE → ENGLISH (mark with ')                                          │
│  ══════════════════════════════════════                                         │
│  צ /ts/  → ts'     צִפּוֹר → ts'ipor                                              │
│  ח /x/   → ch'     חַיִים → ch'ayim     ⚠️ NOT like English "ch"!               │
│  כ /x/   → kh'     מֶלֶךְ → melekh'                                               │
│  ע /ʔ/   → '       עַיִן → 'ayin                                                 │
│  ר /ʁ/   → r'      רֹאשׁ → r'osh        ⚠️ Guttural R, not English R!           │
│  ק /k/   → k'      קוֹל → k'ol          (emphatic K)                            │
│                                                                                  │
│  ENGLISH UNIQUE → HEBREW (mark with ׳)                                          │
│  ══════════════════════════════════════                                         │
│  th /ð/  → ד׳      the → ד׳ָה           ⚠️ NO Hebrew equivalent!                │
│  th /θ/  → ת׳      think → ת׳ִינק       ⚠️ NO Hebrew equivalent!                │
│  j /dʒ/  → ג׳      jam → ג׳ֶם           ⚠️ NOT like Hebrew י!                   │
│  ch /tʃ/ → צ׳      chair → צ׳ֵיר        ⚠️ NOT like Hebrew ח!                   │
│  w /w/   → ו׳/וו   water → ווֹטֶר       ⚠️ W ≠ V!                               │
│  r /ɹ/   → ר׳      red → ר׳ֶד           ⚠️ Alveolar R, not Hebrew R!            │
│  ng /ŋ/  → נג      sing → סִינג         (velar nasal)                           │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
`);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { HE_UNIQUE, EN_UNIQUE, GERESH_MAP };
}
