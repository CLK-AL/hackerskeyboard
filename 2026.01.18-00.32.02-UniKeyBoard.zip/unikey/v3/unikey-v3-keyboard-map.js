// ═══════════════════════════════════════════════════════════════════════════════
// KEYBOARD_MAP - Complete with EN and HE IPA
// ═══════════════════════════════════════════════════════════════════════════════
// Each key has:
//   en: English letter
//   en_ipa: IPA of English letter sound
//   he: Hebrew letter (Israeli standard layout)
//   he_ipa: IPA of Hebrew letter sound
//   opts: special handling (dagesh, guttural, final, shin/sin)

const KEYBOARD_MAP = {
  // ═══════════════════════════════════════════════════════════════════════════
  // ROW 1: QWERTYUIOP
  // ═══════════════════════════════════════════════════════════════════════════
  'q': { en: 'q', en_ipa: 'kw', he: '/',  he_ipa: null,  opts: {} },
  'w': { en: 'w', en_ipa: 'w',  he: "'",  he_ipa: null,  opts: {} },
  'e': { en: 'e', en_ipa: 'ɛ',  he: 'ק',  he_ipa: 'k',   opts: {} },
  'r': { en: 'r', en_ipa: 'ɹ',  he: 'ר',  he_ipa: 'ʁ',   opts: {} },
  't': { en: 't', en_ipa: 't',  he: 'א',  he_ipa: 'ʔ',   opts: { guttural: true } },
  'y': { en: 'y', en_ipa: 'j',  he: 'ט',  he_ipa: 't',   opts: {} },
  'u': { en: 'u', en_ipa: 'ʌ',  he: 'ו',  he_ipa: 'v',   opts: {} },
  'i': { en: 'i', en_ipa: 'ɪ',  he: 'ן',  he_ipa: 'n',   opts: { final: true } },
  'o': { en: 'o', en_ipa: 'oʊ', he: 'ם',  he_ipa: 'm',   opts: { final: true } },
  'p': { en: 'p', en_ipa: 'p',  he: 'פ',  he_ipa: 'f',   opts: { dagesh: 'p' } },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // ROW 2: ASDFGHJKL
  // ═══════════════════════════════════════════════════════════════════════════
  'a': { en: 'a', en_ipa: 'æ',  he: 'ש',  he_ipa: 'ʃ',   opts: { shin: true } }, // שׁ/שׂ
  's': { en: 's', en_ipa: 's',  he: 'ד',  he_ipa: 'd',   opts: {} },
  'd': { en: 'd', en_ipa: 'd',  he: 'ג',  he_ipa: 'g',   opts: {} },
  'f': { en: 'f', en_ipa: 'f',  he: 'כ',  he_ipa: 'x',   opts: { dagesh: 'k' } },
  'g': { en: 'g', en_ipa: 'g',  he: 'ע',  he_ipa: 'ʕ',   opts: { guttural: true } },
  'h': { en: 'h', en_ipa: 'h',  he: 'י',  he_ipa: 'j',   opts: {} },
  'j': { en: 'j', en_ipa: 'dʒ', he: 'ח',  he_ipa: 'ħ',   opts: { guttural: true } },
  'k': { en: 'k', en_ipa: 'k',  he: 'ל',  he_ipa: 'l',   opts: {} },
  'l': { en: 'l', en_ipa: 'l',  he: 'ך',  he_ipa: 'x',   opts: { final: true } },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // ROW 3: ZXCVBNM
  // ═══════════════════════════════════════════════════════════════════════════
  'z': { en: 'z', en_ipa: 'z',  he: 'ז',  he_ipa: 'z',   opts: {} },
  'x': { en: 'x', en_ipa: 'ks', he: 'ס',  he_ipa: 's',   opts: {} },
  'c': { en: 'c', en_ipa: 'k',  he: 'ב',  he_ipa: 'v',   opts: { dagesh: 'b' } },
  'v': { en: 'v', en_ipa: 'v',  he: 'ה',  he_ipa: 'h',   opts: { guttural: true } },
  'b': { en: 'b', en_ipa: 'b',  he: 'נ',  he_ipa: 'n',   opts: {} },
  'n': { en: 'n', en_ipa: 'n',  he: 'מ',  he_ipa: 'm',   opts: {} },
  'm': { en: 'm', en_ipa: 'm',  he: 'צ',  he_ipa: 'ts',  opts: {} },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // PUNCTUATION
  // ═══════════════════════════════════════════════════════════════════════════
  ';': { en: ';', en_ipa: null, he: 'ף',  he_ipa: 'f',   opts: { final: true } },
  ',': { en: ',', en_ipa: null, he: 'ת',  he_ipa: 't',   opts: {} },
  '.': { en: '.', en_ipa: null, he: 'ץ',  he_ipa: 'ts',  opts: { final: true } },
  '/': { en: '/', en_ipa: null, he: '.',  he_ipa: null,  opts: {} },
  "'": { en: "'", en_ipa: null, he: ',',  he_ipa: null,  opts: {} },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // NUMBER ROW (for MG keys in v3)
  // ═══════════════════════════════════════════════════════════════════════════
  '1': { en: '1', en_ipa: null, he: '1',  he_ipa: null,  mg: 'ו/ה',     mg_sem: 'poss-3s' },
  '2': { en: '2', en_ipa: null, he: '2',  he_ipa: null,  mg: 'יו/יה',   mg_sem: 'poss-3s-ext' },
  '3': { en: '3', en_ipa: null, he: '3',  he_ipa: null,  mg: 'ם/ן',     mg_sem: 'poss-3p' },
  '4': { en: '4', en_ipa: null, he: '4',  he_ipa: null,  mg: 'הם/הן',   mg_sem: 'pronoun-3p' },
  '5': { en: '5', en_ipa: null, he: '5',  he_ipa: null,  mg: 'ד/ת',     mg_sem: 'present' },
  '6': { en: '6', en_ipa: null, he: '6',  he_ipa: null,  mg: 'ים/ות',   mg_sem: 'plural' },
  '7': { en: '7', en_ipa: null, he: '7',  he_ipa: null,  mg: 'י/ית',    mg_sem: 'gentilic' },
  '8': { en: '8', en_ipa: null, he: '8',  he_ipa: null,  mg: 'ן/ת',     mg_sem: 'adj' },
  '9': { en: '9', en_ipa: null, he: '9',  he_ipa: null,  mg: 'ן/נה',    mg_sem: 'prof' },
  '0': { en: '0', en_ipa: null, he: '0',  he_ipa: null,  mg: 'כם/כן',   mg_sem: 'poss-2p' },
  '-': { en: '-', en_ipa: null, he: '-',  he_ipa: null,  mg: 'יהם/יהן', mg_sem: 'poss-3p-ext' },
  '=': { en: '=', en_ipa: null, he: '=',  he_ipa: null,  mg: 'יש/ישה',  mg_sem: 'person' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// IPA MAPPING TABLES
// ═══════════════════════════════════════════════════════════════════════════════

// English consonant IPA (standard American)
const EN_CONSONANT_IPA = {
  'b': 'b', 'c': 'k', 'd': 'd', 'f': 'f', 'g': 'g', 'h': 'h',
  'j': 'dʒ', 'k': 'k', 'l': 'l', 'm': 'm', 'n': 'n', 'p': 'p',
  'q': 'kw', 'r': 'ɹ', 's': 's', 't': 't', 'v': 'v', 'w': 'w',
  'x': 'ks', 'y': 'j', 'z': 'z',
};

// English vowel IPA (multiple possible)
const EN_VOWEL_IPA = {
  'a': ['æ', 'eɪ', 'ɑ'],   // cat, make, father
  'e': ['ɛ', 'i'],         // bed, be
  'i': ['ɪ', 'aɪ'],        // sit, time
  'o': ['ɒ', 'oʊ'],        // hot, go
  'u': ['ʌ', 'u', 'ju'],   // cup, blue, use
};

// Hebrew consonant IPA
const HE_CONSONANT_IPA = {
  'א': 'ʔ', 'ב': 'v', 'בּ': 'b', 'ג': 'g', 'גּ': 'g', 'ד': 'd',
  'ה': 'h', 'ו': 'v', 'ז': 'z', 'ח': 'ħ', 'ט': 't', 'י': 'j',
  'כ': 'x', 'כּ': 'k', 'ך': 'x', 'ל': 'l', 'מ': 'm', 'ם': 'm',
  'נ': 'n', 'ן': 'n', 'ס': 's', 'ע': 'ʕ', 'פ': 'f', 'פּ': 'p',
  'ף': 'f', 'צ': 'ts', 'ץ': 'ts', 'ק': 'k', 'ר': 'ʁ',
  'שׁ': 'ʃ', 'שׂ': 's', 'ש': 'ʃ', 'ת': 't',
};

// Hebrew vowel IPA (nikud)
const HE_VOWEL_IPA = {
  'ַ': 'a',   // patach
  'ָ': 'ɑ',   // kamatz
  'ֶ': 'ɛ',   // segol
  'ֵ': 'e',   // tzere
  'ִ': 'i',   // chirik
  'ֹ': 'o',   // cholam
  'ֻ': 'u',   // kubutz
  'ְ': 'ə',   // shva
  'ֲ': 'a',   // hataf patach
  'ֱ': 'ɛ',   // hataf segol
  'ֳ': 'o',   // hataf kamatz
  'וֹ': 'o',  // cholam male
  'וּ': 'u',  // shuruk
  'ִי': 'i',  // chirik male
  'ֵי': 'ej', // tzere male
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('KEYBOARD_MAP with EN and HE IPA');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('Letter Keys:');
console.log('─────────────────────────────────────────────────────────────────');
console.log('Key  EN   EN_IPA   HE   HE_IPA   Opts');
console.log('─────────────────────────────────────────────────────────────────');

const letterKeys = 'qwertyuiopasdfghjklzxcvbnm'.split('');
letterKeys.forEach(k => {
  const m = KEYBOARD_MAP[k];
  if (m) {
    const opts = Object.keys(m.opts).filter(o => m.opts[o]).join(',') || '-';
    console.log(`[${k}]  ${m.en.padEnd(2)}   ${(m.en_ipa||'-').padEnd(4)}     ${m.he}    ${(m.he_ipa||'-').padEnd(4)}     ${opts}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('MG Keys (Number Row):');
console.log('═══════════════════════════════════════════════════════════════\n');

'1234567890-='.split('').forEach(k => {
  const m = KEYBOARD_MAP[k];
  if (m && m.mg) {
    console.log(`[${k}]  ${m.mg.padEnd(10)}  ${m.mg_sem}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('IPA Summary:');
console.log('═══════════════════════════════════════════════════════════════');
console.log(`EN Consonants: ${Object.keys(EN_CONSONANT_IPA).length}`);
console.log(`EN Vowels:     ${Object.keys(EN_VOWEL_IPA).length} (with variants)`);
console.log(`HE Consonants: ${Object.keys(HE_CONSONANT_IPA).length}`);
console.log(`HE Vowels:     ${Object.keys(HE_VOWEL_IPA).length}`);
