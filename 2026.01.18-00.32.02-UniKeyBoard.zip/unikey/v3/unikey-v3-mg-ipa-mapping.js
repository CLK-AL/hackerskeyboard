// ═══════════════════════════════════════════════════════════════════════════════
// MG KEYS - Mapped by IPA of each pair value
// ═══════════════════════════════════════════════════════════════════════════════
//
// Each MG pair has TWO values (m/f), each with its own IPA
// The pair can be accessed in EITHER order (m/f or f/m)
// IPA creates bidirectional mapping to letters
//
// ═══════════════════════════════════════════════════════════════════════════════

const MG_PAIRS = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 1: ו/ה - POSS_3S (his/her)
  // ═══════════════════════════════════════════════════════════════════════════
  '1': {
    semantic: 'POSS_3S',
    he: {
      m: { text: 'ו', nikud: 'וֹ', ipa: 'o' },
      f: { text: 'ה', nikud: 'הּ', ipa: 'a' },
    },
    en: {
      m: { text: 'his', ipa: 'hɪz' },
      f: { text: 'her', ipa: 'hɜr' },
    },
    // IPA mapping: o→m, a→f
    ipa_map: { 'o': 'm', 'a': 'f' },
    // Reverse pair order available
    orders: ['m/f', 'f/m'], // ו/ה or ה/ו
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 2: יו/יה - POSS_3S_EXT
  // ═══════════════════════════════════════════════════════════════════════════
  '2': {
    semantic: 'POSS_3S_EXT',
    he: {
      m: { text: 'יו', nikud: 'ָיו', ipa: 'av' },
      f: { text: 'יה', nikud: 'ֶיהָ', ipa: 'eha' },
    },
    en: {
      m: { text: 'his', ipa: 'hɪz' },
      f: { text: 'hers', ipa: 'hɜrz' },
    },
    ipa_map: { 'av': 'm', 'eha': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 3: ם/ן - POSS_3P
  // ═══════════════════════════════════════════════════════════════════════════
  '3': {
    semantic: 'POSS_3P',
    he: {
      m: { text: 'ם', nikud: 'ָם', ipa: 'am' },
      f: { text: 'ן', nikud: 'ָן', ipa: 'an' },
    },
    en: {
      m: { text: 'their', ipa: 'ðɛr' },
      f: { text: 'their', ipa: 'ðɛr' },
    },
    ipa_map: { 'am': 'm', 'an': 'f' },
    orders: ['m/f', 'f/m'], // ם/ן or ן/ם
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 4: הם/הן - PRONOUN_3P
  // ═══════════════════════════════════════════════════════════════════════════
  '4': {
    semantic: 'PRONOUN_3P',
    he: {
      m: { text: 'הם', nikud: 'הֵם', ipa: 'hem' },
      f: { text: 'הן', nikud: 'הֵן', ipa: 'hen' },
    },
    en: {
      m: { text: 'they', ipa: 'ðeɪ' },
      f: { text: 'they', ipa: 'ðeɪ' },
    },
    ipa_map: { 'hem': 'm', 'hen': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 5: ד/ת - VERB_PRESENT
  // ═══════════════════════════════════════════════════════════════════════════
  '5': {
    semantic: 'VERB_PRESENT',
    he: {
      m: { text: 'ד', nikud: 'ֵד', ipa: 'ed' },
      f: { text: 'ת', nikud: 'ֶת', ipa: 'et' },
    },
    en: {
      m: { text: '-s', ipa: 'z' },
      f: { text: '-s', ipa: 'z' },
    },
    ipa_map: { 'ed': 'm', 'et': 'f' },
    orders: ['m/f', 'f/m'], // ד/ת or ת/ד
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 6: ים/ות - PLURAL
  // ═══════════════════════════════════════════════════════════════════════════
  '6': {
    semantic: 'PLURAL',
    he: {
      m: { text: 'ים', nikud: 'ִים', ipa: 'im' },
      f: { text: 'ות', nikud: 'וֹת', ipa: 'ot' },
    },
    en: {
      m: { text: '-s', ipa: 'z' },
      f: { text: '-s', ipa: 'z' },
    },
    ipa_map: { 'im': 'm', 'ot': 'f' },
    orders: ['m/f', 'f/m'], // ים/ות or ות/ים
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 7: י/ית - GENTILIC
  // ═══════════════════════════════════════════════════════════════════════════
  '7': {
    semantic: 'GENTILIC',
    he: {
      m: { text: 'י', nikud: 'ִי', ipa: 'i' },
      f: { text: 'ית', nikud: 'ִית', ipa: 'it' },
    },
    en: {
      m: { text: '-n', ipa: 'n' },
      f: { text: '-n', ipa: 'n' },
    },
    ipa_map: { 'i': 'm', 'it': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 8: ן/נית - ADJECTIVE
  // ═══════════════════════════════════════════════════════════════════════════
  '8': {
    semantic: 'ADJECTIVE',
    he: {
      m: { text: 'ן', nikud: 'ָן', ipa: 'an' },
      f: { text: 'נית', nikud: 'ָנִית', ipa: 'anit' },
    },
    en: {
      m: { text: '-er', ipa: 'ər' },
      f: { text: '-ess', ipa: 'əs' },
    },
    ipa_map: { 'an': 'm', 'anit': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 9: אי/אית - PROFESSION
  // ═══════════════════════════════════════════════════════════════════════════
  '9': {
    semantic: 'PROFESSION',
    he: {
      m: { text: 'אי', nikud: 'אִי', ipa: 'ai' },
      f: { text: 'אית', nikud: 'אִית', ipa: 'ait' },
    },
    en: {
      m: { text: '-or', ipa: 'ər' },
      f: { text: '-ress', ipa: 'rəs' },
    },
    ipa_map: { 'ai': 'm', 'ait': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY 0: כם/כן - POSS_2P
  // ═══════════════════════════════════════════════════════════════════════════
  '0': {
    semantic: 'POSS_2P',
    he: {
      m: { text: 'כם', nikud: 'כֶם', ipa: 'xem' },
      f: { text: 'כן', nikud: 'כֶן', ipa: 'xen' },
    },
    en: {
      m: { text: 'your', ipa: 'jɔr' },
      f: { text: 'your', ipa: 'jɔr' },
    },
    ipa_map: { 'xem': 'm', 'xen': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY -: יהם/יהן - POSS_3P_EXT
  // ═══════════════════════════════════════════════════════════════════════════
  '-': {
    semantic: 'POSS_3P_EXT',
    he: {
      m: { text: 'יהם', nikud: 'ֵיהֶם', ipa: 'ehem' },
      f: { text: 'יהן', nikud: 'ֵיהֶן', ipa: 'ehen' },
    },
    en: {
      m: { text: 'theirs', ipa: 'ðɛrz' },
      f: { text: 'theirs', ipa: 'ðɛrz' },
    },
    ipa_map: { 'ehem': 'm', 'ehen': 'f' },
    orders: ['m/f', 'f/m'],
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // KEY =: הוא/היא - PRONOUN_3S
  // ═══════════════════════════════════════════════════════════════════════════
  '=': {
    semantic: 'PRONOUN_3S',
    he: {
      m: { text: 'הוא', nikud: 'הוּא', ipa: 'hu' },
      f: { text: 'היא', nikud: 'הִיא', ipa: 'hi' },
    },
    en: {
      m: { text: 'he', ipa: 'hi' },
      f: { text: 'she', ipa: 'ʃi' },
    },
    ipa_map: { 'hu': 'm', 'hi': 'f' },
    orders: ['m/f', 'f/m'], // הוא/היא or היא/הוא
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// IPA REVERSE INDEX - Find MG pairs by IPA sound
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_TO_MG = {};

// Build reverse index
Object.entries(MG_PAIRS).forEach(([key, pair]) => {
  // Hebrew IPA mappings
  const he_m_ipa = pair.he.m.ipa;
  const he_f_ipa = pair.he.f.ipa;
  
  if (!IPA_TO_MG[he_m_ipa]) IPA_TO_MG[he_m_ipa] = [];
  IPA_TO_MG[he_m_ipa].push({ key, lang: 'he', gender: 'm', semantic: pair.semantic });
  
  if (!IPA_TO_MG[he_f_ipa]) IPA_TO_MG[he_f_ipa] = [];
  IPA_TO_MG[he_f_ipa].push({ key, lang: 'he', gender: 'f', semantic: pair.semantic });
  
  // English IPA mappings
  const en_m_ipa = pair.en.m.ipa;
  const en_f_ipa = pair.en.f.ipa;
  
  if (!IPA_TO_MG[en_m_ipa]) IPA_TO_MG[en_m_ipa] = [];
  IPA_TO_MG[en_m_ipa].push({ key, lang: 'en', gender: 'm', semantic: pair.semantic });
  
  if (en_f_ipa !== en_m_ipa) {
    if (!IPA_TO_MG[en_f_ipa]) IPA_TO_MG[en_f_ipa] = [];
    IPA_TO_MG[en_f_ipa].push({ key, lang: 'en', gender: 'f', semantic: pair.semantic });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════════════════════════

// Get MG pair by key
function getMGPair(key) {
  return MG_PAIRS[key] || null;
}

// Get MG value by key, lang, gender
function getMG(key, lang, gender) {
  const pair = MG_PAIRS[key];
  if (!pair) return null;
  return pair[lang]?.[gender] || null;
}

// Find MG pairs by IPA sound
function findMGByIPA(ipa) {
  return IPA_TO_MG[ipa] || [];
}

// Get pair in specific order
function getMGOrdered(key, lang, order = 'm/f') {
  const pair = MG_PAIRS[key];
  if (!pair) return null;
  
  const data = pair[lang];
  if (order === 'm/f') {
    return `${data.m.text}/${data.f.text}`;
  } else {
    return `${data.f.text}/${data.m.text}`;
  }
}

// Get nikud version in specific order
function getMGNikudOrdered(key, order = 'm/f') {
  const pair = MG_PAIRS[key];
  if (!pair) return null;
  
  const data = pair.he;
  if (order === 'm/f') {
    return `${data.m.nikud}/${data.f.nikud}`;
  } else {
    return `${data.f.nikud}/${data.m.nikud}`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('MG PAIRS - Mapped by IPA of each value');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Key  Semantic       HE (m)    IPA     HE (f)    IPA      EN (m)   EN (f)');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(MG_PAIRS).forEach(([key, pair]) => {
  const sem = pair.semantic.padEnd(13);
  const he_m = pair.he.m.nikud.padEnd(8);
  const he_m_ipa = pair.he.m.ipa.padEnd(6);
  const he_f = pair.he.f.nikud.padEnd(8);
  const he_f_ipa = pair.he.f.ipa.padEnd(7);
  const en_m = pair.en.m.text.padEnd(7);
  const en_f = pair.en.f.text;
  console.log(`[${key}]  ${sem} ${he_m} ${he_m_ipa} ${he_f} ${he_f_ipa} ${en_m} ${en_f}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA REVERSE INDEX - Find MG by sound');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const sampleIPAs = ['o', 'a', 'im', 'ot', 'hi', 'hu', 'hem', 'hen'];
sampleIPAs.forEach(ipa => {
  const matches = findMGByIPA(ipa);
  if (matches.length > 0) {
    const matchStr = matches.map(m => `[${m.key}]${m.gender}`).join(', ');
    console.log(`/${ipa}/ → ${matchStr}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('PAIR ORDER - Same pair, different order');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Key 1 (POSS_3S):');
console.log(`  m/f: ${getMGOrdered('1', 'he', 'm/f')} (${getMGNikudOrdered('1', 'm/f')})`);
console.log(`  f/m: ${getMGOrdered('1', 'he', 'f/m')} (${getMGNikudOrdered('1', 'f/m')})`);

console.log('\nKey 6 (PLURAL):');
console.log(`  m/f: ${getMGOrdered('6', 'he', 'm/f')} (${getMGNikudOrdered('6', 'm/f')})`);
console.log(`  f/m: ${getMGOrdered('6', 'he', 'f/m')} (${getMGNikudOrdered('6', 'f/m')})`);

console.log('\nKey = (PRONOUN_3S):');
console.log(`  m/f: ${getMGOrdered('=', 'he', 'm/f')} (${getMGNikudOrdered('=', 'm/f')})`);
console.log(`  f/m: ${getMGOrdered('=', 'he', 'f/m')} (${getMGNikudOrdered('=', 'f/m')})`);
console.log(`  EN m/f: ${getMGOrdered('=', 'en', 'm/f')}`);
console.log(`  EN f/m: ${getMGOrdered('=', 'en', 'f/m')}`);

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA connects MG pairs to keyboard letters:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('MG [1] ו/ה:');
console.log('  ו (vav) has IPA /o/ → same as חוֹלָם vowel');
console.log('  ה (he) has IPA /a/ → same as פַּתַח vowel');
console.log('  → Can be typed via IPA vowel keys!');

console.log('\nMG [6] ים/ות:');
console.log('  ים has IPA /im/ → י(/i/) + מ(/m/)');
console.log('  ות has IPA /ot/ → ו(/o/) + ת(/t/)');
console.log('  → Can be accessed via consonant IPA!');
