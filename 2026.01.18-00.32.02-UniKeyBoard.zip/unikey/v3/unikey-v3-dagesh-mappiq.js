// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - DAGESH & MAPPIQ (דגש ומפיק)
// ═══════════════════════════════════════════════════════════════════════════════
//
// דגש = changes pronunciation (קל/חזק)
// מפיק = makes final ה pronounced
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// בג"ד כפ"ת - LETTERS AFFECTED BY DAGESH
// ═══════════════════════════════════════════════════════════════════════════════

const BGDKPT = {
  'ב': {
    with_dagesh: { letter: 'בּ', ipa: 'b', en: 'b', example: { he: 'בַּיִת', en: 'bayit' } },
    without_dagesh: { letter: 'ב', ipa: 'v', en: 'v', example: { he: 'אָב', en: 'av' } },
  },
  'ג': {
    with_dagesh: { letter: 'גּ', ipa: 'g', en: 'g', example: { he: 'גָּדוֹל', en: 'gadol' } },
    without_dagesh: { letter: 'ג', ipa: 'g', en: 'g', example: { he: 'נָגַע', en: 'naga' }, note: 'בעברית מודרנית אותו צליל' },
    classical: { without: 'ɣ', note: 'בעברית קלאסית היה צליל גרוני' },
  },
  'ד': {
    with_dagesh: { letter: 'דּ', ipa: 'd', en: 'd', example: { he: 'דָּבָר', en: 'davar' } },
    without_dagesh: { letter: 'ד', ipa: 'd', en: 'd', example: { he: 'יָד', en: 'yad' }, note: 'בעברית מודרנית אותו צליל' },
    classical: { without: 'ð', note: 'בעברית קלאסית כמו th באנגלית!' },
  },
  'כ': {
    with_dagesh: { letter: 'כּ', ipa: 'k', en: 'k', example: { he: 'כֵּן', en: 'ken' } },
    without_dagesh: { letter: 'כ', ipa: 'x', en: "kh'", example: { he: 'מֶלֶךְ', en: "melekh'" } },
    note: 'כ רפויה = כמו ח, אבל ח גרונית יותר!',
  },
  'פ': {
    with_dagesh: { letter: 'פּ', ipa: 'p', en: 'p', example: { he: 'פֹּה', en: 'po' } },
    without_dagesh: { letter: 'פ', ipa: 'f', en: 'f', example: { he: 'סוֹפֵר', en: 'sofer' } },
  },
  'ת': {
    with_dagesh: { letter: 'תּ', ipa: 't', en: 't', example: { he: 'תּוֹדָה', en: 'toda' } },
    without_dagesh: { letter: 'ת', ipa: 't', en: 't', example: { he: 'אוֹת', en: 'ot' }, note: 'בעברית מודרנית אותו צליל' },
    classical: { without: 'θ', note: 'בעברית קלאסית כמו th באנגלית!' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ח vs כ - GUTTURAL DISTINCTION
// ═══════════════════════════════════════════════════════════════════════════════

const GUTTURAL_KH = {
  'ח': {
    letter: 'ח',
    ipa: 'ħ',  // pharyngeal
    ipa_modern: 'x',
    en_transcription: "ḥ'",
    alt_transcription: "h'",
    name: 'חֵית',
    type: 'גרונית (pharyngeal)',
    examples: { he: ['חֵן', 'לֶחֶם', 'רוּחַ'], en: ["ḥ'en", "leḥ'em", "ruaḥ'"] },
    note: 'גרונית עמוקה - מהגרון',
    warning: '⚠️ שונה מ-כ! ח = גרונית, כ = חיכית',
  },
  'כ': {
    letter: 'כ',
    ipa: 'x',  // velar
    en_transcription: "kh'",
    name: 'כָף רפויה',
    type: 'חיכית (velar)',
    examples: { he: ['מֶלֶךְ', 'בָּרוּךְ', 'לָכֶם'], en: ["melekh'", "barukh'", "lakhem"] },
    note: 'חיכית - מהחך הרך',
  },
  distinction: {
    note: 'בעברית מודרנית רבים לא מבחינים, אבל ח גרונית יותר!',
    classical: 'בעברית קלאסית ח = /ħ/ (pharyngeal), כ = /x/ (velar)',
    transcription: {
      'ח': "ḥ' (עם נקודה תחתית) או h'",
      'כ': "kh'",
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// מפיק - MAPPIQ (pronounced final ה)
// ═══════════════════════════════════════════════════════════════════════════════

const MAPPIQ = {
  description: 'נקודה בתוך ה בסוף מילה - מציינת שה נשמעת',
  letter: 'הּ',
  ipa: 'h',
  
  examples: {
    with_mappiq: [
      { he: 'שֶׁלָּהּ', en: "shela'", meaning: 'שלה (נקבה)', note: 'ה נשמעת!' },
      { he: 'גָּבֹהַּ', en: "gavoah'", meaning: 'גבוה', note: 'ה נשמעת!' },
      { he: 'אֱלוֹהַּ', en: "eloah'", meaning: 'אלוה', note: 'ה נשמעת!' },
      { he: 'אַרְצָהּ', en: "artsa'", meaning: 'ארצה (שלה)', note: 'ה נשמעת!' },
      { he: 'בֵּיתָהּ', en: "beta'", meaning: 'ביתה (שלה)', note: 'ה נשמעת!' },
    ],
    without_mappiq: [
      { he: 'שֶׁלָּה', en: 'shela', meaning: 'שלה (מקום)', note: 'ה שקטה' },
      { he: 'יָפָה', en: 'yafa', meaning: 'יפה', note: 'ה שקטה' },
      { he: 'גְּדוֹלָה', en: 'gdola', meaning: 'גדולה', note: 'ה שקטה' },
      { he: 'בַּיְתָה', en: 'bayta', meaning: 'הביתה (לכיוון)', note: 'ה שקטה' },
    ],
  },
  
  rule: 'מפיק = ה נשמעת בסוף מילה, בדרך כלל בסמיכות או כינוי',
  transcription: "הּ = ' בסוף (או h)",
};

// ═══════════════════════════════════════════════════════════════════════════════
// SMICHUT (סמיכות) - CONSTRUCT STATE
// ═══════════════════════════════════════════════════════════════════════════════

const SMICHUT = {
  description: 'צורת הסמיכות משנה הגייה ומשמעות',
  
  examples: [
    { 
      absolute: { he: 'בַּיִת', en: 'bayit', meaning: 'בית' },
      construct: { he: 'בֵּית', en: 'bet', meaning: 'בית של...' },
      example: 'בֵּית סֵפֶר = bet sefer',
    },
    {
      absolute: { he: 'דְּבַר', en: 'dvar', meaning: 'דבר' },
      construct: { he: 'דְּבַר', en: 'dvar', meaning: 'דבר של...' },
      example: 'דְּבַר הַמֶּלֶךְ = dvar hamelekh\'',
    },
    {
      note: 'כינוי שלה עם מפיק:',
      absolute: { he: 'יָד', en: 'yad', meaning: 'יד' },
      construct: { he: 'יָדָהּ', en: "yada'", meaning: 'ידה (שלה)' },
    },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// COMPLETE TRANSCRIPTION SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

const TRANSCRIPTION_RULES = {
  // בג"ד כפ"ת
  'בּ': 'b',    'ב': 'v',
  'גּ': 'g',    'ג': 'g',
  'דּ': 'd',    'ד': 'd',
  'כּ': 'k',    'כ': "kh'",   'ךּ': 'k',    'ך': "kh'",
  'פּ': 'p',    'פ': 'f',     'ףּ': 'p',    'ף': 'f',
  'תּ': 't',    'ת': 't',
  
  // גרוניות
  'ח': "ḥ'",   // or h' - pharyngeal
  'ע': "'",    // glottal stop
  'א': "'",    // glottal stop (when pronounced)
  'הּ': "'",   // mappiq - pronounced final ה
  'ה': 'h',    // regular ה (silent at end)
  
  // אחרות
  'צ': "ts'",
  'ק': "k'",   // or q' for emphatic
  'ר': "r'",   // guttural R
  'שׁ': 'sh',
  'שׂ': 's',
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('DAGESH & MAPPIQ - דגש ומפיק');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('בג"ד כפ"ת - WITH vs WITHOUT DAGESH:');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('Letter   With Dagesh    Without Dagesh    Note');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(BGDKPT).forEach(([letter, info]) => {
  const withD = `${info.with_dagesh.letter} /${info.with_dagesh.ipa}/ = ${info.with_dagesh.en}`;
  const withoutD = `${info.without_dagesh.letter} /${info.without_dagesh.ipa}/ = ${info.without_dagesh.en}`;
  const note = info.note || info.without_dagesh.note || '';
  console.log(`  ${letter}      ${withD.padEnd(18)} ${withoutD.padEnd(18)} ${note}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ח vs כ - GUTTURAL DISTINCTION:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ח /ħ/ = גרונית (pharyngeal) - מהגרון העמוק');
console.log(`       תעתיק: ḥ' או h'`);
console.log('       דוגמאות: חֵן→ḥ\'en, לֶחֶם→leḥ\'em, רוּחַ→ruaḥ\'');
console.log('');
console.log('  כ /x/ = חיכית (velar) - מהחך הרך');
console.log(`       תעתיק: kh'`);
console.log('       דוגמאות: מֶלֶךְ→melekh\', בָּרוּךְ→barukh\'');
console.log('');
console.log('  ⚠️ בעברית מודרנית רבים לא מבחינים, אבל ח גרונית יותר!');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('מפיק - MAPPIQ (ה נשמעת):');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('WITH MAPPIQ (הּ נשמעת):');
MAPPIQ.examples.with_mappiq.forEach(ex => {
  console.log(`  ${ex.he.padEnd(10)} → ${ex.en.padEnd(12)} (${ex.meaning}) - ${ex.note}`);
});

console.log('\nWITHOUT MAPPIQ (ה שקטה):');
MAPPIQ.examples.without_mappiq.forEach(ex => {
  console.log(`  ${ex.he.padEnd(10)} → ${ex.en.padEnd(12)} (${ex.meaning}) - ${ex.note}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('TRANSCRIPTION EXAMPLES:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const examples = [
  { he: 'כֵּן', en: 'ken', note: 'כּ with dagesh = k' },
  { he: 'מֶלֶךְ', en: "melekh'", note: 'ך without dagesh = kh\'' },
  { he: 'חֵן', en: "ḥ'en", note: 'ח = ḥ\' (guttural)' },
  { he: 'בַּיִת', en: 'bayit', note: 'בּ with dagesh = b' },
  { he: 'אָב', en: 'av', note: 'ב without dagesh = v' },
  { he: 'פֹּה', en: 'po', note: 'פּ with dagesh = p' },
  { he: 'סוֹפֵר', en: 'sofer', note: 'פ without dagesh = f' },
  { he: 'שֶׁלָּהּ', en: "shela'", note: 'הּ with mappiq = \' (pronounced)' },
  { he: 'יָפָה', en: 'yafa', note: 'ה without mappiq = silent' },
  { he: 'צִפּוֹר', en: "ts'ipor", note: 'צ = ts\'' },
  { he: 'עַיִן', en: "'ayin", note: 'ע = \'' },
];

console.log('Hebrew     English      Note');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
examples.forEach(ex => {
  console.log(`${ex.he.padEnd(11)} ${ex.en.padEnd(13)} ${ex.note}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SUMMARY:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log(`
┌──────────────────────────────────────────────────────────────────────────────────┐
│  DAGESH (דגש):                                                                  │
│  ═════════════                                                                  │
│  בּ = b     ב = v                                                               │
│  כּ = k     כ = kh' (velar)                                                     │
│  פּ = p     פ = f                                                               │
│  גּ = g     ג = g (modern same)                                                 │
│  דּ = d     ד = d (modern same, classical = /ð/ like "the"!)                    │
│  תּ = t     ת = t (modern same, classical = /θ/ like "think"!)                  │
│                                                                                  │
│  GUTTURAL (גרוניות):                                                            │
│  ═════════════════                                                              │
│  ח = ḥ' (pharyngeal - deep throat)   חֵן → ḥ'en                                │
│  כ = kh' (velar - soft palate)       מֶלֶךְ → melekh'                            │
│  ע = ' (glottal stop)                עַיִן → 'ayin                              │
│  ⚠️ ח ≠ כ! ח is deeper/more guttural                                           │
│                                                                                  │
│  MAPPIQ (מפיק):                                                                 │
│  ═════════════                                                                  │
│  הּ = ' (pronounced at end)          שֶׁלָּהּ → shela'                           │
│  ה = (silent at end)                 יָפָה → yafa                               │
│  Used in: סמיכות (construct), כינויים (possessives)                             │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
`);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { BGDKPT, GUTTURAL_KH, MAPPIQ, SMICHUT, TRANSCRIPTION_RULES };
}
