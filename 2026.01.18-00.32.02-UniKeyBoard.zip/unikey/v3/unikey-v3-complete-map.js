// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - COMPLETE BIDIRECTIONAL IPA MAP (Merged & Enhanced)
// ═══════════════════════════════════════════════════════════════════════════════
//
// MERGED: HTML data + Bidirectional structure
// COMPLETE: All Hebrew + All English vowels and consonants
//
// ═══════════════════════════════════════════════════════════════════════════════

const UNIKEY_MAP = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // VOWELS - Complete set
  // ═══════════════════════════════════════════════════════════════════════════
  
  vowels: {
    
    // ═══════════════════════════════════════════════════════════════════════
    // PURE VOWELS (תנועות טהורות)
    // ═══════════════════════════════════════════════════════════════════════
    
    'a': {
      ipa: 'a',
      type: 'pure',
      he: { chaser: 'ַ', male: null, name: 'פַּתַח' },
      en: { single: ['a'], combos: [], examples: ['cat', 'hat'] },
    },
    
    'ɑ': {
      ipa: 'ɑ',
      type: 'pure',
      he: { chaser: 'ָ', male: 'ָא', name: 'קָמָץ' },
      en: { single: ['a', 'o'], combos: ['ar', 'al'], examples: ['father', 'car'] },
    },
    
    'ɑː': {
      ipa: 'ɑː',
      type: 'long',
      he: { chaser: 'ָ', male: 'ָא', name: 'קָמָץ', note: 'Same as /ɑ/' },
      en: { single: ['a'], combos: ['ar', 'al', 'au'], examples: ['father', 'car', 'calm'] },
    },
    
    'æ': {
      ipa: 'æ',
      type: 'pure',
      he: { chaser: null, male: null, name: '—', note: 'No Hebrew equivalent' },
      en: { single: ['a'], combos: [], examples: ['cat', 'bad', 'man'] },
    },
    
    'ɛ': {
      ipa: 'ɛ',
      type: 'pure',
      he: { chaser: 'ֶ', male: 'ֶא', name: 'סֶגוֹל' },
      en: { single: ['e'], combos: ['ea', 'ai', 'ie'], examples: ['bed', 'bread', 'said'] },
    },
    
    'e': {
      ipa: 'e',
      type: 'pure',
      he: { chaser: 'ֵ', male: 'ֵא', name: 'צֵירֵי' },
      en: { single: [], combos: ['ay', 'ai', 'ei'], examples: ['day', 'rain'], note: 'Usually /eɪ/ in English' },
    },
    
    'i': {
      ipa: 'i',
      type: 'pure',
      he: { chaser: 'ִ', male: 'ִי', name: 'חִירִיק' },
      en: { single: ['i', 'y'], combos: ['ee', 'ea', 'ie', 'ei', 'ey'], examples: ['see', 'sea', 'field'] },
    },
    
    'iː': {
      ipa: 'iː',
      type: 'long',
      he: { chaser: 'ִ', male: 'ִי', name: 'חִירִיק מָלֵא' },
      en: { single: [], combos: ['ee', 'ea', 'ie', 'ei', 'ey', 'e_e', 'i_e'], examples: ['see', 'eat', 'field'] },
    },
    
    'ɪ': {
      ipa: 'ɪ',
      type: 'short',
      he: { chaser: 'ִ', male: null, name: 'חִירִיק קָצָר' },
      en: { single: ['i', 'y', 'e'], combos: ['ui', 'u'], examples: ['sit', 'gym', 'pretty'] },
    },
    
    'o': {
      ipa: 'o',
      type: 'pure',
      he: { chaser: 'ֹ', male: 'וֹ', name: 'חוֹלָם' },
      en: { single: ['o'], combos: ['oa', 'ow', 'o_e', 'oe'], examples: ['go', 'boat', 'know'] },
    },
    
    'ɔ': {
      ipa: 'ɔ',
      type: 'pure',
      he: { chaser: 'ָ', male: null, name: 'קָמָץ קָטָן', note: 'Same mark as קָמָץ' },
      en: { single: ['o'], combos: ['aw', 'au', 'al'], examples: ['saw', 'taught', 'all'] },
    },
    
    'ɔː': {
      ipa: 'ɔː',
      type: 'long',
      he: { chaser: 'ָ', male: null, name: 'קָמָץ קָטָן' },
      en: { single: [], combos: ['or', 'aw', 'au', 'al', 'our', 'oor'], examples: ['for', 'saw', 'taught'] },
    },
    
    'ɒ': {
      ipa: 'ɒ',
      type: 'short',
      he: { chaser: null, male: null, name: '—', note: 'British short o' },
      en: { single: ['o'], combos: ['a', 'au', 'aw'], examples: ['hot', 'want', 'because'] },
    },
    
    'u': {
      ipa: 'u',
      type: 'pure',
      he: { chaser: 'ֻ', male: 'וּ', name: 'קֻבּוּץ / שׁוּרוּק' },
      en: { single: ['u'], combos: ['oo', 'ue', 'ew', 'ou'], examples: ['moon', 'blue', 'new'] },
    },
    
    'uː': {
      ipa: 'uː',
      type: 'long',
      he: { chaser: 'ֻ', male: 'וּ', name: 'שׁוּרוּק' },
      en: { single: [], combos: ['oo', 'u', 'ue', 'ew', 'o', 'ou'], examples: ['moon', 'rule', 'blue'] },
    },
    
    'ʊ': {
      ipa: 'ʊ',
      type: 'short',
      he: { chaser: 'ֻ', male: null, name: 'קֻבּוּץ קָצָר' },
      en: { single: ['u'], combos: ['oo', 'ou', 'o'], examples: ['book', 'put', 'could'] },
    },
    
    'ʌ': {
      ipa: 'ʌ',
      type: 'short',
      he: { chaser: null, male: null, name: '—', note: 'No Hebrew equivalent' },
      en: { single: ['u', 'o'], combos: ['ou', 'oo'], examples: ['cup', 'son', 'touch', 'blood'] },
    },
    
    'ɜː': {
      ipa: 'ɜː',
      type: 'long',
      he: { chaser: null, male: null, name: '—', note: 'No Hebrew equivalent' },
      en: { single: [], combos: ['er', 'ir', 'ur', 'ear', 'or'], examples: ['her', 'bird', 'turn', 'learn'] },
    },
    
    'ə': {
      ipa: 'ə',
      type: 'reduced',
      he: {
        chaser: 'ְ', male: null, name: 'שְׁוָא',
        variants: { na: { mark: 'ְ', voiced: true }, nach: { mark: 'ְ', voiced: false } },
      },
      en: { single: ['a', 'e', 'i', 'o', 'u'], combos: [], examples: ['about', 'taken', 'pencil'] },
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // HATAF VOWELS (חטפים - גרוניות בלבד)
    // ═══════════════════════════════════════════════════════════════════════
    
    'ă': {
      ipa: 'ă',
      type: 'hataf',
      he: { chaser: 'ֲ', male: null, name: 'חֲטַף פַּתַח', guttural_only: ['א', 'ה', 'ח', 'ע'] },
      en: { single: [], combos: [], examples: [] },
    },
    
    'ĕ': {
      ipa: 'ĕ',
      type: 'hataf',
      he: { chaser: 'ֱ', male: null, name: 'חֲטַף סֶגוֹל', guttural_only: ['א', 'ה', 'ח', 'ע'] },
      en: { single: [], combos: [], examples: [] },
    },
    
    'ŏ': {
      ipa: 'ŏ',
      type: 'hataf',
      he: { chaser: 'ֳ', male: null, name: 'חֲטַף קָמָץ', guttural_only: ['א', 'ה', 'ח', 'ע'] },
      en: { single: [], combos: [], examples: [] },
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // HEBREW DIPHTHONGS (תנועות כפולות עבריות)
    // ═══════════════════════════════════════════════════════════════════════
    
    'aj': {
      ipa: 'aj',
      type: 'diphthong',
      he: { chaser: 'ַי', male: 'ַיְ', name: 'פַּתַח + יוֹד', examples: ['בַּיִת', 'עַיִן'] },
      en: { single: ['i', 'y'], combos: ['i_e', 'igh', 'ie'], examples: ['my', 'high'], maps_to: 'aɪ' },
    },
    
    'ej': {
      ipa: 'ej',
      type: 'diphthong',
      he: { chaser: 'ֵי', male: 'ֵיְ', name: 'צֵירֵי + יוֹד', examples: ['בֵּית', 'עֵינַיִם'] },
      en: { single: [], combos: ['ay', 'ei', 'ey'], examples: ['day', 'they'], maps_to: 'eɪ' },
    },
    
    'aw': {
      ipa: 'aw',
      type: 'diphthong',
      he: { chaser: 'ַו', male: 'ָו', name: 'פַּתַח/קָמָץ + וָו', examples: ['יָו', 'תָּו'] },
      en: { single: [], combos: ['ou', 'ow'], examples: ['out', 'now'], maps_to: 'aʊ' },
    },
    
    'oj': {
      ipa: 'oj',
      type: 'diphthong',
      he: { chaser: 'ֹי', male: 'וֹי', name: 'חוֹלָם + יוֹד', examples: ['גּוֹי', 'אוֹי'] },
      en: { single: [], combos: ['oi', 'oy'], examples: ['boy', 'oil'], maps_to: 'ɔɪ' },
    },
    
    'uj': {
      ipa: 'uj',
      type: 'diphthong',
      he: { chaser: 'וּי', male: null, name: 'שׁוּרוּק + יוֹד', examples: ['גּוּי'] },
      en: { single: [], combos: ['ooey', 'ui'], examples: ['gooey', 'ruin'] },
    },
    
    // ═══════════════════════════════════════════════════════════════════════
    // ENGLISH DIPHTHONGS (with Hebrew mapping)
    // ═══════════════════════════════════════════════════════════════════════
    
    'eɪ': {
      ipa: 'eɪ',
      type: 'diphthong',
      he: { chaser: null, male: null, maps_to: 'ej', he_equiv: 'ֵי' },
      en: { single: [], combos: ['a_e', 'ai', 'ay', 'ei', 'ey', 'ea'], examples: ['make', 'rain', 'day'] },
    },
    
    'aɪ': {
      ipa: 'aɪ',
      type: 'diphthong',
      he: { chaser: null, male: null, maps_to: 'aj', he_equiv: 'ַי' },
      en: { single: ['i', 'y'], combos: ['i_e', 'igh', 'ie', 'uy', 'eye'], examples: ['time', 'high', 'my'] },
    },
    
    'ɔɪ': {
      ipa: 'ɔɪ',
      type: 'diphthong',
      he: { chaser: null, male: null, maps_to: 'oj', he_equiv: 'וֹי' },
      en: { single: [], combos: ['oi', 'oy'], examples: ['oil', 'boy'] },
    },
    
    'aʊ': {
      ipa: 'aʊ',
      type: 'diphthong',
      he: { chaser: null, male: null, maps_to: 'aw', he_equiv: 'ָו' },
      en: { single: [], combos: ['ou', 'ow'], examples: ['out', 'now'] },
    },
    
    'oʊ': {
      ipa: 'oʊ',
      type: 'diphthong',
      he: { chaser: null, male: null, note: 'Hebrew /o/ is pure, not diphthong', he_equiv: 'וֹ' },
      en: { single: ['o'], combos: ['oa', 'ow', 'o_e', 'oe'], examples: ['go', 'boat', 'home'] },
    },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS - Complete set
  // ═══════════════════════════════════════════════════════════════════════════
  
  consonants: {
    // Stops
    'p': { ipa: 'p', name: 'voiceless bilabial', he: { letters: ['פּ'], names: ['פֵּא'] }, en: { single: ['p'], combos: ['pp'] } },
    'b': { ipa: 'b', name: 'voiced bilabial', he: { letters: ['בּ'], names: ['בֵּית'] }, en: { single: ['b'], combos: ['bb'] } },
    't': { ipa: 't', name: 'voiceless alveolar', he: { letters: ['ת', 'ט'], names: ['תָּו', 'טֵית'] }, en: { single: ['t'], combos: ['tt', 'ed'] } },
    'd': { ipa: 'd', name: 'voiced alveolar', he: { letters: ['ד'], names: ['דָּלֶת'] }, en: { single: ['d'], combos: ['dd', 'ed'] } },
    'k': { ipa: 'k', name: 'voiceless velar', he: { letters: ['כּ', 'ק'], names: ['כָּף', 'קוֹף'] }, en: { single: ['k', 'c'], combos: ['ck', 'cc', 'ch', 'qu'] } },
    'g': { ipa: 'g', name: 'voiced velar', he: { letters: ['ג'], names: ['גִּימֶל'] }, en: { single: ['g'], combos: ['gg', 'gh'] } },
    'ʔ': { ipa: 'ʔ', name: 'glottal stop', he: { letters: ['א', 'ע'], names: ['אָלֶף', 'עַיִן'] }, en: { single: [], combos: [] } },
    
    // Fricatives
    'f': { ipa: 'f', name: 'voiceless labiodental', he: { letters: ['פ', 'ף'], names: ['פֵא', 'פֵא סוֹפִית'] }, en: { single: ['f'], combos: ['ff', 'ph', 'gh'] } },
    'v': { ipa: 'v', name: 'voiced labiodental', he: { letters: ['ב', 'ו'], names: ['בֵית', 'וָו'] }, en: { single: ['v'], combos: ['ve'] } },
    'θ': { ipa: 'θ', name: 'voiceless dental', he: { letters: [], names: [], note: 'No Hebrew equivalent' }, en: { single: [], combos: ['th'] } },
    'ð': { ipa: 'ð', name: 'voiced dental', he: { letters: [], names: [], note: 'No Hebrew equivalent' }, en: { single: [], combos: ['th'] } },
    's': { ipa: 's', name: 'voiceless alveolar', he: { letters: ['ס', 'שׂ'], names: ['סָמֶךְ', 'שִׂין'] }, en: { single: ['s', 'c'], combos: ['ss', 'sc', 'ce'] } },
    'z': { ipa: 'z', name: 'voiced alveolar', he: { letters: ['ז'], names: ['זַיִן'] }, en: { single: ['z', 's'], combos: ['zz', 'ze'] } },
    'ʃ': { ipa: 'ʃ', name: 'voiceless postalveolar', he: { letters: ['שׁ'], names: ['שִׁין'] }, en: { single: [], combos: ['sh', 'ti', 'ci', 'ssi', 'si'] } },
    'ʒ': { ipa: 'ʒ', name: 'voiced postalveolar', he: { letters: ["ז'"], names: ["ז׳"] }, en: { single: [], combos: ['si', 'su', 'ge'] } },
    'x': { ipa: 'x', name: 'voiceless velar', he: { letters: ['כ', 'ח'], names: ['כָף', 'חֵית'] }, en: { single: [], combos: ['ch', 'kh'] } },
    'ħ': { ipa: 'ħ', name: 'voiceless pharyngeal', he: { letters: ['ח'], names: ['חֵית'] }, en: { single: [], combos: [] } },
    'ʕ': { ipa: 'ʕ', name: 'voiced pharyngeal', he: { letters: ['ע'], names: ['עַיִן'] }, en: { single: [], combos: [] } },
    'h': { ipa: 'h', name: 'voiceless glottal', he: { letters: ['ה'], names: ['הֵא'] }, en: { single: ['h'], combos: [] } },
    
    // Affricates
    'ts': { ipa: 'ts', name: 'voiceless alveolar', he: { letters: ['צ', 'ץ'], names: ['צָדִי', 'צָדִי סוֹפִית'] }, en: { single: [], combos: ['ts', 'tz', 'z'] } },
    'tʃ': { ipa: 'tʃ', name: 'voiceless postalveolar', he: { letters: ["צ'"], names: ["צ׳"] }, en: { single: [], combos: ['ch', 'tch', 'tu'] } },
    'dʒ': { ipa: 'dʒ', name: 'voiced postalveolar', he: { letters: ["ג'"], names: ["ג׳"] }, en: { single: ['j'], combos: ['dge', 'ge', 'gi'] } },
    
    // Nasals
    'm': { ipa: 'm', name: 'bilabial nasal', he: { letters: ['מ', 'ם'], names: ['מֵם', 'מֵם סוֹפִית'] }, en: { single: ['m'], combos: ['mm', 'mb', 'mn'] } },
    'n': { ipa: 'n', name: 'alveolar nasal', he: { letters: ['נ', 'ן'], names: ['נוּן', 'נוּן סוֹפִית'] }, en: { single: ['n'], combos: ['nn', 'kn', 'gn', 'pn'] } },
    'ŋ': { ipa: 'ŋ', name: 'velar nasal', he: { letters: [], names: [], note: 'No Hebrew equivalent' }, en: { single: [], combos: ['ng', 'n'] } },
    
    // Approximants
    'l': { ipa: 'l', name: 'alveolar lateral', he: { letters: ['ל'], names: ['לָמֶד'] }, en: { single: ['l'], combos: ['ll'] } },
    'ʁ': { ipa: 'ʁ', name: 'uvular fricative', he: { letters: ['ר'], names: ['רֵישׁ'] }, en: { single: ['r'], combos: ['rr', 'wr'] } },
    'r': { ipa: 'r', name: 'alveolar approximant', he: { letters: ['ר'], names: ['רֵישׁ'], note: 'English r differs' }, en: { single: ['r'], combos: ['rr', 'wr'] } },
    'j': { ipa: 'j', name: 'palatal approximant', he: { letters: ['י'], names: ['יוֹד'] }, en: { single: ['y'], combos: [] } },
    'w': { ipa: 'w', name: 'labial-velar', he: { letters: ['ו'], names: ['וָו'] }, en: { single: ['w'], combos: ['wh'] } },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// REVERSE INDEXES - Bidirectional lookup
// ═══════════════════════════════════════════════════════════════════════════════

const HE_TO_IPA = {};
const EN_TO_IPA = {};
const IPA_TO_HE = {};
const IPA_TO_EN = {};

function buildIndexes() {
  // Vowels
  Object.entries(UNIKEY_MAP.vowels).forEach(([ipa, data]) => {
    // IPA → Hebrew
    if (data.he.chaser) {
      IPA_TO_HE[ipa] = { chaser: data.he.chaser, male: data.he.male, name: data.he.name };
      HE_TO_IPA[data.he.chaser] = HE_TO_IPA[data.he.chaser] || [];
      HE_TO_IPA[data.he.chaser].push(ipa);
    }
    if (data.he.male) {
      HE_TO_IPA[data.he.male] = HE_TO_IPA[data.he.male] || [];
      HE_TO_IPA[data.he.male].push(ipa);
    }
    
    // IPA → English
    IPA_TO_EN[ipa] = { single: data.en.single || [], combos: data.en.combos || [] };
    
    // English → IPA
    (data.en.single || []).forEach(s => {
      EN_TO_IPA[s] = EN_TO_IPA[s] || [];
      if (!EN_TO_IPA[s].includes(ipa)) EN_TO_IPA[s].push(ipa);
    });
    (data.en.combos || []).forEach(c => {
      EN_TO_IPA[c] = EN_TO_IPA[c] || [];
      if (!EN_TO_IPA[c].includes(ipa)) EN_TO_IPA[c].push(ipa);
    });
  });
  
  // Consonants
  Object.entries(UNIKEY_MAP.consonants).forEach(([ipa, data]) => {
    // IPA → Hebrew
    if (data.he.letters && data.he.letters.length > 0) {
      IPA_TO_HE[ipa] = { letters: data.he.letters, names: data.he.names };
      data.he.letters.forEach(l => {
        HE_TO_IPA[l] = HE_TO_IPA[l] || [];
        if (!HE_TO_IPA[l].includes(ipa)) HE_TO_IPA[l].push(ipa);
      });
    }
    
    // IPA → English
    IPA_TO_EN[ipa] = { single: data.en.single || [], combos: data.en.combos || [] };
    
    // English → IPA
    (data.en.single || []).forEach(s => {
      EN_TO_IPA[s] = EN_TO_IPA[s] || [];
      if (!EN_TO_IPA[s].includes(ipa)) EN_TO_IPA[s].push(ipa);
    });
    (data.en.combos || []).forEach(c => {
      EN_TO_IPA[c] = EN_TO_IPA[c] || [];
      if (!EN_TO_IPA[c].includes(ipa)) EN_TO_IPA[c].push(ipa);
    });
  });
}

buildIndexes();

// ═══════════════════════════════════════════════════════════════════════════════
// API Functions
// ═══════════════════════════════════════════════════════════════════════════════

function ipaToHebrew(ipa, options = { male: false }) {
  const vowel = UNIKEY_MAP.vowels[ipa];
  if (vowel && vowel.he.chaser) {
    return options.male && vowel.he.male ? vowel.he.male : vowel.he.chaser;
  }
  const cons = UNIKEY_MAP.consonants[ipa];
  if (cons && cons.he.letters && cons.he.letters.length > 0) {
    return cons.he.letters[0];
  }
  return null;
}

function ipaToEnglish(ipa, options = { preferCombo: false }) {
  const data = IPA_TO_EN[ipa];
  if (!data) return null;
  if (options.preferCombo && data.combos.length > 0) return data.combos[0];
  return data.single[0] || data.combos[0] || null;
}

function hebrewToIPA(he) {
  return HE_TO_IPA[he] || null;
}

function englishToIPA(en) {
  return EN_TO_IPA[en] || null;
}

function getAllOptions(ipa) {
  return UNIKEY_MAP.vowels[ipa] || UNIKEY_MAP.consonants[ipa] || null;
}

function getVowelsByType(type) {
  return Object.entries(UNIKEY_MAP.vowels)
    .filter(([_, v]) => v.type === type)
    .map(([ipa, v]) => ({ ipa, ...v }));
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY COMPLETE MAP - Merged & Enhanced');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const vowelCount = Object.keys(UNIKEY_MAP.vowels).length;
const consCount = Object.keys(UNIKEY_MAP.consonants).length;
const pureVowels = getVowelsByType('pure').length;
const shortVowels = getVowelsByType('short').length;
const longVowels = getVowelsByType('long').length;
const hatafVowels = getVowelsByType('hataf').length;
const diphthongs = getVowelsByType('diphthong').length;

console.log('STATISTICS:');
console.log(`Total vowels:     ${vowelCount}`);
console.log(`  Pure:           ${pureVowels}`);
console.log(`  Short:          ${shortVowels}`);
console.log(`  Long:           ${longVowels}`);
console.log(`  Hataf:          ${hatafVowels}`);
console.log(`  Diphthongs:     ${diphthongs}`);
console.log(`Total consonants: ${consCount}`);
console.log(`Hebrew → IPA:     ${Object.keys(HE_TO_IPA).length} entries`);
console.log(`English → IPA:    ${Object.keys(EN_TO_IPA).length} entries`);

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SAMPLE LOOKUPS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA → Hebrew:');
['a', 'i', 'o', 'ʃ', 'aj', 'eɪ'].forEach(ipa => {
  const he = ipaToHebrew(ipa);
  const heMale = ipaToHebrew(ipa, { male: true });
  console.log(`  /${ipa}/ → ${he || '—'} (male: ${heMale || '—'})`);
});

console.log('\nHebrew → IPA:');
['ַ', 'ָ', 'ִי', 'וֹ', 'שׁ', 'ֵי'].forEach(he => {
  const ipa = hebrewToIPA(he);
  console.log(`  ${he} → /${ipa?.join(', ') || '—'}/`);
});

console.log('\nEnglish → IPA:');
['sh', 'ee', 'igh', 'ou', 'th'].forEach(en => {
  const ipa = englishToIPA(en);
  console.log(`  ${en} → /${ipa?.join(', ') || '—'}/`);
});

// Export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    UNIKEY_MAP,
    HE_TO_IPA,
    EN_TO_IPA,
    IPA_TO_HE,
    IPA_TO_EN,
    ipaToHebrew,
    ipaToEnglish,
    hebrewToIPA,
    englishToIPA,
    getAllOptions,
    getVowelsByType,
  };
}
