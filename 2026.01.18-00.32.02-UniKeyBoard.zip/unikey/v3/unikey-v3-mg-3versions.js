// ═══════════════════════════════════════════════════════════════════════════════
// MG KEYS - 3 VERSIONS: English, Hebrew Plain, Hebrew Nikud
// ═══════════════════════════════════════════════════════════════════════════════

const MG_SEMANTIC = {
  // ═══════════════════════════════════════════════════════════════════════════
  // NUMBER ROW - Core MG Suffixes (3 versions each)
  // ═══════════════════════════════════════════════════════════════════════════
  
  '1': {
    semantic: 'POSS_3S',
    meaning: 'belonging to him/her',
    en:    { m: 'his',    f: 'her',    mf: 'his/her' },
    he:    { m: 'ו',      f: 'ה',      mf: 'ו/ה' },
    nikud: { m: 'וֹ',     f: 'הּ',     mf: 'וֹ/הּ' },
    ipa:   { m: 'o',      f: 'a' },
  },
  
  '2': {
    semantic: 'POSS_3S_EXT',
    meaning: 'of his/hers (noun suffix)',
    en:    { m: 'his',    f: 'hers',   mf: 'his/hers' },
    he:    { m: 'יו',     f: 'יה',     mf: 'יו/יה' },
    nikud: { m: 'ָיו',    f: 'ֶיהָ',   mf: 'ָיו/ֶיהָ' },
    ipa:   { m: 'av',     f: 'eha' },
  },
  
  '3': {
    semantic: 'POSS_3P',
    meaning: 'belonging to them',
    en:    { m: 'their',  f: 'their',  mf: 'their' },
    he:    { m: 'ם',      f: 'ן',      mf: 'ם/ן' },
    nikud: { m: 'ָם',     f: 'ָן',     mf: 'ָם/ָן' },
    ipa:   { m: 'am',     f: 'an' },
  },
  
  '4': {
    semantic: 'PRONOUN_3P',
    meaning: 'they (m/f)',
    en:    { m: 'they',   f: 'they',   mf: 'they' },
    he:    { m: 'הם',     f: 'הן',     mf: 'הם/הן' },
    nikud: { m: 'הֵם',    f: 'הֵן',    mf: 'הֵם/הֵן' },
    ipa:   { m: 'hem',    f: 'hen' },
  },
  
  '5': {
    semantic: 'VERB_PRESENT',
    meaning: 'present tense singular',
    en:    { m: '-s',     f: '-s',     mf: '-s' },
    he:    { m: 'ד',      f: 'ת',      mf: 'ד/ת' },
    nikud: { m: 'ֵד',     f: 'ֶת',     mf: 'ֵד/ֶת' },
    ipa:   { m: 'ed',     f: 'et' },
  },
  
  '6': {
    semantic: 'PLURAL',
    meaning: 'plural (m/f)',
    en:    { m: '-s',     f: '-s',     mf: '-s' },
    he:    { m: 'ים',     f: 'ות',     mf: 'ים/ות' },
    nikud: { m: 'ִים',    f: 'וֹת',    mf: 'ִים/וֹת' },
    ipa:   { m: 'im',     f: 'ot' },
  },
  
  '7': {
    semantic: 'GENTILIC',
    meaning: 'nationality/origin',
    en:    { m: '-n',     f: '-n',     mf: '-n/-an' },
    he:    { m: 'י',      f: 'ית',     mf: 'י/ית' },
    nikud: { m: 'ִי',     f: 'ִית',    mf: 'ִי/ִית' },
    ipa:   { m: 'i',      f: 'it' },
  },
  
  '8': {
    semantic: 'ADJECTIVE',
    meaning: 'adjective/agent suffix',
    en:    { m: '-er',    f: '-ess',   mf: '-er/-ess' },
    he:    { m: 'ן',      f: 'נית',    mf: 'ן/נית' },
    nikud: { m: 'ָן',     f: 'ָנִית',  mf: 'ָן/ָנִית' },
    ipa:   { m: 'an',     f: 'anit' },
  },
  
  '9': {
    semantic: 'PROFESSION',
    meaning: 'professional suffix',
    en:    { m: '-or',    f: '-ress',  mf: '-or/-ress' },
    he:    { m: 'אי',     f: 'אית',    mf: 'אי/אית' },
    nikud: { m: 'אִי',    f: 'אִית',   mf: 'אִי/אִית' },
    ipa:   { m: 'ai',     f: 'ait' },
  },
  
  '0': {
    semantic: 'POSS_2P',
    meaning: 'belonging to you (plural)',
    en:    { m: 'your',   f: 'your',   mf: 'your' },
    he:    { m: 'כם',     f: 'כן',     mf: 'כם/כן' },
    nikud: { m: 'כֶם',    f: 'כֶן',    mf: 'כֶם/כֶן' },
    ipa:   { m: 'xem',    f: 'xen' },
  },
  
  '-': {
    semantic: 'POSS_3P_EXT',
    meaning: 'of theirs (noun suffix)',
    en:    { m: 'theirs', f: 'theirs', mf: 'theirs' },
    he:    { m: 'יהם',    f: 'יהן',    mf: 'יהם/יהן' },
    nikud: { m: 'ֵיהֶם',  f: 'ֵיהֶן',  mf: 'ֵיהֶם/ֵיהֶן' },
    ipa:   { m: 'ehem',   f: 'ehen' },
  },
  
  '=': {
    semantic: 'PRONOUN_3S',
    meaning: 'he/she',
    en:    { m: 'he',     f: 'she',    mf: 'he/she' },
    he:    { m: 'הוא',    f: 'היא',    mf: 'הוא/היא' },
    nikud: { m: 'הוּא',   f: 'הִיא',   mf: 'הוּא/הִיא' },
    ipa:   { m: 'hu',     f: 'hi' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// EXTENDED MG WORDS - 3 versions each
// ═══════════════════════════════════════════════════════════════════════════════

const MG_WORDS = {
  'PARENT': {
    en:    { m: 'father',   f: 'mother',   mf: 'father/mother' },
    he:    { m: 'אב',       f: 'אם',       mf: 'אב/אם' },
    nikud: { m: 'אָב',      f: 'אֵם',      mf: 'אָב/אֵם' },
  },
  'CHILD': {
    en:    { m: 'son',      f: 'daughter', mf: 'son/daughter' },
    he:    { m: 'בן',       f: 'בת',       mf: 'בן/בת' },
    nikud: { m: 'בֵּן',     f: 'בַּת',     mf: 'בֵּן/בַּת' },
  },
  'SIBLING': {
    en:    { m: 'brother',  f: 'sister',   mf: 'brother/sister' },
    he:    { m: 'אח',       f: 'אחות',     mf: 'אח/אחות' },
    nikud: { m: 'אָח',      f: 'אָחוֹת',   mf: 'אָח/אָחוֹת' },
  },
  'SPOUSE': {
    en:    { m: 'husband',  f: 'wife',     mf: 'husband/wife' },
    he:    { m: 'בעל',      f: 'אישה',     mf: 'בעל/אישה' },
    nikud: { m: 'בַּעַל',   f: 'אִשָּׁה',  mf: 'בַּעַל/אִשָּׁה' },
  },
  'PERSON': {
    en:    { m: 'man',      f: 'woman',    mf: 'man/woman' },
    he:    { m: 'איש',      f: 'אישה',     mf: 'איש/אישה' },
    nikud: { m: 'אִישׁ',    f: 'אִשָּׁה',  mf: 'אִישׁ/אִשָּׁה' },
  },
  'YOUTH': {
    en:    { m: 'boy',      f: 'girl',     mf: 'boy/girl' },
    he:    { m: 'ילד',      f: 'ילדה',     mf: 'ילד/ילדה' },
    nikud: { m: 'יֶלֶד',    f: 'יַלְדָּה', mf: 'יֶלֶד/יַלְדָּה' },
  },
  'PRONOUN_I': {
    en:    { m: 'I',        f: 'I',        mf: 'I' },
    he:    { m: 'אני',      f: 'אני',      mf: 'אני' },
    nikud: { m: 'אֲנִי',    f: 'אֲנִי',    mf: 'אֲנִי' },
  },
  'PRONOUN_YOU_S': {
    en:    { m: 'you',      f: 'you',      mf: 'you' },
    he:    { m: 'אתה',      f: 'את',       mf: 'אתה/את' },
    nikud: { m: 'אַתָּה',   f: 'אַתְּ',    mf: 'אַתָּה/אַתְּ' },
  },
  'PRONOUN_WE': {
    en:    { m: 'we',       f: 'we',       mf: 'we' },
    he:    { m: 'אנחנו',    f: 'אנחנו',    mf: 'אנחנו' },
    nikud: { m: 'אֲנַחְנוּ', f: 'אֲנַחְנוּ', mf: 'אֲנַחְנוּ' },
  },
  'PRONOUN_YOU_P': {
    en:    { m: 'you',      f: 'you',      mf: 'you' },
    he:    { m: 'אתם',      f: 'אתן',      mf: 'אתם/אתן' },
    nikud: { m: 'אַתֶּם',   f: 'אַתֶּן',   mf: 'אַתֶּם/אַתֶּן' },
  },
  'OBJ_3S': {
    en:    { m: 'him',      f: 'her',      mf: 'him/her' },
    he:    { m: 'אותו',     f: 'אותה',     mf: 'אותו/אותה' },
    nikud: { m: 'אוֹתוֹ',   f: 'אוֹתָהּ',  mf: 'אוֹתוֹ/אוֹתָהּ' },
  },
  'OBJ_3P': {
    en:    { m: 'them',     f: 'them',     mf: 'them' },
    he:    { m: 'אותם',     f: 'אותן',     mf: 'אותם/אותן' },
    nikud: { m: 'אוֹתָם',   f: 'אוֹתָן',   mf: 'אוֹתָם/אוֹתָן' },
  },
  'SELF': {
    en:    { m: 'himself',  f: 'herself',  mf: 'himself/herself' },
    he:    { m: 'עצמו',     f: 'עצמה',     mf: 'עצמו/עצמה' },
    nikud: { m: 'עַצְמוֹ',  f: 'עַצְמָהּ', mf: 'עַצְמוֹ/עַצְמָהּ' },
  },
  'TITLE': {
    en:    { m: 'Mr.',      f: 'Ms.',      mf: 'Mr./Ms.' },
    he:    { m: 'מר',       f: 'גברת',     mf: 'מר/גברת' },
    nikud: { m: 'מַר',      f: 'גְּבֶרֶת', mf: 'מַר/גְּבֶרֶת' },
  },
  'ROYAL': {
    en:    { m: 'king',     f: 'queen',    mf: 'king/queen' },
    he:    { m: 'מלך',      f: 'מלכה',     mf: 'מלך/מלכה' },
    nikud: { m: 'מֶלֶךְ',   f: 'מַלְכָּה', mf: 'מֶלֶךְ/מַלְכָּה' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════════════════════════

function getMG(key, version, gender) {
  // version: 'en', 'he', 'nikud'
  // gender: 'm', 'f', 'mf'
  const mg = MG_SEMANTIC[key] || MG_WORDS[key];
  if (!mg) return null;
  const v = mg[version];
  if (!v) return null;
  return gender === 'mf' ? v.mf : (gender === 'f' ? v.f : v.m);
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('MG KEYS - 3 VERSIONS: English | Hebrew Plain | Hebrew Nikud');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Key  SEMANTIC        English      Hebrew       Nikud         IPA');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(MG_SEMANTIC).forEach(([key, data]) => {
  const sem = data.semantic.padEnd(14);
  const en = data.en.mf.padEnd(12);
  const he = data.he.mf.padEnd(12);
  const nikud = data.nikud.mf.padEnd(14);
  const ipa = `${data.ipa.m}/${data.ipa.f}`;
  console.log(`[${key}]  ${sem} ${en} ${he} ${nikud} ${ipa}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('MG WORDS - 3 VERSIONS');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

Object.entries(MG_WORDS).forEach(([sem, data]) => {
  console.log(`${sem.padEnd(14)} EN: ${data.en.mf.padEnd(18)} HE: ${data.he.mf.padEnd(14)} NIKUD: ${data.nikud.mf}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('API Examples:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log("getMG('1', 'en', 'm')     →", getMG('1', 'en', 'm'));      // his
console.log("getMG('1', 'he', 'f')     →", getMG('1', 'he', 'f'));      // ה
console.log("getMG('1', 'nikud', 'f')  →", getMG('1', 'nikud', 'f'));   // הּ
console.log("getMG('6', 'en', 'mf')    →", getMG('6', 'en', 'mf'));     // -s
console.log("getMG('6', 'he', 'mf')    →", getMG('6', 'he', 'mf'));     // ים/ות
console.log("getMG('6', 'nikud', 'mf') →", getMG('6', 'nikud', 'mf'));  // ִים/וֹת
console.log("getMG('CHILD', 'en', 'f') →", getMG('CHILD', 'en', 'f'));  // daughter
console.log("getMG('CHILD', 'nikud', 'f') →", getMG('CHILD', 'nikud', 'f')); // בַּת
