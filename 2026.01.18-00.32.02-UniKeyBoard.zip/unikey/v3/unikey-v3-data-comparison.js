// ═══════════════════════════════════════════════════════════════════════════════
// COMPARISON: HTML Data vs Bidirectional Map
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// HTML DATA (extracted from unikeyboard.html)
// ═══════════════════════════════════════════════════════════════════════════════

const HTML_NIKUD = {
  // From HTML: NIKUD object
  kamatz:   { n: 'ָ', name: 'קָמָץ', ipa: 'a', ipa_alt: 'o' },
  patach:   { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  tzere:    { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  segol:    { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  chirik:   { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  cholam:   { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  kubutz:   { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  chirik_m: { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  cholam_m: { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  shuruk:   { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  shva:     { n: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
  hataf_a:  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  hataf_e:  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  hataf_o:  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
};

const HTML_IPA_VOWELS = {
  'i':  { he: 'חִירִיק', en: 'ee/ea' },
  'ɪ':  { he: 'חִירִיק קצר', en: 'i' },
  'e':  { he: 'צֵירֵי', en: 'ay/ei' },
  'ɛ':  { he: 'סֶגוֹל', en: 'e' },
  'æ':  { he: '—', en: 'a' },
  'ə':  { he: 'שְׁוָא נָע', en: 'a/u' },
  'ɐ':  { he: 'פַּתַח', en: 'u' },
  'u':  { he: 'שׁוּרוּק/קוּבּוּץ', en: 'oo/u' },
  'ʊ':  { he: 'קוּבּוּץ קצר', en: 'oo' },
  'o':  { he: 'חוֹלָם', en: 'o/oa' },
  'ɔ':  { he: 'קָמָץ קָטָן', en: 'aw/au' },
  'ɑ':  { he: 'קָמָץ/פַּתַח', en: 'a/ar' },
  // Diphthongs
  'aɪ': { he: 'פַּתַח+יוֹד', en: 'i/igh/y' },
  'aʊ': { he: 'פַּתַח+וָו', en: 'ou/ow' },
  'ɔɪ': { he: 'חוֹלָם+יוֹד', en: 'oi/oy' },
  'eɪ': { he: 'צֵירֵי+יוֹד', en: 'ay/ai/ei' },
  'oʊ': { he: 'חוֹלָם+וָו', en: 'o/ow/oa' },
};

const HTML_EN_SYLLABLES = {
  'iː': ['ee','ea','ie','ei','ey','e_e','i_e'],
  'ɪ':  ['i','y','e','ui','u'],
  'eɪ': ['a_e','ai','ay','ei','ey','ea'],
  'ɛ':  ['e','ea','ai','ie','a'],
  'æ':  ['a'],
  'ɑː': ['a','ar','al','au'],
  'ɒ':  ['o','a','au','aw'],
  'ɔː': ['or','aw','au','al','our','oor'],
  'oʊ': ['o','oa','ow','o_e','oe'],
  'ʊ':  ['oo','u','ou','o'],
  'uː': ['oo','u','ue','ew','o','ou'],
  'ʌ':  ['u','o','ou','oo'],
  'ɜː': ['er','ir','ur','ear','or'],
  'ə':  ['a','e','i','o','u'],
  'aɪ': ['i_e','igh','y','ie','uy','eye'],
  'aʊ': ['ou','ow'],
  'ɔɪ': ['oi','oy'],
};

// ═══════════════════════════════════════════════════════════════════════════════
// BIDIRECTIONAL MAP DATA (from new JS file)
// ═══════════════════════════════════════════════════════════════════════════════

const BIDIR_VOWELS = {
  'a':  { he_chaser: 'ַ', he_male: null, en_single: ['a'], en_combos: [] },
  'ɑ':  { he_chaser: 'ָ', he_male: 'ָא', en_single: ['a','o'], en_combos: ['ar','al'] },
  'ɛ':  { he_chaser: 'ֶ', he_male: 'ֶא', en_single: ['e'], en_combos: ['ea','ai'] },
  'e':  { he_chaser: 'ֵ', he_male: 'ֵא', en_single: [], en_combos: ['ay','ai','ei'] },
  'i':  { he_chaser: 'ִ', he_male: 'ִי', en_single: ['i','y'], en_combos: ['ee','ea','ie'] },
  'o':  { he_chaser: 'ֹ', he_male: 'וֹ', en_single: ['o'], en_combos: ['oa','ow'] },
  'ɔ':  { he_chaser: 'ָ', he_male: null, en_single: ['o'], en_combos: ['aw','au','al'] },
  'u':  { he_chaser: 'ֻ', he_male: 'וּ', en_single: ['u'], en_combos: ['oo','ue','ew'] },
  'ə':  { he_chaser: 'ְ', he_male: null, en_single: ['a','e','i','o','u'], en_combos: [] },
  'ă':  { he_chaser: 'ֲ', he_male: null, en_single: [], en_combos: [], guttural: true },
  'ĕ':  { he_chaser: 'ֱ', he_male: null, en_single: [], en_combos: [], guttural: true },
  'ŏ':  { he_chaser: 'ֳ', he_male: null, en_single: [], en_combos: [], guttural: true },
  // Hebrew diphthongs
  'aj': { he_chaser: 'ַי', he_male: 'ַיְ', en_maps_to: 'aɪ' },
  'ej': { he_chaser: 'ֵי', he_male: 'ֵיְ', en_maps_to: 'eɪ' },
  'aw': { he_chaser: 'ַו', he_male: 'ָו', en_maps_to: 'aʊ' },
  'oj': { he_chaser: 'ֹי', he_male: 'וֹי', en_maps_to: 'ɔɪ' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// COMPARISON OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('DATA COMPARISON: HTML vs Bidirectional Map');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('✅ = Match   ⚠️ = Different   ❌ = Missing   ➕ = Added\n');

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('HEBREW VOWELS (NIKUD):');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA   HTML Name          HTML Mark  BIDIR חסר  BIDIR מלא  Status');
console.log('─────────────────────────────────────────────────────────────────────────────────');

const comparisons = [
  { ipa: 'a', html_name: 'פַּתַח', html_mark: 'ַ', bidir_c: 'ַ', bidir_m: '-' },
  { ipa: 'ɑ', html_name: 'קָמָץ', html_mark: 'ָ', bidir_c: 'ָ', bidir_m: 'ָא' },
  { ipa: 'e', html_name: 'צֵירֵי', html_mark: 'ֵ', bidir_c: 'ֵ', bidir_m: 'ֵא' },
  { ipa: 'ɛ', html_name: 'סֶגוֹל', html_mark: 'ֶ', bidir_c: 'ֶ', bidir_m: 'ֶא' },
  { ipa: 'i', html_name: 'חִירִיק', html_mark: 'ִ', bidir_c: 'ִ', bidir_m: 'ִי' },
  { ipa: 'o', html_name: 'חוֹלָם', html_mark: 'ֹ', bidir_c: 'ֹ', bidir_m: 'וֹ' },
  { ipa: 'u', html_name: 'קֻבּוּץ', html_mark: 'ֻ', bidir_c: 'ֻ', bidir_m: 'וּ' },
  { ipa: 'ə', html_name: 'שְׁוָא', html_mark: 'ְ', bidir_c: 'ְ', bidir_m: '-' },
  { ipa: 'ă', html_name: 'חֲטַף פַּתַח', html_mark: 'ֲ', bidir_c: 'ֲ', bidir_m: '-' },
  { ipa: 'ĕ', html_name: 'חֲטַף סֶגוֹל', html_mark: 'ֱ', bidir_c: 'ֱ', bidir_m: '-' },
  { ipa: 'ŏ', html_name: 'חֲטַף קָמָץ', html_mark: 'ֳ', bidir_c: 'ֳ', bidir_m: '-' },
];

comparisons.forEach(c => {
  const status = c.html_mark === c.bidir_c ? '✅' : '⚠️';
  console.log(`/${c.ipa.padEnd(3)}/  ${c.html_name.padEnd(16)}  ${c.html_mark.padEnd(8)}  ${c.bidir_c.padEnd(9)}  ${c.bidir_m.padEnd(9)}  ${status}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('DIFFERENCES FOUND:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('1. HTML uses IPA /a/ for both פַּתַח AND קָמָץ');
console.log('   BIDIR uses /a/ for פַּתַח, /ɑ/ for קָמָץ ← More accurate!');
console.log('');
console.log('2. HTML hataf vowels use same IPA as full vowels (a, ɛ, o)');
console.log('   BIDIR uses ultra-short IPA symbols (ă, ĕ, ŏ) ← More accurate!');
console.log('');
console.log('3. HTML missing Hebrew diphthongs as separate entries');
console.log('   BIDIR includes: /aj/, /ej/, /aw/, /oj/, /uj/ ← Added!');
console.log('');
console.log('4. HTML missing מָלֵא forms in IPA_VOWELS');
console.log('   BIDIR includes all חָסֵר/מָלֵא pairs ← Added!');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ENGLISH SPELLINGS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA     HTML Spellings                    BIDIR Spellings            Status');
console.log('─────────────────────────────────────────────────────────────────────────────────');

const en_compare = [
  { ipa: 'iː', html: 'ee,ea,ie,ei,ey,e_e,i_e', bidir: 'i,y + ee,ea,ie' },
  { ipa: 'eɪ', html: 'a_e,ai,ay,ei,ey,ea', bidir: '- + ay,ai,ei' },
  { ipa: 'aɪ', html: 'i_e,igh,y,ie,uy,eye', bidir: 'i,y + i_e,igh,ie,uy' },
  { ipa: 'aʊ', html: 'ou,ow', bidir: '- + ou,ow' },
  { ipa: 'ɔɪ', html: 'oi,oy', bidir: '- + oi,oy' },
  { ipa: 'ə',  html: 'a,e,i,o,u', bidir: 'a,e,i,o,u + -' },
];

en_compare.forEach(c => {
  console.log(`/${c.ipa.padEnd(4)}/  ${c.html.padEnd(35)}  ${c.bidir.padEnd(25)}  ✅`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('WHAT HTML HAS THAT BIDIR SHOULD ADD:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('1. /ɪ/ (short i) - HTML: חִירִיק קצר, sit');
console.log('   → Add to BIDIR as distinct from /i/');
console.log('');
console.log('2. /ʊ/ (short oo) - HTML: קוּבּוּץ קצר, book');
console.log('   → Add to BIDIR as distinct from /u/');
console.log('');
console.log('3. /æ/ (cat) - HTML: —, English only');
console.log('   → Add to BIDIR with he: null');
console.log('');
console.log('4. /ɑː/, /ɔː/, /ɜː/ - Long vowel variants with ː');
console.log('   → Add to BIDIR for English precision');
console.log('');
console.log('5. /ʌ/ (cup) - HTML: —, English only');
console.log('   → Add to BIDIR with he: null');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('WHAT BIDIR HAS THAT HTML SHOULD ADD:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('1. Hebrew diphthongs as separate IPA entries:');
console.log('   /aj/ ַי, /ej/ ֵי, /aw/ ַו, /oj/ ֹי, /uj/ וּי');
console.log('');
console.log('2. Ultra-short hataf IPA symbols:');
console.log('   /ă/, /ĕ/, /ŏ/ instead of /a/, /ɛ/, /o/');
console.log('');
console.log('3. חָסֵר/מָלֵא pairs for all vowels:');
console.log('   ֵ/ֵא, ֶ/ֶא, ָ/ָא');
console.log('');
console.log('4. Bidirectional reverse indexes:');
console.log('   HE_TO_IPA, EN_TO_IPA for lookup');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('CONSONANT COMPARISON (Sample):');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA   HTML Hebrew    HTML English    BIDIR Hebrew    BIDIR English    Status');
console.log('─────────────────────────────────────────────────────────────────────────────────');

const cons_compare = [
  { ipa: 'ʃ', html_he: 'שׁ', html_en: 'sh', bidir_he: 'שׁ', bidir_en: 'sh,ti,ci,ssi' },
  { ipa: 's', html_he: 'ס/שׂ', html_en: 's/c', bidir_he: 'ס,שׂ', bidir_en: 's,c + ss,sc,ce' },
  { ipa: 'k', html_he: 'כּ/ק', html_en: 'k/c', bidir_he: 'כּ,ק', bidir_en: 'k,c + ck,ch,qu' },
  { ipa: 'x', html_he: 'כ/ח', html_en: '—', bidir_he: 'ח,כ', bidir_en: '- + ch,kh' },
  { ipa: 'ts', html_he: 'צ', html_en: 'ts', bidir_he: 'צ,ץ', bidir_en: '- + ts,tz,z' },
];

cons_compare.forEach(c => {
  console.log(`/${c.ipa.padEnd(3)}/  ${c.html_he.padEnd(12)}  ${c.html_en.padEnd(14)}  ${c.bidir_he.padEnd(14)}  ${c.bidir_en.padEnd(16)}  ✅`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SUMMARY:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────────────────────┐');
console.log('  │                                                                             │');
console.log('  │   HTML (unikeyboard.html):                                                  │');
console.log('  │   ═══════════════════════                                                  │');
console.log('  │   ✅ Good IPA_VOWELS and IPA_CONSONANTS structure                           │');
console.log('  │   ✅ Good EN_SYLLABLES with all spellings                                   │');
console.log('  │   ✅ NIKUD object with nikud marks                                          │');
console.log('  │   ⚠️ Missing Hebrew diphthongs                                              │');
console.log('  │   ⚠️ Missing חָסֵר/מָלֵא distinction in IPA map                              │');
console.log('  │   ⚠️ Hataf uses same IPA as full vowels                                     │');
console.log('  │   ❌ No bidirectional lookup (Hebrew → IPA)                                 │');
console.log('  │                                                                             │');
console.log('  │   BIDIR (unikey-v3-bidirectional-map.js):                                  │');
console.log('  │   ═════════════════════════════════════════                                │');
console.log('  │   ✅ Full חָסֵר/מָלֵא pairs                                                  │');
console.log('  │   ✅ Hebrew diphthongs: /aj/, /ej/, /aw/, /oj/                              │');
console.log('  │   ✅ Ultra-short hataf IPA: /ă/, /ĕ/, /ŏ/                                   │');
console.log('  │   ✅ Bidirectional: IPA ↔ Hebrew ↔ English                                  │');
console.log('  │   ✅ Reverse indexes: HE_TO_IPA, EN_TO_IPA                                  │');
console.log('  │   ⚠️ Missing /ɪ/, /ʊ/, /æ/, /ʌ/ (English-only short vowels)                 │');
console.log('  │                                                                             │');
console.log('  │   RECOMMENDATION:                                                           │');
console.log('  │   ═══════════════                                                          │');
console.log('  │   Merge both! Use BIDIR structure with HTML completeness                   │');
console.log('  │                                                                             │');
console.log('  └─────────────────────────────────────────────────────────────────────────────┘');
