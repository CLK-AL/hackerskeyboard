// ═══════════════════════════════════════════════════════════════════════════
// UNIKEY v3 - FULL IPA IMPLEMENTATION
// ═══════════════════════════════════════════════════════════════════════════
//
// ALL syllables: Hebrew + English, unified through IPA
// 12 MG pairs included as subset
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// IPA VOWELS → Hebrew Nikud / English Spelling
// ═══════════════════════════════════════════════════════════════════════════

const IPA_VOWELS = {
  'a':  { he: 'ַ', he_name: 'patach', en: 'a', ex_he: 'פַּת', ex_en: 'cat' },
  'ɑ':  { he: 'ָ', he_name: 'kamatz', en: 'a,o', ex_he: 'קָם', ex_en: 'father' },
  'e':  { he: 'ֶ', he_name: 'segol', en: 'e', ex_he: 'סֶפֶר', ex_en: 'bed' },
  'ɛ':  { he: 'ֵ', he_name: 'tzere', en: 'e,ei', ex_he: 'שֵׁם', ex_en: 'they' },
  'i':  { he: 'ִ', he_name: 'chirik', en: 'i,ee', ex_he: 'מִי', ex_en: 'see' },
  'o':  { he: 'ֹ', he_name: 'cholam', en: 'o', ex_he: 'שָׁלוֹם', ex_en: 'go' },
  'u':  { he: 'ֻ', he_name: 'kubutz', en: 'u,oo', ex_he: 'קוּם', ex_en: 'blue' },
  'ə':  { he: 'ְ', he_name: 'shva', en: 'e,a', ex_he: 'בְּ', ex_en: 'about' },
  'ɔ':  { he: 'ָ', he_name: 'kamatz', en: 'aw,o', ex_he: 'כָּל', ex_en: 'law' },
  'æ':  { he: 'ַ', he_name: 'patach', en: 'a', ex_he: 'פַּת', ex_en: 'cat' },
  'ʊ':  { he: 'ֻ', he_name: 'kubutz', en: 'oo,u', ex_he: 'סֻכָּה', ex_en: 'book' },
  'ɪ':  { he: 'ִ', he_name: 'chirik', en: 'i', ex_he: 'בִּית', ex_en: 'bit' },
};

// ═══════════════════════════════════════════════════════════════════════════
// IPA CONSONANTS → Hebrew / English
// ═══════════════════════════════════════════════════════════════════════════

const IPA_CONSONANTS = {
  // Stops
  'b':  { he: 'בּ', he_plain: 'ב', en: 'b' },
  'p':  { he: 'פּ', he_plain: 'פ', en: 'p' },
  'd':  { he: 'ד', he_plain: 'ד', en: 'd' },
  't':  { he: 'ת', he_plain: 'ת', en: 't' },
  'g':  { he: 'גּ', he_plain: 'ג', en: 'g' },
  'k':  { he: 'כּ', he_plain: 'כ', en: 'k,c' },
  'ʔ':  { he: 'א', he_plain: 'א', en: "'" },
  
  // Fricatives
  'v':  { he: 'ב', he_plain: 'ב', en: 'v' },
  'f':  { he: 'פ', he_plain: 'פ', en: 'f,ph' },
  'z':  { he: 'ז', he_plain: 'ז', en: 'z' },
  's':  { he: 'ס', he_plain: 'ס', en: 's,c' },
  'ʃ':  { he: 'שׁ', he_plain: 'ש', en: 'sh' },
  'ʒ':  { he: 'ז׳', he_plain: 'ז', en: 'zh,s' },
  'x':  { he: 'ח', he_plain: 'ח', en: 'ch' },
  'h':  { he: 'ה', he_plain: 'ה', en: 'h' },
  'ʕ':  { he: 'ע', he_plain: 'ע', en: "'" },
  
  // Sonorants
  'm':  { he: 'מ', he_plain: 'מ', he_final: 'ם', en: 'm' },
  'n':  { he: 'נ', he_plain: 'נ', he_final: 'ן', en: 'n' },
  'l':  { he: 'ל', he_plain: 'ל', en: 'l' },
  'r':  { he: 'ר', he_plain: 'ר', en: 'r' },
  'j':  { he: 'י', he_plain: 'י', en: 'y' },
  'w':  { he: 'ו', he_plain: 'ו', en: 'w' },
  
  // Affricates
  'ts': { he: 'צ', he_plain: 'צ', he_final: 'ץ', en: 'ts,tz' },
  'tʃ': { he: 'צ׳', he_plain: 'צ', en: 'ch,tch' },
  'dʒ': { he: 'ג׳', he_plain: 'ג', en: 'j,dg' },
  
  // English only
  'θ':  { he: 'ת', he_plain: 'ת', en: 'th' },
  'ð':  { he: 'ד', he_plain: 'ד', en: 'th' },
  'ŋ':  { he: 'נג', he_plain: 'נ', en: 'ng' },
};

// ═══════════════════════════════════════════════════════════════════════════
// CV SYLLABLES (Consonant + Vowel)
// ═══════════════════════════════════════════════════════════════════════════

function generateCVSyllables() {
  const syllables = {};
  
  Object.entries(IPA_CONSONANTS).forEach(([c, cData]) => {
    Object.entries(IPA_VOWELS).forEach(([v, vData]) => {
      const ipa = c + v;
      syllables[ipa] = {
        ipa,
        he: cData.he + vData.he,
        he_plain: cData.he_plain,
        en: cData.en + vData.en.split(',')[0],
        nikud: vData.he_name,
      };
    });
  });
  
  return syllables;
}

const CV_SYLLABLES = generateCVSyllables();

// ═══════════════════════════════════════════════════════════════════════════
// 12 MG PAIRS (Gender Syllable Pairs)
// ═══════════════════════════════════════════════════════════════════════════

const MG_12 = {
  1:  { m: { p: 'ו', n: 'וֹ', ipa: 'o' },    f: { p: 'ה', n: 'ָהּ', ipa: 'a' } },
  2:  { m: { p: 'ם', n: 'ָם', ipa: 'am' },   f: { p: 'ן', n: 'ָן', ipa: 'an' } },
  3:  { m: { p: 'ד', n: 'ֵד', ipa: 'ed' },   f: { p: 'ת', n: 'ֶת', ipa: 'et' } },
  4:  { m: { p: 'י', n: 'יִ', ipa: 'ji' },   f: { p: 'ת', n: 'תִּ', ipa: 'ti' } },
  5:  { m: { p: 'ים', n: 'ִים', ipa: 'im' }, f: { p: 'ות', n: 'וֹת', ipa: 'ot' } },
  6:  { m: { p: 'ן', n: 'ָן', ipa: 'an' },   f: { p: 'נית', n: 'נִית', ipa: 'nit' } },
  7:  { m: { p: 'י', n: 'ִי', ipa: 'i' },    f: { p: 'ית', n: 'ִית', ipa: 'it' } },
  8:  { m: { p: 'יו', n: 'ָיו', ipa: 'av' }, f: { p: 'יה', n: 'ֶיהָ', ipa: 'eha' } },
  9:  { m: { p: 'יהם', n: 'ֵיהֶם', ipa: 'ehem' }, f: { p: 'יהן', n: 'ֵיהֶן', ipa: 'ehen' } },
  10: { m: { p: 'כם', n: 'כֶם', ipa: 'xem' }, f: { p: 'כן', n: 'כֶן', ipa: 'xen' } },
  11: { m: { p: 'הוא', n: 'הוּא', ipa: 'hu' }, f: { p: 'היא', n: 'הִיא', ipa: 'hi' } },
  12: { m: { p: 'אתה', n: 'אַתָּה', ipa: 'ata' }, f: { p: 'את', n: 'אַתְּ', ipa: 'at' } },
  
  // English equivalents
  'en-1': { m: { p: 'he', ipa: 'hi' }, f: { p: 'she', ipa: 'ʃi' } },
  'en-2': { m: { p: 'him', ipa: 'hɪm' }, f: { p: 'her', ipa: 'hɜr' } },
  'en-3': { m: { p: 'his', ipa: 'hɪz' }, f: { p: 'her', ipa: 'hɜr' } },
  'en-4': { m: { p: 'man', ipa: 'mæn' }, f: { p: 'woman', ipa: 'wʊmən' } },
  'en-5': { m: { p: 'men', ipa: 'mɛn' }, f: { p: 'women', ipa: 'wɪmɪn' } },
  'en-6': { m: { p: 'son', ipa: 'sʌn' }, f: { p: 'daughter', ipa: 'dɔtər' } },
  'en-7': { m: { p: 'actor', ipa: 'æktər' }, f: { p: 'actress', ipa: 'æktrəs' } },
  'en-8': { m: { p: 'king', ipa: 'kɪŋ' }, f: { p: 'queen', ipa: 'kwin' } },
};

// ═══════════════════════════════════════════════════════════════════════════
// COMMON SYLLABLES (High frequency)
// ═══════════════════════════════════════════════════════════════════════════

const COMMON_HE = {
  // Prefixes
  'ב': { p: 'בְּ', n: 'בְּ', ipa: 'bə', type: 'prefix' },
  'ל': { p: 'לְ', n: 'לְ', ipa: 'lə', type: 'prefix' },
  'מ': { p: 'מִ', n: 'מִ', ipa: 'mi', type: 'prefix' },
  'ה': { p: 'הַ', n: 'הַ', ipa: 'ha', type: 'prefix' },
  'ו': { p: 'וְ', n: 'וְ', ipa: 'və', type: 'prefix' },
  'כ': { p: 'כְּ', n: 'כְּ', ipa: 'kə', type: 'prefix' },
  'ש': { p: 'שֶׁ', n: 'שֶׁ', ipa: 'ʃe', type: 'prefix' },
  
  // Common endings
  'תי': { p: 'תִּי', n: 'תִּי', ipa: 'ti', type: 'suffix', tense: 'past' },
  'ת_2s': { p: 'תָּ', n: 'תָּ', ipa: 'ta', type: 'suffix', tense: 'past' },
  'נו': { p: 'נוּ', n: 'נוּ', ipa: 'nu', type: 'suffix', tense: 'past' },
  'תם': { p: 'תֶּם', n: 'תֶּם', ipa: 'tem', type: 'suffix', tense: 'past' },
  
  // Patterns
  'מת': { p: 'מַ', n: 'מַ', ipa: 'ma', type: 'pattern', binyan: 'hifil' },
  'הת': { p: 'הִתְ', n: 'הִתְ', ipa: 'hit', type: 'pattern', binyan: 'hitpael' },
  'נ_p': { p: 'נִ', n: 'נִ', ipa: 'ni', type: 'pattern', binyan: 'nifal' },
};

const COMMON_EN = {
  // Prefixes
  'un': { p: 'un', ipa: 'ʌn', type: 'prefix' },
  're': { p: 're', ipa: 'ri', type: 'prefix' },
  'pre': { p: 'pre', ipa: 'pri', type: 'prefix' },
  'dis': { p: 'dis', ipa: 'dɪs', type: 'prefix' },
  
  // Suffixes
  'ing': { p: 'ing', ipa: 'ɪŋ', type: 'suffix' },
  'ed': { p: 'ed', ipa: 'əd', type: 'suffix' },
  'er': { p: 'er', ipa: 'ər', type: 'suffix' },
  'est': { p: 'est', ipa: 'əst', type: 'suffix' },
  'ly': { p: 'ly', ipa: 'li', type: 'suffix' },
  'tion': { p: 'tion', ipa: 'ʃən', type: 'suffix' },
  'ness': { p: 'ness', ipa: 'nəs', type: 'suffix' },
  'ment': { p: 'ment', ipa: 'mənt', type: 'suffix' },
  'able': { p: 'able', ipa: 'əbəl', type: 'suffix' },
  's': { p: 's', ipa: 'z', type: 'suffix', grammar: 'plural' },
  'es': { p: 'es', ipa: 'ɪz', type: 'suffix', grammar: 'plural' },
};

// ═══════════════════════════════════════════════════════════════════════════
// UNIKEY API
// ═══════════════════════════════════════════════════════════════════════════

const UniKey = {
  // Get syllable by IPA
  byIPA(ipa) {
    return CV_SYLLABLES[ipa] || null;
  },
  
  // Get MG pair
  mg(key, gender = null, nikud = false) {
    const pair = MG_12[key];
    if (!pair) return null;
    if (gender) {
      const g = pair[gender];
      return nikud ? g.n : g.p;
    }
    const m = nikud ? pair.m.n : pair.m.p;
    const f = nikud ? pair.f.n : pair.f.p;
    return `${m}/${f}`;
  },
  
  // IPA to Hebrew
  toHebrew(ipa, withNikud = true) {
    let result = '';
    let i = 0;
    while (i < ipa.length) {
      // Try 2-char first (ts, tʃ, etc)
      const two = ipa.slice(i, i + 2);
      const one = ipa[i];
      
      if (CV_SYLLABLES[two]) {
        result += withNikud ? CV_SYLLABLES[two].he : CV_SYLLABLES[two].he_plain;
        i += 2;
      } else if (IPA_CONSONANTS[two]) {
        result += withNikud ? IPA_CONSONANTS[two].he : IPA_CONSONANTS[two].he_plain;
        i += 2;
      } else if (IPA_CONSONANTS[one]) {
        result += withNikud ? IPA_CONSONANTS[one].he : IPA_CONSONANTS[one].he_plain;
        i++;
      } else if (IPA_VOWELS[one]) {
        result += IPA_VOWELS[one].he;
        i++;
      } else {
        i++;
      }
    }
    return result;
  },
  
  // IPA to English
  toEnglish(ipa) {
    let result = '';
    let i = 0;
    while (i < ipa.length) {
      const two = ipa.slice(i, i + 2);
      const one = ipa[i];
      
      if (IPA_CONSONANTS[two]) {
        result += IPA_CONSONANTS[two].en.split(',')[0];
        i += 2;
      } else if (IPA_CONSONANTS[one]) {
        result += IPA_CONSONANTS[one].en.split(',')[0];
        i++;
      } else if (IPA_VOWELS[one]) {
        result += IPA_VOWELS[one].en.split(',')[0];
        i++;
      } else {
        result += one;
        i++;
      }
    }
    return result;
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIKEY v3 - FULL IPA IMPLEMENTATION');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('STATS:');
console.log(`  Vowels:      ${Object.keys(IPA_VOWELS).length}`);
console.log(`  Consonants:  ${Object.keys(IPA_CONSONANTS).length}`);
console.log(`  CV Syllables: ${Object.keys(CV_SYLLABLES).length}`);
console.log(`  MG Pairs:    ${Object.keys(MG_12).length}`);
console.log(`  Common HE:   ${Object.keys(COMMON_HE).length}`);
console.log(`  Common EN:   ${Object.keys(COMMON_EN).length}`);

console.log('\n───────────────────────────────────────────────────────────────');
console.log('IPA VOWELS:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('IPA   Hebrew   Name       English   Example');
console.log('───   ──────   ────       ───────   ───────');
Object.entries(IPA_VOWELS).forEach(([ipa, v]) => {
  console.log(`/${ipa}/   ${v.he}        ${v.he_name.padEnd(10)} ${v.en.padEnd(9)} ${v.ex_en}`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('12 MG PAIRS (Hebrew):');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('Key   Plain      Nikud       IPA');
console.log('───   ─────      ─────       ───');
for (let i = 1; i <= 12; i++) {
  const p = MG_12[i];
  console.log(`${i.toString().padStart(2)}    ${(p.m.p + '/' + p.f.p).padEnd(10)} ${(p.m.n + '/' + p.f.n).padEnd(11)} ${p.m.ipa}/${p.f.ipa}`);
}

console.log('\n───────────────────────────────────────────────────────────────');
console.log('12 MG PAIRS (English):');
console.log('───────────────────────────────────────────────────────────────\n');

Object.entries(MG_12).filter(([k]) => k.startsWith('en')).forEach(([k, p]) => {
  console.log(`${k.padEnd(6)} ${(p.m.p + '/' + p.f.p).padEnd(20)} ${p.m.ipa}/${p.f.ipa}`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('IPA → Hebrew/English:');
console.log('───────────────────────────────────────────────────────────────\n');

const examples = ['ʃalom', 'talmid', 'sefer', 'student', 'teacher'];
examples.forEach(ipa => {
  console.log(`/${ipa}/ → HE: ${UniKey.toHebrew(ipa)} | EN: ${UniKey.toEnglish(ipa)}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('UNIFIED KEYBOARD STRUCTURE');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
┌─────────────────────────────────────────────────────────────────────────┐
│                           UNIKEY KEYBOARD                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  NUMBER ROW (Alt = MG pairs):                                          │
│  ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐         │
│  │ 1  │ 2  │ 3  │ 4  │ 5  │ 6  │ 7  │ 8  │ 9  │ 0  │ -  │ =  │         │
│  │ו/ה │ם/ן │ד/ת │י/ת │ים/ות│ן/נית│י/ית│יו/יה│יהם/ן│כם/כן│הוא/י│אתה/ת│         │
│  └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘         │
│                                                                         │
│  LETTER ROWS (IPA-based):                                              │
│  ┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐                   │
│  │ Q  │ W  │ E  │ R  │ T  │ Y  │ U  │ I  │ O  │ P  │                   │
│  │ ק  │ ו  │ א  │ ר  │ ת  │ י  │ ו  │ י  │ ו  │ פ  │                   │
│  │/k/ │/v/ │/e/ │/r/ │/t/ │/j/ │/u/ │/i/ │/o/ │/p/ │                   │
│  └────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘                   │
│  ┌────┬────┬────┬────┬────┬────┬────┬────┬────┐                        │
│  │ A  │ S  │ D  │ F  │ G  │ H  │ J  │ K  │ L  │                        │
│  │ א  │ ס  │ ד  │ פ  │ ג  │ ה  │ י  │ כ  │ ל  │                        │
│  │/a/ │/s/ │/d/ │/f/ │/g/ │/h/ │/j/ │/k/ │/l/ │                        │
│  └────┴────┴────┴────┴────┴────┴────┴────┴────┘                        │
│  ┌────┬────┬────┬────┬────┬────┬────┐                                  │
│  │ Z  │ X  │ C  │ V  │ B  │ N  │ M  │                                  │
│  │ ז  │ ח  │ צ  │ ב  │ ב  │ נ  │ מ  │                                  │
│  │/z/ │/x/ │/ts/│/v/ │/b/ │/n/ │/m/ │                                  │
│  └────┴────┴────┴────┴────┴────┴────┘                                  │
│                                                                         │
│  MODIFIERS:                                                            │
│    Normal     = Hebrew plain                                           │
│    Shift      = Hebrew shift / caps                                    │
│    Alt        = MG pair (numbers) / Syllable (letters)                │
│    Alt+Shift  = MG nikud / Syllable nikud                             │
│    Ctrl       = IPA symbol                                             │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
`);
