// ═══════════════════════════════════════════════════════════════════════════
// UNIKEY v3 - FINAL MODEL
// ═══════════════════════════════════════════════════════════════════════════
//
//   IPA = Bridge between Hebrew & English
//   SYLLABLE = Base unit
//   MODIFIERS = nikud, gender, number, tense, position
//
//   MG = NOT a new structure, just TWO KEYS with pair relationship
//
// ═══════════════════════════════════════════════════════════════════════════

/*
┌─────────────────────────────────────────────────────────────────────────────┐
│                              ARCHITECTURE                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│     ┌─────────┐         ┌─────────┐                                        │
│     │ English │ ←──────→│   IPA   │←───────→ ┌─────────┐                   │
│     │   Key   │         │ /a/ /b/ │          │ Hebrew  │                   │
│     └─────────┘         └─────────┘          │   Key   │                   │
│                              │               └─────────┘                   │
│                              ▼                                              │
│                    ┌─────────────────┐                                      │
│                    │    SYLLABLE     │                                      │
│                    │  { p, n, ipa }  │                                      │
│                    └────────┬────────┘                                      │
│                             │                                               │
│           ┌─────────────────┼─────────────────┐                             │
│           ▼                 ▼                 ▼                             │
│     ┌──────────┐     ┌──────────┐     ┌──────────┐                         │
│     │  nikud   │     │  gender  │     │  number  │  ...more modifiers     │
│     │  ניקוד   │     │  מין     │     │  מספר    │                         │
│     └──────────┘     └──────────┘     └──────────┘                         │
│                             │                                               │
│                             ▼                                               │
│                      ┌──────────┐                                           │
│                      │   pair   │  ← MG is just this!                      │
│                      │  (m↔f)   │                                           │
│                      └──────────┘                                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘

MODIFIERS (like nikud, but for grammar):

  ┌────────────┬────────────────────────────────────────────────────────────┐
  │ Modifier   │ Values                                                     │
  ├────────────┼────────────────────────────────────────────────────────────┤
  │ nikud      │ kamatz, patach, segol, tzere, chirik, cholam, kubutz, shva│
  │ gender     │ m, f                                                       │
  │ number     │ sg, pl                                                     │
  │ tense      │ past, pres, fut                                            │
  │ position   │ prefix, suffix, middle                                     │
  │ person     │ 1, 2, 3                                                    │
  └────────────┴────────────────────────────────────────────────────────────┘

*/

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLE DATABASE
// ═══════════════════════════════════════════════════════════════════════════

const S = {
  // Hebrew endings - each has pair for MG
  'ו':   { p:'ו',   n:'וֹ',   ipa:'o',   g:'m', pair:'ה',   pos:'suf' },
  'ה':   { p:'ה',   n:'ָהּ',  ipa:'a',   g:'f', pair:'ו',   pos:'suf' },
  'ם':   { p:'ם',   n:'ָם',   ipa:'am',  g:'m', pair:'ן',   pos:'suf', num:'pl' },
  'ן':   { p:'ן',   n:'ָן',   ipa:'an',  g:'f', pair:'ם',   pos:'suf', num:'pl' },
  'ים':  { p:'ים',  n:'ִים',  ipa:'im',  g:'m', pair:'ות',  pos:'suf', num:'pl' },
  'ות':  { p:'ות',  n:'וֹת',  ipa:'ot',  g:'f', pair:'ים',  pos:'suf', num:'pl' },
  'ד':   { p:'ד',   n:'ֵד',   ipa:'ed',  g:'m', pair:'ת',   pos:'suf' },
  'ת':   { p:'ת',   n:'ֶת',   ipa:'et',  g:'f', pair:'ד',   pos:'suf' },
  'נית': { p:'נית', n:'נִית', ipa:'nit', g:'f', pair:'ן2',  pos:'suf' },
  'ן2':  { p:'ן',   n:'ָן',   ipa:'an',  g:'m', pair:'נית', pos:'suf' },
  
  // Hebrew verb prefixes
  'י':   { p:'י',   n:'יִ',   ipa:'ji',  g:'m', pair:'ת2',  pos:'pre', tense:'fut' },
  'ת2':  { p:'ת',   n:'תִּ',  ipa:'ti',  g:'f', pair:'י',   pos:'pre', tense:'fut' },
  
  // Same letter, different nikud (present tense)
  'הֶ':  { p:'ה',   n:'ֶה',   ipa:'e',   g:'m', pair:'הָ',  pos:'suf', tense:'pres' },
  'הָ':  { p:'ה',   n:'ָה',   ipa:'a',   g:'f', pair:'הֶ',  pos:'suf', tense:'pres' },
  
  // Same letter, different nikud (2nd person)
  'ךָ':  { p:'ך',   n:'ְךָ',  ipa:'xa',  g:'m', pair:'ךְ',  pos:'suf', per:2 },
  'ךְ':  { p:'ך',   n:'ֵךְ',  ipa:'ex',  g:'f', pair:'ךָ',  pos:'suf', per:2 },
};

// ═══════════════════════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════════════════════

const syl = (id, n=false) => S[id] ? (n ? S[id].n : S[id].p) : id;
const ipa = (id) => S[id]?.ipa || '';
const pair = (id) => S[id]?.pair;
const mf = (id, n=false) => {
  const s = S[id];
  if (!s?.pair) return syl(id, n);
  const [m, f] = s.g === 'm' ? [id, s.pair] : [s.pair, id];
  return `${syl(m,n)}/${syl(f,n)}`;
};

// Query by properties
const find = (props) => Object.entries(S)
  .filter(([k,v]) => Object.entries(props).every(([p,val]) => v[p] === val))
  .map(([k]) => k);

// ═══════════════════════════════════════════════════════════════════════════
// DEMO
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIKEY v3 - Syllables with Modifiers');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('KEY INSIGHT:');
console.log('  Nikud    = modifier on letter  →  בָּ בַּ בֶּ');
console.log('  Gender   = modifier on syl     →  ו/ה ם/ן ים/ות');
console.log('  Number   = modifier on syl     →  sg/pl');
console.log('  MG       = just TWO KEYS with pair!\n');

console.log('───────────────────────────────────────────────────────────────');
console.log('Query Examples:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('Male suffixes:    ', find({g:'m', pos:'suf'}).join(', '));
console.log('Female suffixes:  ', find({g:'f', pos:'suf'}).join(', '));
console.log('Plural:           ', find({num:'pl'}).join(', '));
console.log('Future prefix:    ', find({tense:'fut'}).join(', '));
console.log('Present suffix:   ', find({tense:'pres'}).join(', '));
console.log('2nd person:       ', find({per:2}).join(', '));

console.log('\n───────────────────────────────────────────────────────────────');
console.log('MG = Just get pair:');
console.log('───────────────────────────────────────────────────────────────\n');

['ו', 'ם', 'ים', 'ד', 'י', 'הֶ', 'ךָ'].forEach(id => {
  console.log(`${id.padEnd(4)} → pair: ${pair(id).padEnd(4)} → mf: ${mf(id).padEnd(8)} → nikud: ${mf(id,true)}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('SIMPLIFICATION:');
console.log('  OLD: Separate MG_DATA, SYL_DATA, etc.');
console.log('  NEW: One S{} with modifiers. MG = pair lookup.');
console.log('═══════════════════════════════════════════════════════════════');
