// ═══════════════════════════════════════════════════════════════════════════
// AUTO NIKUD: IPA → Syllables → Automatic Correct Nikud
// ═══════════════════════════════════════════════════════════════════════════
//
// Each syllable CARRIES its nikud rules
// Combining syllables = automatic correct result
// Works for ANY length - like English spelling patterns
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLE DATABASE - Each carries its rules
// ═══════════════════════════════════════════════════════════════════════════

const SYL = {
  // Consonants with following vowel nikud
  'ba': { p: 'בַּ', plain: 'ב', ipa: 'ba' },
  'be': { p: 'בֶּ', plain: 'ב', ipa: 'be' },
  'bi': { p: 'בִּ', plain: 'ב', ipa: 'bi' },
  'bo': { p: 'בֹּ', plain: 'ב', ipa: 'bo' },
  'bu': { p: 'בֻּ', plain: 'ב', ipa: 'bu' },
  'bə': { p: 'בְּ', plain: 'ב', ipa: 'bə' },
  
  'ta': { p: 'תַּ', plain: 'ת', ipa: 'ta' },
  'te': { p: 'תֶּ', plain: 'ת', ipa: 'te' },
  'ti': { p: 'תִּ', plain: 'ת', ipa: 'ti' },
  
  'la': { p: 'לַ', plain: 'ל', ipa: 'la' },
  'le': { p: 'לֶ', plain: 'ל', ipa: 'le' },
  'li': { p: 'לִ', plain: 'ל', ipa: 'li' },
  'lo': { p: 'לֹ', plain: 'ל', ipa: 'lo' },
  'lə': { p: 'לְ', plain: 'ל', ipa: 'lə' },
  
  'ma': { p: 'מַ', plain: 'מ', ipa: 'ma' },
  'me': { p: 'מֶ', plain: 'מ', ipa: 'me' },
  'mi': { p: 'מִ', plain: 'מ', ipa: 'mi' },
  'mo': { p: 'מֹ', plain: 'מ', ipa: 'mo' },
  
  'da': { p: 'דַ', plain: 'ד', ipa: 'da' },
  'di': { p: 'דִ', plain: 'ד', ipa: 'di' },
  
  'sa': { p: 'סַ', plain: 'ס', ipa: 'sa' },
  'se': { p: 'סֶ', plain: 'ס', ipa: 'se' },
  
  'pa': { p: 'פַּ', plain: 'פ', ipa: 'pa' },
  'pe': { p: 'פֶּ', plain: 'פ', ipa: 'pe' },
  
  'ra': { p: 'רַ', plain: 'ר', ipa: 'ra' },
  're': { p: 'רֶ', plain: 'ר', ipa: 're' },
  
  'ša': { p: 'שַׁ', plain: 'ש', ipa: 'ʃa' },
  'ši': { p: 'שִׁ', plain: 'ש', ipa: 'ʃi' },
  
  // Final consonants
  'd_': { p: 'ד', plain: 'ד', ipa: 'd', final: true },
  'r_': { p: 'ר', plain: 'ר', ipa: 'r', final: true },
  'm_': { p: 'ם', plain: 'ם', ipa: 'm', final: true },
  'n_': { p: 'ן', plain: 'ן', ipa: 'n', final: true },
  
  // Gender suffixes (from 19 Ivrita patterns!)
  'im': { p: 'ִים', plain: 'ים', ipa: 'im', gender: 'm', num: 'pl' },
  'ot': { p: 'וֹת', plain: 'ות', ipa: 'ot', gender: 'f', num: 'pl' },
  'a_f': { p: 'ָה', plain: 'ה', ipa: 'a', gender: 'f' },
  'et': { p: 'ֶת', plain: 'ת', ipa: 'et', gender: 'f' },
  'o_m': { p: 'וֹ', plain: 'ו', ipa: 'o', gender: 'm', poss: true },
  'a_poss': { p: 'ָהּ', plain: 'ה', ipa: 'a', gender: 'f', poss: true },
};

// ═══════════════════════════════════════════════════════════════════════════
// BUILD WORD FROM IPA SEQUENCE
// ═══════════════════════════════════════════════════════════════════════════

function buildWord(syllables, withNikud = true) {
  return syllables.map(s => {
    const syl = SYL[s];
    return syl ? (withNikud ? syl.p : syl.plain) : s;
  }).join('');
}

console.log('═══════════════════════════════════════════════════════════════');
console.log('AUTO NIKUD: Syllables carry their rules');
console.log('═══════════════════════════════════════════════════════════════\n');

const words = [
  { name: 'תלמיד', syls: ['ta', 'lə', 'mi', 'd_'] },
  { name: 'תלמידה', syls: ['ta', 'lə', 'mi', 'da', 'a_f'] },
  { name: 'תלמידים', syls: ['ta', 'lə', 'mi', 'di', 'im'] },
  { name: 'תלמידות', syls: ['ta', 'lə', 'mi', 'do', 'ot'] },
  { name: 'מורה', syls: ['mo', 're', 'a_f'] },
  { name: 'ספר', syls: ['se', 'pe', 'r_'] },
  { name: 'שלום', syls: ['ša', 'lo', 'm_'] },
  { name: 'שלו', syls: ['še', 'lo', 'o_m'] },
  { name: 'שלה', syls: ['še', 'la', 'a_poss'] },
];

console.log('IPA syllables → nikud → plain:\n');
words.forEach(w => {
  const nikud = buildWord(w.syls, true);
  const plain = buildWord(w.syls, false);
  console.log(`  ${w.syls.join('-').padEnd(25)} → ${nikud.padEnd(12)} → ${plain}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('THE 19 SUFFIX PATTERNS = COMPLETE COVERAGE');
console.log('═══════════════════════════════════════════════════════════════\n');

const patterns = [
  { id: 1, m: '', f: 'ה', ex: 'תלמיד.ה', type: 'noun-sg' },
  { id: 2, m: '', f: 'ת', ex: 'נהג.ת', type: 'noun-sg' },
  { id: 3, m: 'ן', f: 'ת', ex: 'בן.ת', type: 'noun-sg' },
  { id: 4, m: 'ן', f: 'נית', ex: 'שחקן.ית', type: 'profession' },
  { id: 5, m: 'ן', f: 'נה', ex: 'אמן.ה', type: 'profession' },
  { id: 6, m: 'ה', f: 'ה', ex: 'מורֶה.ָה', type: 'present' },
  { id: 7, m: 'ים', f: 'ות', ex: 'תלמידים.ות', type: 'plural' },
  { id: 8, m: 'ו', f: 'ה', ex: 'שלו.ה', type: 'poss-3s' },
  { id: 9, m: 'ם', f: 'ן', ex: 'שלהם.ן', type: 'poss-3p' },
  { id: 10, m: 'ך', f: 'ך', ex: 'שלךָ.ְ', type: 'poss-2s' },
  { id: 11, m: 'י', f: 'ת', ex: 'יכתוב.תכתוב', type: 'future' },
  { id: 12, m: 'ד', f: 'ת', ex: 'עומד.ת', type: 'present' },
];

console.log('Pattern        M      F       Example        Type');
console.log('───────        ─      ─       ───────        ────');
patterns.forEach(p => {
  const m = p.m || '∅';
  const f = p.f || '∅';
  console.log(`${p.id.toString().padStart(2)}.            ${m.padEnd(5)}  ${f.padEnd(6)}  ${p.ex.padEnd(14)} ${p.type}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('THE KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  ┌────────────────────────────────────────────────────────────────┐
  │  IPA = THE KEY                                                 │
  ├────────────────────────────────────────────────────────────────┤
  │                                                                │
  │  /ta.ləm.mid/  →  תַּלְמִיד                                    │
  │       +                                                        │
  │  suffix .ה     →  תַּלְמִידָה                                   │
  │       +                                                        │
  │  suffix ים     →  תַּלְמִידִים                                  │
  │                                                                │
  │  ════════════════════════════════════════════════════════════  │
  │                                                                │
  │  SAME MECHANISM AS ENGLISH:                                    │
  │                                                                │
  │  /stju.dənt/   →  student                                      │
  │       +                                                        │
  │  suffix -s     →  students                                     │
  │                                                                │
  │  ════════════════════════════════════════════════════════════  │
  │                                                                │
  │  IPA syllables CARRY their spelling/nikud rules               │
  │  Combining = automatic correct result                         │
  │  Works for ANY length sequence!                                │
  │                                                                │
  └────────────────────────────────────────────────────────────────┘
`);
