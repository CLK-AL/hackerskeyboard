// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - NIKUD vs NO-NIKUD: More Options Without Vowels
// ═══════════════════════════════════════════════════════════════════════════════
//
// KEY INSIGHT:
// - IPA requires vowels → specific pronunciation → ONE option
// - Hebrew WITHOUT nikud → ALL vowel possibilities → MANY options
// - Unvocalized Hebrew is DENSER - each letter contains all its variations
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// COMPARISON: Letter with nikud vs without
// ═══════════════════════════════════════════════════════════════════════════════

const LETTER_OPTIONS = {
  
  // ש - SHIN/SIN base letter
  'ש': {
    without_nikud: {
      letter: 'ש',
      contains: 'ALL options below',
      total_options: 16, // 2 sounds × 8 vowels
    },
    with_nikud: [
      // SHIN (right dot) - /ʃ/
      { text: 'שַׁ', ipa: 'ʃa', one_option: true },
      { text: 'שָׁ', ipa: 'ʃɑ', one_option: true },
      { text: 'שֶׁ', ipa: 'ʃɛ', one_option: true },
      { text: 'שֵׁ', ipa: 'ʃe', one_option: true },
      { text: 'שִׁ', ipa: 'ʃi', one_option: true },
      { text: 'שֹׁ', ipa: 'ʃo', one_option: true },
      { text: 'שֻׁ', ipa: 'ʃu', one_option: true },
      { text: 'שְׁ', ipa: 'ʃə', one_option: true },
      // SIN (left dot) - /s/
      { text: 'שַׂ', ipa: 'sa', one_option: true },
      { text: 'שָׂ', ipa: 'sɑ', one_option: true },
      { text: 'שֶׂ', ipa: 'sɛ', one_option: true },
      { text: 'שֵׂ', ipa: 'se', one_option: true },
      { text: 'שִׂ', ipa: 'si', one_option: true },
      { text: 'שֹׂ', ipa: 'so', one_option: true },
      { text: 'שֻׂ', ipa: 'su', one_option: true },
      { text: 'שְׂ', ipa: 'sə', one_option: true },
    ],
  },
  
  // ב - BET/VET base letter
  'ב': {
    without_nikud: {
      letter: 'ב',
      contains: 'ALL options below',
      total_options: 16, // 2 sounds × 8 vowels
    },
    with_nikud: [
      // BET (with dagesh) - /b/
      { text: 'בַּ', ipa: 'ba', one_option: true },
      { text: 'בָּ', ipa: 'bɑ', one_option: true },
      { text: 'בֶּ', ipa: 'bɛ', one_option: true },
      { text: 'בֵּ', ipa: 'be', one_option: true },
      { text: 'בִּ', ipa: 'bi', one_option: true },
      { text: 'בֹּ', ipa: 'bo', one_option: true },
      { text: 'בֻּ', ipa: 'bu', one_option: true },
      { text: 'בְּ', ipa: 'bə', one_option: true },
      // VET (without dagesh) - /v/
      { text: 'בַ', ipa: 'va', one_option: true },
      { text: 'בָ', ipa: 'vɑ', one_option: true },
      { text: 'בֶ', ipa: 'vɛ', one_option: true },
      { text: 'בֵ', ipa: 've', one_option: true },
      { text: 'בִ', ipa: 'vi', one_option: true },
      { text: 'בֹ', ipa: 'vo', one_option: true },
      { text: 'בֻ', ipa: 'vu', one_option: true },
      { text: 'בְ', ipa: 'və', one_option: true },
    ],
  },
  
  // כ - KAF/KHAF base letter
  'כ': {
    without_nikud: {
      letter: 'כ',
      contains: 'ALL options below',
      total_options: 16, // 2 sounds × 8 vowels
    },
    with_nikud: [
      // KAF (with dagesh) - /k/
      { text: 'כַּ', ipa: 'ka', one_option: true },
      { text: 'כָּ', ipa: 'kɑ', one_option: true },
      { text: 'כֶּ', ipa: 'kɛ', one_option: true },
      { text: 'כֵּ', ipa: 'ke', one_option: true },
      { text: 'כִּ', ipa: 'ki', one_option: true },
      { text: 'כֹּ', ipa: 'ko', one_option: true },
      { text: 'כֻּ', ipa: 'ku', one_option: true },
      { text: 'כְּ', ipa: 'kə', one_option: true },
      // KHAF (without dagesh) - /x/
      { text: 'כַ', ipa: 'xa', one_option: true },
      { text: 'כָ', ipa: 'xɑ', one_option: true },
      { text: 'כֶ', ipa: 'xɛ', one_option: true },
      { text: 'כֵ', ipa: 'xe', one_option: true },
      { text: 'כִ', ipa: 'xi', one_option: true },
      { text: 'כֹ', ipa: 'xo', one_option: true },
      { text: 'כֻ', ipa: 'xu', one_option: true },
      { text: 'כְ', ipa: 'xə', one_option: true },
    ],
  },
  
  // מ - MEM (regular letter, one sound)
  'מ': {
    without_nikud: {
      letter: 'מ',
      contains: 'ALL options below',
      total_options: 8, // 1 sound × 8 vowels
    },
    with_nikud: [
      { text: 'מַ', ipa: 'ma', one_option: true },
      { text: 'מָ', ipa: 'mɑ', one_option: true },
      { text: 'מֶ', ipa: 'mɛ', one_option: true },
      { text: 'מֵ', ipa: 'me', one_option: true },
      { text: 'מִ', ipa: 'mi', one_option: true },
      { text: 'מֹ', ipa: 'mo', one_option: true },
      { text: 'מֻ', ipa: 'mu', one_option: true },
      { text: 'מְ', ipa: 'mə', one_option: true },
    ],
  },
  
  // ח - CHET (guttural - gets hataf vowels too!)
  'ח': {
    without_nikud: {
      letter: 'ח',
      contains: 'ALL options below',
      total_options: 11, // 8 regular + 3 hataf
    },
    with_nikud: [
      { text: 'חַ', ipa: 'xa', one_option: true },
      { text: 'חָ', ipa: 'xɑ', one_option: true },
      { text: 'חֶ', ipa: 'xɛ', one_option: true },
      { text: 'חֵ', ipa: 'xe', one_option: true },
      { text: 'חִ', ipa: 'xi', one_option: true },
      { text: 'חֹ', ipa: 'xo', one_option: true },
      { text: 'חֻ', ipa: 'xu', one_option: true },
      { text: 'חְ', ipa: 'x', one_option: true },
      // HATAF vowels (gutturals only!)
      { text: 'חֲ', ipa: 'xa', name: 'חֲטַף פַּתַח', one_option: true },
      { text: 'חֱ', ipa: 'xɛ', name: 'חֲטַף סֶגוֹל', one_option: true },
      { text: 'חֳ', ipa: 'xo', name: 'חֲטַף קָמָץ', one_option: true },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// WORD EXAMPLE: Same letters, different meanings based on nikud
// ═══════════════════════════════════════════════════════════════════════════════

const WORD_AMBIGUITY = {
  // שמר - 3 letters without nikud = MANY possible words
  'שמר': {
    without_nikud: 'שמר',
    possible_readings: [
      { nikud: 'שָׁמַר', ipa: 'ʃamar', meaning: 'he guarded (past)' },
      { nikud: 'שֹׁמֵר', ipa: 'ʃomer', meaning: 'guard (noun) / guarding' },
      { nikud: 'שְׁמֹר', ipa: 'ʃmor', meaning: 'guard! (imperative)' },
      { nikud: 'שֶׁמֶר', ipa: 'ʃɛmɛr', meaning: 'sediment/dregs' },
    ],
  },
  
  // דבר - multiple meanings
  'דבר': {
    without_nikud: 'דבר',
    possible_readings: [
      { nikud: 'דָּבָר', ipa: 'davar', meaning: 'thing/word' },
      { nikud: 'דִּבֵּר', ipa: 'diber', meaning: 'he spoke' },
      { nikud: 'דֶּבֶר', ipa: 'dɛvɛr', meaning: 'plague' },
      { nikud: 'דְּבַר', ipa: 'dvar', meaning: 'word of (construct)' },
    ],
  },
  
  // ספר - multiple meanings
  'ספר': {
    without_nikud: 'ספר',
    possible_readings: [
      { nikud: 'סֵפֶר', ipa: 'sefer', meaning: 'book' },
      { nikud: 'סָפַר', ipa: 'safar', meaning: 'he counted' },
      { nikud: 'סַפָּר', ipa: 'sapar', meaning: 'barber' },
      { nikud: 'סִפֵּר', ipa: 'siper', meaning: 'he told' },
      { nikud: 'סְפֹר', ipa: 'sfor', meaning: 'count! (imperative)' },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// KEYBOARD MODES
// ═══════════════════════════════════════════════════════════════════════════════

const KEYBOARD_MODES = {
  
  // MODE 1: No nikud - maximum ambiguity = maximum options
  'plain': {
    name: 'Hebrew Plain (No Nikud)',
    description: 'Each letter contains ALL its vowel possibilities',
    options_per_letter: 'Maximum (8-16 per letter)',
    use_case: 'Fast typing, reader infers vowels from context',
    example: {
      typed: 'שלום',
      contains: 'שָׁלוֹם, שְׁלוֹם, שַׁלּוּם, etc.',
    },
  },
  
  // MODE 2: With nikud - specific pronunciation = one option
  'nikud': {
    name: 'Hebrew with Nikud',
    description: 'Each letter+nikud = ONE specific pronunciation',
    options_per_letter: '1 (fully specified)',
    use_case: 'Poetry, teaching, disambiguation',
    example: {
      typed: 'שָׁלוֹם',
      contains: 'Only /ʃalom/',
    },
  },
  
  // MODE 3: IPA - universal phonetic = one option
  'ipa': {
    name: 'IPA Mode',
    description: 'Direct phonetic input = ONE specific sound',
    options_per_letter: '1 (phonetically exact)',
    use_case: 'Linguistic work, cross-language',
    example: {
      typed: '/ʃalom/',
      contains: 'Only this exact pronunciation',
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('NIKUD vs NO-NIKUD: The Density Paradox');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('WITHOUT NIKUD = MORE OPTIONS (letter contains all possibilities)\n');

console.log('Letter   Without Nikud    With Nikud (each is ONE option)');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

Object.entries(LETTER_OPTIONS).forEach(([letter, data]) => {
  const count = data.without_nikud.total_options;
  const samples = data.with_nikud.slice(0, 4).map(n => n.text).join(' ');
  console.log(`  ${letter}       = ${count.toString().padEnd(2)} options     ${samples} ...`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('WORD AMBIGUITY: Same letters, different meanings');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

Object.entries(WORD_AMBIGUITY).forEach(([word, data]) => {
  console.log(`${word} (without nikud) contains ${data.possible_readings.length} possible words:`);
  data.possible_readings.forEach(r => {
    console.log(`  ${r.nikud.padEnd(8)} /${r.ipa.padEnd(8)}/ = ${r.meaning}`);
  });
  console.log('');
});

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('KEYBOARD MODES - Specificity vs Options');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Mode        Options/Letter   Description');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
console.log('Plain       8-16             Letter = ALL vowel combinations');
console.log('Nikud       1                Letter+nikud = ONE pronunciation');
console.log('IPA         1                Sound = ONE exact phoneme');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('THE INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────┐');
console.log('  │                                                             │');
console.log('  │   ש (no nikud)  →  16 options (8 vowels × 2 sounds)        │');
console.log('  │   שַׁ (with nikud) →  1 option  (specific /ʃa/)             │');
console.log('  │   /ʃa/ (IPA)     →  1 option  (exact phoneme)              │');
console.log('  │                                                             │');
console.log('  │   Less precision = More possibilities                       │');
console.log('  │   פחות דיוק = יותר אפשרויות                                  │');
console.log('  │                                                             │');
console.log('  └─────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY supports ALL modes:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  [Plain Mode]  →  Fast typing, context determines vowels');
console.log('  [Nikud Mode]  →  Precise input, poetry, teaching');
console.log('  [IPA Mode]    →  Universal phonetic, cross-language');
console.log('');
console.log('  Toggle between modes based on need.');
console.log('  מעבר בין מצבים לפי הצורך.');
