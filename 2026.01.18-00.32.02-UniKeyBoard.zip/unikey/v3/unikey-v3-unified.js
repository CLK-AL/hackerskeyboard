// ═══════════════════════════════════════════════════════════════════════════
// UNIFIED SYLLABLES + MG
// ═══════════════════════════════════════════════════════════════════════════
//
// OBSERVATION:
//   MG is just a PAIR of syllables with gender tags!
//
// OLD (redundant):
//   { m: 'ו', f: 'ה', mf: 'ו/ה', ipa: 'o/a' }  ← mf is computed!
//   { m: 'וֹ', f: 'הּ', mf: 'וֹ/הּ', ipa: 'o/a' }  ← same pattern, different nikud
//
// NEW (unified):
//   Syllable = { plain, nikud, ipa }
//   MG = pair of syllable IDs
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLES DATABASE - Single source of truth
// ═══════════════════════════════════════════════════════════════════════════

const SYL = {
  // Hebrew suffixes
  'ו': { p: 'ו', n: 'וֹ', ipa: 'o' },
  'ה': { p: 'ה', n: 'הּ', ipa: 'a' },
  'ם': { p: 'ם', n: 'ָם', ipa: 'm' },
  'ן': { p: 'ן', n: 'ָן', ipa: 'n' },
  'ך': { p: 'ך', n: 'ְךָ', ipa: 'xa' },
  'ךְ': { p: 'ך', n: 'ֵךְ', ipa: 'ex' },
  'ת': { p: 'ת', n: 'ֶת', ipa: 't' },
  'ד': { p: 'ד', n: 'ֵד', ipa: 'd' },
  
  'ים': { p: 'ים', n: 'ִים', ipa: 'im' },
  'ות': { p: 'ות', n: 'וֹת', ipa: 'ot' },
  'ין': { p: 'ין', n: 'ִין', ipa: 'in' },
  
  'י': { p: 'י', n: 'ִי', ipa: 'i' },
  'ית': { p: 'ית', n: 'ִית', ipa: 'it' },
  
  'יו': { p: 'יו', n: 'ָיו', ipa: 'av' },
  'יה': { p: 'יה', n: 'ֶיהָ', ipa: 'eha' },
  
  'הם': { p: 'הם', n: 'הֶם', ipa: 'hem' },
  'הן': { p: 'הן', n: 'הֶן', ipa: 'hen' },
  
  'יהם': { p: 'יהם', n: 'ֵיהֶם', ipa: 'ehem' },
  'יהן': { p: 'יהן', n: 'ֵיהֶן', ipa: 'ehen' },
  
  'ן2': { p: 'ן', n: 'ָן', ipa: 'an' },  // different nikud
  'נית': { p: 'נית', n: 'נִית', ipa: 'nit' },
  'נה': { p: 'נה', n: 'נָה', ipa: 'na' },
  
  'דה': { p: 'דה', n: 'דָה', ipa: 'da' },
  
  'יש': { p: 'יש', n: 'יש', ipa: 'ish' },
  'ישה': { p: 'ישה', n: 'ישָׁה', ipa: 'isha' },
  
  // Present tense ה (different vowels)
  'הֶ': { p: 'ה', n: 'ֶה', ipa: 'e' },
  'הָ': { p: 'ה', n: 'ָה', ipa: 'a' },
  
  // Prefix
  'הוא': { p: 'הוא', n: 'הוּא', ipa: 'hu' },
  'היא': { p: 'היא', n: 'הִיא', ipa: 'hi' },
  
  'אתה': { p: 'אתה', n: 'אַתָּה', ipa: 'ata' },
  'את': { p: 'את', n: 'אַתְּ', ipa: 'at' },
  
  // Verb prefix
  'י': { p: 'י', n: 'יִ', ipa: 'ji' },
  'ת2': { p: 'ת', n: 'תִּ', ipa: 'ti' },
  
  // English
  'he': { p: 'e', n: 'e', ipa: 'i' },
  'she': { p: 'she', n: 'she', ipa: 'ʃi' },
  'his': { p: 'is', n: 'is', ipa: 'ɪz' },
  'her': { p: 'er', n: 'er', ipa: 'ɜr' },
  'him': { p: 'im', n: 'im', ipa: 'ɪm' },
  'they': { p: 'ey', n: 'ey', ipa: 'eɪ' },
  'them': { p: 'em', n: 'em', ipa: 'əm' },
};

// ═══════════════════════════════════════════════════════════════════════════
// MG PAIRS - Just references to syllables
// ═══════════════════════════════════════════════════════════════════════════

const MG_PAIRS = [
  // Hebrew 3rd person singular
  { m: 'ו', f: 'ה', ctx: '3s' },
  { m: 'יו', f: 'יה', ctx: '3s-pl' },
  
  // Hebrew 3rd person plural
  { m: 'ם', f: 'ן', ctx: '3p' },
  { m: 'הם', f: 'הן', ctx: '3p-full' },
  { m: 'יהם', f: 'יהן', ctx: '3p-of' },
  
  // Hebrew 2nd person
  { m: 'ך', f: 'ךְ', ctx: '2s' },
  
  // Plural
  { m: 'ים', f: 'ות', ctx: 'pl' },
  { m: 'ין', f: 'ות', ctx: 'pl-aram' },
  
  // Adjective/noun suffixes
  { m: 'ד', f: 'ת', ctx: 'adj' },
  { m: 'ן2', f: 'ת', ctx: 'adj2' },
  { m: 'ן2', f: 'נית', ctx: 'prof' },
  { m: 'ן2', f: 'נה', ctx: 'prof2' },
  { m: 'י', f: 'ית', ctx: 'gent' },
  
  // Noun pairs
  { m: 'ן', f: 'ת', ctx: 'noun' },
  { m: 'ד', f: 'דה', ctx: 'noun2' },
  { m: 'יש', f: 'ישה', ctx: 'person' },
  
  // Present tense (same letter, different nikud)
  { m: 'הֶ', f: 'הָ', ctx: 'pres' },
  
  // Pronouns (full words as syllables)
  { m: 'הוא', f: 'היא', ctx: 'pron-3s' },
  { m: 'אתה', f: 'את', ctx: 'pron-2s' },
  
  // Verb prefix
  { m: 'י', f: 'ת2', ctx: 'fut' },
  
  // English
  { m: 'he', f: 'she', ctx: 'en-pron' },
  { m: 'his', f: 'her', ctx: 'en-poss' },
  { m: 'him', f: 'her', ctx: 'en-obj' },
  { m: 'they', f: 'them', ctx: 'en-3p' },
];

// ═══════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

function syl(id, nikud = false) {
  const s = SYL[id];
  if (!s) return id;  // fallback to raw string
  return nikud ? s.n : s.p;
}

function syl_ipa(id) {
  return SYL[id]?.ipa || '';
}

function mg_get(pair, nikud = false) {
  return {
    m: syl(pair.m, nikud),
    f: syl(pair.f, nikud),
    mf: `${syl(pair.m, nikud)}/${syl(pair.f, nikud)}`,
    ipa: `${syl_ipa(pair.m)}/${syl_ipa(pair.f)}`,
  };
}

function mg_ivrita(pair, nikud = false) {
  const m = syl(pair.m, nikud);
  const f = syl(pair.f, nikud);
  if (m === f) return m;
  return `${m}.${f}`;
}

// Find pairs by context
function mg_by_ctx(ctx) {
  return MG_PAIRS.filter(p => p.ctx === ctx);
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIFIED: Syllables + MG');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('Syllables count:', Object.keys(SYL).length);
console.log('MG pairs count:', MG_PAIRS.length);
console.log('');

console.log('───────────────────────────────────────────────────────────────');
console.log('MG Pairs (plain / nikud / ivrita):');
console.log('───────────────────────────────────────────────────────────────\n');

MG_PAIRS.forEach(pair => {
  const plain = mg_get(pair, false);
  const nikud = mg_get(pair, true);
  console.log(`${pair.ctx.padEnd(10)}: ${plain.mf.padEnd(12)} | ${nikud.mf.padEnd(14)} | ${mg_ivrita(pair).padEnd(10)} | ipa: ${plain.ipa}`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('Find pairs by context:');
console.log('───────────────────────────────────────────────────────────────\n');

['3s', 'pl', 'pron-3s', 'en-pron'].forEach(ctx => {
  const pairs = mg_by_ctx(ctx);
  console.log(`${ctx}:`, pairs.map(p => mg_get(p).mf).join(', '));
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('BENEFIT: Single source of truth for syllables!');
console.log('MG is just pair of syllable references.');
console.log('═══════════════════════════════════════════════════════════════');
