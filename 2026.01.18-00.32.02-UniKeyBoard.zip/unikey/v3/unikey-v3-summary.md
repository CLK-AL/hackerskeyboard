# UniKey v3 - Unified Architecture

## 🎯 Core Insight

**מקלדת אחת עם שכבות, לא מקלדות נפרדות**

```
Physical Key → IPA → Hebrew / English / Nikud / MG
```

## 📐 Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     PHYSICAL KEY                                │
│                         [A]                                     │
└─────────────────────────┬───────────────────────────────────────┘
                          │
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │  Normal  │    │ +Modifier│    │  +Ctrl   │
    │    א     │    │   ו/ה    │    │   /a/    │
    └──────────┘    └──────────┘    └──────────┘
          │               │               │
          └───────────────┴───────────────┘
                          │
                   ┌──────┴──────┐
                   │     IPA     │
                   │   Bridge    │
                   │    /a/      │
                   └─────────────┘
                          │
            ┌─────────────┼─────────────┐
            ▼             ▼             ▼
       ┌────────┐   ┌────────┐   ┌────────┐
       │ Hebrew │   │English │   │  MG    │
       │   א    │   │   a    │   │  m/f   │
       └────────┘   └────────┘   └────────┘
```

## 🔑 Key Principles

### 1. IPA = Universal Bridge
```
English 'a' ←→ IPA /a/ ←→ Hebrew א/ַ
```

### 2. Etymology = Logical Placement
```
Key  EN   HE   IPA   Etymology
───  ──   ──   ───   ─────────
b    b    ב    /b/   bet
v    v    ב    /v/   bet (soft)
t    t    ת    /t/   tav
s    s    ס    /s/   samekh
m    m    מ    /m/   mem
n    n    נ    /n/   nun
```

### 3. MG = NOT New Structure
```
MG = Two existing syllables with pair relationship

OLD: Separate MG_DATA structure
NEW: SYL['ו'].pair = 'ה'  ← Just a property!
```

### 4. Modifiers (Like Nikud)
```
Same base unit + different modifiers:

Letter + Nikud    →  בָּ בַּ בֶּ בֵּ בִּ
Letter + Gender   →  ו/ה  ם/ן  ים/ות
Letter + Number   →  יחיד/רבים
Letter + Tense    →  י/ת (עתיד)
Letter + Position →  תחילית/סופית
```

## 📋 Layers

| Modifier | Numbers | Letters |
|----------|---------|---------|
| Normal | 1 | א |
| Shift | ! | shift variant |
| Alt | ו/ה (MG) | syllable |
| Alt+Shift | וֹ/ָהּ (MG+nikud) | syllable+nikud |
| Ctrl | - | /a/ (IPA) |

## 🗃️ Data Structure

```javascript
// ONE unified structure
const SYL = {
  'ו': { 
    p: 'ו',      // plain
    n: 'וֹ',     // nikud
    ipa: 'o',    // IPA
    g: 'm',      // gender
    pair: 'ה',   // MG pair
    pos: 'suf',  // position
    num: 'sg',   // number
  },
  // ...
};

// API
syl('ו')           → 'ו'
syl('ו', true)     → 'וֹ'
pair('ו')          → 'ה'
mf('ו')            → 'ו/ה'
mf('ו', true)      → 'וֹ/ָהּ'
```

## ✅ Benefits

| Before | After |
|--------|-------|
| 4+ separate data structures | 1 unified SYL |
| Duplicated syllables | Single source of truth |
| MG as special case | MG = pair property |
| Complex lookups | Simple API |

## 🎹 Result

**מקלדת יעילה ומוכרת:**
- QWERTY layout (familiar)
- IPA-based (logical)
- Etymology connections (memorable)
- Layers via modifiers (efficient)
- No new keys needed for MG!
