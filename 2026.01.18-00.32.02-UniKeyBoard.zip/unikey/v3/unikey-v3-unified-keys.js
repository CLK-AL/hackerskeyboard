// ═══════════════════════════════════════════════════════════════════════════
// THE INSIGHT: Everything is a SYLLABLE with MODIFIERS
// ═══════════════════════════════════════════════════════════════════════════
//
// Like nikud can be added to any letter,
// these modifiers can be added to any syllable:
//
//   - nikud     (ניקוד)
//   - number    (יחיד/רבים)  
//   - gender    (זכר/נקבה)
//   - tense     (עבר/הווה/עתיד)
//   - position  (תחילית/סופית)
//
// MG = just TWO KEYS tagged as m/f pair
// NOT a new data structure!
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLE = Base unit with all possible forms
// ═══════════════════════════════════════════════════════════════════════════

const SYL = {
  // ─────────────────────────────────────────────────────────────────────────
  // Hebrew syllables with modifiers
  // ─────────────────────────────────────────────────────────────────────────
  
  'ו': {
    p: 'ו', n: 'וֹ', ipa: 'o',
    pos: 'suffix',      // position
    gender: 'm',        // male form
    pair: 'ה',          // female pair
  },
  'ה': {
    p: 'ה', n: 'ָהּ', ipa: 'a',
    pos: 'suffix',
    gender: 'f',
    pair: 'ו',
  },
  
  'ם': {
    p: 'ם', n: 'ָם', ipa: 'am',
    pos: 'suffix',
    gender: 'm',
    number: 'pl',       // plural
    pair: 'ן',
  },
  'ן': {
    p: 'ן', n: 'ָן', ipa: 'an',
    pos: 'suffix',
    gender: 'f',
    number: 'pl',
    pair: 'ם',
  },
  
  'ים': {
    p: 'ים', n: 'ִים', ipa: 'im',
    pos: 'suffix',
    gender: 'm',
    number: 'pl',
    pair: 'ות',
  },
  'ות': {
    p: 'ות', n: 'וֹת', ipa: 'ot',
    pos: 'suffix',
    gender: 'f',
    number: 'pl',
    pair: 'ים',
  },
  
  'ת': {
    p: 'ת', n: 'ֶת', ipa: 'et',
    pos: 'suffix',
    gender: 'f',
    pair: 'ד',
  },
  'ד': {
    p: 'ד', n: 'ֵד', ipa: 'ed',
    pos: 'suffix',
    gender: 'm',
    pair: 'ת',
  },
  
  // Verb prefixes
  'י': {
    p: 'י', n: 'יִ', ipa: 'ji',
    pos: 'prefix',
    gender: 'm',
    tense: 'fut',
    pair: 'ת_f',
  },
  'ת_f': {
    p: 'ת', n: 'תִּ', ipa: 'ti',
    pos: 'prefix',
    gender: 'f',
    tense: 'fut',
    pair: 'י',
  },
  
  // Present tense (same plain, different nikud!)
  'ה_m': {
    p: 'ה', n: 'ֶה', ipa: 'e',
    pos: 'suffix',
    gender: 'm',
    tense: 'pres',
    pair: 'ה_f',
  },
  'ה_f': {
    p: 'ה', n: 'ָה', ipa: 'a',
    pos: 'suffix',
    gender: 'f',
    tense: 'pres',
    pair: 'ה_m',
  },
  
  // ─────────────────────────────────────────────────────────────────────────
  // English syllables
  // ─────────────────────────────────────────────────────────────────────────
  
  'he': { p: 'e', n: 'e', ipa: 'i', gender: 'm', pair: 'she' },
  'she': { p: 'she', n: 'she', ipa: 'ʃi', gender: 'f', pair: 'he' },
  
  'his': { p: 'is', n: 'is', ipa: 'ɪz', gender: 'm', pair: 'her' },
  'her': { p: 'er', n: 'er', ipa: 'ɜr', gender: 'f', pair: 'his' },
  
  'him': { p: 'im', n: 'im', ipa: 'ɪm', gender: 'm', pair: 'her_o' },
  'her_o': { p: 'er', n: 'er', ipa: 'ɜr', gender: 'f', pair: 'him' },
  
  'man': { p: 'an', n: 'an', ipa: 'æn', gender: 'm', pair: 'woman' },
  'woman': { p: 'oman', n: 'oman', ipa: 'ʊmən', gender: 'f', pair: 'man' },
};

// ═══════════════════════════════════════════════════════════════════════════
// API - Get syllable or its pair
// ═══════════════════════════════════════════════════════════════════════════

const syl = (id, nikud = false) => {
  const s = SYL[id];
  return s ? (nikud ? s.n : s.p) : id;
};

const pair = (id) => SYL[id]?.pair;

const swap = (id) => pair(id) || id;

const mf = (id, nikud = false) => {
  const s = SYL[id];
  if (!s?.pair) return syl(id, nikud);
  const m = s.gender === 'm' ? id : s.pair;
  const f = s.gender === 'f' ? id : s.pair;
  return `${syl(m, nikud)}/${syl(f, nikud)}`;
};

const ivrita = (id, nikud = false) => {
  const s = SYL[id];
  if (!s?.pair) return syl(id, nikud);
  const m = s.gender === 'm' ? id : s.pair;
  const f = s.gender === 'f' ? id : s.pair;
  const mv = syl(m, nikud);
  const fv = syl(f, nikud);
  return mv === fv ? mv : `${mv}.${fv}`;
};

// Filter by properties
const by = (prop, value) => 
  Object.entries(SYL)
    .filter(([k, v]) => v[prop] === value)
    .map(([k]) => k);

// ═══════════════════════════════════════════════════════════════════════════
// TEST
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIFIED: Syllable = Base unit with modifiers');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('MG is NOT a separate structure!');
console.log('MG = syllable + its pair\n');

console.log('───────────────────────────────────────────────────────────────');
console.log('Examples:');
console.log('───────────────────────────────────────────────────────────────\n');

['ו', 'ם', 'ים', 'ת', 'י', 'ה_m', 'he', 'man'].forEach(id => {
  console.log(`syl('${id}'):`);
  console.log(`  plain:  ${syl(id)}`);
  console.log(`  nikud:  ${syl(id, true)}`);
  console.log(`  pair:   ${pair(id)} → ${syl(pair(id))}`);
  console.log(`  mf:     ${mf(id)}`);
  console.log(`  ivrita: ${ivrita(id)}`);
  console.log('');
});

console.log('───────────────────────────────────────────────────────────────');
console.log('Filter by property:');
console.log('───────────────────────────────────────────────────────────────\n');

console.log('Suffixes:', by('pos', 'suffix').join(', '));
console.log('Prefixes:', by('pos', 'prefix').join(', '));
console.log('Male:', by('gender', 'm').join(', '));
console.log('Female:', by('gender', 'f').join(', '));
console.log('Plural:', by('number', 'pl').join(', '));
console.log('Future:', by('tense', 'fut').join(', '));
console.log('Present:', by('tense', 'pres').join(', '));

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('KEY INSIGHT:');
console.log('───────────────────────────────────────────────────────────────');
console.log('');
console.log('  Letter + Nikud     →  בָּ בַּ בֶּ בֵּ בִּ בֹּ בֻּ');
console.log('  Letter + Gender    →  ו/ה  ם/ן  ים/ות');
console.log('  Letter + Number    →  יחיד/רבים');
console.log('  Letter + Tense     →  י/ת (עתיד)');
console.log('  Letter + Position  →  תחילית/סופית');
console.log('');
console.log('  ALL ARE MODIFIERS ON THE SAME BASE UNIT!');
console.log('═══════════════════════════════════════════════════════════════');
