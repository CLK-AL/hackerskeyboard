// ═══════════════════════════════════════════════════════════════════════════
// 12 MG (PUA) vs 19 IVRITA - Different Usage, Same Space
// ═══════════════════════════════════════════════════════════════════════════
//
// 12 PUA  = VISUAL glyphs (for fonts, rendering)
// 19 Ivrita = TEXT notation (for writing, interchange)
//
// They cover the SAME grammatical space in DIFFERENT ways!
//
// ═══════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('12 MG (PUA) vs 19 IVRITA');
console.log('═══════════════════════════════════════════════════════════════\n');

// ═══════════════════════════════════════════════════════════════════════════
// 12 PUA GLYPHS - Visual Representation
// ═══════════════════════════════════════════════════════════════════════════

const PUA_12 = [
  // Hybrid letters - VISUAL glyphs for font rendering
  { id: 1,  glyph: 'הא', letters: 'ה+א', usage: 'הוא/היא → הו[הא]' },
  { id: 2,  glyph: 'וי', letters: 'ו+י', usage: 'שלו/שלי → של[וי]' },
  { id: 3,  glyph: 'םן', letters: 'ם+ן', usage: 'הם/הן → ה[םן]' },
  { id: 4,  glyph: 'תה', letters: 'ת+ה', usage: 'את/אתה → א[תה]' },
  { id: 5,  glyph: 'דת', letters: 'ד+ת', usage: 'עומד/עומדת → עומ[דת]' },
  { id: 6,  glyph: 'נת', letters: 'נ+ת', usage: 'שחקן/שחקנית' },
  { id: 7,  glyph: 'יו', letters: 'י+ו', usage: 'prefix י/ת' },
  // ... more hybrid glyphs
];

// ═══════════════════════════════════════════════════════════════════════════
// 19 IVRITA PATTERNS - Text Notation
// ═══════════════════════════════════════════════════════════════════════════

const IVRITA_19 = [
  // Notation patterns - TEXT representation for writing
  { id: 1,  notation: '.ה', m: '', f: 'ה', usage: 'תלמיד.ה' },
  { id: 2,  notation: '.ת', m: '', f: 'ת', usage: 'נהג.ת' },
  { id: 3,  notation: 'ן.ת', m: 'ן', f: 'ת', usage: 'בן.ת' },
  { id: 4,  notation: 'ן.נית', m: 'ן', f: 'נית', usage: 'שחקן.ית' },
  { id: 5,  notation: 'ים.ות', m: 'ים', f: 'ות', usage: 'תלמידים.ות' },
  { id: 6,  notation: 'ו.ה', m: 'ו', f: 'ה', usage: 'שלו.ה' },
  { id: 7,  notation: 'ם.ן', m: 'ם', f: 'ן', usage: 'הם.ן' },
  { id: 8,  notation: 'י.ת', m: 'י', f: 'ת', usage: 'יכתוב.תכתוב' },
  { id: 9,  notation: 'ד.ת', m: 'ד', f: 'ת', usage: 'עומד.ת' },
  { id: 10, notation: 'הוא.היא', m: 'הוא', f: 'היא', usage: 'pronoun' },
  { id: 11, notation: 'אתה.את', m: 'אתה', f: 'את', usage: 'pronoun' },
  // ... more patterns
];

console.log('┌─────────────────────────────────────────────────────────────────┐');
console.log('│                    DIFFERENT PURPOSES                          │');
console.log('├─────────────────────────────────────────────────────────────────┤');
console.log('│                                                                 │');
console.log('│   12 PUA GLYPHS              │    19 IVRITA PATTERNS           │');
console.log('│   ══════════════             │    ═══════════════════          │');
console.log('│                              │                                  │');
console.log('│   Purpose: VISUAL            │    Purpose: TEXT                 │');
console.log('│   For: Font rendering        │    For: Writing/interchange      │');
console.log('│   Format: Single glyph       │    Format: Notation string       │');
console.log('│   Display: ה[א] (hybrid)     │    Display: הוא.היא              │');
console.log('│                              │                                  │');
console.log('│   Usage:                     │    Usage:                        │');
console.log('│   - MGHebrew font            │    - Plain text                  │');
console.log('│   - PDF rendering            │    - Markdown                    │');
console.log('│   - Print                    │    - Email/chat                  │');
console.log('│   - Any font context         │    - Any text context            │');
console.log('│                              │                                  │');
console.log('└─────────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('SAME GRAMMATICAL SPACE, DIFFERENT REPRESENTATION');
console.log('═══════════════════════════════════════════════════════════════\n');

const mappings = [
  { grammar: '3rd sg pronoun', pua: 'הא (hybrid)', ivrita: 'הוא.היא', resolved: 'הוא / היא' },
  { grammar: '3rd pl pronoun', pua: 'םן (hybrid)', ivrita: 'הם.ן', resolved: 'הם / הן' },
  { grammar: 'possessive 3s', pua: 'וי (hybrid)', ivrita: 'ו.ה', resolved: 'שלו / שלה' },
  { grammar: 'plural', pua: 'ים+ות', ivrita: 'ים.ות', resolved: 'תלמידים / תלמידות' },
  { grammar: 'present tense', pua: 'דת (hybrid)', ivrita: 'ד.ת', resolved: 'עומד / עומדת' },
  { grammar: 'future prefix', pua: 'יו (hybrid)', ivrita: 'י.ת', resolved: 'יכתוב / תכתוב' },
];

console.log('Grammar            PUA Glyph      Ivrita         Resolved');
console.log('───────            ─────────      ──────         ────────');
mappings.forEach(m => {
  console.log(`${m.grammar.padEnd(18)} ${m.pua.padEnd(14)} ${m.ivrita.padEnd(14)} ${m.resolved}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('CONVERSION FLOW');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  ┌─────────────────────────────────────────────────────────────────┐
  │                                                                 │
  │   INPUT (any form)                                             │
  │        │                                                        │
  │        ▼                                                        │
  │   ┌─────────────┐                                               │
  │   │   GRAMMAR   │  ← הבנה דקדוקית (גוף, מין, מספר, זמן)         │
  │   │   SPACE     │                                               │
  │   └──────┬──────┘                                               │
  │          │                                                      │
  │     ┌────┴────┐                                                 │
  │     ▼         ▼                                                 │
  │  ┌──────┐  ┌──────┐                                             │
  │  │ PUA  │  │Ivrita│                                             │
  │  │ 12   │  │ 19   │                                             │
  │  └──┬───┘  └──┬───┘                                             │
  │     │         │                                                 │
  │     ▼         ▼                                                 │
  │  VISUAL    TEXT                                                 │
  │  ה[א]      הוא.היא                                              │
  │                                                                 │
  │     │         │                                                 │
  │     └────┬────┘                                                 │
  │          ▼                                                      │
  │   RESOLVED (when needed)                                        │
  │   הוא / היא                                                     │
  │                                                                 │
  └─────────────────────────────────────────────────────────────────┘
`);

console.log('═══════════════════════════════════════════════════════════════');
console.log('COMMON USAGE DIFFERENCES');
console.log('═══════════════════════════════════════════════════════════════\n');

const useCases = [
  { context: 'Font/PDF', use: 'PUA', reason: 'Visual hybrid glyph renders correctly' },
  { context: 'Plain text', use: 'Ivrita', reason: 'Works in any font/context' },
  { context: 'Markdown', use: 'Ivrita', reason: 'Readable notation' },
  { context: 'Code/data', use: 'Ivrita', reason: 'Parseable, transformable' },
  { context: 'Print', use: 'PUA', reason: 'Single glyph, clean display' },
  { context: 'Keyboard', use: 'Both', reason: 'Input→Ivrita, Display→PUA' },
];

console.log('Context        Format    Reason');
console.log('───────        ──────    ──────');
useCases.forEach(u => {
  console.log(`${u.context.padEnd(14)} ${u.use.padEnd(9)} ${u.reason}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('SUMMARY');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  12 PUA   = HOW TO DISPLAY (visual layer)
  19 Ivrita = HOW TO WRITE  (text layer)
  
  Both map to SAME grammatical concepts!
  
  Keyboard types → Ivrita notation
  Font renders  → PUA glyph (if available)
  Export/share  → Ivrita or resolved form
`);
