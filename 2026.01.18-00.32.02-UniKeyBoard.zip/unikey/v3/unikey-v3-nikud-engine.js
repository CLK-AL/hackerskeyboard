// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY NIKUD ENGINE - Complete Letter + Vowel Mapping for Auto-Nikud
// ═══════════════════════════════════════════════════════════════════════════════
//
// PURPOSE: Map every Hebrew letter with every possible nikud
//          Enable easy nikud input by IPA or English equivalent
//          Support Multi-Gender (MG) forms
//
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW LETTERS - Base consonants
// ═══════════════════════════════════════════════════════════════════════════════

const HE_LETTERS = {
  // Regular letters
  'א': { name: 'אָלֶף', ipa: 'ʔ', guttural: true, final: null },
  'ב': { name: 'בֵּית', ipa: 'v', ipa_dagesh: 'b', final: null },
  'ג': { name: 'גִּימֶל', ipa: 'g', final: null },
  'ד': { name: 'דָּלֶת', ipa: 'd', final: null },
  'ה': { name: 'הֵא', ipa: 'h', guttural: true, final: null },
  'ו': { name: 'וָו', ipa: 'v', ipa_vowel: 'o/u', final: null },
  'ז': { name: 'זַיִן', ipa: 'z', final: null },
  'ח': { name: 'חֵית', ipa: 'x', guttural: true, final: null },
  'ט': { name: 'טֵית', ipa: 't', final: null },
  'י': { name: 'יוֹד', ipa: 'j', ipa_vowel: 'i', final: null },
  'כ': { name: 'כָּף', ipa: 'x', ipa_dagesh: 'k', final: 'ך' },
  'ל': { name: 'לָמֶד', ipa: 'l', final: null },
  'מ': { name: 'מֵם', ipa: 'm', final: 'ם' },
  'נ': { name: 'נוּן', ipa: 'n', final: 'ן' },
  'ס': { name: 'סָמֶךְ', ipa: 's', final: null },
  'ע': { name: 'עַיִן', ipa: 'ʕ', guttural: true, final: null },
  'פ': { name: 'פֵּא', ipa: 'f', ipa_dagesh: 'p', final: 'ף' },
  'צ': { name: 'צָדִי', ipa: 'ts', final: 'ץ' },
  'ק': { name: 'קוֹף', ipa: 'k', final: null },
  'ר': { name: 'רֵישׁ', ipa: 'ʁ', final: null },
  'ש': { name: 'שִׁין/שִׂין', ipa: 'ʃ', ipa_sin: 's', final: null },
  'ת': { name: 'תָּו', ipa: 't', final: null },
  
  // Final letters
  'ך': { name: 'כָּף סוֹפִית', ipa: 'x', is_final: true, base: 'כ' },
  'ם': { name: 'מֵם סוֹפִית', ipa: 'm', is_final: true, base: 'מ' },
  'ן': { name: 'נוּן סוֹפִית', ipa: 'n', is_final: true, base: 'נ' },
  'ף': { name: 'פֵּא סוֹפִית', ipa: 'f', is_final: true, base: 'פ' },
  'ץ': { name: 'צָדִי סוֹפִית', ipa: 'ts', is_final: true, base: 'צ' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// NIKUD MARKS - All vowel marks
// ═══════════════════════════════════════════════════════════════════════════════

const NIKUD_MARKS = {
  // Full vowels (תנועות גדולות)
  'ַ': { name: 'פַּתַח', ipa: 'a', type: 'full', en: 'a' },
  'ָ': { name: 'קָמָץ', ipa: 'ɑ', ipa_alt: 'ɔ', type: 'full', en: 'a/o' },
  'ֵ': { name: 'צֵירֵי', ipa: 'e', type: 'full', en: 'e/ay' },
  'ֶ': { name: 'סֶגוֹל', ipa: 'ɛ', type: 'full', en: 'e' },
  'ִ': { name: 'חִירִיק', ipa: 'i', type: 'full', en: 'i/ee' },
  'ֹ': { name: 'חוֹלָם', ipa: 'o', type: 'full', en: 'o' },
  'ֻ': { name: 'קֻבּוּץ', ipa: 'u', type: 'full', en: 'u/oo' },
  
  // Reduced vowels (תנועות קטנות)
  'ְ': { name: 'שְׁוָא', ipa: 'ə', ipa_silent: '', type: 'reduced', en: 'e/silent' },
  'ֲ': { name: 'חֲטַף פַּתַח', ipa: 'ă', type: 'hataf', guttural: true, en: 'a' },
  'ֱ': { name: 'חֲטַף סֶגוֹל', ipa: 'ĕ', type: 'hataf', guttural: true, en: 'e' },
  'ֳ': { name: 'חֲטַף קָמָץ', ipa: 'ŏ', type: 'hataf', guttural: true, en: 'o' },
  
  // Modifiers
  'ּ': { name: 'דָּגֵשׁ', type: 'dagesh', mod: 'hard' },
  'ׁ': { name: 'שִׁין', type: 'dot', ipa: 'ʃ' },
  'ׂ': { name: 'שִׂין', type: 'dot', ipa: 's' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// IPA TO NIKUD - Primary mapping
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_TO_NIKUD = {
  // Pure vowels
  'a': { primary: 'ַ', name: 'פַּתַח' },
  'ɑ': { primary: 'ָ', name: 'קָמָץ' },
  'e': { primary: 'ֵ', name: 'צֵירֵי' },
  'ɛ': { primary: 'ֶ', name: 'סֶגוֹל' },
  'i': { primary: 'ִ', name: 'חִירִיק', male: 'ִי' },
  'o': { primary: 'ֹ', name: 'חוֹלָם', male: 'וֹ' },
  'ɔ': { primary: 'ָ', name: 'קָמָץ קָטָן' },
  'u': { primary: 'ֻ', name: 'קֻבּוּץ', male: 'וּ' },
  'ə': { primary: 'ְ', name: 'שְׁוָא' },
  
  // Hataf (for gutturals)
  'ă': { primary: 'ֲ', name: 'חֲטַף פַּתַח', guttural: true },
  'ĕ': { primary: 'ֱ', name: 'חֲטַף סֶגוֹל', guttural: true },
  'ŏ': { primary: 'ֳ', name: 'חֲטַף קָמָץ', guttural: true },
  
  // Diphthongs
  'aj': { primary: 'ַי', name: 'פַּתַח+יוֹד', en_equiv: 'aɪ' },
  'ej': { primary: 'ֵי', name: 'צֵירֵי+יוֹד', en_equiv: 'eɪ' },
  'aw': { primary: 'ָו', name: 'קָמָץ+וָו', en_equiv: 'aʊ' },
  'oj': { primary: 'וֹי', name: 'חוֹלָם+יוֹד', en_equiv: 'ɔɪ' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ENGLISH TO IPA - For English input
// ═══════════════════════════════════════════════════════════════════════════════

const EN_TO_IPA = {
  // Single vowels
  'a': ['a', 'ɑ', 'æ'],
  'e': ['e', 'ɛ', 'ə'],
  'i': ['i', 'ɪ'],
  'o': ['o', 'ɔ', 'ɒ'],
  'u': ['u', 'ʊ', 'ʌ'],
  
  // Combos → IPA
  'ee': ['i'],
  'ea': ['i', 'ɛ'],
  'oo': ['u', 'ʊ'],
  'ay': ['e', 'eɪ'],
  'ai': ['e', 'eɪ'],
  'ou': ['aʊ', 'u'],
  'ow': ['aʊ', 'oʊ'],
  'oi': ['ɔɪ'],
  'oy': ['ɔɪ'],
  'igh': ['aɪ'],
  
  // Consonants
  'sh': ['ʃ'],
  'ch': ['tʃ', 'x'],
  'th': ['θ', 'ð'],
  'ng': ['ŋ'],
  'ts': ['ts'],
  'tz': ['ts'],
};

// ═══════════════════════════════════════════════════════════════════════════════
// GENERATE ALL LETTER+NIKUD COMBINATIONS
// ═══════════════════════════════════════════════════════════════════════════════

function generateNikudCombinations() {
  const combinations = {};
  const vowels = ['ַ', 'ָ', 'ֵ', 'ֶ', 'ִ', 'ֹ', 'ֻ', 'ְ'];
  const hatafim = ['ֲ', 'ֱ', 'ֳ'];
  const gutturals = ['א', 'ה', 'ח', 'ע'];
  
  Object.keys(HE_LETTERS).forEach(letter => {
    if (HE_LETTERS[letter].is_final) return; // Skip finals for now
    
    combinations[letter] = {};
    const isGuttural = gutturals.includes(letter);
    
    // Regular vowels
    vowels.forEach(nikud => {
      const ipa = NIKUD_MARKS[nikud].ipa;
      combinations[letter][ipa] = letter + nikud;
    });
    
    // Hataf vowels (gutturals only)
    if (isGuttural) {
      hatafim.forEach(nikud => {
        const ipa = NIKUD_MARKS[nikud].ipa;
        combinations[letter][ipa] = letter + nikud;
      });
    }
    
    // With dagesh (for בגדכפת)
    if (['ב', 'ג', 'ד', 'כ', 'פ', 'ת'].includes(letter)) {
      combinations[letter + 'ּ'] = {};
      vowels.forEach(nikud => {
        const ipa = NIKUD_MARKS[nikud].ipa;
        combinations[letter + 'ּ'][ipa] = letter + 'ּ' + nikud;
      });
    }
    
    // Shin/Sin dots
    if (letter === 'ש') {
      combinations['שׁ'] = {}; // Shin
      combinations['שׂ'] = {}; // Sin
      vowels.forEach(nikud => {
        const ipa = NIKUD_MARKS[nikud].ipa;
        combinations['שׁ'][ipa] = 'שׁ' + nikud;
        combinations['שׂ'][ipa] = 'שׂ' + nikud;
      });
    }
  });
  
  return combinations;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MULTI-GENDER (MG) MAPPINGS
// ═══════════════════════════════════════════════════════════════════════════════

const MG_PATTERNS = {
  // Pronouns
  pronouns: {
    '3S': { m: 'הוּא', f: 'הִיא', n: 'הוּא/הִיא', ipa_m: 'hu', ipa_f: 'hi' },
    '3P': { m: 'הֵם', f: 'הֵן', n: 'הֵם/הֵן', ipa_m: 'hem', ipa_f: 'hen' },
    '2S': { m: 'אַתָּה', f: 'אַתְּ', n: 'אַתָּה/אַתְּ', ipa_m: 'ata', ipa_f: 'at' },
    '2P': { m: 'אַתֶּם', f: 'אַתֶּן', n: 'אַתֶּם/אַתֶּן', ipa_m: 'atem', ipa_f: 'aten' },
  },
  
  // Noun endings
  endings: {
    plural: { m: 'ִים', f: 'וֹת', ipa_m: 'im', ipa_f: 'ot' },
    dual: { common: 'ַיִם', ipa: 'ajim' },
    possessive_3s: { m: 'וֹ', f: 'הּ', ipa_m: 'o', ipa_f: 'a' },
    possessive_3p: { m: 'ָם', f: 'ָן', ipa_m: 'am', ipa_f: 'an' },
  },
  
  // Verb patterns (בניינים)
  verb_patterns: {
    // Past tense endings
    past: {
      '1S': { common: 'תִּי', ipa: 'ti' },
      '2SM': { m: 'תָּ', ipa: 'ta' },
      '2SF': { f: 'תְּ', ipa: 't' },
      '3SM': { m: '', ipa: '' },
      '3SF': { f: 'ָה', ipa: 'a' },
      '1P': { common: 'נוּ', ipa: 'nu' },
      '2PM': { m: 'תֶּם', ipa: 'tem' },
      '2PF': { f: 'תֶּן', ipa: 'ten' },
      '3P': { common: 'וּ', ipa: 'u' },
    },
    
    // Present tense patterns (בינוני)
    present: {
      'MS': { pattern: 'קוֹטֵל', ending: '' },
      'FS': { pattern: 'קוֹטֶלֶת', ending: 'ֶת' },
      'MP': { pattern: 'קוֹטְלִים', ending: 'ִים' },
      'FP': { pattern: 'קוֹטְלוֹת', ending: 'וֹת' },
    },
    
    // Future tense prefixes
    future: {
      '1S': { prefix: 'אֶ', ipa: 'e' },
      '2SM': { prefix: 'תִּ', ipa: 'ti' },
      '2SF': { prefix: 'תִּ', suffix: 'ִי', ipa: 'ti...i' },
      '3SM': { prefix: 'יִ', ipa: 'ji' },
      '3SF': { prefix: 'תִּ', ipa: 'ti' },
      '1P': { prefix: 'נִ', ipa: 'ni' },
      '2PM': { prefix: 'תִּ', suffix: 'וּ', ipa: 'ti...u' },
      '2PF': { prefix: 'תִּ', suffix: 'נָה', ipa: 'ti...na' },
      '3PM': { prefix: 'יִ', suffix: 'וּ', ipa: 'ji...u' },
      '3PF': { prefix: 'תִּ', suffix: 'נָה', ipa: 'ti...na' },
    },
  },
  
  // Adjective patterns
  adjective: {
    'MS': { ending: '', example: 'גָּדוֹל' },
    'FS': { ending: 'ָה', example: 'גְּדוֹלָה' },
    'MP': { ending: 'ִים', example: 'גְּדוֹלִים' },
    'FP': { ending: 'וֹת', example: 'גְּדוֹלוֹת' },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API: Nikud lookup functions
// ═══════════════════════════════════════════════════════════════════════════════

// Get nikud for a letter by IPA
function nikudByIPA(letter, ipa, options = {}) {
  const isGuttural = ['א', 'ה', 'ח', 'ע'].includes(letter);
  const mapping = IPA_TO_NIKUD[ipa];
  
  if (!mapping) return null;
  
  // For gutturals, prefer hataf for reduced vowels
  if (isGuttural && mapping.guttural) {
    return letter + mapping.primary;
  }
  
  // Check for male (אם קריאה) option
  if (options.male && mapping.male) {
    return letter + mapping.male;
  }
  
  return letter + mapping.primary;
}

// Get nikud for a letter by English sound
function nikudByEnglish(letter, enSound, options = {}) {
  const ipaOptions = EN_TO_IPA[enSound.toLowerCase()];
  if (!ipaOptions || ipaOptions.length === 0) return null;
  
  // Use first IPA option by default
  return nikudByIPA(letter, ipaOptions[0], options);
}

// Get all nikud options for a letter
function getAllNikudOptions(letter) {
  const isGuttural = ['א', 'ה', 'ח', 'ע'].includes(letter);
  const options = [];
  
  // Regular vowels
  Object.entries(IPA_TO_NIKUD).forEach(([ipa, data]) => {
    if (data.guttural && !isGuttural) return;
    options.push({
      ipa,
      nikud: data.primary,
      combined: letter + data.primary,
      name: data.name,
      male: data.male ? letter + data.male : null,
    });
  });
  
  return options;
}

// Get MG form
function getMGForm(pattern, gender, number = 'S') {
  const key = gender.toUpperCase() + number.toUpperCase();
  const patternData = MG_PATTERNS[pattern];
  
  if (!patternData) return null;
  
  if (patternData[key]) return patternData[key];
  if (patternData[gender.toLowerCase()]) return patternData[gender.toLowerCase()];
  
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

const allCombinations = generateNikudCombinations();

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY NIKUD ENGINE - Complete Letter + Vowel Mapping');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('STATISTICS:');
console.log(`Letters: ${Object.keys(HE_LETTERS).length}`);
console.log(`Nikud marks: ${Object.keys(NIKUD_MARKS).length}`);
console.log(`IPA → Nikud mappings: ${Object.keys(IPA_TO_NIKUD).length}`);
console.log(`English → IPA mappings: ${Object.keys(EN_TO_IPA).length}`);
console.log(`Letter+Nikud combinations: ${Object.keys(allCombinations).length}`);

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('SAMPLE LOOKUPS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('nikudByIPA:');
['ב', 'ג', 'ד', 'א', 'ש'].forEach(letter => {
  console.log(`  ${letter} + /a/ = ${nikudByIPA(letter, 'a')}`);
  console.log(`  ${letter} + /i/ = ${nikudByIPA(letter, 'i')} (male: ${nikudByIPA(letter, 'i', {male: true})})`);
});

console.log('\nnikudByEnglish:');
console.log(`  ב + 'a' = ${nikudByEnglish('ב', 'a')}`);
console.log(`  ב + 'ee' = ${nikudByEnglish('ב', 'ee')}`);
console.log(`  ב + 'oo' = ${nikudByEnglish('ב', 'oo')}`);

console.log('\ngetAllNikudOptions("ב"):');
getAllNikudOptions('ב').slice(0, 5).forEach(opt => {
  console.log(`  /${opt.ipa}/ → ${opt.combined} (${opt.name})`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('MG PATTERNS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Pronouns:');
Object.entries(MG_PATTERNS.pronouns).forEach(([key, val]) => {
  console.log(`  ${key}: ${val.m} (m) / ${val.f} (f)`);
});

console.log('\nNoun endings:');
console.log(`  Plural: ${MG_PATTERNS.endings.plural.m} (m) / ${MG_PATTERNS.endings.plural.f} (f)`);
console.log(`  Possessive 3S: ${MG_PATTERNS.endings.possessive_3s.m} (m) / ${MG_PATTERNS.endings.possessive_3s.f} (f)`);

console.log('\nAdjective pattern (גָּדוֹל):');
Object.entries(MG_PATTERNS.adjective).forEach(([key, val]) => {
  console.log(`  ${key}: ${val.example}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('FULL LETTER+NIKUD TABLE (sample):');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Letter  /a/   /e/   /i/   /o/   /u/   /ə/');
console.log('─────────────────────────────────────────────');
['ב', 'ג', 'ד', 'ה', 'כ', 'ל', 'מ', 'נ', 'ש'].forEach(letter => {
  const a = nikudByIPA(letter, 'a');
  const e = nikudByIPA(letter, 'e');
  const i = nikudByIPA(letter, 'i');
  const o = nikudByIPA(letter, 'o');
  const u = nikudByIPA(letter, 'u');
  const shva = nikudByIPA(letter, 'ə');
  console.log(`  ${letter}     ${a}    ${e}    ${i}    ${o}    ${u}    ${shva}`);
});

// Export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    HE_LETTERS,
    NIKUD_MARKS,
    IPA_TO_NIKUD,
    EN_TO_IPA,
    MG_PATTERNS,
    generateNikudCombinations,
    nikudByIPA,
    nikudByEnglish,
    getAllNikudOptions,
    getMGForm,
  };
}
