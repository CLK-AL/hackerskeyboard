// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW vs ENGLISH VOWELS - Hebrew has MORE vowel distinctions
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// HEBREW VOWELS (NIKUD) - 13+ distinct vowel marks
// ═══════════════════════════════════════════════════════════════════════════════

const HE_VOWELS = {
  // === FULL VOWELS (תנועות גדולות) ===
  
  // A-type vowels
  kamatz: { 
    nikud: 'ָ', name: 'קָמָץ', ipa: 'ɑ', 
    type: 'full', class: 'a',
    example: { word: 'אָב', meaning: 'father' }
  },
  patach: { 
    nikud: 'ַ', name: 'פַּתַח', ipa: 'a', 
    type: 'full', class: 'a',
    example: { word: 'בַּת', meaning: 'daughter' }
  },
  
  // E-type vowels
  segol: { 
    nikud: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ', 
    type: 'full', class: 'e',
    example: { word: 'יֶלֶד', meaning: 'child' }
  },
  tzere: { 
    nikud: 'ֵ', name: 'צֵירֵי', ipa: 'e', 
    type: 'full', class: 'e',
    example: { word: 'בֵּית', meaning: 'house' }
  },
  
  // I-type vowels
  chirik: { 
    nikud: 'ִ', name: 'חִירִיק', ipa: 'i', 
    type: 'full', class: 'i',
    example: { word: 'מִי', meaning: 'who' }
  },
  chirik_male: { 
    nikud: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'iː', 
    type: 'full', class: 'i',
    example: { word: 'שִׁיר', meaning: 'song' }
  },
  
  // O-type vowels
  cholam: { 
    nikud: 'ֹ', name: 'חוֹלָם חָסֵר', ipa: 'o', 
    type: 'full', class: 'o',
    example: { word: 'כֹּל', meaning: 'all' }
  },
  cholam_male: { 
    nikud: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'oː', 
    type: 'full', class: 'o',
    example: { word: 'שָׁלוֹם', meaning: 'peace' }
  },
  kamatz_katan: { 
    nikud: 'ָ', name: 'קָמָץ קָטָן', ipa: 'ɔ', 
    type: 'full', class: 'o',
    note: 'Same mark as kamatz, but short O sound',
    example: { word: 'חָכְמָה', meaning: 'wisdom' }
  },
  
  // U-type vowels
  kubutz: { 
    nikud: 'ֻ', name: 'קֻבּוּץ', ipa: 'u', 
    type: 'full', class: 'u',
    example: { word: 'קֻם', meaning: 'arise' }
  },
  shuruk: { 
    nikud: 'וּ', name: 'שׁוּרוּק', ipa: 'uː', 
    type: 'full', class: 'u',
    example: { word: 'שׁוּק', meaning: 'market' }
  },
  
  // === REDUCED VOWELS (תנועות קטנות / חטפים) ===
  
  shva_na: { 
    nikud: 'ְ', name: 'שְׁוָא נָע', ipa: 'ə', 
    type: 'reduced', class: 'schwa',
    example: { word: 'בְּרֵאשִׁית', meaning: 'in the beginning' }
  },
  shva_nach: { 
    nikud: 'ְ', name: 'שְׁוָא נָח', ipa: '', 
    type: 'silent', class: 'schwa',
    note: 'Silent - no vowel sound',
    example: { word: 'מַלְכָּה', meaning: 'queen' }
  },
  
  // === HATAF VOWELS (חטפים - for gutturals) ===
  
  hataf_patach: { 
    nikud: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'ă', 
    type: 'ultra-short', class: 'a',
    guttural_only: true,
    example: { word: 'אֲנִי', meaning: 'I' }
  },
  hataf_segol: { 
    nikud: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ĕ', 
    type: 'ultra-short', class: 'e',
    guttural_only: true,
    example: { word: 'אֱמֶת', meaning: 'truth' }
  },
  hataf_kamatz: { 
    nikud: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'ŏ', 
    type: 'ultra-short', class: 'o',
    guttural_only: true,
    example: { word: 'חֳלִי', meaning: 'illness' }
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ENGLISH VOWELS - Fewer base vowels, but with length distinctions
// ═══════════════════════════════════════════════════════════════════════════════

const EN_VOWELS = {
  // Short vowels
  'æ': { name: 'short A', ipa: 'æ', spellings: ['a'], example: 'cat' },
  'ɛ': { name: 'short E', ipa: 'ɛ', spellings: ['e', 'ea'], example: 'bed' },
  'ɪ': { name: 'short I', ipa: 'ɪ', spellings: ['i', 'y'], example: 'sit' },
  'ɒ': { name: 'short O', ipa: 'ɒ', spellings: ['o', 'a'], example: 'hot' },
  'ʌ': { name: 'short U', ipa: 'ʌ', spellings: ['u', 'o'], example: 'cup' },
  'ʊ': { name: 'short OO', ipa: 'ʊ', spellings: ['oo', 'u'], example: 'book' },
  
  // Long vowels
  'iː': { name: 'long E', ipa: 'iː', spellings: ['ee', 'ea', 'ie'], example: 'see' },
  'ɑː': { name: 'long A', ipa: 'ɑː', spellings: ['a', 'ar'], example: 'father' },
  'ɔː': { name: 'long O', ipa: 'ɔː', spellings: ['or', 'aw', 'au'], example: 'saw' },
  'uː': { name: 'long U', ipa: 'uː', spellings: ['oo', 'ue', 'ew'], example: 'moon' },
  'ɜː': { name: 'long ER', ipa: 'ɜː', spellings: ['er', 'ir', 'ur'], example: 'bird' },
  
  // Diphthongs (two vowels glided together)
  'eɪ': { name: 'long A', ipa: 'eɪ', spellings: ['a_e', 'ai', 'ay'], example: 'day' },
  'aɪ': { name: 'long I', ipa: 'aɪ', spellings: ['i_e', 'igh', 'y'], example: 'my' },
  'ɔɪ': { name: 'OI', ipa: 'ɔɪ', spellings: ['oi', 'oy'], example: 'boy' },
  'aʊ': { name: 'OU', ipa: 'aʊ', spellings: ['ou', 'ow'], example: 'now' },
  'oʊ': { name: 'long O', ipa: 'oʊ', spellings: ['o', 'oa', 'ow'], example: 'go' },
  
  // Schwa
  'ə': { name: 'schwa', ipa: 'ə', spellings: ['a', 'e', 'i', 'o', 'u'], example: 'about' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// COMPARISON
// ═══════════════════════════════════════════════════════════════════════════════

const COMPARISON = {
  hebrew: {
    total_vowels: 16, // Including hatafim and male/chaser variants
    full_vowels: 11,
    reduced_vowels: 2, // shva na, shva nach
    hataf_vowels: 3,
    unique_features: [
      'Hataf vowels for gutturals only',
      'Male/Chaser distinction (with/without vav/yod)',
      'Kamatz gadol vs katan (same mark, different sound)',
      'Shva na vs nach (same mark, voiced vs silent)',
    ],
  },
  english: {
    total_vowels: 17, // Including diphthongs
    pure_vowels: 11,
    diphthongs: 5,
    schwa: 1,
    unique_features: [
      'Diphthongs (two vowels glided)',
      'Highly irregular spelling-to-sound',
      'R-colored vowels',
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('HEBREW vs ENGLISH VOWELS - Hebrew has MORE vowel marks');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('HEBREW VOWELS (ניקוד) - 16 distinct vowel marks:');
console.log('─────────────────────────────────────────────────────────────────────────────────────\n');

console.log('FULL VOWELS (תנועות גדולות):');
console.log('  A-class:  ָ קָמָץ /ɑ/    ַ פַּתַח /a/');
console.log('  E-class:  ֶ סֶגוֹל /ɛ/   ֵ צֵירֵי /e/');
console.log('  I-class:  ִ חִירִיק /i/   ִי חִירִיק מָלֵא /iː/');
console.log('  O-class:  ֹ חוֹלָם /o/    וֹ חוֹלָם מָלֵא /oː/   ָ קָמָץ קָטָן /ɔ/');
console.log('  U-class:  ֻ קֻבּוּץ /u/   וּ שׁוּרוּק /uː/');

console.log('\nREDUCED VOWELS (תנועות קטנות):');
console.log('  ְ שְׁוָא נָע /ə/   (mobile - makes sound)');
console.log('  ְ שְׁוָא נָח /-/   (silent - no sound)');

console.log('\nHATAF VOWELS (חטפים - gutturals only!):');
console.log('  ֲ חֲטַף פַּתַח /ă/   ֱ חֲטַף סֶגוֹל /ĕ/   ֳ חֲטַף קָמָץ /ŏ/');
console.log('  Used ONLY with: א ה ח ע');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ENGLISH VOWELS - 17 vowel sounds:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('SHORT VOWELS:');
console.log('  /æ/ cat   /ɛ/ bed   /ɪ/ sit   /ɒ/ hot   /ʌ/ cup   /ʊ/ book');

console.log('\nLONG VOWELS:');
console.log('  /iː/ see   /ɑː/ father   /ɔː/ saw   /uː/ moon   /ɜː/ bird');

console.log('\nDIPHTHONGS:');
console.log('  /eɪ/ day   /aɪ/ my   /ɔɪ/ boy   /aʊ/ now   /oʊ/ go');

console.log('\nSCHWA:');
console.log('  /ə/ about');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('KEY DIFFERENCES:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('Hebrew unique features:');
console.log('  • Hataf vowels (חטפים) - ultra-short, gutturals only');
console.log('  • Male/Chaser - same sound with/without mater lectionis');
console.log('  • Kamatz gadol/katan - same mark, different sounds');
console.log('  • Shva na/nach - same mark, voiced/silent');
console.log('');
console.log('English unique features:');
console.log('  • Diphthongs - two vowels glided together');
console.log('  • Highly irregular spelling');
console.log('  • R-colored vowels');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('VOWEL COUNT COMPARISON:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌────────────────────────────────────────────────────────────┐');
console.log('  │  Hebrew Nikud:  16 distinct vowel marks                    │');
console.log('  │    • 11 full vowels                                        │');
console.log('  │    • 2 reduced (shva)                                      │');
console.log('  │    • 3 hataf (gutturals)                                   │');
console.log('  │                                                            │');
console.log('  │  English:       17 vowel sounds                            │');
console.log('  │    • 11 pure vowels                                        │');
console.log('  │    • 5 diphthongs                                          │');
console.log('  │    • 1 schwa                                               │');
console.log('  │                                                            │');
console.log('  │  BUT: Hebrew has MORE fine distinctions!                   │');
console.log('  │    • A: קָמָץ vs פַּתַח vs חֲטַף פַּתַח                         │');
console.log('  │    • E: צֵירֵי vs סֶגוֹל vs חֲטַף סֶגוֹל                        │');
console.log('  │    • O: חוֹלָם vs קָמָץ קָטָן vs חֲטַף קָמָץ                     │');
console.log('  └────────────────────────────────────────────────────────────┘');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('HEBREW VOWEL GRID - All 16 marks:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const grid = [
  ['Type', 'A', 'E', 'I', 'O', 'U'],
  ['Full', 'ָ ַ', 'ֵ ֶ', 'ִ ִי', 'ֹ וֹ', 'ֻ וּ'],
  ['Hataf', 'ֲ', 'ֱ', '-', 'ֳ', '-'],
  ['Reduced', '', '', '', '', 'ְ'],
];

grid.forEach(row => {
  console.log(`  ${row[0].padEnd(8)} ${row.slice(1).map(c => c.padEnd(6)).join('')}`);
});
