// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - VOWEL APPROXIMATIONS (תעתיק קירוב)
// ═══════════════════════════════════════════════════════════════════════════════
//
// English vowels that don't exist in Hebrew have APPROXIMATIONS (קירוב)
// These are NOT exact matches - they're the closest Hebrew equivalent
//
// ═══════════════════════════════════════════════════════════════════════════════

const VOWEL_MAP = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // EXACT MATCHES (התאמה מדויקת)
  // ═══════════════════════════════════════════════════════════════════════════
  
  // These have direct equivalents in both languages
  
  'a': {
    ipa: 'a',
    type: 'exact',
    he: { mark: 'ַ', name: 'פַּתַח', male: null },
    en: { spellings: ['a'], examples: ['father (first a)', 'spa'] },
    match_quality: 'exact',
  },
  
  'i': {
    ipa: 'i',
    type: 'exact',
    he: { mark: 'ִ', name: 'חִירִיק', male: 'ִי' },
    en: { spellings: ['ee', 'ea', 'i'], examples: ['see', 'eat', 'machine'] },
    match_quality: 'exact',
  },
  
  'u': {
    ipa: 'u',
    type: 'exact',
    he: { mark: 'ֻ', name: 'קֻבּוּץ', male: 'וּ' },
    en: { spellings: ['oo', 'u', 'ue'], examples: ['moon', 'rule', 'blue'] },
    match_quality: 'exact',
  },
  
  'e': {
    ipa: 'e',
    type: 'exact',
    he: { mark: 'ֵ', name: 'צֵירֵי', male: 'ֵי' },
    en: { spellings: ['ay', 'ai', 'ei'], examples: ['say', 'rain', 'vein'] },
    match_quality: 'exact',
    note: 'English often diphthongizes to /eɪ/',
  },
  
  'o': {
    ipa: 'o',
    type: 'exact',
    he: { mark: 'ֹ', name: 'חוֹלָם', male: 'וֹ' },
    en: { spellings: ['o', 'oa', 'ow'], examples: ['go', 'boat', 'show'] },
    match_quality: 'exact',
    note: 'English often diphthongizes to /oʊ/',
  },
  
  'ɛ': {
    ipa: 'ɛ',
    type: 'exact',
    he: { mark: 'ֶ', name: 'סֶגוֹל', male: 'ֶא' },
    en: { spellings: ['e', 'ea'], examples: ['bed', 'bread'] },
    match_quality: 'exact',
  },
  
  'ə': {
    ipa: 'ə',
    type: 'exact',
    he: { mark: 'ְ', name: 'שְׁוָא נָע', male: null },
    en: { spellings: ['a', 'e', 'i', 'o', 'u'], examples: ['about', 'taken'] },
    match_quality: 'exact',
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // APPROXIMATIONS (קירוב - לא מדויק!)
  // ═══════════════════════════════════════════════════════════════════════════
  
  'æ': {
    ipa: 'æ',
    type: 'approximation',
    he: { 
      mark: 'ֶ', 
      name: 'סֶגוֹל (קירוב)', 
      male: null,
      alt_mark: 'ַ',
      alt_name: 'פַּתַח (קירוב)',
    },
    en: { spellings: ['a'], examples: ['cat', 'bat', 'man'] },
    match_quality: 'approximate',
    transcription: {
      cat: 'קֶט',      // More accurate to Hebrew ears
      bat: 'בֶּט',
      man: 'מֶן',
      // Alternative with patach (more common in Israeli transcription)
      cat_alt: 'קַט',
      bat_alt: 'בַּט',
      man_alt: 'מַן',
    },
    note: 'Hebrew has no /æ/. Closest is סֶגוֹל /ɛ/ or פַּתַח /a/. Neither is exact!',
    warning: '⚠️ קירוב בלבד - הצליל האנגלי שונה!',
  },
  
  'ʌ': {
    ipa: 'ʌ',
    type: 'approximation',
    he: { 
      mark: 'ַ', 
      name: 'פַּתַח (קירוב)', 
      male: null,
      alt_mark: 'ָ',
      alt_name: 'קָמָץ (קירוב)',
    },
    en: { spellings: ['u', 'o', 'ou'], examples: ['cup', 'son', 'touch'] },
    match_quality: 'approximate',
    transcription: {
      cup: 'קַפּ',      // Common Israeli transcription
      son: 'סַן',
      blood: 'בְּלַד',
      // Alternative with kamatz
      cup_alt: 'קָפּ',
      love: 'לָב',
    },
    note: 'Hebrew has no /ʌ/. Closest is פַּתַח /a/. The English sound is more central.',
    warning: '⚠️ קירוב בלבד - הצליל האנגלי שונה!',
  },
  
  'ɒ': {
    ipa: 'ɒ',
    type: 'approximation',
    he: { 
      mark: 'ָ', 
      name: 'קָמָץ קָטָן (קירוב)', 
      male: null,
      alt_mark: 'ֹ',
      alt_name: 'חוֹלָם (קירוב)',
    },
    en: { spellings: ['o', 'a'], examples: ['hot', 'lot', 'want'] },
    match_quality: 'approximate',
    transcription: {
      hot: 'הָט',       // With kamatz katan
      lot: 'לָט',
      want: 'וָנט',
      // Alternative with cholam
      hot_alt: 'הֹט',
      got: 'גֹט',
    },
    note: 'Hebrew has no /ɒ/. British "hot" is between קָמָץ קָטָן /ɔ/ and חוֹלָם /o/.',
    warning: '⚠️ קירוב בלבד - הצליל האנגלי שונה!',
    dialect: 'British English primarily. American uses /ɑː/ instead.',
  },
  
  'ɪ': {
    ipa: 'ɪ',
    type: 'approximation',
    he: { 
      mark: 'ִ', 
      name: 'חִירִיק (קירוב)', 
      male: null,
    },
    en: { spellings: ['i', 'y', 'e'], examples: ['sit', 'gym', 'pretty'] },
    match_quality: 'approximate',
    transcription: {
      sit: 'סִיט',      // Usually transcribed as chirik
      bit: 'בִּיט',
      gym: 'גִ׳ים',
    },
    note: 'Hebrew חִירִיק is closer to /i/. English /ɪ/ is more lax/centralized.',
    warning: '⚠️ קירוב בלבד - הצליל האנגלי יותר רפוי!',
  },
  
  'ʊ': {
    ipa: 'ʊ',
    type: 'approximation',
    he: { 
      mark: 'ֻ', 
      name: 'קֻבּוּץ (קירוב)', 
      male: null,
    },
    en: { spellings: ['oo', 'u', 'ou'], examples: ['book', 'put', 'could'] },
    match_quality: 'approximate',
    transcription: {
      book: 'בּוּק',
      put: 'פּוּט',
      good: 'גוּד',
    },
    note: 'Hebrew קֻבּוּץ is closer to /u/. English /ʊ/ is more lax/centralized.',
    warning: '⚠️ קירוב בלבד - הצליל האנגלי יותר רפוי!',
  },
  
  'ɜː': {
    ipa: 'ɜː',
    type: 'approximation',
    he: { 
      mark: 'ֶ', 
      name: 'סֶגוֹל (קירוב)', 
      male: null,
      alt_mark: 'ְ',
      alt_name: 'שְׁוָא (קירוב)',
    },
    en: { spellings: ['er', 'ir', 'ur', 'ear'], examples: ['bird', 'her', 'turn'] },
    match_quality: 'approximate',
    transcription: {
      bird: 'בֶּרד',     // Israeli common
      her: 'הֶר',
      turn: 'טֶרן',
      // R-less transcription
      bird_alt: 'בְּרד',
    },
    note: 'Hebrew has no central rounded vowel. This is a rough approximation.',
    warning: '⚠️ קירוב גס - הצליל האנגלי שונה מאוד!',
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DIPHTHONGS (תנועות כפולות)
  // ═══════════════════════════════════════════════════════════════════════════
  
  'aɪ': {
    ipa: 'aɪ',
    type: 'diphthong',
    he: { mark: 'ַי', name: 'פַּתַח + יוֹד', male: null, he_ipa: 'aj' },
    en: { spellings: ['i', 'y', 'igh', 'ie'], examples: ['my', 'fly', 'high', 'tie'] },
    match_quality: 'near-exact',
    transcription: {
      my: 'מַיי',
      fly: 'פְלַיי',
      high: 'הַיי',
    },
  },
  
  'eɪ': {
    ipa: 'eɪ',
    type: 'diphthong',
    he: { mark: 'ֵי', name: 'צֵירֵי + יוֹד', male: null, he_ipa: 'ej' },
    en: { spellings: ['a', 'ay', 'ai', 'ei'], examples: ['day', 'say', 'rain', 'vein'] },
    match_quality: 'near-exact',
    transcription: {
      day: 'דֵיי',
      say: 'סֵיי',
      make: 'מֵייק',
    },
  },
  
  'ɔɪ': {
    ipa: 'ɔɪ',
    type: 'diphthong',
    he: { mark: 'וֹי', name: 'חוֹלָם + יוֹד', male: null, he_ipa: 'oj' },
    en: { spellings: ['oi', 'oy'], examples: ['boy', 'oil', 'toy'] },
    match_quality: 'near-exact',
    transcription: {
      boy: 'בּוֹי',
      toy: 'טוֹי',
      oil: 'אוֹיל',
    },
  },
  
  'aʊ': {
    ipa: 'aʊ',
    type: 'diphthong',
    he: { mark: 'ָאוּ', name: 'קָמָץ + וָו', male: null, he_ipa: 'aw' },
    en: { spellings: ['ou', 'ow'], examples: ['now', 'out', 'how'] },
    match_quality: 'near-exact',
    transcription: {
      now: 'נָאוּ',
      out: 'אָאוּט',
      how: 'הָאוּ',
    },
  },
  
  'oʊ': {
    ipa: 'oʊ',
    type: 'diphthong',
    he: { mark: 'וֹ', name: 'חוֹלָם מָלֵא (קירוב)', male: null },
    en: { spellings: ['o', 'ow', 'oa'], examples: ['go', 'show', 'boat'] },
    match_quality: 'approximate',
    transcription: {
      go: 'גּוֹ',
      show: 'שׁוֹ',
      boat: 'בּוֹט',
    },
    note: 'Hebrew /o/ is pure. English /oʊ/ glides to /ʊ/.',
    warning: '⚠️ עברית: תנועה טהורה. אנגלית: דיפתונג!',
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// TRANSCRIPTION QUALITY GUIDE
// ═══════════════════════════════════════════════════════════════════════════════

const QUALITY_GUIDE = {
  'exact': {
    symbol: '✅',
    description: 'התאמה מדויקת',
    description_en: 'Exact match',
  },
  'near-exact': {
    symbol: '✓',
    description: 'כמעט מדויק',
    description_en: 'Near-exact match',
  },
  'approximate': {
    symbol: '⚠️',
    description: 'קירוב בלבד - לא מדויק!',
    description_en: 'Approximation only - not exact!',
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API Functions
// ═══════════════════════════════════════════════════════════════════════════════

function getVowelInfo(ipa) {
  return VOWEL_MAP[ipa] || null;
}

function getHebrewForIPA(ipa, options = {}) {
  const vowel = VOWEL_MAP[ipa];
  if (!vowel) return null;
  
  return {
    mark: vowel.he.mark,
    name: vowel.he.name,
    quality: QUALITY_GUIDE[vowel.match_quality],
    warning: vowel.warning || null,
    alt: vowel.he.alt_mark ? { mark: vowel.he.alt_mark, name: vowel.he.alt_name } : null,
  };
}

function transcribe(enWord, ipa) {
  const vowel = VOWEL_MAP[ipa];
  if (!vowel || !vowel.transcription) return null;
  
  return vowel.transcription[enWord] || null;
}

function isApproximation(ipa) {
  const vowel = VOWEL_MAP[ipa];
  return vowel?.type === 'approximation';
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('VOWEL APPROXIMATIONS - קירוב תנועות');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('EXACT MATCHES (התאמה מדויקת):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
Object.entries(VOWEL_MAP).filter(([_, v]) => v.type === 'exact').forEach(([ipa, v]) => {
  console.log(`✅ /${ipa}/  ${v.he.mark} ${v.he.name.padEnd(15)}  ${v.en.examples.slice(0,2).join(', ')}`);
});

console.log('\nAPPROXIMATIONS (קירוב - לא מדויק!):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
Object.entries(VOWEL_MAP).filter(([_, v]) => v.type === 'approximation').forEach(([ipa, v]) => {
  console.log(`⚠️ /${ipa}/  ${v.he.mark} ${v.he.name.padEnd(20)}  ${v.en.examples.slice(0,2).join(', ')}`);
  if (v.transcription) {
    const examples = Object.entries(v.transcription).slice(0, 3);
    console.log(`         תעתיק: ${examples.map(([en, he]) => `${en}→${he}`).join(', ')}`);
  }
  console.log(`         ${v.warning}`);
});

console.log('\nDIPHTHONGS (תנועות כפולות):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
Object.entries(VOWEL_MAP).filter(([_, v]) => v.type === 'diphthong').forEach(([ipa, v]) => {
  const symbol = v.match_quality === 'near-exact' ? '✓' : '⚠️';
  console.log(`${symbol} /${ipa}/  ${v.he.mark} ${v.he.name.padEnd(20)}  ${v.en.examples.slice(0,2).join(', ')}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('TRANSCRIPTION EXAMPLES:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('English → Hebrew Transcription (with quality indicator):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');

const examples = [
  { en: 'cat', ipa: 'æ', he: 'קֶט / קַט' },
  { en: 'cup', ipa: 'ʌ', he: 'קַפּ' },
  { en: 'hot', ipa: 'ɒ', he: 'הָט / הֹט' },
  { en: 'sit', ipa: 'ɪ', he: 'סִיט' },
  { en: 'book', ipa: 'ʊ', he: 'בּוּק' },
  { en: 'bird', ipa: 'ɜː', he: 'בֶּרד' },
  { en: 'see', ipa: 'i', he: 'סִי' },
  { en: 'moon', ipa: 'u', he: 'מוּן' },
];

examples.forEach(ex => {
  const vowel = VOWEL_MAP[ex.ipa];
  const symbol = vowel?.match_quality === 'exact' ? '✅' : '⚠️';
  console.log(`${symbol} ${ex.en.padEnd(6)} /${ex.ipa.padEnd(3)}/  →  ${ex.he}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('  ┌─────────────────────────────────────────────────────────────────────────────┐');
console.log('  │                                                                             │');
console.log('  │   ⚠️ APPROXIMATIONS ARE NOT EXACT MATCHES!                                  │');
console.log('  │      קירוב אינו התאמה מדויקת!                                                │');
console.log('  │                                                                             │');
console.log('  │   English vowels that don\'t exist in Hebrew:                               │');
console.log('  │   תנועות אנגליות שאינן קיימות בעברית:                                         │');
console.log('  │                                                                             │');
console.log('  │   /æ/ (cat)  → ⚠️ סֶגוֹל או פַּתַח (לא אותו צליל!)                            │');
console.log('  │   /ʌ/ (cup)  → ⚠️ פַּתַח (לא אותו צליל!)                                    │');
console.log('  │   /ɒ/ (hot)  → ⚠️ קָמָץ קָטָן או חוֹלָם (לא אותו צליל!)                       │');
console.log('  │   /ɪ/ (sit)  → ⚠️ חִירִיק (יותר רפוי באנגלית)                               │');
console.log('  │   /ʊ/ (book) → ⚠️ קֻבּוּץ (יותר רפוי באנגלית)                               │');
console.log('  │   /ɜː/ (bird) → ⚠️ סֶגוֹל או שְׁוָא (קירוב גס!)                              │');
console.log('  │                                                                             │');
console.log('  │   The transcription is for READING, not for PRONUNCIATION!                 │');
console.log('  │   התעתיק הוא לקריאה, לא להגייה!                                               │');
console.log('  │                                                                             │');
console.log('  └─────────────────────────────────────────────────────────────────────────────┘');

// Export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    VOWEL_MAP,
    QUALITY_GUIDE,
    getVowelInfo,
    getHebrewForIPA,
    transcribe,
    isApproximation,
  };
}
