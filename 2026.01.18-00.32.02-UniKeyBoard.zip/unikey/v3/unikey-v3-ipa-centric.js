// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V3 - IPA AS PRIMARY KEY (Sound → All Variations)
// ═══════════════════════════════════════════════════════════════════════════════
// IPA phoneme is the UNIVERSAL KEY that maps to:
//   - Hebrew letters that produce this sound (with their unique nikud options)
//   - English letters/digraphs that produce this sound (with spelling patterns)
//   - All syllable variations in BOTH languages
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_UNIKEYS = {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // CONSONANTS
  // ═══════════════════════════════════════════════════════════════════════════
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /ʃ/ - SHIN sound (שׁ vs English sh)
  // ─────────────────────────────────────────────────────────────────────────────
  'ʃ': {
    name: 'voiceless postalveolar fricative',
    
    // Hebrew: ONLY שׁ (shin with RIGHT dot)
    he: {
      letters: ['שׁ'],
      base: 'ש',
      diacritic: 'ׁ', // shin dot (right)
      
      // Unique nikud options for שׁ
      syllables: [
        { text: 'שַׁ', nikud: 'ַ', name: 'שִׁין פַּתַח', ipa: 'ʃa' },
        { text: 'שָׁ', nikud: 'ָ', name: 'שִׁין קָמָץ', ipa: 'ʃɑ' },
        { text: 'שֶׁ', nikud: 'ֶ', name: 'שִׁין סֶגוֹל', ipa: 'ʃɛ' },
        { text: 'שֵׁ', nikud: 'ֵ', name: 'שִׁין צֵירֵי', ipa: 'ʃe' },
        { text: 'שִׁ', nikud: 'ִ', name: 'שִׁין חִירִיק', ipa: 'ʃi' },
        { text: 'שֹׁ', nikud: 'ֹ', name: 'שִׁין חוֹלָם', ipa: 'ʃo' },
        { text: 'שֻׁ', nikud: 'ֻ', name: 'שִׁין קֻבּוּץ', ipa: 'ʃu' },
        { text: 'שְׁ', nikud: 'ְ', name: 'שִׁין שְׁוָא', ipa: 'ʃə' },
      ],
      examples: ['שָׁלוֹם', 'שֶׁמֶשׁ', 'שִׁיר'],
    },
    
    // English: sh, ti, ci, ssi, etc.
    en: {
      spellings: ['sh', 'ti', 'ci', 'ssi', 'si', 'ch'],
      primary: 'sh',
      
      // Syllable patterns
      syllables: [
        { text: 'sha', spelling: 'sh+a', ipa: 'ʃæ', ex: 'shall' },
        { text: 'she', spelling: 'sh+e', ipa: 'ʃi', ex: 'she' },
        { text: 'shi', spelling: 'sh+i', ipa: 'ʃɪ', ex: 'ship' },
        { text: 'sho', spelling: 'sh+o', ipa: 'ʃɑ', ex: 'shop' },
        { text: 'shu', spelling: 'sh+u', ipa: 'ʃʌ', ex: 'shut' },
        { text: 'tion', spelling: 'ti+on', ipa: 'ʃən', ex: 'nation' },
        { text: 'sion', spelling: 'si+on', ipa: 'ʃən', ex: 'mission' },
        { text: 'cial', spelling: 'ci+al', ipa: 'ʃəl', ex: 'special' },
      ],
      examples: ['she', 'ship', 'nation', 'special'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /s/ - SAMECH/SIN sound (ס OR שׂ vs English s)
  // ─────────────────────────────────────────────────────────────────────────────
  's': {
    name: 'voiceless alveolar fricative',
    
    // Hebrew: ס (samech) OR שׂ (sin with LEFT dot) - SAME SOUND, DIFFERENT LETTERS!
    he: {
      letters: ['ס', 'שׂ'],
      
      // ס (Samech) - regular consonant
      samech: {
        base: 'ס',
        syllables: [
          { text: 'סַ', nikud: 'ַ', name: 'סָמֶךְ פַּתַח', ipa: 'sa' },
          { text: 'סָ', nikud: 'ָ', name: 'סָמֶךְ קָמָץ', ipa: 'sɑ' },
          { text: 'סֶ', nikud: 'ֶ', name: 'סָמֶךְ סֶגוֹל', ipa: 'sɛ' },
          { text: 'סֵ', nikud: 'ֵ', name: 'סָמֶךְ צֵירֵי', ipa: 'se' },
          { text: 'סִ', nikud: 'ִ', name: 'סָמֶךְ חִירִיק', ipa: 'si' },
          { text: 'סֹ', nikud: 'ֹ', name: 'סָמֶךְ חוֹלָם', ipa: 'so' },
          { text: 'סֻ', nikud: 'ֻ', name: 'סָמֶךְ קֻבּוּץ', ipa: 'su' },
          { text: 'סְ', nikud: 'ְ', name: 'סָמֶךְ שְׁוָא', ipa: 'sə' },
        ],
        examples: ['סוּס', 'סֵפֶר', 'סָבָא'],
      },
      
      // שׂ (Sin) - shin with LEFT dot
      sin: {
        base: 'ש',
        diacritic: 'ׂ', // sin dot (left)
        syllables: [
          { text: 'שַׂ', nikud: 'ַ', name: 'שִׂין פַּתַח', ipa: 'sa' },
          { text: 'שָׂ', nikud: 'ָ', name: 'שִׂין קָמָץ', ipa: 'sɑ' },
          { text: 'שֶׂ', nikud: 'ֶ', name: 'שִׂין סֶגוֹל', ipa: 'sɛ' },
          { text: 'שֵׂ', nikud: 'ֵ', name: 'שִׂין צֵירֵי', ipa: 'se' },
          { text: 'שִׂ', nikud: 'ִ', name: 'שִׂין חִירִיק', ipa: 'si' },
          { text: 'שֹׂ', nikud: 'ֹ', name: 'שִׂין חוֹלָם', ipa: 'so' },
          { text: 'שֻׂ', nikud: 'ֻ', name: 'שִׂין קֻבּוּץ', ipa: 'su' },
          { text: 'שְׂ', nikud: 'ְ', name: 'שִׂין שְׁוָא', ipa: 'sə' },
        ],
        examples: ['שָׂדֶה', 'שָׂרָה', 'שְׂמֹאל'],
      },
    },
    
    // English: s, c, ss, sc, etc.
    en: {
      spellings: ['s', 'c', 'ss', 'sc', 'ce', 'se'],
      primary: 's',
      
      syllables: [
        { text: 'sa', spelling: 's+a', ipa: 'sæ', ex: 'sat' },
        { text: 'se', spelling: 's+e', ipa: 'sɛ', ex: 'set' },
        { text: 'si', spelling: 's+i', ipa: 'sɪ', ex: 'sit' },
        { text: 'so', spelling: 's+o', ipa: 'soʊ', ex: 'so' },
        { text: 'su', spelling: 's+u', ipa: 'sʌ', ex: 'sun' },
        { text: 'ce', spelling: 'c+e', ipa: 'si', ex: 'cent' },
        { text: 'ci', spelling: 'c+i', ipa: 'sɪ', ex: 'city' },
        { text: 'cy', spelling: 'c+y', ipa: 'si', ex: 'cycle' },
        { text: 'ss', spelling: 'ss', ipa: 's', ex: 'miss' },
      ],
      examples: ['sun', 'city', 'miss', 'scene'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /k/ - KAF/QOF sound (כּ OR ק vs English k/c)
  // ─────────────────────────────────────────────────────────────────────────────
  'k': {
    name: 'voiceless velar stop',
    
    he: {
      letters: ['כּ', 'ק'],
      
      // כּ (Kaf with dagesh)
      kaf: {
        base: 'כ',
        dagesh: true,
        syllables: [
          { text: 'כַּ', nikud: 'ַ', name: 'כָּף פַּתַח', ipa: 'ka' },
          { text: 'כָּ', nikud: 'ָ', name: 'כָּף קָמָץ', ipa: 'kɑ' },
          { text: 'כֶּ', nikud: 'ֶ', name: 'כָּף סֶגוֹל', ipa: 'kɛ' },
          { text: 'כֵּ', nikud: 'ֵ', name: 'כָּף צֵירֵי', ipa: 'ke' },
          { text: 'כִּ', nikud: 'ִ', name: 'כָּף חִירִיק', ipa: 'ki' },
          { text: 'כֹּ', nikud: 'ֹ', name: 'כָּף חוֹלָם', ipa: 'ko' },
          { text: 'כֻּ', nikud: 'ֻ', name: 'כָּף קֻבּוּץ', ipa: 'ku' },
          { text: 'כְּ', nikud: 'ְ', name: 'כָּף שְׁוָא', ipa: 'kə' },
        ],
        examples: ['כֹּל', 'כֵּן', 'כִּי'],
      },
      
      // ק (Qof)
      qof: {
        base: 'ק',
        syllables: [
          { text: 'קַ', nikud: 'ַ', name: 'קוֹף פַּתַח', ipa: 'ka' },
          { text: 'קָ', nikud: 'ָ', name: 'קוֹף קָמָץ', ipa: 'kɑ' },
          { text: 'קֶ', nikud: 'ֶ', name: 'קוֹף סֶגוֹל', ipa: 'kɛ' },
          { text: 'קֵ', nikud: 'ֵ', name: 'קוֹף צֵירֵי', ipa: 'ke' },
          { text: 'קִ', nikud: 'ִ', name: 'קוֹף חִירִיק', ipa: 'ki' },
          { text: 'קֹ', nikud: 'ֹ', name: 'קוֹף חוֹלָם', ipa: 'ko' },
          { text: 'קֻ', nikud: 'ֻ', name: 'קוֹף קֻבּוּץ', ipa: 'ku' },
          { text: 'קְ', nikud: 'ְ', name: 'קוֹף שְׁוָא', ipa: 'kə' },
        ],
        examples: ['קָטָן', 'קוֹל', 'קָם'],
      },
    },
    
    en: {
      spellings: ['k', 'c', 'ck', 'ch', 'q', 'que'],
      primary: 'k',
      
      syllables: [
        { text: 'ka', spelling: 'k/c+a', ipa: 'kæ', ex: 'cat' },
        { text: 'ke', spelling: 'k+e', ipa: 'kɛ', ex: 'kept' },
        { text: 'ki', spelling: 'k+i', ipa: 'kɪ', ex: 'kid' },
        { text: 'ko', spelling: 'k/c+o', ipa: 'koʊ', ex: 'coat' },
        { text: 'ku', spelling: 'k/c+u', ipa: 'kʌ', ex: 'cup' },
        { text: 'ck', spelling: 'ck', ipa: 'k', ex: 'back' },
        { text: 'que', spelling: 'que', ipa: 'k', ex: 'unique' },
      ],
      examples: ['cat', 'kid', 'back', 'queen'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /x/ - KHAF/CHET sound (כ OR ח vs Scottish ch/German ch)
  // ─────────────────────────────────────────────────────────────────────────────
  'x': {
    name: 'voiceless velar fricative',
    
    he: {
      letters: ['כ', 'ח'],
      
      // כ (Khaf without dagesh)
      khaf: {
        base: 'כ',
        dagesh: false,
        final: 'ך',
        syllables: [
          { text: 'כַ', nikud: 'ַ', name: 'כָף פַּתַח', ipa: 'xa' },
          { text: 'כָ', nikud: 'ָ', name: 'כָף קָמָץ', ipa: 'xɑ' },
          { text: 'כֶ', nikud: 'ֶ', name: 'כָף סֶגוֹל', ipa: 'xɛ' },
          { text: 'כֵ', nikud: 'ֵ', name: 'כָף צֵירֵי', ipa: 'xe' },
          { text: 'כִ', nikud: 'ִ', name: 'כָף חִירִיק', ipa: 'xi' },
          { text: 'כֹ', nikud: 'ֹ', name: 'כָף חוֹלָם', ipa: 'xo' },
          { text: 'כֻ', nikud: 'ֻ', name: 'כָף קֻבּוּץ', ipa: 'xu' },
          { text: 'כְ', nikud: 'ְ', name: 'כָף שְׁוָא', ipa: 'xə' },
        ],
        // Final form ך
        final_syllables: [
          { text: 'ךְ', nikud: 'ְ', name: 'כָף סוֹפִית שְׁוָא', ipa: 'x' },
          { text: 'ךָ', nikud: 'ָ', name: 'כָף סוֹפִית קָמָץ', ipa: 'xa' },
        ],
        examples: ['לֶכֶת', 'מֶלֶךְ', 'בָּרוּךְ'],
      },
      
      // ח (Chet) - guttural, special rules!
      chet: {
        base: 'ח',
        guttural: true,
        syllables: [
          { text: 'חַ', nikud: 'ַ', name: 'חֵית פַּתַח', ipa: 'xa' },
          { text: 'חָ', nikud: 'ָ', name: 'חֵית קָמָץ', ipa: 'xɑ' },
          { text: 'חֶ', nikud: 'ֶ', name: 'חֵית סֶגוֹל', ipa: 'xɛ' },
          { text: 'חֵ', nikud: 'ֵ', name: 'חֵית צֵירֵי', ipa: 'xe' },
          { text: 'חִ', nikud: 'ִ', name: 'חֵית חִירִיק', ipa: 'xi' },
          { text: 'חֹ', nikud: 'ֹ', name: 'חֵית חוֹלָם', ipa: 'xo' },
          // Hataf vowels (gutturals only!)
          { text: 'חֲ', nikud: 'ֲ', name: 'חֵית חֲטַף פַּתַח', ipa: 'xa' },
          { text: 'חֱ', nikud: 'ֱ', name: 'חֵית חֲטַף סֶגוֹל', ipa: 'xɛ' },
          { text: 'חֳ', nikud: 'ֳ', name: 'חֵית חֲטַף קָמָץ', ipa: 'xo' },
        ],
        // Furtive patach (פתח גנובה) - unique to gutturals at word end!
        furtive: { text: 'חַ', note: 'פַּתַח גְּנוּבָה - at word end', ipa: 'ax' },
        examples: ['חַם', 'חָכָם', 'רוּחַ'],
      },
    },
    
    en: {
      spellings: ['ch', 'kh'],
      primary: 'ch',
      note: 'Not native to English - appears in loanwords',
      syllables: [
        { text: 'ch', spelling: 'ch', ipa: 'x', ex: 'loch (Scottish)' },
        { text: 'kh', spelling: 'kh', ipa: 'x', ex: 'khan' },
      ],
      examples: ['loch', 'Bach', 'chutzpah'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /b/ - BET sound (בּ vs English b)
  // ─────────────────────────────────────────────────────────────────────────────
  'b': {
    name: 'voiced bilabial stop',
    
    he: {
      letters: ['בּ'],
      
      bet: {
        base: 'ב',
        dagesh: true, // בּ with dagesh = /b/
        syllables: [
          { text: 'בַּ', nikud: 'ַ', name: 'בֵּית פַּתַח', ipa: 'ba' },
          { text: 'בָּ', nikud: 'ָ', name: 'בֵּית קָמָץ', ipa: 'bɑ' },
          { text: 'בֶּ', nikud: 'ֶ', name: 'בֵּית סֶגוֹל', ipa: 'bɛ' },
          { text: 'בֵּ', nikud: 'ֵ', name: 'בֵּית צֵירֵי', ipa: 'be' },
          { text: 'בִּ', nikud: 'ִ', name: 'בֵּית חִירִיק', ipa: 'bi' },
          { text: 'בֹּ', nikud: 'ֹ', name: 'בֵּית חוֹלָם', ipa: 'bo' },
          { text: 'בֻּ', nikud: 'ֻ', name: 'בֵּית קֻבּוּץ', ipa: 'bu' },
          { text: 'בְּ', nikud: 'ְ', name: 'בֵּית שְׁוָא', ipa: 'bə' },
        ],
        examples: ['בַּיִת', 'בֵּן', 'בֹּקֶר'],
      },
    },
    
    en: {
      spellings: ['b', 'bb'],
      primary: 'b',
      syllables: [
        { text: 'ba', ipa: 'bæ', ex: 'bat' },
        { text: 'be', ipa: 'bi', ex: 'be' },
        { text: 'bi', ipa: 'bɪ', ex: 'bit' },
        { text: 'bo', ipa: 'boʊ', ex: 'boat' },
        { text: 'bu', ipa: 'bʌ', ex: 'but' },
      ],
      examples: ['bat', 'be', 'bit', 'boat'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /v/ - VET/VAV sound (ב OR ו vs English v)
  // ─────────────────────────────────────────────────────────────────────────────
  'v': {
    name: 'voiced labiodental fricative',
    
    he: {
      letters: ['ב', 'ו'],
      
      // ב (Vet without dagesh)
      vet: {
        base: 'ב',
        dagesh: false, // ב without dagesh = /v/
        syllables: [
          { text: 'בַ', nikud: 'ַ', name: 'בֵית רָפָה פַּתַח', ipa: 'va' },
          { text: 'בָ', nikud: 'ָ', name: 'בֵית רָפָה קָמָץ', ipa: 'vɑ' },
          { text: 'בֶ', nikud: 'ֶ', name: 'בֵית רָפָה סֶגוֹל', ipa: 'vɛ' },
          { text: 'בֵ', nikud: 'ֵ', name: 'בֵית רָפָה צֵירֵי', ipa: 've' },
          { text: 'בִ', nikud: 'ִ', name: 'בֵית רָפָה חִירִיק', ipa: 'vi' },
          { text: 'בֹ', nikud: 'ֹ', name: 'בֵית רָפָה חוֹלָם', ipa: 'vo' },
          { text: 'בֻ', nikud: 'ֻ', name: 'בֵית רָפָה קֻבּוּץ', ipa: 'vu' },
          { text: 'בְ', nikud: 'ְ', name: 'בֵית רָפָה שְׁוָא', ipa: 'və' },
        ],
        examples: ['טוֹב', 'אָב', 'עֶרֶב'],
      },
      
      // ו (Vav as consonant)
      vav: {
        base: 'ו',
        note: 'ו as consonant (not vowel)',
        syllables: [
          { text: 'וַ', nikud: 'ַ', name: 'וָו פַּתַח', ipa: 'va' },
          { text: 'וָ', nikud: 'ָ', name: 'וָו קָמָץ', ipa: 'vɑ' },
          { text: 'וֶ', nikud: 'ֶ', name: 'וָו סֶגוֹל', ipa: 'vɛ' },
          { text: 'וֵ', nikud: 'ֵ', name: 'וָו צֵירֵי', ipa: 've' },
          { text: 'וִ', nikud: 'ִ', name: 'וָו חִירִיק', ipa: 'vi' },
          { text: 'וְ', nikud: 'ְ', name: 'וָו שְׁוָא', ipa: 'və' },
        ],
        examples: ['וָו', 'וַדַּאי'],
      },
    },
    
    en: {
      spellings: ['v', 'f'],
      primary: 'v',
      syllables: [
        { text: 'va', ipa: 'væ', ex: 'van' },
        { text: 've', ipa: 'vi', ex: 'eve' },
        { text: 'vi', ipa: 'vɪ', ex: 'visit' },
        { text: 'vo', ipa: 'voʊ', ex: 'vote' },
        { text: 'vu', ipa: 'vʌ', ex: 'vulgar' },
      ],
      examples: ['van', 'very', 'of'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /t/ - TAV/TET sound (ת OR ט vs English t)
  // ─────────────────────────────────────────────────────────────────────────────
  't': {
    name: 'voiceless alveolar stop',
    
    he: {
      letters: ['ת', 'ט'],
      
      // ת (Tav)
      tav: {
        base: 'ת',
        syllables: [
          { text: 'תַ', nikud: 'ַ', name: 'תָו פַּתַח', ipa: 'ta' },
          { text: 'תָ', nikud: 'ָ', name: 'תָו קָמָץ', ipa: 'tɑ' },
          { text: 'תֶ', nikud: 'ֶ', name: 'תָו סֶגוֹל', ipa: 'tɛ' },
          { text: 'תֵ', nikud: 'ֵ', name: 'תָו צֵירֵי', ipa: 'te' },
          { text: 'תִ', nikud: 'ִ', name: 'תָו חִירִיק', ipa: 'ti' },
          { text: 'תֹ', nikud: 'ֹ', name: 'תָו חוֹלָם', ipa: 'to' },
          { text: 'תֻ', nikud: 'ֻ', name: 'תָו קֻבּוּץ', ipa: 'tu' },
          { text: 'תְ', nikud: 'ְ', name: 'תָו שְׁוָא', ipa: 'tə' },
        ],
        // Common endings with ת
        endings: [
          { text: 'תִּי', name: 'past 1s', ipa: 'ti' },
          { text: 'תָּ', name: 'past 2ms', ipa: 'ta' },
          { text: 'תְּ', name: 'past 2fs', ipa: 'tə' },
          { text: 'וֹת', name: 'plural f', ipa: 'ot' },
        ],
        examples: ['תָּם', 'תּוֹרָה', 'בַּת'],
      },
      
      // ט (Tet)
      tet: {
        base: 'ט',
        syllables: [
          { text: 'טַ', nikud: 'ַ', name: 'טֵית פַּתַח', ipa: 'ta' },
          { text: 'טָ', nikud: 'ָ', name: 'טֵית קָמָץ', ipa: 'tɑ' },
          { text: 'טֶ', nikud: 'ֶ', name: 'טֵית סֶגוֹל', ipa: 'tɛ' },
          { text: 'טֵ', nikud: 'ֵ', name: 'טֵית צֵירֵי', ipa: 'te' },
          { text: 'טִ', nikud: 'ִ', name: 'טֵית חִירִיק', ipa: 'ti' },
          { text: 'טֹ', nikud: 'ֹ', name: 'טֵית חוֹלָם', ipa: 'to' },
          { text: 'טֻ', nikud: 'ֻ', name: 'טֵית קֻבּוּץ', ipa: 'tu' },
          { text: 'טְ', nikud: 'ְ', name: 'טֵית שְׁוָא', ipa: 'tə' },
        ],
        examples: ['טוֹב', 'טַל', 'טָהוֹר'],
      },
    },
    
    en: {
      spellings: ['t', 'tt', 'ed', 'th'],
      primary: 't',
      syllables: [
        { text: 'ta', ipa: 'tæ', ex: 'tap' },
        { text: 'te', ipa: 'ti', ex: 'tea' },
        { text: 'ti', ipa: 'tɪ', ex: 'tip' },
        { text: 'to', ipa: 'toʊ', ex: 'toe' },
        { text: 'tu', ipa: 'tu', ex: 'tube' },
        { text: 'tion', ipa: 'ʃən', ex: 'nation', note: '/ʃ/ not /t/' },
      ],
      examples: ['top', 'time', 'water'],
    },
  },
  
  // ─────────────────────────────────────────────────────────────────────────────
  // /ts/ - TSADI sound (צ vs English ts)
  // ─────────────────────────────────────────────────────────────────────────────
  'ts': {
    name: 'voiceless alveolar affricate',
    
    he: {
      letters: ['צ'],
      
      tsadi: {
        base: 'צ',
        final: 'ץ',
        syllables: [
          { text: 'צַ', nikud: 'ַ', name: 'צָדִי פַּתַח', ipa: 'tsa' },
          { text: 'צָ', nikud: 'ָ', name: 'צָדִי קָמָץ', ipa: 'tsɑ' },
          { text: 'צֶ', nikud: 'ֶ', name: 'צָדִי סֶגוֹל', ipa: 'tsɛ' },
          { text: 'צֵ', nikud: 'ֵ', name: 'צָדִי צֵירֵי', ipa: 'tse' },
          { text: 'צִ', nikud: 'ִ', name: 'צָדִי חִירִיק', ipa: 'tsi' },
          { text: 'צֹ', nikud: 'ֹ', name: 'צָדִי חוֹלָם', ipa: 'tso' },
          { text: 'צֻ', nikud: 'ֻ', name: 'צָדִי קֻבּוּץ', ipa: 'tsu' },
          { text: 'צְ', nikud: 'ְ', name: 'צָדִי שְׁוָא', ipa: 'tsə' },
        ],
        examples: ['צַד', 'צִפּוֹר', 'עֵץ'],
      },
    },
    
    en: {
      spellings: ['ts', 'tz', 'zz'],
      primary: 'ts',
      syllables: [
        { text: 'ts', ipa: 'ts', ex: 'cats' },
        { text: 'tz', ipa: 'ts', ex: 'blitz' },
      ],
      examples: ['cats', 'pizza', 'tsunami'],
    },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// API: Get by IPA
// ═══════════════════════════════════════════════════════════════════════════════

function getByIPA(ipa) {
  return IPA_UNIKEYS[ipa] || null;
}

function getHeSyllables(ipa, letterKey) {
  const data = IPA_UNIKEYS[ipa];
  if (!data || !data.he) return [];
  
  // If specific letter requested
  if (letterKey && data.he[letterKey]) {
    return data.he[letterKey].syllables;
  }
  
  // Return all syllables from all Hebrew letters for this IPA
  const all = [];
  Object.values(data.he).forEach(letterData => {
    if (letterData.syllables) {
      all.push(...letterData.syllables);
    }
  });
  return all;
}

function getEnSyllables(ipa) {
  const data = IPA_UNIKEYS[ipa];
  return data?.en?.syllables || [];
}

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('IPA-CENTRIC UNIKEY - Sound is the Universal Key');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

Object.entries(IPA_UNIKEYS).forEach(([ipa, data]) => {
  const heLetters = data.he?.letters?.join(', ') || '-';
  const enSpellings = data.en?.spellings?.join(', ') || '-';
  
  console.log(`/${ipa}/ - ${data.name}`);
  console.log(`   Hebrew: ${heLetters}`);
  console.log(`   English: ${enSpellings}`);
  console.log('');
});

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('Example: /s/ has TWO Hebrew letters (same sound, different spelling!)');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const sData = IPA_UNIKEYS['s'];
console.log('ס (Samech) syllables:');
sData.he.samech.syllables.slice(0, 3).forEach(s => console.log(`   ${s.text} - ${s.name}`));
console.log('שׂ (Sin) syllables:');
sData.he.sin.syllables.slice(0, 3).forEach(s => console.log(`   ${s.text} - ${s.name}`));

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('Example: /ʃ/ maps to שׁ (shin) AND English sh');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const shData = IPA_UNIKEYS['ʃ'];
console.log('Hebrew שׁ:');
shData.he.syllables.slice(0, 3).forEach(s => console.log(`   ${s.text} - ${s.ipa}`));
console.log('English sh:');
shData.en.syllables.slice(0, 3).forEach(s => console.log(`   ${s.text} - ${s.ipa} - ${s.ex}`));
