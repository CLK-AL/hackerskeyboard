// ═══════════════════════════════════════════════════════════════════════════════
// KEYBOARD_MAP - Complete with EN and HE IPA + MG pairs in both languages
// ═══════════════════════════════════════════════════════════════════════════════

const KEYBOARD_MAP = {
  // ═══════════════════════════════════════════════════════════════════════════
  // NUMBER ROW - MG Keys (Hebrew AND English pairs)
  // ═══════════════════════════════════════════════════════════════════════════
  '1': { 
    en: '1', en_ipa: null, he: '1', he_ipa: null,
    mg_sem: 'poss-3s',
    mg_he: { m: 'ו', f: 'ה', mf: 'ו/ה', ipa_m: 'o', ipa_f: 'a' },
    mg_en: { m: 'his', f: 'her', mf: 'his/her', ipa_m: 'hɪz', ipa_f: 'hɜr' },
  },
  '2': { 
    en: '2', en_ipa: null, he: '2', he_ipa: null,
    mg_sem: 'poss-3s-ext',
    mg_he: { m: 'יו', f: 'יה', mf: 'יו/יה', ipa_m: 'av', ipa_f: 'eha' },
    mg_en: { m: 'his', f: 'hers', mf: 'his/hers', ipa_m: 'hɪz', ipa_f: 'hɜrz' },
  },
  '3': { 
    en: '3', en_ipa: null, he: '3', he_ipa: null,
    mg_sem: 'poss-3p',
    mg_he: { m: 'ם', f: 'ן', mf: 'ם/ן', ipa_m: 'am', ipa_f: 'an' },
    mg_en: { m: 'their', f: 'their', mf: 'their', ipa_m: 'ðɛr', ipa_f: 'ðɛr' },
  },
  '4': { 
    en: '4', en_ipa: null, he: '4', he_ipa: null,
    mg_sem: 'pronoun-3p',
    mg_he: { m: 'הם', f: 'הן', mf: 'הם/הן', ipa_m: 'hem', ipa_f: 'hen' },
    mg_en: { m: 'they', f: 'they', mf: 'they', ipa_m: 'ðeɪ', ipa_f: 'ðeɪ' },
  },
  '5': { 
    en: '5', en_ipa: null, he: '5', he_ipa: null,
    mg_sem: 'present',
    mg_he: { m: 'ד', f: 'ת', mf: 'ד/ת', ipa_m: 'ed', ipa_f: 'et' },
    mg_en: { m: '-s', f: '-s', mf: '-s', ipa_m: 'z', ipa_f: 'z' },
  },
  '6': { 
    en: '6', en_ipa: null, he: '6', he_ipa: null,
    mg_sem: 'plural',
    mg_he: { m: 'ים', f: 'ות', mf: 'ים/ות', ipa_m: 'im', ipa_f: 'ot' },
    mg_en: { m: '-s', f: '-s', mf: '-s', ipa_m: 'z', ipa_f: 'z' },
  },
  '7': { 
    en: '7', en_ipa: null, he: '7', he_ipa: null,
    mg_sem: 'gentilic',
    mg_he: { m: 'י', f: 'ית', mf: 'י/ית', ipa_m: 'i', ipa_f: 'it' },
    mg_en: { m: '-n', f: '-n', mf: '-n', ipa_m: 'n', ipa_f: 'n' },
  },
  '8': { 
    en: '8', en_ipa: null, he: '8', he_ipa: null,
    mg_sem: 'adj',
    mg_he: { m: 'ן', f: 'ת', mf: 'ן/ת', ipa_m: 'an', ipa_f: 'et' },
    mg_en: { m: '-er', f: '-ess', mf: '-er/-ess', ipa_m: 'ər', ipa_f: 'əs' },
  },
  '9': { 
    en: '9', en_ipa: null, he: '9', he_ipa: null,
    mg_sem: 'profession',
    mg_he: { m: 'ן', f: 'נית', mf: 'ן/נית', ipa_m: 'an', ipa_f: 'nit' },
    mg_en: { m: '-or', f: '-ress', mf: '-or/-ress', ipa_m: 'ər', ipa_f: 'rəs' },
  },
  '0': { 
    en: '0', en_ipa: null, he: '0', he_ipa: null,
    mg_sem: 'poss-2p',
    mg_he: { m: 'כם', f: 'כן', mf: 'כם/כן', ipa_m: 'xem', ipa_f: 'xen' },
    mg_en: { m: 'your', f: 'your', mf: 'your', ipa_m: 'jɔr', ipa_f: 'jɔr' },
  },
  '-': { 
    en: '-', en_ipa: null, he: '-', he_ipa: null,
    mg_sem: 'poss-3p-ext',
    mg_he: { m: 'יהם', f: 'יהן', mf: 'יהם/יהן', ipa_m: 'ehem', ipa_f: 'ehen' },
    mg_en: { m: 'theirs', f: 'theirs', mf: 'theirs', ipa_m: 'ðɛrz', ipa_f: 'ðɛrz' },
  },
  '=': { 
    en: '=', en_ipa: null, he: '=', he_ipa: null,
    mg_sem: 'pronoun-3s',
    mg_he: { m: 'הוא', f: 'היא', mf: 'הוא/היא', ipa_m: 'hu', ipa_f: 'hi' },
    mg_en: { m: 'he', f: 'she', mf: 'he/she', ipa_m: 'hi', ipa_f: 'ʃi' },
  },
  
  // ═══════════════════════════════════════════════════════════════════════════
  // LETTER ROWS - with EN and HE IPA
  // ═══════════════════════════════════════════════════════════════════════════
  
  // ROW 1: QWERTYUIOP
  'q': { en: 'q', en_ipa: 'kw', he: '/',  he_ipa: null,  opts: {} },
  'w': { en: 'w', en_ipa: 'w',  he: "'",  he_ipa: null,  opts: {} },
  'e': { en: 'e', en_ipa: 'ɛ',  he: 'ק',  he_ipa: 'k',   opts: {} },
  'r': { en: 'r', en_ipa: 'ɹ',  he: 'ר',  he_ipa: 'ʁ',   opts: {} },
  't': { en: 't', en_ipa: 't',  he: 'א',  he_ipa: 'ʔ',   opts: { guttural: true } },
  'y': { en: 'y', en_ipa: 'j',  he: 'ט',  he_ipa: 't',   opts: {} },
  'u': { en: 'u', en_ipa: 'ʌ',  he: 'ו',  he_ipa: 'v',   opts: {} },
  'i': { en: 'i', en_ipa: 'ɪ',  he: 'ן',  he_ipa: 'n',   opts: { final: true } },
  'o': { en: 'o', en_ipa: 'oʊ', he: 'ם',  he_ipa: 'm',   opts: { final: true } },
  'p': { en: 'p', en_ipa: 'p',  he: 'פ',  he_ipa: 'f',   opts: { dagesh: 'p' } },
  
  // ROW 2: ASDFGHJKL
  'a': { en: 'a', en_ipa: 'æ',  he: 'ש',  he_ipa: 'ʃ',   opts: { shin: true, sin: 's' } },
  's': { en: 's', en_ipa: 's',  he: 'ד',  he_ipa: 'd',   opts: {} },
  'd': { en: 'd', en_ipa: 'd',  he: 'ג',  he_ipa: 'g',   opts: {} },
  'f': { en: 'f', en_ipa: 'f',  he: 'כ',  he_ipa: 'x',   opts: { dagesh: 'k' } },
  'g': { en: 'g', en_ipa: 'g',  he: 'ע',  he_ipa: 'ʕ',   opts: { guttural: true } },
  'h': { en: 'h', en_ipa: 'h',  he: 'י',  he_ipa: 'j',   opts: {} },
  'j': { en: 'j', en_ipa: 'dʒ', he: 'ח',  he_ipa: 'ħ',   opts: { guttural: true } },
  'k': { en: 'k', en_ipa: 'k',  he: 'ל',  he_ipa: 'l',   opts: {} },
  'l': { en: 'l', en_ipa: 'l',  he: 'ך',  he_ipa: 'x',   opts: { final: true } },
  
  // ROW 3: ZXCVBNM
  'z': { en: 'z', en_ipa: 'z',  he: 'ז',  he_ipa: 'z',   opts: {} },
  'x': { en: 'x', en_ipa: 'ks', he: 'ס',  he_ipa: 's',   opts: {} },
  'c': { en: 'c', en_ipa: 'k',  he: 'ב',  he_ipa: 'v',   opts: { dagesh: 'b' } },
  'v': { en: 'v', en_ipa: 'v',  he: 'ה',  he_ipa: 'h',   opts: { guttural: true } },
  'b': { en: 'b', en_ipa: 'b',  he: 'נ',  he_ipa: 'n',   opts: {} },
  'n': { en: 'n', en_ipa: 'n',  he: 'מ',  he_ipa: 'm',   opts: {} },
  'm': { en: 'm', en_ipa: 'm',  he: 'צ',  he_ipa: 'ts',  opts: {} },
  
  // PUNCTUATION
  ';': { en: ';', en_ipa: null, he: 'ף',  he_ipa: 'f',   opts: { final: true } },
  ',': { en: ',', en_ipa: null, he: 'ת',  he_ipa: 't',   opts: {} },
  '.': { en: '.', en_ipa: null, he: 'ץ',  he_ipa: 'ts',  opts: { final: true } },
  '/': { en: '/', en_ipa: null, he: '.',  he_ipa: null,  opts: {} },
  "'": { en: "'", en_ipa: null, he: ',',  he_ipa: null,  opts: {} },
};

// ═══════════════════════════════════════════════════════════════════════════════
// ADDITIONAL MG PAIRS (Extended set)
// ═══════════════════════════════════════════════════════════════════════════════

const MG_EXTENDED = {
  // Family terms
  'parent':   { he: { m: 'אב', f: 'אם', mf: 'אב/אם' },       en: { m: 'father', f: 'mother', mf: 'father/mother' } },
  'child':    { he: { m: 'בן', f: 'בת', mf: 'בן/בת' },       en: { m: 'son', f: 'daughter', mf: 'son/daughter' } },
  'sibling':  { he: { m: 'אח', f: 'אחות', mf: 'אח/אחות' },   en: { m: 'brother', f: 'sister', mf: 'brother/sister' } },
  'spouse':   { he: { m: 'בעל', f: 'אישה', mf: 'בעל/אישה' }, en: { m: 'husband', f: 'wife', mf: 'husband/wife' } },
  'person':   { he: { m: 'איש', f: 'אישה', mf: 'איש/אישה' }, en: { m: 'man', f: 'woman', mf: 'man/woman' } },
  'youth':    { he: { m: 'ילד', f: 'ילדה', mf: 'ילד/ילדה' }, en: { m: 'boy', f: 'girl', mf: 'boy/girl' } },
  
  // Pronouns
  'pron-1s':  { he: { m: 'אני', f: 'אני', mf: 'אני' },       en: { m: 'I', f: 'I', mf: 'I' } },
  'pron-2s':  { he: { m: 'אתה', f: 'את', mf: 'אתה/את' },     en: { m: 'you', f: 'you', mf: 'you' } },
  'pron-3s':  { he: { m: 'הוא', f: 'היא', mf: 'הוא/היא' },   en: { m: 'he', f: 'she', mf: 'he/she' } },
  'pron-1p':  { he: { m: 'אנחנו', f: 'אנחנו', mf: 'אנחנו' }, en: { m: 'we', f: 'we', mf: 'we' } },
  'pron-2p':  { he: { m: 'אתם', f: 'אתן', mf: 'אתם/אתן' },   en: { m: 'you', f: 'you', mf: 'you' } },
  'pron-3p':  { he: { m: 'הם', f: 'הן', mf: 'הם/הן' },       en: { m: 'they', f: 'they', mf: 'they' } },
  
  // Object pronouns
  'obj-3s':   { he: { m: 'אותו', f: 'אותה', mf: 'אותו/ה' },  en: { m: 'him', f: 'her', mf: 'him/her' } },
  'obj-3p':   { he: { m: 'אותם', f: 'אותן', mf: 'אותם/ן' },  en: { m: 'them', f: 'them', mf: 'them' } },
  
  // Titles
  'title':    { he: { m: 'מר', f: 'גברת', mf: 'מר/גברת' },   en: { m: 'Mr.', f: 'Ms.', mf: 'Mr./Ms.' } },
  'royal':    { he: { m: 'מלך', f: 'מלכה', mf: 'מלך/מלכה' }, en: { m: 'king', f: 'queen', mf: 'king/queen' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// OUTPUT
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('MG KEYS - Number Row (Hebrew AND English)');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('Key  Semantic       Hebrew (M/F)    IPA        English (M/F)   IPA');
console.log('─────────────────────────────────────────────────────────────────────────');

'1234567890-='.split('').forEach(k => {
  const m = KEYBOARD_MAP[k];
  if (m && m.mg_he) {
    const he_mf = m.mg_he.mf.padEnd(12);
    const he_ipa = `${m.mg_he.ipa_m}/${m.mg_he.ipa_f}`.padEnd(10);
    const en_mf = m.mg_en.mf.padEnd(14);
    const en_ipa = `${m.mg_en.ipa_m}/${m.mg_en.ipa_f}`;
    console.log(`[${k}]  ${m.mg_sem.padEnd(13)} ${he_mf} ${he_ipa} ${en_mf} ${en_ipa}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('LETTER KEYS');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('Key  EN   EN_IPA   HE   HE_IPA   Opts');
console.log('─────────────────────────────────────────────────────────────────');

const letterKeys = 'qwertyuiopasdfghjklzxcvbnm'.split('');
letterKeys.forEach(k => {
  const m = KEYBOARD_MAP[k];
  if (m && m.opts !== undefined) {
    const opts = Object.keys(m.opts).filter(o => m.opts[o]).join(',') || '-';
    console.log(`[${k}]  ${m.en.padEnd(2)}   ${(m.en_ipa||'-').padEnd(4)}     ${m.he}    ${(m.he_ipa||'-').padEnd(4)}     ${opts}`);
  }
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('EXTENDED MG PAIRS');
console.log('═══════════════════════════════════════════════════════════════\n');

Object.entries(MG_EXTENDED).forEach(([sem, data]) => {
  console.log(`${sem.padEnd(10)} HE: ${data.he.mf.padEnd(12)} EN: ${data.en.mf}`);
});
