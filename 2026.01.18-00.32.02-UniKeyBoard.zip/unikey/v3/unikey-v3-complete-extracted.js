// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V3 - COMPLETE DATA EXTRACTED FROM unikeyboard.html
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// 1. UK_HE_VOWELS (8) - Hebrew nikud vowels
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_VOWELS = [
  { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  { n: 'ָ', name: 'קָמָץ', ipa: 'ɑ' },
  { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  { n: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// 2. UK_HE_HATAF (3) - Hataf vowels for gutturals
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_HATAF = [
  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// 3. UK_HE_MALE (4) - Full vowels (with yod/vav)
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_MALE = [
  { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  { n: 'ֵי', name: 'צֵירֵי מָלֵא', ipa: 'ej' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// 4. IPA_VOWELS (17) - Universal vowel inventory
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_VOWELS = {
  // Front vowels
  'i': { name: 'close front', he: 'חִירִיק', en: 'ee/ea', ex: { he: 'מִי', en: 'see' } },
  'ɪ': { name: 'near-close front', he: 'חִירִיק קצר', en: 'i', ex: { he: 'אִם', en: 'sit' } },
  'e': { name: 'close-mid front', he: 'צֵירֵי', en: 'ay/ei', ex: { he: 'בֵּית', en: 'say' } },
  'ɛ': { name: 'open-mid front', he: 'סֶגוֹל', en: 'e', ex: { he: 'אֶת', en: 'bed' } },
  'æ': { name: 'near-open front', he: '—', en: 'a', ex: { he: '—', en: 'cat' } },
  // Central vowels
  'ə': { name: 'schwa', he: 'שְׁוָא נָע', en: 'a/u', ex: { he: 'בְּ', en: 'about' } },
  'ɐ': { name: 'near-open central', he: 'פַּתַח', en: 'u', ex: { he: 'אַ', en: 'cup' } },
  // Back vowels  
  'u': { name: 'close back', he: 'שׁוּרוּק/קוּבּוּץ', en: 'oo/u', ex: { he: 'הוּא', en: 'moon' } },
  'ʊ': { name: 'near-close back', he: 'קוּבּוּץ קצר', en: 'oo', ex: { he: 'קֻם', en: 'book' } },
  'o': { name: 'close-mid back', he: 'חוֹלָם', en: 'o/oa', ex: { he: 'לֹא', en: 'go' } },
  'ɔ': { name: 'open-mid back', he: 'קָמָץ קָטָן', en: 'aw/au', ex: { he: 'כָּל', en: 'law' } },
  'ɑ': { name: 'open back', he: 'קָמָץ/פַּתַח', en: 'a/ar', ex: { he: 'אָב', en: 'father' } },
  // Diphthongs
  'aɪ': { name: 'diphthong', he: 'פַּתַח+יוֹד', en: 'i/igh/y', ex: { he: 'אַיִן', en: 'my' } },
  'aʊ': { name: 'diphthong', he: 'פַּתַח+וָו', en: 'ou/ow', ex: { he: 'אָו', en: 'now' } },
  'ɔɪ': { name: 'diphthong', he: 'חוֹלָם+יוֹד', en: 'oi/oy', ex: { he: 'גּוֹי', en: 'boy' } },
  'eɪ': { name: 'diphthong', he: 'צֵירֵי+יוֹד', en: 'ay/ai/ei', ex: { he: 'יֵשׁ', en: 'day' } },
  'oʊ': { name: 'diphthong', he: 'חוֹלָם+וָו', en: 'o/ow/oa', ex: { he: 'אוֹ', en: 'go' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// 5. IPA_CONSONANTS (26) - Universal consonant inventory
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_CONSONANTS = {
  // Stops
  'p': { name: 'voiceless bilabial', he: 'פּ', en: 'p', ex: { he: 'פֹּה', en: 'pen' } },
  'b': { name: 'voiced bilabial', he: 'בּ', en: 'b', ex: { he: 'בַּיִת', en: 'bat' } },
  't': { name: 'voiceless alveolar', he: 'ת/ט', en: 't', ex: { he: 'תַּם', en: 'top' } },
  'd': { name: 'voiced alveolar', he: 'ד', en: 'd', ex: { he: 'דָּג', en: 'dog' } },
  'k': { name: 'voiceless velar', he: 'כּ/ק', en: 'k/c', ex: { he: 'כֹּל', en: 'cat' } },
  'g': { name: 'voiced velar', he: 'ג', en: 'g', ex: { he: 'גַּם', en: 'go' } },
  'ʔ': { name: 'glottal stop', he: 'א/ע', en: '—', ex: { he: 'אָב', en: 'uh-oh' } },
  // Fricatives
  'f': { name: 'voiceless labiodental', he: 'פ', en: 'f/ph', ex: { he: 'סוֹף', en: 'fan' } },
  'v': { name: 'voiced labiodental', he: 'ב/ו', en: 'v', ex: { he: 'טוֹב', en: 'van' } },
  'θ': { name: 'voiceless dental', he: '—', en: 'th', ex: { he: '—', en: 'thin' } },
  'ð': { name: 'voiced dental', he: '—', en: 'th', ex: { he: '—', en: 'the' } },
  's': { name: 'voiceless alveolar', he: 'ס/שׂ', en: 's/c', ex: { he: 'סוּס', en: 'sun' } },
  'z': { name: 'voiced alveolar', he: 'ז', en: 'z/s', ex: { he: 'זֶה', en: 'zoo' } },
  'ʃ': { name: 'voiceless postalveolar', he: 'שׁ', en: 'sh', ex: { he: 'שָׁם', en: 'she' } },
  'ʒ': { name: 'voiced postalveolar', he: 'ז׳', en: 'si/su', ex: { he: 'ז׳וּק', en: 'vision' } },
  'x': { name: 'voiceless velar', he: 'כ/ח', en: '—', ex: { he: 'לֶךְ', en: 'loch' } },
  'ħ': { name: 'voiceless pharyngeal', he: 'ח', en: '—', ex: { he: 'חַם', en: '—' } },
  'ʕ': { name: 'voiced pharyngeal', he: 'ע', en: '—', ex: { he: 'עַם', en: '—' } },
  'h': { name: 'voiceless glottal', he: 'ה', en: 'h', ex: { he: 'הוּא', en: 'hat' } },
  // Affricates
  'ts': { name: 'voiceless alveolar', he: 'צ', en: 'ts', ex: { he: 'צַד', en: 'cats' } },
  'tʃ': { name: 'voiceless postalveolar', he: 'צ׳', en: 'ch', ex: { he: 'צ׳יפּ', en: 'chat' } },
  'dʒ': { name: 'voiced postalveolar', he: 'ג׳', en: 'j/g', ex: { he: 'ג׳ינס', en: 'jam' } },
  // Nasals
  'm': { name: 'bilabial nasal', he: 'מ', en: 'm', ex: { he: 'מָה', en: 'man' } },
  'n': { name: 'alveolar nasal', he: 'נ', en: 'n', ex: { he: 'נָא', en: 'no' } },
  'ŋ': { name: 'velar nasal', he: '—', en: 'ng', ex: { he: '—', en: 'sing' } },
  // Approximants
  'l': { name: 'alveolar lateral', he: 'ל', en: 'l', ex: { he: 'לֹא', en: 'let' } },
  'r': { name: 'alveolar/uvular', he: 'ר', en: 'r', ex: { he: 'רַב', en: 'red' } },
  'j': { name: 'palatal approximant', he: 'י', en: 'y', ex: { he: 'יָד', en: 'yes' } },
  'w': { name: 'labial-velar', he: 'ו', en: 'w', ex: { he: 'וָו', en: 'we' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// 6. UK_EN_CONNECTORS - English function words with IPA
// ═══════════════════════════════════════════════════════════════════════════════

const UK_EN_CONNECTORS = {
  conj: [
    { word:'and',ipa:'ænd' },{ word:'or',ipa:'ɔːr' },{ word:'but',ipa:'bʌt' },{ word:'so',ipa:'soʊ' },
    { word:'if',ipa:'ɪf' },{ word:'as',ipa:'æz' },{ word:'for',ipa:'fɔːr' },{ word:'nor',ipa:'nɔːr' },
    { word:'yet',ipa:'jet' },{ word:'than',ipa:'ðæn' },
  ],
  prep: [
    { word:'in',ipa:'ɪn' },{ word:'on',ipa:'ɒn' },{ word:'at',ipa:'æt' },{ word:'to',ipa:'tuː' },
    { word:'of',ipa:'ɒv' },{ word:'by',ipa:'baɪ' },{ word:'up',ipa:'ʌp' },{ word:'off',ipa:'ɒf' },
    { word:'out',ipa:'aʊt' },{ word:'with',ipa:'wɪð' },{ word:'from',ipa:'frɒm' },
  ],
  det: [
    { word:'the',ipa:'ðə' },{ word:'a',ipa:'ə' },{ word:'an',ipa:'æn' },
    { word:'this',ipa:'ðɪs' },{ word:'that',ipa:'ðæt' },{ word:'some',ipa:'sʌm' },
    { word:'all',ipa:'ɔːl' },{ word:'no',ipa:'noʊ' },{ word:'each',ipa:'iːtʃ' },
  ],
  pron: [
    { word:'I',ipa:'aɪ' },{ word:'you',ipa:'juː' },{ word:'he',ipa:'hiː' },{ word:'she',ipa:'ʃiː' },
    { word:'it',ipa:'ɪt' },{ word:'we',ipa:'wiː' },{ word:'they',ipa:'ðeɪ' },
    { word:'me',ipa:'miː' },{ word:'him',ipa:'hɪm' },{ word:'her',ipa:'hɜːr' },{ word:'us',ipa:'ʌs' },{ word:'them',ipa:'ðɛm' },
    { word:'my',ipa:'maɪ' },{ word:'your',ipa:'jɔːr' },{ word:'his',ipa:'hɪz' },{ word:'its',ipa:'ɪts' },{ word:'our',ipa:'aʊr' },{ word:'their',ipa:'ðɛr' },
  ],
  verb: [
    { word:'is',ipa:'ɪz' },{ word:'am',ipa:'æm' },{ word:'are',ipa:'ɑːr' },{ word:'was',ipa:'wɒz' },{ word:'were',ipa:'wɜːr' },
    { word:'be',ipa:'biː' },{ word:'been',ipa:'biːn' },{ word:'have',ipa:'hæv' },{ word:'has',ipa:'hæz' },{ word:'had',ipa:'hæd' },
    { word:'do',ipa:'duː' },{ word:'does',ipa:'dʌz' },{ word:'did',ipa:'dɪd' },
    { word:'can',ipa:'kæn' },{ word:'will',ipa:'wɪl' },{ word:'may',ipa:'meɪ' },{ word:'must',ipa:'mʌst' },{ word:'shall',ipa:'ʃæl' },
    { word:'would',ipa:'wʊd' },{ word:'could',ipa:'kʊd' },{ word:'should',ipa:'ʃʊd' },{ word:'might',ipa:'maɪt' },
  ],
  quest: [
    { word:'who',ipa:'huː' },{ word:'what',ipa:'wɒt' },{ word:'when',ipa:'wɛn' },{ word:'where',ipa:'wɛr' },
    { word:'why',ipa:'waɪ' },{ word:'how',ipa:'haʊ' },{ word:'which',ipa:'wɪtʃ' },
  ],
  adv: [
    { word:'not',ipa:'nɒt' },{ word:'just',ipa:'dʒʌst' },{ word:'now',ipa:'naʊ' },{ word:'then',ipa:'ðɛn' },
    { word:'here',ipa:'hɪr' },{ word:'there',ipa:'ðɛr' },{ word:'very',ipa:'vɛri' },{ word:'too',ipa:'tuː' },
    { word:'more',ipa:'mɔːr' },{ word:'most',ipa:'moʊst' },{ word:'well',ipa:'wɛl' },{ word:'still',ipa:'stɪl' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// 7. UK_HE_CONNECTORS - Hebrew function words with IPA
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_CONNECTORS = {
  prefix: [
    { word:'וְ',name:'ו החיבור',ex:'and',ipa:'ve' },
    { word:'בְּ',name:'ב היחס',ex:'in/at',ipa:'be' },
    { word:'לְ',name:'ל היחס',ex:'to/for',ipa:'le' },
    { word:'מִ',name:'מ היחס',ex:'from',ipa:'mi' },
    { word:'כְּ',name:'כ הדימוי',ex:'like/as',ipa:'ke' },
    { word:'הַ',name:'ה הידיעה',ex:'the',ipa:'ha' },
    { word:'שֶׁ',name:'ש הזיקה',ex:'that/which',ipa:'ʃe' },
  ],
  prep: [
    { word:'אֶל',name:'אל',ex:'to/toward',ipa:'ʔel' },
    { word:'עַל',name:'על',ex:'on/about',ipa:'ʔal' },
    { word:'עִם',name:'עם',ex:'with',ipa:'ʔim' },
    { word:'אֶת',name:'את',ex:'(object marker)',ipa:'ʔet' },
    { word:'בֵּין',name:'בין',ex:'between',ipa:'ben' },
    { word:'תַּחַת',name:'תחת',ex:'under',ipa:'taħat' },
    { word:'עַד',name:'עד',ex:'until',ipa:'ʔad' },
    { word:'מִן',name:'מן',ex:'from',ipa:'min' },
  ],
  conj: [
    { word:'כִּי',name:'כי',ex:'because/that',ipa:'ki' },
    { word:'אִם',name:'אם',ex:'if',ipa:'ʔim' },
    { word:'אוֹ',name:'או',ex:'or',ipa:'ʔo' },
    { word:'גַּם',name:'גם',ex:'also',ipa:'gam' },
    { word:'רַק',name:'רק',ex:'only',ipa:'rak' },
    { word:'אַךְ',name:'אך',ex:'but/however',ipa:'ʔax' },
    { word:'אוּלָם',name:'אולם',ex:'however',ipa:'ʔulam' },
    { word:'לָכֵן',name:'לכן',ex:'therefore',ipa:'laxen' },
    { word:'אֲבָל',name:'אבל',ex:'but',ipa:'ʔaval' },
  ],
  pron: [
    { word:'אֲנִי',name:'אני',ex:'I',ipa:'ʔani' },
    { word:'אַתָּה',name:'אתה',ex:'you (m)',ipa:'ʔata' },
    { word:'אַתְּ',name:'את',ex:'you (f)',ipa:'ʔat' },
    { word:'הוּא',name:'הוא',ex:'he',ipa:'hu' },
    { word:'הִיא',name:'היא',ex:'she',ipa:'hi' },
    { word:'אֲנַחְנוּ',name:'אנחנו',ex:'we',ipa:'ʔanaħnu' },
    { word:'אַתֶּם',name:'אתם',ex:'you (m.pl)',ipa:'ʔatem' },
    { word:'אַתֶּן',name:'אתן',ex:'you (f.pl)',ipa:'ʔaten' },
    { word:'הֵם',name:'הם',ex:'they (m)',ipa:'hem' },
    { word:'הֵן',name:'הן',ex:'they (f)',ipa:'hen' },
    { word:'זֶה',name:'זה',ex:'this (m)',ipa:'ze' },
    { word:'זֹאת',name:'זאת',ex:'this (f)',ipa:'zot' },
    { word:'מִי',name:'מי',ex:'who',ipa:'mi' },
    { word:'מָה',name:'מה',ex:'what',ipa:'ma' },
  ],
  quest: [
    { word:'מִי',name:'מי',ex:'who',ipa:'mi' },
    { word:'מָה',name:'מה',ex:'what',ipa:'ma' },
    { word:'אֵיפֹה',name:'איפה',ex:'where',ipa:'ʔefo' },
    { word:'מָתַי',name:'מתי',ex:'when',ipa:'mataj' },
    { word:'לָמָּה',name:'למה',ex:'why',ipa:'lama' },
    { word:'אֵיךְ',name:'איך',ex:'how',ipa:'ʔex' },
    { word:'כַּמָּה',name:'כמה',ex:'how many',ipa:'kama' },
    { word:'אֵיזֶה',name:'איזה',ex:'which',ipa:'ʔeze' },
  ],
  adv: [
    { word:'לֹא',name:'לא',ex:'no/not',ipa:'lo' },
    { word:'כֵּן',name:'כן',ex:'yes',ipa:'ken' },
    { word:'עַכְשָׁיו',name:'עכשיו',ex:'now',ipa:'ʔaxʃav' },
    { word:'פֹּה',name:'פה',ex:'here',ipa:'po' },
    { word:'שָׁם',name:'שם',ex:'there',ipa:'ʃam' },
    { word:'מְאֹד',name:'מאוד',ex:'very',ipa:'meʔod' },
    { word:'עוֹד',name:'עוד',ex:'more/still',ipa:'ʔod' },
    { word:'כְּבָר',name:'כבר',ex:'already',ipa:'kvar' },
    { word:'תָּמִיד',name:'תמיד',ex:'always',ipa:'tamid' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// 8. MG_SYL_DATA - Complete MG suffix pairs
// ═══════════════════════════════════════════════════════════════════════════════

const MG_SYL_DATA = {
  // ו/ה - 3rd person singular
  'ו': {
    plain: [
      { m: 'ו', f: 'ה', mf: 'ו/ה', ipa: 'o/a' },
      { m: 'יו', f: 'יה', mf: 'יו/יה', ipa: 'av/a' },
    ],
    nikud: [
      { m: 'וֹ', f: 'הּ', mf: 'וֹ/הּ', ipa: 'o/a' },
      { m: 'ָיו', f: 'ֶיהָ', mf: 'ָיו/ֶיהָ', ipa: 'av/eha' },
    ],
  },
  'ה': 'ו', // alias
  
  // ם/ן - 3rd person plural
  'ם': {
    plain: [
      { m: 'ם', f: 'ן', mf: 'ם/ן', ipa: 'm/n' },
      { m: 'הם', f: 'הן', mf: 'הם/הן', ipa: 'hem/hen' },
      { m: 'יהם', f: 'יהן', mf: 'יהם/יהן', ipa: 'ehem/ehen' },
    ],
    nikud: [
      { m: 'ָם', f: 'ָן', mf: 'ָם/ָן', ipa: 'am/an' },
      { m: 'הֶם', f: 'הֶן', mf: 'הֶם/הֶן', ipa: 'hem/hen' },
      { m: 'ֵיהֶם', f: 'ֵיהֶן', mf: 'ֵיהֶם/ֵיהֶן', ipa: 'ehem/ehen' },
    ],
  },
  'ן': 'ם', // alias
  
  // ך - 2nd person singular
  'ך': {
    plain: [
      { m: 'ך', f: 'ך', mf: 'ךָ/ךְ', ipa: 'xa/ex' },
      { m: 'יך', f: 'יך', mf: 'יךָ/יךְ', ipa: 'exa/aix' },
      { m: 'כם', f: 'כן', mf: 'כם/כן', ipa: 'xem/xen' },
    ],
    nikud: [
      { m: 'ְךָ', f: 'ֵךְ', mf: 'ְךָ/ֵךְ', ipa: 'xa/ex' },
      { m: 'ֶיךָ', f: 'ַיִךְ', mf: 'ֶיךָ/ַיִךְ', ipa: 'exa/aix' },
      { m: 'כֶם', f: 'כֶן', mf: 'כֶם/כֶן', ipa: 'xem/xen' },
    ],
  },
  'כ': 'ך', // alias
  
  // ד/ת - present tense (בינוני)
  'ד': {
    plain: [{ m: 'ד', f: 'ת', mf: 'ד/ת', ipa: 'd/t' }],
    nikud: [{ m: 'ֵד', f: 'ֶת', mf: 'ֵד/ֶת', ipa: 'ed/et' }],
  },
  'ת': 'ד', // alias
  
  // ס - present (רואֶה/רואָה)
  'ס': {
    plain: [{ m: 'ה', f: 'ה', mf: 'ה/ה', ipa: 'e/a' }],
    nikud: [{ m: 'ֶה', f: 'ָה', mf: 'ֶה/ָה', ipa: 'e/a' }],
  },
  
  // ר/ג - plural ים/ות
  'ר': {
    plain: [
      { m: 'ים', f: 'ות', mf: 'ים/ות', ipa: 'im/ot' },
      { m: 'ין', f: 'ות', mf: 'ין/ות', ipa: 'in/ot' },
    ],
    nikud: [
      { m: 'ִים', f: 'וֹת', mf: 'ִים/וֹת', ipa: 'im/ot' },
      { m: 'ִין', f: 'וֹת', mf: 'ִין/וֹת', ipa: 'in/ot' },
    ],
  },
  'ג': 'ר', // alias
  
  // י - gentilic י/ית
  'י': {
    plain: [
      { m: 'י', f: 'ית', mf: 'י/ית', ipa: 'i/it' },
      { m: 'אי', f: 'ית', mf: 'אי/ית', ipa: 'ai/it' },
    ],
    nikud: [
      { m: 'ִי', f: 'ִית', mf: 'ִי/ִית', ipa: 'i/it' },
      { m: 'אִי', f: 'ִית', mf: 'אִי/ִית', ipa: 'ai/it' },
    ],
  },
  
  // נ - adjective ן/ת
  'נ': {
    plain: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ן', f: 'נה', mf: 'ן/נה', ipa: 'n/na' },
    ],
    nikud: [
      { m: 'ָן', f: 'ֶת', mf: 'ָן/ֶת', ipa: 'an/et' },
      { m: 'ן', f: 'נָה', mf: 'ן/נָה', ipa: 'n/na' },
    ],
  },
  
  // ב/ל - בן/בת, ילד/ילדה
  'ב': {
    plain: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ד', f: 'דה', mf: 'ד/דה', ipa: 'd/da' },
    ],
    nikud: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ד', f: 'דָה', mf: 'ד/דָה', ipa: 'd/da' },
    ],
  },
  'ל': 'ב', // alias
  
  // א - איש/אישה
  'א': {
    plain: [{ m: 'יש', f: 'ישה', mf: 'יש/ישה', ipa: 'ish/isha' }],
    nikud: [{ m: 'יש', f: 'ישָׁה', mf: 'יש/ישָׁה', ipa: 'ish/isha' }],
  },
  
  // === ENGLISH MG PAIRS ===
  't': {
    plain: [{ m: 'ey', f: 'em', mf: 'ey/em', ipa: 'eɪ/əm' }],
    nikud: [{ m: 'ey', f: 'em', mf: 'ey/em', ipa: 'eɪ/əm' }],
  },
  'h': {
    plain: [
      { m: 'e', f: 'she', mf: 'e/she', ipa: 'i/ʃi' },
      { m: 'is', f: 'er', mf: 'is/er', ipa: 'ɪz/ɜr' },
      { m: 'im', f: 'er', mf: 'im/er', ipa: 'ɪm/ɜr' },
    ],
    nikud: [
      { m: 'e', f: 'she', mf: 'e/she', ipa: 'i/ʃi' },
      { m: 'is', f: 'er', mf: 'is/er', ipa: 'ɪz/ɜr' },
      { m: 'im', f: 'er', mf: 'im/er', ipa: 'ɪm/ɜr' },
    ],
  },
  's': {
    plain: [{ m: 'imself', f: 'erself', mf: 'imself/erself', ipa: 'self' }],
    nikud: [{ m: 'imself', f: 'erself', mf: 'imself/erself', ipa: 'self' }],
  },
  'w': {
    plain: [
      { m: 'an', f: 'oman', mf: 'an/oman', ipa: 'æn/ʊmən' },
      { m: 'en', f: 'omen', mf: 'en/omen', ipa: 'ɛn/ɪmən' },
    ],
    nikud: [
      { m: 'an', f: 'oman', mf: 'an/oman', ipa: 'æn/ʊmən' },
      { m: 'en', f: 'omen', mf: 'en/omen', ipa: 'ɛn/ɪmən' },
    ],
  },
  'c': {
    plain: [
      { m: 'on', f: 'aughter', mf: 'on/aughter', ipa: 'ʌn/ɔtər' },
      { m: 'oy', f: 'irl', mf: 'oy/irl', ipa: 'ɔɪ/ɜrl' },
    ],
    nikud: [
      { m: 'on', f: 'aughter', mf: 'on/aughter', ipa: 'ʌn/ɔtər' },
      { m: 'oy', f: 'irl', mf: 'oy/irl', ipa: 'ɔɪ/ɜrl' },
    ],
  },
  'p': {
    plain: [
      { m: 'rother', f: 'ister', mf: 'rother/ister', ipa: 'rʌðər/ɪstər' },
      { m: 'ather', f: 'other', mf: 'ather/other', ipa: 'æðər/ʌðər' },
    ],
    nikud: [
      { m: 'rother', f: 'ister', mf: 'rother/ister', ipa: 'rʌðər/ɪstər' },
      { m: 'ather', f: 'other', mf: 'ather/other', ipa: 'æðər/ʌðər' },
    ],
  },
  'k': {
    plain: [
      { m: 'ing', f: 'ueen', mf: 'ing/ueen', ipa: 'ɪŋ/in' },
      { m: 'r.', f: 's.', mf: 'r./s.', ipa: 'r/s' },
    ],
    nikud: [
      { m: 'ing', f: 'ueen', mf: 'ing/ueen', ipa: 'ɪŋ/in' },
      { m: 'r.', f: 's.', mf: 'r./s.', ipa: 'r/s' },
    ],
  },
  
  // Aliases
  'ש': 'ו', 'ע': 'ו', 'מ': 'ם', 'ז': 'ב', 'ט': 'ד',
  'ף': 'ו', 'ץ': 'ר', 'ק': 'ר', 'פ': 'ו', 'ח': 'ב', 'צ': 'ר',
};

// ═══════════════════════════════════════════════════════════════════════════════
// 9. UNIKEYS - Main keyboard mapping (Israeli layout)
// ═══════════════════════════════════════════════════════════════════════════════

// Key mappings: QWERTY key → { en, EN, he, ipa, ... }
const KEYBOARD_MAP = {
  // Letters row 1
  't': { en:'t', EN:'T', he:'א', ipa:'ʔ', guttural:true },
  'c': { en:'c', EN:'C', he:'ב', ipa:'v', dagesh:'b' },
  'd': { en:'d', EN:'D', he:'ג', ipa:'g' },
  's': { en:'s', EN:'S', he:'ד', ipa:'d' },
  'v': { en:'v', EN:'V', he:'ה', ipa:'h', guttural:true },
  'u': { en:'u', EN:'U', he:'ו', ipa:'v' },
  'z': { en:'z', EN:'Z', he:'ז', ipa:'z' },
  'j': { en:'j', EN:'J', he:'ח', ipa:'ħ', guttural:true },
  'y': { en:'y', EN:'Y', he:'ט', ipa:'t' },
  'h': { en:'h', EN:'H', he:'י', ipa:'j' },
  'f': { en:'f', EN:'F', he:'כ', ipa:'x', dagesh:'k' },
  'l': { en:'l', EN:'L', he:'ך', ipa:'x', final:true },
  'k': { en:'k', EN:'K', he:'ל', ipa:'l' },
  'n': { en:'n', EN:'N', he:'מ', ipa:'m' },
  'o': { en:'o', EN:'O', he:'ם', ipa:'m', final:true },
  'b': { en:'b', EN:'B', he:'נ', ipa:'n' },
  'i': { en:'i', EN:'I', he:'ן', ipa:'n', final:true },
  'x': { en:'x', EN:'X', he:'ס', ipa:'s' },
  'g': { en:'g', EN:'G', he:'ע', ipa:'ʕ', guttural:true },
  'p': { en:'p', EN:'P', he:'פ', ipa:'f', dagesh:'p' },
  ';': { en:';', EN:':', he:'ף', ipa:'f', final:true },
  'm': { en:'m', EN:'M', he:'צ', ipa:'ts' },
  '.': { en:'.', EN:'>', he:'ץ', ipa:'ts', final:true },
  'e': { en:'e', EN:'E', he:'ק', ipa:'k' },
  'r': { en:'r', EN:'R', he:'ר', ipa:'ʁ' },
  'a': { en:'a', EN:'A', he:'ש', ipa:'ʃ' }, // shin/sin special
  ',': { en:',', EN:'<', he:'ת', ipa:'t' },
  'q': { en:'q', EN:'Q', he:'/', ipa:'kw' },
  'w': { en:'w', EN:'W', he:"'", ipa:'w' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// SUMMARY
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════');
console.log('UNIKEY DATA INVENTORY');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`UK_HE_VOWELS:      ${UK_HE_VOWELS.length} entries`);
console.log(`UK_HE_HATAF:       ${UK_HE_HATAF.length} entries`);
console.log(`UK_HE_MALE:        ${UK_HE_MALE.length} entries`);
console.log(`IPA_VOWELS:        ${Object.keys(IPA_VOWELS).length} entries`);
console.log(`IPA_CONSONANTS:    ${Object.keys(IPA_CONSONANTS).length} entries`);
console.log(`UK_EN_CONNECTORS:  ${Object.values(UK_EN_CONNECTORS).flat().length} entries`);
console.log(`UK_HE_CONNECTORS:  ${Object.values(UK_HE_CONNECTORS).flat().length} entries`);
console.log(`MG_SYL_DATA:       ${Object.keys(MG_SYL_DATA).length} keys`);
console.log(`KEYBOARD_MAP:      ${Object.keys(KEYBOARD_MAP).length} keys`);

console.log('\n───────────────────────────────────────────────────────────────');
console.log('Total unique data points: ~500+');
console.log('───────────────────────────────────────────────────────────────');
