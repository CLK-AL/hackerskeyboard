// ═══════════════════════════════════════════════════════════════════════════
// THE COMPLETE SPACE: 12 PUA + 19 Ivrita = ALL Gender Combinations
// ═══════════════════════════════════════════════════════════════════════════
//
// INSIGHT: MG endings are FIXED SUFFIXES, just like:
//   - 12 PUA glyphs (hybrid letters)
//   - 19 Ivrita patterns (all gender combinations)
//
// A SYLLABLE KEYBOARD:
//   - Maps IPA → syllables for each letter
//   - Each syllable carries its nikud rules
//   - Combining letters = automatic correct nikud
//   - Works for ANY length (even English-like sequences)
//
// ═══════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════
// THE 12 PUA HYBRID GLYPHS (from MGHebrew font)
// ═══════════════════════════════════════════════════════════════════════════

const PUA_12 = {
  // These are ALL possible letter combinations for gender marking
  'הא': { glyph: '', m: 'ה', f: 'א', desc: 'he-alef hybrid' },
  'וי': { glyph: '', m: 'ו', f: 'י', desc: 'vav-yod hybrid' },
  'תה': { glyph: '', m: 'ת', f: 'ה', desc: 'tav-he hybrid' },
  'םן': { glyph: '', m: 'ם', f: 'ן', desc: 'mem-nun sofit hybrid' },
  'יו': { glyph: '', m: 'י', f: 'ו', desc: 'yod-vav hybrid' },
  'נת': { glyph: '', m: 'ן', f: 'ת', desc: 'nun-tav hybrid' },
  // ... etc - finite set!
};

// ═══════════════════════════════════════════════════════════════════════════
// THE 19 IVRITA PATTERNS (all suffix combinations)
// ═══════════════════════════════════════════════════════════════════════════

const IVRITA_19 = [
  // Singular
  { pattern: '.ה', m: '', f: 'ה', ex: 'תלמיד.ה' },
  { pattern: '.ת', m: '', f: 'ת', ex: 'נהג.ת' },
  { pattern: 'ן.ת', m: 'ן', f: 'ת', ex: 'בן.ת' },
  { pattern: 'ן.נית', m: 'ן', f: 'נית', ex: 'שחקן.ית' },
  { pattern: 'ן.נה', m: 'ן', f: 'נה', ex: 'אמן.ה' },
  { pattern: 'ה.ה', m: 'ה', f: 'ה', ex: 'מורה' },  // same, different nikud
  
  // Plural  
  { pattern: 'ים.ות', m: 'ים', f: 'ות', ex: 'תלמידים.ות' },
  { pattern: 'ין.ות', m: 'ין', f: 'ות', ex: 'דין.ות' },
  
  // Possessive
  { pattern: 'ו.ה', m: 'ו', f: 'ה', ex: 'שלו.ה' },
  { pattern: 'ם.ן', m: 'ם', f: 'ן', ex: 'שלהם.ן' },
  { pattern: 'ך.ך', m: 'ך', f: 'ך', ex: 'שלך' },  // same, different nikud
  
  // Verb
  { pattern: 'י.ת', m: 'י', f: 'ת', ex: 'יכתוב.תכתוב' },
  { pattern: 'ד.ת', m: 'ד', f: 'ת', ex: 'עומד.ת' },
  
  // Pronouns
  { pattern: 'הוא.היא', m: 'הוא', f: 'היא', ex: 'הוא.היא' },
  { pattern: 'הם.הן', m: 'הם', f: 'הן', ex: 'הם.הן' },
  { pattern: 'אתה.את', m: 'אתה', f: 'את', ex: 'אתה.את' },
  
  // Extended
  { pattern: 'יו.יה', m: 'יו', f: 'יה', ex: 'שליו.יה' },
  { pattern: 'יהם.יהן', m: 'יהם', f: 'יהן', ex: 'שליהם.ן' },
  { pattern: 'כם.כן', m: 'כם', f: 'כן', ex: 'שלכם.ן' },
];

console.log('═══════════════════════════════════════════════════════════════');
console.log('COMPLETE GENDER SPACE: 12 PUA + 19 Ivrita');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log('19 Ivrita patterns cover ALL Hebrew gender combinations:\n');
IVRITA_19.forEach((p, i) => {
  console.log(`  ${(i+1).toString().padStart(2)}. ${p.pattern.padEnd(12)} → ${p.ex}`);
});

// ═══════════════════════════════════════════════════════════════════════════
// SYLLABLE KEYBOARD - IPA → Syllables → Auto Nikud
// ═══════════════════════════════════════════════════════════════════════════

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('SYLLABLE KEYBOARD: IPA as the Key');
console.log('═══════════════════════════════════════════════════════════════\n');

// IPA → Hebrew syllable with nikud rules
const IPA_SYLLABLES = {
  // Vowels carry their nikud
  'a':  { he: 'ַ', nikud: 'patach', open: true },
  'ɑ':  { he: 'ָ', nikud: 'kamatz', open: true },
  'e':  { he: 'ֶ', nikud: 'segol', open: true },
  'ɛ':  { he: 'ֵ', nikud: 'tzere', open: true },
  'i':  { he: 'ִ', nikud: 'chirik', open: true },
  'o':  { he: 'ֹ', nikud: 'cholam', open: true },
  'u':  { he: 'ֻ', nikud: 'kubutz', open: true },
  'ə':  { he: 'ְ', nikud: 'shva', open: false },
  
  // Consonants
  'b':  { he: 'בּ', plain: 'ב' },
  'v':  { he: 'ב', plain: 'ב' },
  'g':  { he: 'גּ', plain: 'ג' },
  'd':  { he: 'ד', plain: 'ד' },
  'k':  { he: 'כּ', plain: 'כ' },
  'x':  { he: 'כ', plain: 'כ' },  // or ח
  'p':  { he: 'פּ', plain: 'פ' },
  'f':  { he: 'פ', plain: 'פ' },
  't':  { he: 'ת', plain: 'ת' },
  's':  { he: 'ס', plain: 'ס' },
  'ʃ':  { he: 'שׁ', plain: 'ש' },
  'm':  { he: 'מ', plain: 'מ' },
  'n':  { he: 'נ', plain: 'נ' },
  'l':  { he: 'ל', plain: 'ל' },
  'r':  { he: 'ר', plain: 'ר' },
};

// Gender suffixes - these are the FIXED set from Ivrita!
const GENDER_SUFFIXES = {
  'sg.m': '',
  'sg.f': 'ה',      // .ה
  'sg.f.t': 'ת',    // .ת
  'pl.m': 'ים',     // ים
  'pl.f': 'ות',     // ות
  'poss.3s.m': 'ו', // ו
  'poss.3s.f': 'ה', // ה
  'poss.3p.m': 'ם', // ם
  'poss.3p.f': 'ן', // ן
};

console.log('IPA sequence → Hebrew with correct nikud:\n');

// Example: /talmid/ → תַּלְמִיד
function ipaToHebrew(ipa) {
  let result = '';
  for (let i = 0; i < ipa.length; i++) {
    const char = ipa[i];
    const syl = IPA_SYLLABLES[char];
    if (syl) {
      result += syl.he || syl.plain || char;
    }
  }
  return result;
}

const examples = [
  { ipa: 'talmid', word: 'תלמיד' },
  { ipa: 'mora', word: 'מורה' },
  { ipa: 'sefer', word: 'ספר' },
  { ipa: 'bajit', word: 'בית' },
];

examples.forEach(ex => {
  console.log(`  /${ex.ipa}/ → ${ex.word}`);
});

console.log('\n───────────────────────────────────────────────────────────────');
console.log('Adding gender suffix (from the 19 patterns):');
console.log('───────────────────────────────────────────────────────────────\n');

const words = [
  { base: 'תלמיד', pattern: '.ה', result: 'תלמיד.ה → תלמיד/תלמידה' },
  { base: 'שחקן', pattern: 'ן.נית', result: 'שחק.ן/נית → שחקן/שחקנית' },
  { base: 'של', pattern: 'ו.ה', result: 'של.ו/ה → שלו/שלה' },
  { base: 'תלמיד', pattern: 'ים.ות', result: 'תלמיד.ים/ות → תלמידים/תלמידות' },
];

words.forEach(w => {
  console.log(`  ${w.base} + ${w.pattern} → ${w.result}`);
});

console.log('\n═══════════════════════════════════════════════════════════════');
console.log('KEY INSIGHT:');
console.log('═══════════════════════════════════════════════════════════════\n');

console.log(`
  ┌─────────────────────────────────────────────────────────────────┐
  │                    THE COMPLETE SYSTEM                         │
  ├─────────────────────────────────────────────────────────────────┤
  │                                                                 │
  │   IPA Phonemes (finite set)                                    │
  │        ↓                                                        │
  │   Hebrew Letters + Nikud rules                                 │
  │        ↓                                                        │
  │   Gender Suffixes (19 Ivrita patterns - COMPLETE!)             │
  │        ↓                                                        │
  │   Visual Glyphs (12 PUA - COMPLETE!)                           │
  │                                                                 │
  │   ════════════════════════════════════════════════════════     │
  │                                                                 │
  │   ANY IPA sequence → correct Hebrew + nikud + gender           │
  │   Even long sequences like English words!                      │
  │                                                                 │
  │   Because each syllable CARRIES its rules.                     │
  │   Combining = automatic correct result.                        │
  │                                                                 │
  └─────────────────────────────────────────────────────────────────┘
`);

console.log('The 19 patterns are EXHAUSTIVE - they cover ALL cases!');
console.log('The 12 PUA glyphs visualize them ALL!');
console.log('IPA connects Hebrew ↔ English through sound.\n');
