# UniKey v3 - Detailed Design Document

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         KEYBOARD LAYOUT                                 │
│                    Map<PhysicalKey, UniKey>                             │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                            UNIKEY                                       │
│            Physical Key → IPA Base + All Permutations                   │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                  ┌─────────────┴─────────────┐
                  ▼                           ▼
┌────────────────────────────┐  ┌────────────────────────────┐
│        IPA_KEY             │  │        MG_KEY              │
│   Phonetic Interface       │  │   Semantic Interface       │
│   /b/ /t/ /m/ /a/ /o/     │  │   poss, plural, pronoun    │
└─────────────┬──────────────┘  └─────────────┬──────────────┘
              │                               │
              └───────────────┬───────────────┘
                              │
            ┌─────────────────┴─────────────────┐
            ▼                                   ▼
┌────────────────────────┐        ┌────────────────────────┐
│    HEBREW IMPL         │        │    ENGLISH IMPL        │
│    implements          │        │    implements          │
│    IPA_Key, MG_Key     │        │    IPA_Key, MG_Key     │
└────────────────────────┘        └────────────────────────┘
```

## 2. Interfaces

### IPA_Key Interface
```typescript
interface IPA_Key {
  ipa: string;        // IPA symbol: '/b/', '/a/', '/ʃ/'
}
```

### MG_Key Interface
```typescript
interface MG_Key {
  semantic: string;   // 'poss-3s', 'plural', 'pronoun-3s'
  ipa_m: string;      // IPA for masculine
  ipa_f: string;      // IPA for feminine
}
```

### LangImpl Interface
```typescript
interface LangImpl {
  plain: string;      // Plain form
  nikud?: string;     // Decorated form (Hebrew)
  final?: string;     // Final form (ם ן ך ף ץ)
}
```

### UniKey Interface
```typescript
interface UniKey {
  id: string;                 // Physical key: 'B', 'M', '1'
  type: 'consonant' | 'vowel' | 'mg';
  base_ipa: string;           // Base IPA phoneme
  syllables: Map<IPA, {he: LangImpl, en: LangImpl}>;
  mg?: MG_Key;                // If type === 'mg'
}
```

## 3. IPA Inventory

### Vowels (12)
| IPA | Name | Hebrew | Nikud Name | English |
|-----|------|--------|------------|---------|
| /a/ | open front | ַ | patach | a |
| /ɑ/ | open back | ָ | kamatz | a |
| /e/ | mid front | ֶ | segol | e |
| /ɛ/ | open-mid front | ֵ | tzere | e |
| /i/ | close front | ִ | chirik | i |
| /o/ | mid back | ֹ | cholam | o |
| /u/ | close back | ֻ | kubutz | u |
| /ə/ | schwa | ְ | shva | e |
| /ɪ/ | near-close front | ִ | chirik | i |
| /ʊ/ | near-close back | ֻ | kubutz | u |
| /æ/ | near-open front | ַ | patach | a |
| /ɔ/ | open-mid back | ָ | kamatz | o |

### Consonants (26)
| IPA | Hebrew | English | Final |
|-----|--------|---------|-------|
| /b/ | בּ | b | - |
| /p/ | פּ | p | ף |
| /d/ | ד | d | - |
| /t/ | ת | t | - |
| /g/ | גּ | g | - |
| /k/ | כּ | k | ך |
| /v/ | ב | v | - |
| /f/ | פ | f | ף |
| /z/ | ז | z | - |
| /s/ | ס | s | - |
| /ʃ/ | שׁ | sh | - |
| /x/ | ח | ch | - |
| /h/ | ה | h | - |
| /m/ | מ | m | ם |
| /n/ | נ | n | ן |
| /l/ | ל | l | - |
| /r/ | ר | r | - |
| /j/ | י | y | - |
| /w/ | ו | w | - |
| /ts/ | צ | ts | ץ |
| /ʔ/ | א | ' | - |
| /ʕ/ | ע | ' | - |

## 4. MG Pairs (12)

| Key | Semantic | Hebrew M/F | English M/F |
|-----|----------|------------|-------------|
| 1 | poss-3s | ו/ה | his/her |
| 2 | poss-3p | ם/ן | their/their |
| 3 | present | ד/ת | -/- |
| 4 | future-prefix | י/ת | will/will |
| 5 | plural | ים/ות | s/s |
| 6 | profession | ן/נית | or/ress |
| 7 | gentilic | י/ית | n/n |
| 8 | poss-3s-ext | יו/יה | his/hers |
| 9 | poss-3p-ext | יהם/יהן | theirs/theirs |
| 10 | poss-2p | כם/כן | your/your |
| 11 | pronoun-3s | הוא/היא | he/she |
| 12 | pronoun-2s | אתה/את | you/you |

## 5. Keyboard Layout

### Number Row (MG Pairs)
```
┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ 1  │ 2  │ 3  │ 4  │ 5  │ 6  │ 7  │ 8  │ 9  │ 0  │ -  │ =  │
│ו/ה │ם/ן │ד/ת │י/ת │ים/ות│ן/נית│י/ית│יו/יה│יהם/ן│כם/כן│הוא/י│אתה/ת│
│poss│poss│pres│fut │plur│prof│gent│poss│poss│poss│pron│pron│
│ 3s │ 3p │    │    │    │    │    │3s+ │3p+ │ 2p │ 3s │ 2s │
└────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
```

### Letter Rows (IPA-based)
```
┌────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ Q  │ W  │ E  │ R  │ T  │ Y  │ U  │ I  │ O  │ P  │
│ ק  │ ו  │ א  │ ר  │ ת  │ י  │ ו  │ י  │ ו  │ פ  │
│/k/ │/w/ │/e/ │/r/ │/t/ │/j/ │/u/ │/i/ │/o/ │/p/ │
└────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘
┌────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ A  │ S  │ D  │ F  │ G  │ H  │ J  │ K  │ L  │
│ א  │ ס  │ ד  │ פ  │ ג  │ ה  │ י  │ כ  │ ל  │
│/a/ │/s/ │/d/ │/f/ │/g/ │/h/ │/j/ │/k/ │/l/ │
└────┴────┴────┴────┴────┴────┴────┴────┴────┘
┌────┬────┬────┬────┬────┬────┬────┐
│ Z  │ X  │ C  │ V  │ B  │ N  │ M  │
│ ז  │ ח  │ צ  │ ב  │ ב  │ נ  │ מ  │
│/z/ │/x/ │/ts/│/v/ │/b/ │/n/ │/m/ │
└────┴────┴────┴────┴────┴────┴────┘
```

## 6. UniKey Structure

### Consonant UniKey Example (B key)
```javascript
UniKey['B'] = {
  id: 'B',
  type: 'consonant',
  base_ipa: 'b',
  
  base: {
    he: { plain: 'ב', nikud: 'בּ' },
    en: { plain: 'b' }
  },
  
  syllables: {
    'ba': { he: { plain: 'ב', nikud: 'בַּ', vowel: 'patach' }, en: { plain: 'ba' } },
    'bɑ': { he: { plain: 'ב', nikud: 'בָּ', vowel: 'kamatz' }, en: { plain: 'ba' } },
    'be': { he: { plain: 'ב', nikud: 'בֶּ', vowel: 'segol' },  en: { plain: 'be' } },
    'bɛ': { he: { plain: 'ב', nikud: 'בֵּ', vowel: 'tzere' },  en: { plain: 'be' } },
    'bi': { he: { plain: 'ב', nikud: 'בִּ', vowel: 'chirik' }, en: { plain: 'bi' } },
    'bo': { he: { plain: 'ב', nikud: 'בֹּ', vowel: 'cholam' }, en: { plain: 'bo' } },
    'bu': { he: { plain: 'ב', nikud: 'בֻּ', vowel: 'kubutz' }, en: { plain: 'bu' } },
    'bə': { he: { plain: 'ב', nikud: 'בְּ', vowel: 'shva' },   en: { plain: 'be' } },
  }
}
```

### MG UniKey Example (Key 1)
```javascript
UniKey['1'] = {
  id: '1',
  type: 'mg',
  semantic: 'poss-3s',
  
  he: {
    m: { p: 'ו', n: 'וֹ', ipa: 'o' },
    f: { p: 'ה', n: 'ָהּ', ipa: 'a' },
    plain: 'ו/ה',
    nikud: 'וֹ/ָהּ'
  },
  
  en: {
    m: { p: 'his', ipa: 'hɪz' },
    f: { p: 'her', ipa: 'hɜr' },
    plain: 'his/her'
  }
}
```

## 7. API

```javascript
UniKeyAPI = {
  // Get UniKey by physical key
  getKey(keyId) → UniKey
  
  // Get output with modifiers
  getOutput(keyId, lang, {
    nikud?: boolean,    // Include nikud
    vowel?: string,     // Vowel IPA for syllable
    gender?: 'm'|'f',   // Gender for MG
    final?: boolean     // Final form
  }) → string
  
  // Get IPA for key
  getIPA(keyId) → string
  
  // Get all syllables for consonant
  getSyllables(keyId) → Map<IPA, Syllable>
  
  // Get MG pair data
  getMG(keyId, lang) → MGData
}
```

## 8. Modifiers

| Modifier | Numbers (MG) | Letters |
|----------|--------------|---------|
| Normal | plain pair | plain consonant |
| Shift | - | caps/shift |
| Alt | m gender | syllable select |
| Alt+Shift | f gender | syllable + nikud |
| Ctrl+Alt | nikud pair | IPA display |

## 9. Inventory Summary

```
IPA Vowels:      12
IPA Consonants:  26
MG Pairs:        12
UniKeys Total:   42
  - Consonants:  25
  - Vowels:      5
  - MG Keys:     12
  
CV Syllables per consonant: 12
Total CV Syllables: 25 × 12 = 300
```

## 10. Key Principles

1. **IPA as Bridge** - Physical key location = IPA(English letter)
2. **Language Implementations** - Hebrew & English implement same interfaces
3. **Syllable Permutations** - Each consonant key has all CV combinations
4. **MG Semantic Pairs** - 12 pairs cover all gender distinctions
5. **Modifier Layers** - Same physical key → multiple outputs via modifiers
