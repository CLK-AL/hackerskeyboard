// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY - SILENT & SOFT LETTERS (אותיות שקטות ורפות)
// ═══════════════════════════════════════════════════════════════════════════════

const HE_SILENT = {
  mater_lectionis: {
    'א': { name: 'אָלֶף', silent: ['הוּא', 'קָרָא', 'מָצָא'], voiced: ['אָב', 'אֶת', 'אִם'], rule: 'שקטה בסוף, קולית בתחילה' },
    'ה': { name: 'הֵא', silent: ['יָפָה', 'גְּדוֹלָה', 'אַתָּה'], voiced: ['הוּא', 'הִיא', 'הַ'], rule: 'ה סיומת שקטה' },
    'ו': { name: 'וָו', silent: ['אוֹר', 'שׁוּק', 'טוֹב'], voiced: ['וְ', 'וָו'], rule: 'וֹ/וּ אֵם קְרִיאָה' },
    'י': { name: 'יוֹד', silent: ['שִׁיר', 'בֵּית', 'עִיר'], voiced: ['יָד', 'יוֹם'], rule: 'ִי/ֵי אֵם קְרִיאָה' },
  },
  shva: {
    na: { name: 'שְׁוָא נָע', ipa: 'ə', examples: ['בְּ', 'שְׁמוֹ', 'דְּבַר'] },
    nach: { name: 'שְׁוָא נָח', ipa: '', examples: ['מֶלֶךְ', 'כָּתְבָה', 'יִלְמְדוּ'] },
  },
  dagesh: {
    'ב': { with: 'b', without: 'v' },
    'כ': { with: 'k', without: 'x' },
    'פ': { with: 'p', without: 'f' },
  },
};

const EN_SILENT = {
  'kn': { silent: 'k', examples: ['knight', 'knife', 'knee', 'knock', 'know'], ipa: ['naɪt', 'naɪf', 'niː', 'nɒk', 'noʊ'], he: ['נַייט', 'נַייף', 'נִי', 'נוֹק', 'נוֹ'] },
  'gn': { silent: 'g', examples: ['gnome', 'gnat', 'sign', 'design', 'reign'], ipa: ['noʊm', 'næt', 'saɪn', 'dɪzaɪn', 'reɪn'], he: ['נוֹם', 'נֶט', 'סַיין', 'דִיזַיין', 'רֵיין'] },
  'wr': { silent: 'w', examples: ['write', 'wrong', 'wrap', 'wrist', 'wreck'], ipa: ['raɪt', 'rɒŋ', 'ræp', 'rɪst', 'rek'], he: ['רַייט', 'רוֹנג', 'רֶפּ', 'רִיסט', 'רֶק'] },
  'mb': { silent: 'b', examples: ['lamb', 'bomb', 'climb', 'comb', 'dumb', 'thumb'], ipa: ['læm', 'bɒm', 'klaɪm', 'koʊm', 'dʌm', 'θʌm'], he: ['לֶם', 'בּוֹם', 'קְלַיים', 'קוֹם', 'דַם', 'ת׳אַם'] },
  'bt': { silent: 'b', examples: ['debt', 'doubt', 'subtle'], ipa: ['det', 'daʊt', 'sʌtl'], he: ['דֶט', 'דַאוּט', 'סַטְל'] },
  'igh': { silent: 'gh', examples: ['night', 'light', 'right', 'high', 'fight', 'sight'], ipa: ['naɪt', 'laɪt', 'raɪt', 'haɪ', 'faɪt', 'saɪt'], he: ['נַייט', 'לַייט', 'רַייט', 'הַיי', 'פַייט', 'סַייט'] },
  'ough': { silent: 'gh', examples: ['though', 'through', 'thought', 'dough'], ipa: ['ðoʊ', 'θruː', 'θɔːt', 'doʊ'], he: ['ד׳וֹ', 'ת׳רוּ', 'ת׳וֹט', 'דוֹ'] },
  'augh': { silent: 'gh', examples: ['caught', 'taught', 'daughter'], ipa: ['kɔːt', 'tɔːt', 'dɔːtər'], he: ['קוֹט', 'טוֹט', 'דוֹטֶר'] },
  'alk': { silent: 'l', examples: ['walk', 'talk', 'chalk', 'stalk'], ipa: ['wɔːk', 'tɔːk', 'tʃɔːk', 'stɔːk'], he: ['ווֹק', 'טוֹק', 'צ׳וֹק', 'סטוֹק'] },
  'alm': { silent: 'l', examples: ['calm', 'palm', 'balm', 'psalm'], ipa: ['kɑːm', 'pɑːm', 'bɑːm', 'sɑːm'], he: ['קָאם', 'פָּאם', 'בָּאם', 'סָאם'] },
  'alf': { silent: 'l', examples: ['half', 'calf'], ipa: ['hɑːf', 'kɑːf'], he: ['הָאף', 'קָאף'] },
  'ould': { silent: 'l', examples: ['could', 'would', 'should'], ipa: ['kʊd', 'wʊd', 'ʃʊd'], he: ['קוּד', 'ווּד', 'שׁוּד'] },
  'ps': { silent: 'p', examples: ['psychology', 'psalm', 'pseudo', 'psyche'], ipa: ['saɪkɒlədʒi', 'sɑːm', 'suːdoʊ', 'saɪki'], he: ['סַייקוֹלוֹג׳י', 'סָאם', 'סוּדוֹ', 'סַייקִי'] },
  'pn': { silent: 'p', examples: ['pneumonia', 'pneumatic'], ipa: ['njuːmoʊniə', 'njuːmætɪk'], he: ['נְיוּמוֹנְיָה', 'נְיוּמֶטִיק'] },
  'sten': { silent: 't', examples: ['listen', 'fasten', 'glisten', 'moisten'], ipa: ['lɪsn', 'fæsn', 'glɪsn', 'mɔɪsn'], he: ['לִיסֶן', 'פֶסֶן', 'גְלִיסֶן', 'מוֹיסֶן'] },
  'stle': { silent: 't', examples: ['castle', 'whistle', 'wrestle', 'bustle'], ipa: ['kæsl', 'wɪsl', 'resl', 'bʌsl'], he: ['קֶסֶל', 'ווִיסֶל', 'רֶסֶל', 'בַּסֶל'] },
  'th_voiced': { sound: 'ð', examples: ['the', 'this', 'that', 'there', 'they', 'with', 'other'], ipa: ['ðə', 'ðɪs', 'ðæt', 'ðer', 'ðeɪ', 'wɪð', 'ʌðər'], he: ['ד׳ָה', 'ד׳ִיס', 'ד׳ֶט', 'ד׳ֶר', 'ד׳ֵיי', 'ווִיד׳', 'אַד׳ֶר'], warning: '⚠️ קירוב! /ð/ לא קיים בעברית' },
  'th_voiceless': { sound: 'θ', examples: ['think', 'thing', 'three', 'through', 'bath', 'path'], ipa: ['θɪŋk', 'θɪŋ', 'θriː', 'θruː', 'bæθ', 'pæθ'], he: ['ת׳ִינק', 'ת׳ִינג', 'ת׳רִי', 'ת׳רוּ', 'בֶּת׳', 'פֶּת׳'], warning: '⚠️ קירוב! /θ/ לא קיים בעברית' },
};

// Output
console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('SILENT & SOFT LETTERS - אותיות שקטות ורפות');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('HEBREW (עברית):');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
Object.entries(HE_SILENT.mater_lectionis).forEach(([letter, info]) => {
  console.log(`${letter} (${info.name}): ${info.rule}`);
  console.log(`   שקטה: ${info.silent.join(', ')}`);
  console.log(`   קולית: ${info.voiced.join(', ')}`);
});

console.log('\nשְׁוָא:');
console.log(`   נָע (voiced /ə/): ${HE_SILENT.shva.na.examples.join(', ')}`);
console.log(`   נָח (silent): ${HE_SILENT.shva.nach.examples.join(', ')}`);

console.log('\nבגדכפ"ת:');
Object.entries(HE_SILENT.dagesh).forEach(([l, d]) => {
  console.log(`   ${l}ּ /${d.with}/ ↔ ${l} /${d.without}/`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ENGLISH SILENT PATTERNS:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const patterns = ['kn', 'gn', 'wr', 'mb', 'igh', 'ough', 'alk', 'alm', 'ps', 'sten', 'stle'];
patterns.forEach(p => {
  const info = EN_SILENT[p];
  console.log(`${p.toUpperCase().padEnd(6)} (${info.silent} silent): ${info.examples.slice(0, 4).join(', ')}`);
  console.log(`        IPA: ${info.ipa.slice(0, 4).join(', ')}`);
  console.log(`        עברית: ${info.he.slice(0, 4).join(', ')}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('TH - אין מקבילה בעברית!');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('⚠️ /ð/ (voiced): the, this, that → ד׳ָה, ד׳ִיס, ד׳ֶט (קירוב בלבד!)');
console.log('⚠️ /θ/ (voiceless): think, three → ת׳ִינק, ת׳רִי (קירוב בלבד!)');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('COMPLETE TRANSCRIPTION TABLE:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

const all = [
  { en: 'knight', ipa: 'naɪt', he: 'נַייט', note: 'K silent' },
  { en: 'know', ipa: 'noʊ', he: 'נוֹ', note: 'K silent' },
  { en: 'gnome', ipa: 'noʊm', he: 'נוֹם', note: 'G silent' },
  { en: 'sign', ipa: 'saɪn', he: 'סַיין', note: 'G silent' },
  { en: 'write', ipa: 'raɪt', he: 'רַייט', note: 'W silent' },
  { en: 'wrong', ipa: 'rɒŋ', he: 'רוֹנג', note: 'W silent' },
  { en: 'lamb', ipa: 'læm', he: 'לֶם', note: 'B silent' },
  { en: 'doubt', ipa: 'daʊt', he: 'דַאוּט', note: 'B silent' },
  { en: 'night', ipa: 'naɪt', he: 'נַייט', note: 'GH silent' },
  { en: 'though', ipa: 'ðoʊ', he: 'ד׳וֹ', note: 'GH silent + TH' },
  { en: 'thought', ipa: 'θɔːt', he: 'ת׳וֹט', note: 'GH silent + TH' },
  { en: 'walk', ipa: 'wɔːk', he: 'ווֹק', note: 'L silent' },
  { en: 'half', ipa: 'hɑːf', he: 'הָאף', note: 'L silent' },
  { en: 'psalm', ipa: 'sɑːm', he: 'סָאם', note: 'P silent' },
  { en: 'listen', ipa: 'lɪsn', he: 'לִיסֶן', note: 'T silent' },
  { en: 'castle', ipa: 'kæsl', he: 'קֶסֶל', note: 'T silent' },
  { en: 'the', ipa: 'ðə', he: 'ד׳ָה', note: '⚠️ TH→ד׳ קירוב' },
  { en: 'think', ipa: 'θɪŋk', he: 'ת׳ִינק', note: '⚠️ TH→ת׳ קירוב' },
];

console.log('English      IPA         Hebrew      Note');
console.log('─────────────────────────────────────────────────────────────────────────────────────');
all.forEach(t => {
  console.log(`${t.en.padEnd(13)}${t.ipa.padEnd(12)}${t.he.padEnd(12)}${t.note}`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('PATTERN SUMMARY:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log(`
┌─────────────────────────────────────────────────────────────────────────────┐
│  ENGLISH SILENT PATTERNS:                                                   │
│  kn- → /n/     knight, knife, knee, know                                   │
│  gn- → /n/     gnome, gnat, sign, design                                   │
│  wr- → /r/     write, wrong, wrap, wrist                                   │
│  -mb → /m/     lamb, bomb, climb, thumb                                    │
│  -bt → /t/     debt, doubt, subtle                                         │
│  -igh → /aɪ/   night, light, right, high                                   │
│  -ough →       though /oʊ/, through /uː/, thought /ɔː/                     │
│  -alk → /ɔːk/  walk, talk, chalk (L silent)                                │
│  -alm → /ɑːm/  calm, palm, psalm (L silent)                                │
│  ps- → /s/     psychology, psalm, pseudo                                   │
│  -sten → /sn/  listen, fasten, glisten                                     │
│  -stle → /sl/  castle, whistle, wrestle                                    │
│  th → /ð/,/θ/  ⚠️ NO HEBREW EQUIVALENT! Use ד׳ or ת׳                       │
│                                                                             │
│  HEBREW SILENT PATTERNS:                                                    │
│  א סוף מילה    הוּא, קָרָא, מָצָא                                            │
│  ה סיומת       יָפָה, גְּדוֹלָה, בַּיְתָה                                      │
│  וֹ / וּ        אוֹר, שׁוּק, טוֹב (ו as vowel)                                │
│  ִי / ֵי       שִׁיר, בֵּית, עִיר (י as vowel)                                │
│  שְׁוָא נָח     מֶלֶךְ, דֶּרֶךְ, כָּתְבָה                                       │
│  בגדכפ"ת      בּ/ב, כּ/כ, פּ/פ                                               │
└─────────────────────────────────────────────────────────────────────────────┘
`);

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { HE_SILENT, EN_SILENT };
}
