// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V5 - COMPLETE MERGED PHONETICS ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
//
// This is the AUTHORITATIVE merged module combining:
// - v3-complete-extracted.js: Base IPA data
// - v3-nikud-engine.js: Letter+vowel combinations
// - v3-vowel-approximations.js: Quality indicators
// - v3-silent-letters.js: Silent patterns both languages
// - v3-unique-sounds.js: Geresh marking
// - v3-dagesh-mappiq.js: Diacritical effects
// - v4-phonetics.js: Initial class structure
//
// ═══════════════════════════════════════════════════════════════════════════════

class UniKey {
  
  // ═══════════════════════════════════════════════════════════════════════════
  // HEBREW LETTERS
  // ═══════════════════════════════════════════════════════════════════════════
  
  static HE_LETTERS = {
    // Regular letters
    'א': { name: 'אָלֶף', ipa: 'ʔ', en: "'", type: 'guttural', silent_end: true },
    'ב': { name: 'בֵּית', ipa: 'v', ipa_dagesh: 'b', en: 'v', en_dagesh: 'b', type: 'bgdkpt' },
    'ג': { name: 'גִּימֶל', ipa: 'g', en: 'g', type: 'bgdkpt', classical: 'ɣ' },
    'ד': { name: 'דָּלֶת', ipa: 'd', en: 'd', type: 'bgdkpt', classical: 'ð' },
    'ה': { name: 'הֵא', ipa: 'h', en: 'h', type: 'guttural', silent_end: true, mappiq: 'הּ' },
    'ו': { name: 'וָו', ipa: 'v', en: 'v', type: 'weak', vowel_marker: ['וֹ', 'וּ'] },
    'ז': { name: 'זַיִן', ipa: 'z', en: 'z' },
    'ח': { name: 'חֵית', ipa: 'ħ', ipa_modern: 'x', en: "ḥ'", en_alt: "ch'", type: 'guttural' },
    'ט': { name: 'טֵית', ipa: 't', en: 't', type: 'emphatic' },
    'י': { name: 'יוֹד', ipa: 'j', en: 'y', type: 'weak', vowel_marker: ['ִי', 'ֵי'] },
    'כ': { name: 'כָּף', ipa: 'x', ipa_dagesh: 'k', en: "kh'", en_dagesh: 'k', type: 'bgdkpt', final: 'ך' },
    'ל': { name: 'לָמֶד', ipa: 'l', en: 'l' },
    'מ': { name: 'מֵם', ipa: 'm', en: 'm', final: 'ם' },
    'נ': { name: 'נוּן', ipa: 'n', en: 'n', final: 'ן' },
    'ס': { name: 'סָמֶךְ', ipa: 's', en: 's' },
    'ע': { name: 'עַיִן', ipa: 'ʕ', ipa_modern: 'ʔ', en: "'", type: 'guttural' },
    'פ': { name: 'פֵּא', ipa: 'f', ipa_dagesh: 'p', en: 'f', en_dagesh: 'p', type: 'bgdkpt', final: 'ף' },
    'צ': { name: 'צָדִי', ipa: 'ts', en: "ts'", type: 'emphatic', final: 'ץ' },
    'ק': { name: 'קוֹף', ipa: 'k', en: "k'", type: 'emphatic' },
    'ר': { name: 'רֵישׁ', ipa: 'ʁ', en: "r'", note: 'guttural R' },
    'ש': { name: 'שִׁין/שִׂין', ipa: 'ʃ', ipa_sin: 's', en: 'sh', en_sin: 's' },
    'ת': { name: 'תָּו', ipa: 't', en: 't', type: 'bgdkpt', classical: 'θ' },
    
    // Final letters (סופיות)
    'ך': { name: 'כָּף סוֹפִית', ipa: 'x', en: "kh'", is_final: true, base: 'כ' },
    'ם': { name: 'מֵם סוֹפִית', ipa: 'm', en: 'm', is_final: true, base: 'מ' },
    'ן': { name: 'נוּן סוֹפִית', ipa: 'n', en: 'n', is_final: true, base: 'נ' },
    'ף': { name: 'פֵּא סוֹפִית', ipa: 'f', en: 'f', is_final: true, base: 'פ' },
    'ץ': { name: 'צָדִי סוֹפִית', ipa: 'ts', en: "ts'", is_final: true, base: 'צ' },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // NIKUD MARKS
  // ═══════════════════════════════════════════════════════════════════════════
  
  static NIKUD = {
    // Full vowels (תנועות גדולות)
    'ַ': { name: 'פַּתַח', ipa: 'a', type: 'full', en: 'a' },
    'ָ': { name: 'קָמָץ', ipa: 'ɑ', ipa_katan: 'ɔ', type: 'full', en: 'a/o' },
    'ֵ': { name: 'צֵירֵי', ipa: 'e', type: 'full', en: 'ay/e', male: 'ֵי' },
    'ֶ': { name: 'סֶגוֹל', ipa: 'ɛ', type: 'full', en: 'e' },
    'ִ': { name: 'חִירִיק', ipa: 'i', type: 'full', en: 'i/ee', male: 'ִי' },
    'ֹ': { name: 'חוֹלָם', ipa: 'o', type: 'full', en: 'o', male: 'וֹ' },
    'ֻ': { name: 'קֻבּוּץ', ipa: 'u', type: 'full', en: 'u/oo', male: 'וּ' },
    
    // Reduced vowels (תנועות קטנות)
    'ְ': { name: 'שְׁוָא', ipa: 'ə', ipa_silent: '', type: 'reduced', en: 'e/∅' },
    'ֲ': { name: 'חֲטַף פַּתַח', ipa: 'a', type: 'hataf', for: 'gutturals', en: 'a' },
    'ֱ': { name: 'חֲטַף סֶגוֹל', ipa: 'ɛ', type: 'hataf', for: 'gutturals', en: 'e' },
    'ֳ': { name: 'חֲטַף קָמָץ', ipa: 'o', type: 'hataf', for: 'gutturals', en: 'o' },
    
    // Modifiers
    'ּ': { name: 'דָּגֵשׁ', type: 'dagesh', effect: 'hard/double' },
    'ׁ': { name: 'נְקֻדַּת שִׁין', type: 'dot', ipa: 'ʃ' },
    'ׂ': { name: 'נְקֻדַּת שִׂין', type: 'dot', ipa: 's' },
    'ׄ': { name: 'מַפִּיק', type: 'mappiq', effect: 'pronounced ה' },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // IPA VOWEL MAPPING (with quality)
  // ═══════════════════════════════════════════════════════════════════════════
  
  static IPA_VOWELS = {
    // === EXACT MATCHES (התאמה מדויקת ✅) ===
    'a': { he: 'ַ', name: 'פַּתַח', quality: 'exact', en: ['a'], ex: { he: 'אַב', en: 'father' } },
    'i': { he: 'ִ', name: 'חִירִיק', quality: 'exact', male: 'ִי', en: ['ee', 'ea', 'i'], ex: { he: 'מִי', en: 'see' } },
    'u': { he: 'ֻ', name: 'קֻבּוּץ', quality: 'exact', male: 'וּ', en: ['oo', 'u'], ex: { he: 'הוּא', en: 'moon' } },
    'e': { he: 'ֵ', name: 'צֵירֵי', quality: 'exact', male: 'ֵי', en: ['ay', 'ai', 'e'], ex: { he: 'בֵּית', en: 'say' } },
    'o': { he: 'ֹ', name: 'חוֹלָם', quality: 'exact', male: 'וֹ', en: ['o', 'oa'], ex: { he: 'לֹא', en: 'go' } },
    'ɛ': { he: 'ֶ', name: 'סֶגוֹל', quality: 'exact', en: ['e'], ex: { he: 'אֶת', en: 'bed' } },
    'ə': { he: 'ְ', name: 'שְׁוָא נָע', quality: 'exact', en: ['a', 'e'], ex: { he: 'בְּ', en: 'about' } },
    
    // === APPROXIMATIONS (קירוב ⚠️) ===
    'æ': { he: 'ֶ', alt: 'ַ', name: 'סֶגוֹל/פַּתַח', quality: 'approx', en: ['a'], ex: 'cat', 
          warning: '⚠️ קירוב! /æ/ לא קיים בעברית' },
    'ʌ': { he: 'ַ', name: 'פַּתַח', quality: 'approx', en: ['u', 'o'], ex: 'cup',
          warning: '⚠️ קירוב! /ʌ/ לא קיים בעברית' },
    'ɒ': { he: 'ָ', alt: 'ֹ', name: 'קָמָץ/חוֹלָם', quality: 'approx', en: ['o'], ex: 'hot',
          warning: '⚠️ קירוב! /ɒ/ לא קיים בעברית' },
    'ɪ': { he: 'ִ', name: 'חִירִיק', quality: 'approx', en: ['i'], ex: 'sit',
          warning: '⚠️ קירוב! /ɪ/ יותר רפוי מ-/i/' },
    'ʊ': { he: 'ֻ', name: 'קֻבּוּץ', quality: 'approx', en: ['oo', 'u'], ex: 'book',
          warning: '⚠️ קירוב! /ʊ/ יותר רפוי מ-/u/' },
    'ɜː': { he: 'ֶ', alt: 'ְ', name: 'סֶגוֹל/שְׁוָא', quality: 'approx', en: ['er', 'ir', 'ur'], ex: 'bird',
           warning: '⚠️⚠️ קירוב גס! /ɜː/ שונה מאוד' },
    'ɔ': { he: 'ָ', name: 'קָמָץ קָטָן', quality: 'approx', en: ['aw', 'au'], ex: 'law' },
    'ɑ': { he: 'ָ', name: 'קָמָץ', quality: 'near-exact', en: ['a', 'ar'], ex: 'father' },
    
    // === DIPHTHONGS (תנועות כפולות) ===
    'aɪ': { he: 'ַי', he_ipa: 'aj', quality: 'near-exact', en: ['i', 'y', 'igh', 'ie'], ex: { he: 'בַּיִת', en: 'my' } },
    'eɪ': { he: 'ֵי', he_ipa: 'ej', quality: 'near-exact', en: ['a', 'ay', 'ai', 'ei'], ex: { he: 'יֵשׁ', en: 'day' } },
    'ɔɪ': { he: 'וֹי', he_ipa: 'oj', quality: 'near-exact', en: ['oi', 'oy'], ex: { he: 'גּוֹי', en: 'boy' } },
    'aʊ': { he: 'ָאוּ', he_ipa: 'aw', quality: 'near-exact', en: ['ou', 'ow'], ex: { he: 'תָּו', en: 'now' } },
    'oʊ': { he: 'וֹ', quality: 'approx', en: ['o', 'ow', 'oa'], ex: 'go', 
           note: 'Hebrew /o/ is pure, English glides to /ʊ/' },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // IPA CONSONANTS
  // ═══════════════════════════════════════════════════════════════════════════
  
  static IPA_CONSONANTS = {
    // Stops
    'p': { he: 'פּ', en: 'p', name: 'voiceless bilabial' },
    'b': { he: 'בּ', en: 'b', name: 'voiced bilabial' },
    't': { he: 'ת/ט', en: 't', name: 'voiceless alveolar' },
    'd': { he: 'ד', en: 'd', name: 'voiced alveolar' },
    'k': { he: 'כּ/ק', en: 'k/c', name: 'voiceless velar' },
    'g': { he: 'ג', en: 'g', name: 'voiced velar' },
    'ʔ': { he: 'א/ע', en: '—', name: 'glottal stop' },
    
    // Fricatives
    'f': { he: 'פ', en: 'f/ph', name: 'voiceless labiodental' },
    'v': { he: 'ב/ו', en: 'v', name: 'voiced labiodental' },
    'θ': { he: 'ת׳', en: 'th', name: 'voiceless dental', warning: '⚠️ NO Hebrew equivalent!' },
    'ð': { he: 'ד׳', en: 'th', name: 'voiced dental', warning: '⚠️ NO Hebrew equivalent!' },
    's': { he: 'ס/שׂ', en: 's/c', name: 'voiceless alveolar' },
    'z': { he: 'ז', en: 'z/s', name: 'voiced alveolar' },
    'ʃ': { he: 'שׁ', en: 'sh', name: 'voiceless postalveolar' },
    'ʒ': { he: 'ז׳', en: 'si/su', name: 'voiced postalveolar' },
    'x': { he: 'כ/ח', en: '—', name: 'voiceless velar fricative' },
    'ħ': { he: 'ח', en: "ḥ'", name: 'voiceless pharyngeal', note: 'deeper than כ' },
    'ʕ': { he: 'ע', en: "'", name: 'voiced pharyngeal' },
    'h': { he: 'ה', en: 'h', name: 'voiceless glottal' },
    
    // Affricates
    'ts': { he: 'צ', en: "ts'", name: 'voiceless alveolar affricate' },
    'tʃ': { he: 'צ׳', en: 'ch', name: 'voiceless postalveolar affricate' },
    'dʒ': { he: 'ג׳', en: 'j/g', name: 'voiced postalveolar affricate' },
    
    // Nasals
    'm': { he: 'מ', en: 'm', name: 'bilabial nasal' },
    'n': { he: 'נ', en: 'n', name: 'alveolar nasal' },
    'ŋ': { he: 'נג', en: 'ng', name: 'velar nasal' },
    
    // Approximants
    'l': { he: 'ל', en: 'l', name: 'alveolar lateral' },
    'ɹ': { he: 'ר׳', en: 'r', name: 'alveolar approximant', note: 'English R' },
    'ʁ': { he: 'ר', en: "r'", name: 'uvular fricative', note: 'Hebrew R' },
    'j': { he: 'י', en: 'y', name: 'palatal approximant' },
    'w': { he: 'ו׳/וו', en: 'w', name: 'labio-velar approximant', warning: 'W ≠ V!' },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // SILENT LETTERS
  // ═══════════════════════════════════════════════════════════════════════════
  
  static SILENT = {
    // Hebrew אותיות אֵם קְרִיאָה
    hebrew: {
      mater_lectionis: {
        'א': { when: 'סוף מילה', ex: ['הוּא', 'קָרָא', 'מָצָא'], voiced_ex: ['אָב', 'אֶת'] },
        'ה': { when: 'ה סיומת', ex: ['יָפָה', 'גְּדוֹלָה'], voiced: 'הּ (מַפִּיק)' },
        'ו': { when: 'וֹ/וּ', ex: ['אוֹר', 'שׁוּק', 'טוֹב'] },
        'י': { when: 'ִי/ֵי', ex: ['שִׁיר', 'בֵּית', 'עִיר'] },
      },
      shva: {
        na: { mark: 'ְ', ipa: 'ə', ex: ['בְּ', 'שְׁמוֹ', 'דְּבַר'] },
        nach: { mark: 'ְ', ipa: '', ex: ['מֶלֶךְ', 'כָּתְבָה', 'יִלְמְדוּ'] },
      },
    },
    
    // English silent patterns
    english: {
      'kn': { silent: 'k', ipa: '/n/', ex: ['knight', 'knife', 'know'], he: ['נַייט', 'נַייף', 'נוֹ'] },
      'gn': { silent: 'g', ipa: '/n/', ex: ['gnome', 'sign', 'design'], he: ['נוֹם', 'סַיין', 'דִיזַיין'] },
      'wr': { silent: 'w', ipa: '/r/', ex: ['write', 'wrong', 'wrap'], he: ['רַייט', 'רוֹנג', 'רֶפּ'] },
      'mb': { silent: 'b', ipa: '/m/', ex: ['lamb', 'climb', 'bomb'], he: ['לֶם', 'קְלַיים', 'בּוֹם'] },
      'bt': { silent: 'b', ipa: '/t/', ex: ['debt', 'doubt'], he: ['דֶט', 'דַאוּט'] },
      'igh': { silent: 'gh', ipa: '/aɪ/', ex: ['night', 'light', 'high'], he: ['נַייט', 'לַייט', 'הַיי'] },
      'ough': { silent: 'gh', ipa: 'varies', ex: ['though', 'through', 'thought'], he: ['ד׳וֹ', 'ת׳רוּ', 'ת׳וֹט'] },
      'alk': { silent: 'l', ipa: '/ɔːk/', ex: ['walk', 'talk', 'chalk'], he: ['ווֹק', 'טוֹק', 'צ׳וֹק'] },
      'alm': { silent: 'l', ipa: '/ɑːm/', ex: ['calm', 'palm', 'psalm'], he: ['קָאם', 'פָּאם', 'סָאם'] },
      'ps': { silent: 'p', ipa: '/s/', ex: ['psychology', 'psalm'], he: ['סַייקוֹלוֹג׳י', 'סָאם'] },
      'sten': { silent: 't', ipa: '/sn/', ex: ['listen', 'fasten'], he: ['לִיסֶן', 'פֶסֶן'] },
      'stle': { silent: 't', ipa: '/sl/', ex: ['castle', 'whistle'], he: ['קֶסֶל', 'ווִיסֶל'] },
    },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // GERESH MARKING (צלילים ייחודיים)
  // ═══════════════════════════════════════════════════════════════════════════
  
  static GERESH = {
    // Hebrew → English (צלילים עבריים שצריכים ' באנגלית)
    he_to_en: {
      'צ': "ts'",
      'ח': "ḥ'",
      'כ': "kh'",  // without dagesh
      'ע': "'",
      'ר': "r'",   // guttural R
      'ק': "k'",
    },
    
    // English → Hebrew (צלילים אנגליים שצריכים ׳ בעברית)
    en_to_he: {
      'θ': 'ת׳',   // think, three
      'ð': 'ד׳',   // the, this
      'tʃ': 'צ׳',  // chair, cheese
      'dʒ': 'ג׳',  // jam, job
      'ʒ': 'ז׳',   // vision, measure
      'w': 'ו׳',   // water, want (or וו)
    },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MAPPIQ
  // ═══════════════════════════════════════════════════════════════════════════
  
  static MAPPIQ = {
    mark: 'הּ',
    ipa: 'h',
    rule: 'ה נשמעת בסוף מילה (סמיכות, כינויים)',
    examples: {
      with: [
        { he: 'שֶׁלָּהּ', en: "shela'", meaning: 'שלה (נקבה)' },
        { he: 'גָּבֹהַּ', en: "gavoah'", meaning: 'גבוה' },
        { he: 'בֵּיתָהּ', en: "beta'", meaning: 'ביתה (שלה)' },
      ],
      without: [
        { he: 'שֶׁלָּה', en: 'shela', meaning: 'שלה (מקום)' },
        { he: 'יָפָה', en: 'yafa', meaning: 'יפה' },
        { he: 'בַּיְתָה', en: 'bayta', meaning: 'הביתה (לכיוון)' },
      ],
    },
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // ENGLISH SPELLINGS TO IPA
  // ═══════════════════════════════════════════════════════════════════════════
  
  static EN_TO_IPA = {
    // Vowels
    'ee': 'iː', 'ea': 'iː', 'ie': 'iː',
    'oo': 'uː', 'ue': 'uː', 'ew': 'uː',
    'ay': 'eɪ', 'ai': 'eɪ', 'ei': 'eɪ',
    'oy': 'ɔɪ', 'oi': 'ɔɪ',
    'ou': 'aʊ', 'ow': 'aʊ',
    'igh': 'aɪ', 'ie': 'aɪ', 'y': 'aɪ',
    'oa': 'oʊ',
    
    // Consonants
    'sh': 'ʃ', 'ch': 'tʃ', 'tch': 'tʃ',
    'th': ['θ', 'ð'],  // context dependent
    'ng': 'ŋ', 'nk': 'ŋk',
    'ph': 'f', 'gh': ['f', ''],  // context dependent
    'wh': 'w',
    'ck': 'k', 'qu': 'kw',
  };
  
  // ═══════════════════════════════════════════════════════════════════════════
  // API METHODS
  // ═══════════════════════════════════════════════════════════════════════════
  
  /**
   * Get nikud for IPA vowel
   * @param {string} ipa - IPA vowel symbol
   * @param {object} options - { male: bool, alt: bool }
   * @returns {object} { mark, name, quality, warning? }
   */
  static getNikudForIPA(ipa, options = {}) {
    const vowel = this.IPA_VOWELS[ipa];
    if (!vowel) return null;
    
    return {
      mark: options.male && vowel.male ? vowel.male : (options.alt && vowel.alt ? vowel.alt : vowel.he),
      name: vowel.name,
      quality: vowel.quality,
      warning: vowel.warning,
    };
  }
  
  /**
   * Get IPA for Hebrew character
   */
  static getIPAForHebrew(char) {
    // Check letters
    if (this.HE_LETTERS[char]) {
      return this.HE_LETTERS[char].ipa;
    }
    // Check nikud
    if (this.NIKUD[char]) {
      return this.NIKUD[char].ipa;
    }
    return null;
  }
  
  /**
   * Check if letter is guttural
   */
  static isGuttural(letter) {
    const info = this.HE_LETTERS[letter];
    return info && info.type === 'guttural';
  }
  
  /**
   * Get hataf for guttural
   */
  static getHatafFor(vowelIPA) {
    const map = { 'a': 'ֲ', 'ɛ': 'ֱ', 'o': 'ֳ' };
    return map[vowelIPA] || 'ֲ';
  }
  
  /**
   * Apply nikud to letter
   */
  static applyNikud(letter, ipa, options = {}) {
    // Use hataf for gutturals with schwa
    if (this.isGuttural(letter) && ipa === 'ə') {
      return letter + 'ֲ';
    }
    
    const nikud = this.getNikudForIPA(ipa, options);
    if (!nikud) return letter;
    
    return letter + nikud.mark;
  }
  
  /**
   * Check if sound needs geresh
   */
  static needsGeresh(ipa, direction) {
    if (direction === 'he_to_en') {
      return Object.values(this.GERESH.he_to_en).some(v => v.includes("'"));
    }
    if (direction === 'en_to_he') {
      return !!this.GERESH.en_to_he[ipa];
    }
    return false;
  }
  
  /**
   * Transcribe Hebrew to English
   */
  static transcribeHeToEn(char) {
    const info = this.HE_LETTERS[char];
    if (!info) return char;
    return info.en || info.ipa;
  }
  
  /**
   * Transcribe English to Hebrew (for unique sounds)
   */
  static transcribeEnToHe(ipa) {
    return this.GERESH.en_to_he[ipa] || this.IPA_CONSONANTS[ipa]?.he || null;
  }
  
  /**
   * Get Hebrew transcription for English silent pattern
   */
  static getSilentPattern(pattern) {
    return this.SILENT.english[pattern] || null;
  }
  
  /**
   * Check vowel quality
   */
  static isExactMatch(ipa) {
    return this.IPA_VOWELS[ipa]?.quality === 'exact';
  }
  
  static isApproximation(ipa) {
    return this.IPA_VOWELS[ipa]?.quality === 'approx';
  }
  
  /**
   * Get complete sound info
   */
  static getSoundInfo(char) {
    return {
      letter: this.HE_LETTERS[char],
      nikud: this.NIKUD[char],
      consonant: this.IPA_CONSONANTS[char],
      vowel: this.IPA_VOWELS[char],
      isGuttural: this.isGuttural(char),
    };
  }
  
  /**
   * Generate letter+nikud combination
   */
  static combine(letter, nikudMark) {
    return letter + nikudMark;
  }
  
  /**
   * Get all nikud options for a letter
   */
  static getNikudOptions(letter) {
    const options = [];
    const isGutt = this.isGuttural(letter);
    
    Object.entries(this.NIKUD).forEach(([mark, info]) => {
      if (info.type === 'hataf' && !isGutt) return;
      if (info.type === 'dagesh' || info.type === 'dot') return;
      
      options.push({
        combined: letter + mark,
        mark,
        name: info.name,
        ipa: info.ipa,
      });
    });
    
    return options;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TESTS
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY V5 - MERGED PHONETICS ENGINE');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('LETTERS:', Object.keys(UniKey.HE_LETTERS).length, 'Hebrew letters');
console.log('NIKUD:', Object.keys(UniKey.NIKUD).length, 'marks');
console.log('IPA_VOWELS:', Object.keys(UniKey.IPA_VOWELS).length, 'vowels');
console.log('IPA_CONSONANTS:', Object.keys(UniKey.IPA_CONSONANTS).length, 'consonants');

console.log('\n─── VOWEL QUALITY TESTS ───');
['a', 'i', 'æ', 'ʌ', 'aɪ'].forEach(ipa => {
  const v = UniKey.getNikudForIPA(ipa);
  if (v) console.log(`/${ipa}/ → ${v.mark} [${v.quality}] ${v.warning || ''}`);
});

console.log('\n─── CONSONANT TESTS ───');
console.log('בּ =', UniKey.HE_LETTERS['ב'].ipa_dagesh, '/', UniKey.HE_LETTERS['ב'].en_dagesh);
console.log('ב =', UniKey.HE_LETTERS['ב'].ipa, '/', UniKey.HE_LETTERS['ב'].en);
console.log('כּ =', UniKey.HE_LETTERS['כ'].ipa_dagesh, '/', UniKey.HE_LETTERS['כ'].en_dagesh);
console.log('כ =', UniKey.HE_LETTERS['כ'].ipa, '/', UniKey.HE_LETTERS['כ'].en);

console.log('\n─── GERESH TESTS ───');
console.log('th /θ/ →', UniKey.GERESH.en_to_he['θ']);
console.log('th /ð/ →', UniKey.GERESH.en_to_he['ð']);
console.log('ch /tʃ/ →', UniKey.GERESH.en_to_he['tʃ']);
console.log('צ →', UniKey.GERESH.he_to_en['צ']);
console.log('ח →', UniKey.GERESH.he_to_en['ח']);

console.log('\n─── SILENT PATTERNS ───');
console.log('kn-:', UniKey.SILENT.english['kn'].ex.join(', '));
console.log('igh:', UniKey.SILENT.english['igh'].ex.join(', '));

console.log('\n─── APPLY NIKUD ───');
console.log('ב + /a/ →', UniKey.applyNikud('ב', 'a'));
console.log('ב + /i/ →', UniKey.applyNikud('ב', 'i'));
console.log('ח + /ə/ →', UniKey.applyNikud('ח', 'ə'), '(hataf for guttural)');

console.log('\n─── MAPPIQ ───');
UniKey.MAPPIQ.examples.with.slice(0, 2).forEach(ex => {
  console.log(`${ex.he} → ${ex.en} (${ex.meaning})`);
});

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');

// Export
if (typeof module !== 'undefined' && module.exports) {
  module.exports = UniKey;
}
