// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V5 COMPLETE - ALL DATA FROM unikeyboard.html
// ═══════════════════════════════════════════════════════════════════════════════
// Source: unikeyboard.html (13,960 lines)
// This file contains ALL phonetic data structures
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V5 FULL - COMPLETE DATA EXTRACTION FROM unikeyboard.html
// ═══════════════════════════════════════════════════════════════════════════════
// Generated: $(date)
// Source: unikeyboard.html (13,960 lines)
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// PART 1: CORE CLASS
// ═══════════════════════════════════════════════════════════════════════════════

class UniKey {
  constructor(data) { Object.assign(this, data); }
  
  label(mode, mods = {}) {
    const { shift, alt, ctrl } = mods;
    if (ctrl) return this.ipa || '';
    if (alt && this.mg) {
      const mf = shift;
      if (mode === 'en' || mode === 'EN') return mf ? this.mg.fm_en : this.mg.mf_en;
      return mf ? this.mg.fm : this.mg.mf;
    }
    if (shift && !alt) {
      if (mode === 'he') {
        if (this.syl && this.syl.length > 0) return this.he + '·';
        return this.he;
      }
      if ((mode === 'en' || mode === 'EN') && this.enSyl && this.enSyl.length > 0) return this.en + '·';
      if (mode === 'en') return this.EN || this.en?.toUpperCase() || this.shift;
      if (mode === 'EN') return this.shift || this.EN;
    }
    if (mode === 'en') return this.en;
    if (mode === 'EN') return this.EN || this.en?.toUpperCase();
    if (mode === 'he') return this.he;
    return this.en;
  }
  
  getSyllables(mode) {
    if (mode === 'he') return this.syl || [];
    if (mode === 'en' || mode === 'EN') return this.enSyl || [];
    return [];
  }
  
  getMg(mode, femaleFirst = false) {
    if (!this.mg) return null;
    const isEn = mode === 'en' || mode === 'EN';
    return {
      display: femaleFirst ? (isEn ? this.mg.fm_en : this.mg.fm) : (isEn ? this.mg.mf_en : this.mg.mf),
      male: isEn ? this.mg.m_en : this.mg.m,
      female: isEn ? this.mg.f_en : this.mg.f,
    };
  }
}

// Factory
const UK = (data) => new UniKey(data);

// ═══════════════════════════════════════════════════════════════════════════════
// PART 2: HEBREW VOWELS (NIKUD)
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_VOWELS = [
  { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  { n: 'ָ', name: 'קָמָץ', ipa: 'ɑ' },
  { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  { n: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
];

const UK_HE_HATAF = [
  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
];

const UK_HE_MALE = [
  { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  { n: 'ֵי', name: 'צֵירֵי מָלֵא', ipa: 'ej' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// PART 3: NIKUD COMPLETE
// ═══════════════════════════════════════════════════════════════════════════════

const NIKUD = {
  // תנועות גדולות
  kamatz:   { n: 'ָ', name: 'קָמָץ', ipa: 'a', ipa_alt: 'o' },
  patach:   { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  tzere:    { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  segol:    { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  chirik:   { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  cholam:   { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  kubutz:   { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  
  // תנועות עם אם קריאה
  chirik_m: { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  cholam_m: { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  shuruk:   { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  
  // שווא וחטפים
  shva:     { n: 'ְ', name: 'שְׁוָא', ipa: 'ə', ipa_silent: '' },
  hataf_a:  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  hataf_e:  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  hataf_o:  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
  
  // דגש ונקודות
  dagesh:   { n: 'ּ', name: 'דָּגֵשׁ', mod: 'double/hard' },
  shin_dot: { n: 'ׁ', name: 'נְקֻדַּת שִׁין', ipa: 'ʃ' },
  sin_dot:  { n: 'ׂ', name: 'נְקֻדַּת שִׂין', ipa: 's' },
  rafe:     { n: 'ֿ', name: 'רָפֶה', mod: 'soft' },
  mappiq:   { n: 'ּ', name: 'מַפִּיק', mod: 'pronounced ה' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 4: HEBREW LETTERS
// ═══════════════════════════════════════════════════════════════════════════════

const HE_LETTERS = {
  'א': { ipa: 'ʔ', name: 'אָלֶף', type: 'guttural', silent_end: true, en: "'" },
  'ב': { ipa: 'v', ipa_dagesh: 'b', name: 'בֵּית', type: 'bgdkpt', en: 'v', en_dagesh: 'b' },
  'ג': { ipa: 'g', name: 'גִּימֶל', type: 'bgdkpt', en: 'g' },
  'ד': { ipa: 'd', name: 'דָּלֶת', type: 'bgdkpt', en: 'd' },
  'ה': { ipa: 'h', name: 'הֵא', type: 'guttural', silent_end: true, en: 'h' },
  'ו': { ipa: 'v', name: 'וָו', type: 'weak', en: 'v' },
  'ז': { ipa: 'z', name: 'זַיִן', en: 'z' },
  'ח': { ipa: 'ħ', name: 'חֵית', type: 'guttural', en: "ḥ'" },
  'ט': { ipa: 't', name: 'טֵית', type: 'emphatic', en: 't' },
  'י': { ipa: 'j', name: 'יוֹד', type: 'weak', en: 'y' },
  'כ': { ipa: 'x', ipa_dagesh: 'k', name: 'כַּף', type: 'bgdkpt', en: "kh'", en_dagesh: 'k' },
  'ל': { ipa: 'l', name: 'לָמֶד', en: 'l' },
  'מ': { ipa: 'm', name: 'מֵם', en: 'm' },
  'נ': { ipa: 'n', name: 'נוּן', en: 'n' },
  'ס': { ipa: 's', name: 'סָמֶך', en: 's' },
  'ע': { ipa: 'ʕ', name: 'עַיִן', type: 'guttural', en: "'" },
  'פ': { ipa: 'f', ipa_dagesh: 'p', name: 'פֵּא', type: 'bgdkpt', en: 'f', en_dagesh: 'p' },
  'צ': { ipa: 'ts', name: 'צָדִי', type: 'emphatic', en: "ts'" },
  'ק': { ipa: 'k', name: 'קוֹף', type: 'emphatic', en: "k'" },
  'ר': { ipa: 'ʁ', name: 'רֵישׁ', type: 'guttural', en: "r'" },
  'ש': { ipa: 'ʃ', ipa_sin: 's', name: 'שִׁין/שִׂין', type: 'shin', en: 'sh', en_sin: 's' },
  'ת': { ipa: 't', name: 'תָּו', type: 'bgdkpt', en: 't' },
  // Finals
  'ך': { ipa: 'x', base: 'כ', name: 'כַּף סוֹפִית', final: true, en: "kh'" },
  'ם': { ipa: 'm', base: 'מ', name: 'מֵם סוֹפִית', final: true, en: 'm' },
  'ן': { ipa: 'n', base: 'נ', name: 'נוּן סוֹפִית', final: true, en: 'n' },
  'ף': { ipa: 'f', base: 'פ', name: 'פֵּא סוֹפִית', final: true, en: 'f' },
  'ץ': { ipa: 'ts', base: 'צ', name: 'צָדִי סוֹפִית', final: true, en: "ts'" },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 5: IPA VOWELS WITH QUALITY
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_VOWELS = {
  // EXACT MATCHES
  'i': { name: 'close front', he: 'חִירִיק', nikud: 'ִ', male: 'ִי', en: 'ee/ea', quality: 'exact', ex: { he: 'מִי', en: 'see' } },
  'e': { name: 'close-mid front', he: 'צֵירֵי', nikud: 'ֵ', male: 'ֵי', en: 'ay/ei', quality: 'exact', ex: { he: 'בֵּית', en: 'say' } },
  'ɛ': { name: 'open-mid front', he: 'סֶגוֹל', nikud: 'ֶ', en: 'e', quality: 'exact', ex: { he: 'אֶת', en: 'bed' } },
  'a': { name: 'open', he: 'פַּתַח', nikud: 'ַ', en: 'a', quality: 'exact', ex: { he: 'אַב', en: 'father' } },
  'u': { name: 'close back', he: 'שׁוּרוּק', nikud: 'ֻ', male: 'וּ', en: 'oo', quality: 'exact', ex: { he: 'הוּא', en: 'moon' } },
  'o': { name: 'close-mid back', he: 'חוֹלָם', nikud: 'ֹ', male: 'וֹ', en: 'o', quality: 'exact', ex: { he: 'לֹא', en: 'go' } },
  'ə': { name: 'schwa', he: 'שְׁוָא', nikud: 'ְ', en: 'a/u', quality: 'exact', ex: { he: 'בְּ', en: 'about' } },
  
  // APPROXIMATIONS
  'ɪ': { name: 'near-close front', he: 'חִירִיק', nikud: 'ִ', en: 'i', quality: 'approx', warning: '⚠️', ex: { he: 'אִם', en: 'sit' } },
  'æ': { name: 'near-open front', he: '—', nikud: 'ֶ', alt: 'ַ', en: 'a', quality: 'approx', warning: '⚠️ לא קיים בעברית', ex: { en: 'cat' } },
  'ʌ': { name: 'open-mid back', he: 'פַּתַח', nikud: 'ַ', en: 'u', quality: 'approx', warning: '⚠️', ex: { en: 'cup' } },
  'ʊ': { name: 'near-close back', he: 'קֻבּוּץ', nikud: 'ֻ', en: 'oo', quality: 'approx', warning: '⚠️', ex: { he: 'קֻם', en: 'book' } },
  'ɔ': { name: 'open-mid back', he: 'קָמָץ קָטָן', nikud: 'ָ', en: 'aw', quality: 'approx', ex: { he: 'כָּל', en: 'law' } },
  'ɑ': { name: 'open back', he: 'קָמָץ', nikud: 'ָ', en: 'ar', quality: 'near-exact', ex: { he: 'אָב', en: 'father' } },
  'ɜː': { name: 'open-mid central', he: 'סֶגוֹל', nikud: 'ֶ', en: 'er', quality: 'approx', warning: '⚠️⚠️', ex: { en: 'bird' } },
  
  // DIPHTHONGS
  'aɪ': { name: 'diphthong', he: 'פַּתַח+יוֹד', nikud: 'ַי', en: 'i/y/igh', quality: 'near-exact', ex: { he: 'בַּיִת', en: 'my' } },
  'aʊ': { name: 'diphthong', he: 'פַּתַח+וָו', nikud: 'ָאוּ', en: 'ou/ow', quality: 'near-exact', ex: { he: 'אָו', en: 'now' } },
  'ɔɪ': { name: 'diphthong', he: 'חוֹלָם+יוֹד', nikud: 'וֹי', en: 'oi/oy', quality: 'near-exact', ex: { he: 'גּוֹי', en: 'boy' } },
  'eɪ': { name: 'diphthong', he: 'צֵירֵי+יוֹד', nikud: 'ֵי', en: 'ay/ai', quality: 'near-exact', ex: { he: 'יֵשׁ', en: 'day' } },
  'oʊ': { name: 'diphthong', he: 'חוֹלָם', nikud: 'וֹ', en: 'o/ow', quality: 'approx', ex: { he: 'אוֹ', en: 'go' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 6: IPA CONSONANTS
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_CONSONANTS = {
  // Stops
  'p': { name: 'voiceless bilabial', he: 'פּ', en: 'p', ex: { he: 'פֹּה', en: 'pen' } },
  'b': { name: 'voiced bilabial', he: 'בּ', en: 'b', ex: { he: 'בַּיִת', en: 'bat' } },
  't': { name: 'voiceless alveolar', he: 'ת/ט', en: 't', ex: { he: 'תַּם', en: 'top' } },
  'd': { name: 'voiced alveolar', he: 'ד', en: 'd', ex: { he: 'דָּג', en: 'dog' } },
  'k': { name: 'voiceless velar', he: 'כּ/ק', en: 'k', ex: { he: 'כֹּל', en: 'cat' } },
  'g': { name: 'voiced velar', he: 'ג', en: 'g', ex: { he: 'גַּם', en: 'go' } },
  'ʔ': { name: 'glottal stop', he: 'א/ע', en: '—', ex: { he: 'אָב', en: 'uh-oh' } },
  
  // Fricatives
  'f': { name: 'voiceless labiodental', he: 'פ', en: 'f', ex: { he: 'סוֹף', en: 'fan' } },
  'v': { name: 'voiced labiodental', he: 'ב/ו', en: 'v', ex: { he: 'טוֹב', en: 'van' } },
  's': { name: 'voiceless alveolar', he: 'ס/שׂ', en: 's', ex: { he: 'סוּס', en: 'sun' } },
  'z': { name: 'voiced alveolar', he: 'ז', en: 'z', ex: { he: 'זֶה', en: 'zoo' } },
  'ʃ': { name: 'voiceless postalveolar', he: 'שׁ', en: 'sh', ex: { he: 'שָׁם', en: 'she' } },
  'ʒ': { name: 'voiced postalveolar', he: 'ז׳', en: 'si', geresh: true, ex: { en: 'vision' } },
  'x': { name: 'voiceless velar', he: 'כ/ח', en: "kh'", he_unique: true, ex: { he: 'לֶךְ' } },
  'ħ': { name: 'voiceless pharyngeal', he: 'ח', en: "ḥ'", he_unique: true, ex: { he: 'חַם' } },
  'ʕ': { name: 'voiced pharyngeal', he: 'ע', en: "'", he_unique: true, ex: { he: 'עַם' } },
  'h': { name: 'voiceless glottal', he: 'ה', en: 'h', ex: { he: 'הוּא', en: 'hat' } },
  
  // English unique (need geresh in Hebrew)
  'θ': { name: 'voiceless dental', he: 'ת׳', en: 'th', geresh: true, warning: '⚠️', ex: { en: 'thin' } },
  'ð': { name: 'voiced dental', he: 'ד׳', en: 'th', geresh: true, warning: '⚠️', ex: { en: 'the' } },
  
  // Affricates
  'ts': { name: 'voiceless alveolar affricate', he: 'צ', en: "ts'", he_unique: true, ex: { he: 'צַד', en: 'cats' } },
  'tʃ': { name: 'voiceless postalveolar affricate', he: 'צ׳', en: 'ch', geresh: true, ex: { he: 'צ׳יפּ', en: 'chat' } },
  'dʒ': { name: 'voiced postalveolar affricate', he: 'ג׳', en: 'j', geresh: true, ex: { he: 'ג׳ינס', en: 'jam' } },
  
  // Nasals
  'm': { name: 'bilabial nasal', he: 'מ', en: 'm', ex: { he: 'מָה', en: 'man' } },
  'n': { name: 'alveolar nasal', he: 'נ', en: 'n', ex: { he: 'נָא', en: 'no' } },
  'ŋ': { name: 'velar nasal', he: 'נג', en: 'ng', ex: { en: 'sing' } },
  
  // Approximants
  'l': { name: 'alveolar lateral', he: 'ל', en: 'l', ex: { he: 'לֹא', en: 'let' } },
  'ʁ': { name: 'uvular fricative', he: 'ר', en: "r'", he_unique: true, ex: { he: 'רֹאשׁ' } },
  'r': { name: 'alveolar approximant', he: 'ר׳', en: 'r', different_he: true, ex: { en: 'red' } },
  'j': { name: 'palatal approximant', he: 'י', en: 'y', ex: { he: 'יָד', en: 'yes' } },
  'w': { name: 'labio-velar', he: 'ו׳', en: 'w', geresh: true, warning: 'W≠V', ex: { en: 'we' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 7: GERESH MARKING
// ═══════════════════════════════════════════════════════════════════════════════

const GERESH = {
  he_to_en: {
    'צ': { ipa: 'ts', en: "ts'", note: 'צִפּוֹר→ts\'ipor' },
    'ח': { ipa: 'ħ', en: "ḥ'", note: 'חַיִים→ḥ\'ayim' },
    'כ': { ipa: 'x', en: "kh'", note: 'מֶלֶךְ→melekh\'' },
    'ע': { ipa: 'ʕ', en: "'", note: 'עַיִן→\'ayin' },
    'ר': { ipa: 'ʁ', en: "r'", note: 'רֹאשׁ→r\'osh' },
    'ק': { ipa: 'k', en: "k'", note: 'קוֹל→k\'ol' },
  },
  en_to_he: {
    'θ': { en: 'th (voiceless)', he: 'ת׳', ex: ['think→ת׳ִינק', 'three→ת׳רִי'] },
    'ð': { en: 'th (voiced)', he: 'ד׳', ex: ['the→ד׳ָה', 'this→ד׳ִיס'] },
    'tʃ': { en: 'ch', he: 'צ׳', ex: ['chair→צ׳ֵיר', 'child→צ׳ַיילד'] },
    'dʒ': { en: 'j', he: 'ג׳', ex: ['jam→ג׳ֶם', 'judge→ג׳ַדג׳'] },
    'ʒ': { en: 'zh', he: 'ז׳', ex: ['vision→וִיז׳ָן'] },
    'w': { en: 'w', he: 'ו׳', alt: 'וו', ex: ['water→ווֹטֶר'] },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 8: SILENT LETTERS
// ═══════════════════════════════════════════════════════════════════════════════

const SILENT = {
  hebrew: {
    mater_lectionis: {
      'א': { when: 'סוף מילה', ex: ['הוּא', 'קָרָא'] },
      'ה': { when: 'ה סיומת', ex: ['יָפָה', 'גְּדוֹלָה'], voiced: 'הּ' },
      'ו': { when: 'וֹ/וּ', ex: ['אוֹר', 'שׁוּק'] },
      'י': { when: 'ִי/ֵי', ex: ['שִׁיר', 'בֵּית'] },
    },
    shva: {
      na: { mark: 'ְ', ipa: 'ə', ex: ['בְּ', 'שְׁמוֹ'] },
      nach: { mark: 'ְ', ipa: '', ex: ['מֶלֶךְ', 'כָּתְבָה'] },
    },
  },
  english: {
    'kn': { silent: 'k', ipa: '/n/', ex: ['knight', 'knife', 'know'], he: ['נַייט', 'נַייף', 'נוֹ'] },
    'gn': { silent: 'g', ipa: '/n/', ex: ['gnome', 'sign'], he: ['נוֹם', 'סַיין'] },
    'wr': { silent: 'w', ipa: '/r/', ex: ['write', 'wrong'], he: ['רַייט', 'רוֹנג'] },
    'mb': { silent: 'b', ipa: '/m/', ex: ['lamb', 'climb'], he: ['לֶם', 'קְלַיים'] },
    'bt': { silent: 'b', ipa: '/t/', ex: ['debt', 'doubt'], he: ['דֶט', 'דַאוּט'] },
    'igh': { silent: 'gh', ipa: '/aɪ/', ex: ['night', 'light', 'high'], he: ['נַייט', 'לַייט', 'הַיי'] },
    'ough': { silent: 'gh', ipa: 'varies', ex: ['though', 'through', 'thought'] },
    'alk': { silent: 'l', ipa: '/ɔːk/', ex: ['walk', 'talk'], he: ['ווֹק', 'טוֹק'] },
    'alm': { silent: 'l', ipa: '/ɑːm/', ex: ['calm', 'palm'], he: ['קָאם', 'פָּאם'] },
    'ps': { silent: 'p', ipa: '/s/', ex: ['psychology', 'psalm'] },
    'sten': { silent: 't', ipa: '/sn/', ex: ['listen', 'fasten'] },
    'stle': { silent: 't', ipa: '/sl/', ex: ['castle', 'whistle'] },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 9: MAPPIQ
// ═══════════════════════════════════════════════════════════════════════════════

const MAPPIQ = {
  mark: 'הּ',
  ipa: 'h',
  rule: 'ה נשמעת בסוף מילה',
  examples: {
    with: [
      { he: 'שֶׁלָּהּ', en: "shela'", meaning: 'שלה (נקבה)' },
      { he: 'גָּבֹהַּ', en: "gavoah'", meaning: 'גבוה' },
      { he: 'בֵּיתָהּ', en: "beta'", meaning: 'ביתה' },
    ],
    without: [
      { he: 'יָפָה', en: 'yafa', meaning: 'יפה' },
      { he: 'גְּדוֹלָה', en: 'gdola', meaning: 'גדולה' },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 10: BGDKPT
// ═══════════════════════════════════════════════════════════════════════════════

const BGDKPT = {
  'ב': { with: { letter: 'בּ', ipa: 'b', en: 'b' }, without: { letter: 'ב', ipa: 'v', en: 'v' } },
  'ג': { with: { letter: 'גּ', ipa: 'g', en: 'g' }, without: { letter: 'ג', ipa: 'g', en: 'g' }, classical: { without_ipa: 'ɣ' } },
  'ד': { with: { letter: 'דּ', ipa: 'd', en: 'd' }, without: { letter: 'ד', ipa: 'd', en: 'd' }, classical: { without_ipa: 'ð' } },
  'כ': { with: { letter: 'כּ', ipa: 'k', en: 'k' }, without: { letter: 'כ', ipa: 'x', en: "kh'" } },
  'פ': { with: { letter: 'פּ', ipa: 'p', en: 'p' }, without: { letter: 'פ', ipa: 'f', en: 'f' } },
  'ת': { with: { letter: 'תּ', ipa: 't', en: 't' }, without: { letter: 'ת', ipa: 't', en: 't' }, classical: { without_ipa: 'θ' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 11: ENGLISH CONNECTORS
// ═══════════════════════════════════════════════════════════════════════════════

const UK_EN_CONNECTORS = {
  conj: [
    { word:'and',ipa:'ænd' },{ word:'or',ipa:'ɔːr' },{ word:'but',ipa:'bʌt' },{ word:'so',ipa:'soʊ' },
    { word:'if',ipa:'ɪf' },{ word:'as',ipa:'æz' },{ word:'for',ipa:'fɔːr' },{ word:'yet',ipa:'jet' },
  ],
  prep: [
    { word:'in',ipa:'ɪn' },{ word:'on',ipa:'ɒn' },{ word:'at',ipa:'æt' },{ word:'to',ipa:'tuː' },
    { word:'of',ipa:'ɒv' },{ word:'by',ipa:'baɪ' },{ word:'up',ipa:'ʌp' },{ word:'off',ipa:'ɒf' },
    { word:'with',ipa:'wɪð' },{ word:'from',ipa:'frɒm' },
  ],
  det: [
    { word:'the',ipa:'ðə' },{ word:'a',ipa:'ə' },{ word:'an',ipa:'æn' },
    { word:'this',ipa:'ðɪs' },{ word:'that',ipa:'ðæt' },{ word:'some',ipa:'sʌm' },
  ],
  pron: [
    { word:'I',ipa:'aɪ' },{ word:'you',ipa:'juː' },{ word:'he',ipa:'hiː' },{ word:'she',ipa:'ʃiː' },
    { word:'it',ipa:'ɪt' },{ word:'we',ipa:'wiː' },{ word:'they',ipa:'ðeɪ' },
    { word:'me',ipa:'miː' },{ word:'him',ipa:'hɪm' },{ word:'her',ipa:'hɜːr' },
  ],
  verb: [
    { word:'is',ipa:'ɪz' },{ word:'am',ipa:'æm' },{ word:'are',ipa:'ɑːr' },{ word:'was',ipa:'wɒz' },
    { word:'be',ipa:'biː' },{ word:'have',ipa:'hæv' },{ word:'has',ipa:'hæz' },{ word:'do',ipa:'duː' },
    { word:'can',ipa:'kæn' },{ word:'will',ipa:'wɪl' },{ word:'would',ipa:'wʊd' },{ word:'could',ipa:'kʊd' },
  ],
  quest: [
    { word:'who',ipa:'huː' },{ word:'what',ipa:'wɒt' },{ word:'when',ipa:'wɛn' },{ word:'where',ipa:'wɛr' },
    { word:'why',ipa:'waɪ' },{ word:'how',ipa:'haʊ' },{ word:'which',ipa:'wɪtʃ' },
  ],
  adv: [
    { word:'not',ipa:'nɒt' },{ word:'just',ipa:'dʒʌst' },{ word:'now',ipa:'naʊ' },{ word:'then',ipa:'ðɛn' },
    { word:'here',ipa:'hɪr' },{ word:'there',ipa:'ðɛr' },{ word:'very',ipa:'vɛri' },{ word:'too',ipa:'tuː' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 12: HEBREW CONNECTORS
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_CONNECTORS = {
  prefix: [
    { word:'וְ',name:'ו החיבור',ex:'and',ipa:'ve' },
    { word:'בְּ',name:'ב היחס',ex:'in',ipa:'be' },
    { word:'לְ',name:'ל היחס',ex:'to',ipa:'le' },
    { word:'מִ',name:'מ היחס',ex:'from',ipa:'mi' },
    { word:'כְּ',name:'כ הדימוי',ex:'like',ipa:'ke' },
    { word:'הַ',name:'ה הידיעה',ex:'the',ipa:'ha' },
    { word:'שֶׁ',name:'ש הזיקה',ex:'that',ipa:'ʃe' },
  ],
  prep: [
    { word:'אֶל',name:'אל',ex:'to',ipa:'ʔel' },
    { word:'עַל',name:'על',ex:'on',ipa:'ʔal' },
    { word:'עִם',name:'עם',ex:'with',ipa:'ʔim' },
    { word:'אֶת',name:'את',ex:'(obj)',ipa:'ʔet' },
    { word:'בֵּין',name:'בין',ex:'between',ipa:'ben' },
    { word:'עַד',name:'עד',ex:'until',ipa:'ʔad' },
  ],
  conj: [
    { word:'כִּי',name:'כי',ex:'because',ipa:'ki' },
    { word:'אִם',name:'אם',ex:'if',ipa:'ʔim' },
    { word:'אוֹ',name:'או',ex:'or',ipa:'ʔo' },
    { word:'גַּם',name:'גם',ex:'also',ipa:'gam' },
    { word:'אֲבָל',name:'אבל',ex:'but',ipa:'ʔaval' },
  ],
  pron: [
    { word:'אֲנִי',name:'אני',ex:'I',ipa:'ʔani' },
    { word:'אַתָּה',name:'אתה',ex:'you(m)',ipa:'ʔata' },
    { word:'אַתְּ',name:'את',ex:'you(f)',ipa:'ʔat' },
    { word:'הוּא',name:'הוא',ex:'he',ipa:'hu' },
    { word:'הִיא',name:'היא',ex:'she',ipa:'hi' },
    { word:'אֲנַחְנוּ',name:'אנחנו',ex:'we',ipa:'ʔanaħnu' },
    { word:'הֵם',name:'הם',ex:'they(m)',ipa:'hem' },
    { word:'הֵן',name:'הן',ex:'they(f)',ipa:'hen' },
  ],
  quest: [
    { word:'מִי',name:'מי',ex:'who',ipa:'mi' },
    { word:'מָה',name:'מה',ex:'what',ipa:'ma' },
    { word:'אֵיפֹה',name:'איפה',ex:'where',ipa:'ʔefo' },
    { word:'מָתַי',name:'מתי',ex:'when',ipa:'mataj' },
    { word:'לָמָּה',name:'למה',ex:'why',ipa:'lama' },
    { word:'אֵיךְ',name:'איך',ex:'how',ipa:'ʔex' },
  ],
  adv: [
    { word:'לֹא',name:'לא',ex:'no',ipa:'lo' },
    { word:'כֵּן',name:'כן',ex:'yes',ipa:'ken' },
    { word:'עַכְשָׁיו',name:'עכשיו',ex:'now',ipa:'ʔaxʃav' },
    { word:'פֹּה',name:'פה',ex:'here',ipa:'po' },
    { word:'שָׁם',name:'שם',ex:'there',ipa:'ʃam' },
    { word:'מְאֹד',name:'מאוד',ex:'very',ipa:'meʔod' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 13: IPA TO NIKUD MAPPING
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_TO_NIKUD = {
  'a': ['patach', 'kamatz', 'hataf_a'],
  'e': ['tzere', 'segol', 'hataf_e'],
  'ɛ': ['segol', 'hataf_e'],
  'i': ['chirik', 'chirik_m'],
  'o': ['cholam', 'cholam_m', 'kamatz', 'hataf_o'],
  'u': ['kubutz', 'shuruk'],
  'ə': ['shva'],
  'ɪ': ['chirik'],
  'ʊ': ['kubutz'],
  'æ': ['segol', 'patach'],
  'ʌ': ['patach'],
  'ɔ': ['kamatz'],
  'ɑ': ['kamatz'],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 14: API FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function getNikudForIpa(ipa) { return IPA_TO_NIKUD[ipa] || []; }
function getIpaVowelInfo(ipa) { return IPA_VOWELS[ipa] || null; }
function getIpaConsonantInfo(ipa) { return IPA_CONSONANTS[ipa] || null; }
function isGuttural(letter) { return HE_LETTERS[letter]?.type === 'guttural'; }
function needsGeresh(sound, dir) { return dir === 'he_to_en' ? !!GERESH.he_to_en[sound] : !!GERESH.en_to_he[sound]; }
function getGereshForm(sound, dir) { return dir === 'he_to_en' ? GERESH.he_to_en[sound]?.en : GERESH.en_to_he[sound]?.he; }
function getSilentPattern(pattern) { return SILENT.english[pattern] || null; }
function isExactMatch(ipa) { return IPA_VOWELS[ipa]?.quality === 'exact'; }
function isApproximate(ipa) { return IPA_VOWELS[ipa]?.quality === 'approx'; }

function applyNikud(letter, ipa, options = {}) {
  const nikudOptions = getNikudForIpa(ipa);
  if (!nikudOptions.length) return letter;
  if (isGuttural(letter) && ipa === 'ə') return letter + NIKUD.hataf_a.n;
  const nikudKey = nikudOptions[0];
  if (options.male && IPA_VOWELS[ipa]?.male) return letter + IPA_VOWELS[ipa].male;
  return letter + NIKUD[nikudKey].n;
}

function getBgdkptSound(letter, hasDagesh) {
  const info = BGDKPT[letter];
  return info ? (hasDagesh ? info.with : info.without) : null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORTS & TESTS
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY V5 FULL - COMPLETE DATA EXTRACTION');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('DATA COUNTS:');
console.log('  UniKey class: ✅');
console.log('  UK_HE_VOWELS:', UK_HE_VOWELS.length);
console.log('  UK_HE_HATAF:', UK_HE_HATAF.length);
console.log('  UK_HE_MALE:', UK_HE_MALE.length);
console.log('  NIKUD:', Object.keys(NIKUD).length);
console.log('  HE_LETTERS:', Object.keys(HE_LETTERS).length);
console.log('  IPA_VOWELS:', Object.keys(IPA_VOWELS).length);
console.log('  IPA_CONSONANTS:', Object.keys(IPA_CONSONANTS).length);
console.log('  GERESH.he_to_en:', Object.keys(GERESH.he_to_en).length);
console.log('  GERESH.en_to_he:', Object.keys(GERESH.en_to_he).length);
console.log('  SILENT.english:', Object.keys(SILENT.english).length);
console.log('  BGDKPT:', Object.keys(BGDKPT).length);
console.log('  UK_EN_CONNECTORS:', Object.keys(UK_EN_CONNECTORS).length, 'categories');
console.log('  UK_HE_CONNECTORS:', Object.keys(UK_HE_CONNECTORS).length, 'categories');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════\n');

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    UniKey, UK,
    UK_HE_VOWELS, UK_HE_HATAF, UK_HE_MALE, NIKUD, HE_LETTERS,
    IPA_VOWELS, IPA_CONSONANTS, GERESH, SILENT, MAPPIQ, BGDKPT,
    UK_EN_CONNECTORS, UK_HE_CONNECTORS, IPA_TO_NIKUD,
    getNikudForIpa, getIpaVowelInfo, getIpaConsonantInfo,
    isGuttural, needsGeresh, getGereshForm, getSilentPattern,
    isExactMatch, isApproximate, applyNikud, getBgdkptSound,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// PART 15: UK_EN_VOWELS (FULL - ALL CONSONANT DIGRAPHS)
// ═══════════════════════════════════════════════════════════════════════════════

const UK_EN_VOWELS = {
  // === VOWELS with all common spellings ===
  a: [
    { syl:'a',ipa:'æ',ex:'cat' },{ syl:'a',ipa:'eɪ',ex:'take' },{ syl:'a',ipa:'ɑː',ex:'father' },
    { syl:'ai',ipa:'eɪ',ex:'rain' },{ syl:'ay',ipa:'eɪ',ex:'day' },{ syl:'au',ipa:'ɔː',ex:'caught' },
    { syl:'aw',ipa:'ɔː',ex:'saw' },{ syl:'ar',ipa:'ɑːr',ex:'car' },{ syl:'are',ipa:'ɛr',ex:'care' },
    { syl:'air',ipa:'ɛr',ex:'fair' },{ syl:'al',ipa:'ɔːl',ex:'all' },{ syl:'augh',ipa:'ɔː',ex:'caught' },
  ],
  e: [
    { syl:'e',ipa:'ɛ',ex:'bed' },{ syl:'e',ipa:'iː',ex:'be' },
    { syl:'ee',ipa:'iː',ex:'see' },{ syl:'ea',ipa:'iː',ex:'eat' },{ syl:'ea',ipa:'ɛ',ex:'bread' },
    { syl:'er',ipa:'ɜːr',ex:'her' },{ syl:'ere',ipa:'ɪr',ex:'here' },{ syl:'ear',ipa:'ɪr',ex:'hear' },
    { syl:'ey',ipa:'eɪ',ex:'they' },{ syl:'ei',ipa:'eɪ',ex:'vein' },{ syl:'eigh',ipa:'eɪ',ex:'eight' },
    { syl:'ew',ipa:'juː',ex:'new' },{ syl:'ew',ipa:'uː',ex:'blew' },
  ],
  i: [
    { syl:'i',ipa:'ɪ',ex:'sit' },{ syl:'i',ipa:'aɪ',ex:'hi' },
    { syl:'ie',ipa:'aɪ',ex:'tie' },{ syl:'ie',ipa:'iː',ex:'field' },
    { syl:'ir',ipa:'ɜːr',ex:'bird' },{ syl:'ire',ipa:'aɪr',ex:'fire' },
    { syl:'igh',ipa:'aɪ',ex:'high' },{ syl:'ight',ipa:'aɪt',ex:'night' },
  ],
  o: [
    { syl:'o',ipa:'ɒ',ex:'hot' },{ syl:'o',ipa:'oʊ',ex:'go' },
    { syl:'oo',ipa:'uː',ex:'moon' },{ syl:'oo',ipa:'ʊ',ex:'book' },
    { syl:'ou',ipa:'aʊ',ex:'out' },{ syl:'ow',ipa:'oʊ',ex:'low' },{ syl:'ow',ipa:'aʊ',ex:'cow' },
    { syl:'oy',ipa:'ɔɪ',ex:'boy' },{ syl:'oi',ipa:'ɔɪ',ex:'oil' },
    { syl:'or',ipa:'ɔːr',ex:'for' },{ syl:'oa',ipa:'oʊ',ex:'boat' },
    { syl:'ough',ipa:'oʊ/uː/ɔː',ex:'though/through/thought' },
  ],
  u: [
    { syl:'u',ipa:'ʌ',ex:'cup' },{ syl:'u',ipa:'juː',ex:'use' },{ syl:'u',ipa:'ʊ',ex:'put' },
    { syl:'ue',ipa:'uː',ex:'blue' },{ syl:'ue',ipa:'juː',ex:'cue' },
    { syl:'ui',ipa:'uː',ex:'fruit' },{ syl:'ur',ipa:'ɜːr',ex:'turn' },
  ],
  // === CONSONANT DIGRAPHS ===
  t: [
    { syl:'ta',ipa:'tæ',ex:'tap' },{ syl:'te',ipa:'tiː',ex:'tea' },{ syl:'ti',ipa:'taɪ',ex:'tie' },{ syl:'to',ipa:'tuː',ex:'to' },{ syl:'tu',ipa:'tʌ',ex:'tub' },
    { syl:'th',ipa:'θ',ex:'thin' },{ syl:'th',ipa:'ð',ex:'the' },{ syl:'thr',ipa:'θr',ex:'three' },
    { syl:'tr',ipa:'tr',ex:'try' },{ syl:'tw',ipa:'tw',ex:'two' },{ syl:'tch',ipa:'tʃ',ex:'catch' },{ syl:'tion',ipa:'ʃən',ex:'nation' },
  ],
  s: [
    { syl:'sa',ipa:'sæ',ex:'sat' },{ syl:'se',ipa:'siː',ex:'see' },{ syl:'si',ipa:'saɪ',ex:'sigh' },{ syl:'so',ipa:'soʊ',ex:'so' },{ syl:'su',ipa:'suː',ex:'sue' },
    { syl:'sh',ipa:'ʃ',ex:'she' },{ syl:'shr',ipa:'ʃr',ex:'shrimp' },
    { syl:'sk',ipa:'sk',ex:'sky' },{ syl:'sl',ipa:'sl',ex:'slow' },{ syl:'sm',ipa:'sm',ex:'small' },{ syl:'sn',ipa:'sn',ex:'snow' },
    { syl:'sp',ipa:'sp',ex:'spot' },{ syl:'st',ipa:'st',ex:'stop' },{ syl:'str',ipa:'str',ex:'street' },{ syl:'sw',ipa:'sw',ex:'swim' },
    { syl:'ss',ipa:'s',ex:'miss' },{ syl:'sion',ipa:'ʒən',ex:'vision' },
  ],
  c: [
    { syl:'ca',ipa:'kæ',ex:'cat' },{ syl:'ce',ipa:'siː',ex:'cell' },{ syl:'ci',ipa:'sɪ',ex:'city' },{ syl:'co',ipa:'koʊ',ex:'code' },{ syl:'cu',ipa:'kʌ',ex:'cup' },
    { syl:'ch',ipa:'tʃ',ex:'chat' },{ syl:'ch',ipa:'k',ex:'chrome' },{ syl:'ch',ipa:'ʃ',ex:'chef' },
    { syl:'ck',ipa:'k',ex:'back' },{ syl:'cl',ipa:'kl',ex:'class' },{ syl:'cr',ipa:'kr',ex:'cry' },
  ],
  g: [
    { syl:'ga',ipa:'gæ',ex:'gas' },{ syl:'ge',ipa:'dʒiː',ex:'gee' },{ syl:'gi',ipa:'gɪ',ex:'gift' },{ syl:'go',ipa:'goʊ',ex:'go' },{ syl:'gu',ipa:'gʌ',ex:'gum' },
    { syl:'gh',ipa:'f',ex:'laugh' },{ syl:'gh',ipa:'',ex:'night' },{ syl:'ght',ipa:'t',ex:'light' },
    { syl:'gl',ipa:'gl',ex:'glass' },{ syl:'gr',ipa:'gr',ex:'green' },{ syl:'gn',ipa:'n',ex:'gnat' },
  ],
  p: [
    { syl:'pa',ipa:'pæ',ex:'pat' },{ syl:'pe',ipa:'piː',ex:'pea' },{ syl:'pi',ipa:'paɪ',ex:'pie' },{ syl:'po',ipa:'poʊ',ex:'poe' },{ syl:'pu',ipa:'pʌ',ex:'pup' },
    { syl:'ph',ipa:'f',ex:'phone' },{ syl:'pl',ipa:'pl',ex:'play' },{ syl:'pr',ipa:'pr',ex:'pray' },{ syl:'ps',ipa:'s',ex:'psalm' },
  ],
  w: [
    { syl:'wa',ipa:'wɑ',ex:'wax' },{ syl:'we',ipa:'wiː',ex:'we' },{ syl:'wi',ipa:'waɪ',ex:'why' },{ syl:'wo',ipa:'woʊ',ex:'woe' },
    { syl:'wh',ipa:'w',ex:'what' },{ syl:'wh',ipa:'h',ex:'who' },{ syl:'wr',ipa:'r',ex:'write' },
  ],
  k: [
    { syl:'ka',ipa:'kæ',ex:'cat' },{ syl:'ke',ipa:'kiː',ex:'key' },{ syl:'ki',ipa:'kɪ',ex:'kit' },{ syl:'ko',ipa:'koʊ',ex:'ko' },{ syl:'ku',ipa:'kuː',ex:'koo' },
    { syl:'kn',ipa:'n',ex:'know' },
  ],
  // Remaining consonants
  b: [
    { syl:'ba',ipa:'bæ',ex:'bat' },{ syl:'be',ipa:'biː',ex:'be' },{ syl:'bi',ipa:'bɪ',ex:'bit' },{ syl:'bo',ipa:'boʊ',ex:'bow' },{ syl:'bu',ipa:'bʌ',ex:'bus' },
    { syl:'bl',ipa:'bl',ex:'blue' },{ syl:'br',ipa:'br',ex:'brown' },
  ],
  d: [
    { syl:'da',ipa:'dæ',ex:'dad' },{ syl:'de',ipa:'diː',ex:'deep' },{ syl:'di',ipa:'dɪ',ex:'dig' },{ syl:'do',ipa:'duː',ex:'do' },{ syl:'du',ipa:'dʌ',ex:'duck' },
    { syl:'dr',ipa:'dr',ex:'drop' },{ syl:'dge',ipa:'dʒ',ex:'bridge' },
  ],
  f: [
    { syl:'fa',ipa:'fæ',ex:'fat' },{ syl:'fe',ipa:'fiː',ex:'fee' },{ syl:'fi',ipa:'fɪ',ex:'fit' },{ syl:'fo',ipa:'foʊ',ex:'foe' },{ syl:'fu',ipa:'fjuː',ex:'few' },
    { syl:'fl',ipa:'fl',ex:'fly' },{ syl:'fr',ipa:'fr',ex:'free' },{ syl:'ff',ipa:'f',ex:'off' },
  ],
  h: [
    { syl:'ha',ipa:'hæ',ex:'hat' },{ syl:'he',ipa:'hiː',ex:'he' },{ syl:'hi',ipa:'haɪ',ex:'hi' },{ syl:'ho',ipa:'hoʊ',ex:'home' },{ syl:'hu',ipa:'hjuː',ex:'hue' },
  ],
  j: [
    { syl:'ja',ipa:'dʒæ',ex:'jam' },{ syl:'je',ipa:'dʒɛ',ex:'jet' },{ syl:'ji',ipa:'dʒɪ',ex:'jig' },{ syl:'jo',ipa:'dʒoʊ',ex:'joke' },{ syl:'ju',ipa:'dʒuː',ex:'June' },
  ],
  l: [
    { syl:'la',ipa:'læ',ex:'lap' },{ syl:'le',ipa:'liː',ex:'lee' },{ syl:'li',ipa:'lɪ',ex:'lip' },{ syl:'lo',ipa:'loʊ',ex:'low' },{ syl:'lu',ipa:'luː',ex:'loo' },
    { syl:'ll',ipa:'l',ex:'ball' },
  ],
  m: [
    { syl:'ma',ipa:'mæ',ex:'map' },{ syl:'me',ipa:'miː',ex:'me' },{ syl:'mi',ipa:'mɪ',ex:'mix' },{ syl:'mo',ipa:'moʊ',ex:'mow' },{ syl:'mu',ipa:'mjuː',ex:'muse' },
    { syl:'mm',ipa:'m',ex:'summer' },
  ],
  n: [
    { syl:'na',ipa:'næ',ex:'nap' },{ syl:'ne',ipa:'niː',ex:'knee' },{ syl:'ni',ipa:'nɪ',ex:'nit' },{ syl:'no',ipa:'noʊ',ex:'no' },{ syl:'nu',ipa:'njuː',ex:'new' },
    { syl:'ng',ipa:'ŋ',ex:'sing' },{ syl:'nn',ipa:'n',ex:'dinner' },
  ],
  q: [
    { syl:'qua',ipa:'kwɑ',ex:'quad' },{ syl:'que',ipa:'kwɛ',ex:'quest' },{ syl:'qui',ipa:'kwɪ',ex:'quick' },
  ],
  r: [
    { syl:'ra',ipa:'ræ',ex:'rat' },{ syl:'re',ipa:'riː',ex:'read' },{ syl:'ri',ipa:'raɪ',ex:'rye' },{ syl:'ro',ipa:'roʊ',ex:'row' },{ syl:'ru',ipa:'ruː',ex:'rue' },
    { syl:'rr',ipa:'r',ex:'sorry' },
  ],
  v: [
    { syl:'va',ipa:'væ',ex:'van' },{ syl:'ve',ipa:'viː',ex:'vee' },{ syl:'vi',ipa:'vaɪ',ex:'vie' },{ syl:'vo',ipa:'voʊ',ex:'vote' },{ syl:'vu',ipa:'vjuː',ex:'view' },
  ],
  x: [
    { syl:'xa',ipa:'zæ',ex:'xan' },{ syl:'xe',ipa:'ziː',ex:'xerox' },{ syl:'xi',ipa:'zaɪ',ex:'xi' },
  ],
  y: [
    { syl:'ya',ipa:'jæ',ex:'yak' },{ syl:'ye',ipa:'jɛ',ex:'yes' },{ syl:'yi',ipa:'jɪ',ex:'yin' },{ syl:'yo',ipa:'joʊ',ex:'yo' },{ syl:'yu',ipa:'juː',ex:'you' },
  ],
  z: [
    { syl:'za',ipa:'zæ',ex:'zap' },{ syl:'ze',ipa:'ziː',ex:'zee' },{ syl:'zi',ipa:'zɪ',ex:'zip' },{ syl:'zo',ipa:'zoʊ',ex:'zone' },{ syl:'zu',ipa:'zuː',ex:'zoo' },
    { syl:'zz',ipa:'z',ex:'buzz' },
  ],
  // Common word endings (accessible via dedicated keys or long-press)
  '_endings': [
    // Verb endings
    { syl:'ing',ipa:'ɪŋ',ex:'running' },{ syl:'ed',ipa:'d',ex:'played' },{ syl:'es',ipa:'ɪz',ex:'goes' },{ syl:'s',ipa:'z',ex:'runs' },
    // Comparison
    { syl:'er',ipa:'ər',ex:'faster' },{ syl:'est',ipa:'ɪst',ex:'fastest' },{ syl:'ier',ipa:'iər',ex:'happier' },{ syl:'iest',ipa:'iɪst',ex:'happiest' },
    // Adverb/Adjective
    { syl:'ly',ipa:'li',ex:'quickly' },{ syl:'ful',ipa:'fʊl',ex:'beautiful' },{ syl:'less',ipa:'ləs',ex:'endless' },
    { syl:'ous',ipa:'əs',ex:'famous' },{ syl:'ious',ipa:'iəs',ex:'serious' },{ syl:'eous',ipa:'iəs',ex:'gorgeous' },
    { syl:'al',ipa:'əl',ex:'musical' },{ syl:'ial',ipa:'iəl',ex:'special' },{ syl:'ive',ipa:'ɪv',ex:'active' },
    // Noun endings  
    { syl:'ness',ipa:'nəs',ex:'happiness' },{ syl:'ment',ipa:'mənt',ex:'moment' },{ syl:'ity',ipa:'ɪti',ex:'city' },
    { syl:'tion',ipa:'ʃən',ex:'nation' },{ syl:'sion',ipa:'ʒən',ex:'vision' },{ syl:'ation',ipa:'eɪʃən',ex:'creation' },
    { syl:'able',ipa:'əbəl',ex:'lovable' },{ syl:'ible',ipa:'ɪbəl',ex:'visible' },
    // Plural patterns
    { syl:'ies',ipa:'iz',ex:'babies' },{ syl:'ves',ipa:'vz',ex:'knives' },{ syl:'es',ipa:'ɪz',ex:'boxes' },
    // Common letter combos
    { syl:'th',ipa:'θ',ex:'bath' },{ syl:'gh',ipa:'f',ex:'laugh' },{ syl:'ght',ipa:'t',ex:'night' },{ syl:'ough',ipa:'ʌf',ex:'enough' },
    { syl:'ey',ipa:'i',ex:'monkey' },{ syl:'ck',ipa:'k',ex:'back' },{ syl:'tch',ipa:'tʃ',ex:'catch' },{ syl:'dge',ipa:'dʒ',ex:'bridge' },
    { syl:'ph',ipa:'f',ex:'phone' },{ syl:'wh',ipa:'w',ex:'what' },{ syl:'wr',ipa:'r',ex:'write' },{ syl:'kn',ipa:'n',ex:'know' },
    // Double letters
    { syl:'ss',ipa:'s',ex:'miss' },{ syl:'ll',ipa:'l',ex:'ball' },{ syl:'ff',ipa:'f',ex:'off' },{ syl:'zz',ipa:'z',ex:'buzz' },
    { syl:'tt',ipa:'t',ex:'butter' },{ syl:'pp',ipa:'p',ex:'happy' },{ syl:'mm',ipa:'m',ex:'summer' },{ syl:'nn',ipa:'n',ex:'dinner' },
    // Contractions
    { syl:"'s",ipa:'z',ex:"dog's" },{ syl:"n't",ipa:'nt',ex:"don't" },{ syl:"'ve",ipa:'v',ex:"I've" },{ syl:"'re",ipa:'r',ex:"you're" },
    { syl:"'ll",ipa:'l',ex:"I'll" },{ syl:"'d",ipa:'d',ex:"I'd" },{ syl:"'m",ipa:'m',ex:"I'm" },
    // Person endings (for MG)
    { syl:'man',ipa:'mæn',ex:'fireman' },{ syl:'woman',ipa:'wʊmən',ex:'firewoman' },{ syl:'person',ipa:'pɜːrsən',ex:'fireperson' },
    { syl:'or',ipa:'ər',ex:'actor' },{ syl:'ress',ipa:'rəs',ex:'actress' },{ syl:'ess',ipa:'əs',ex:'hostess' },
    { syl:'er',ipa:'ər',ex:'waiter' },
  ],
  // MG pronoun pairs (Ivrita-style for English)
  '_mg_pronouns': [
    { syl:'he/she',ipa:'hiː/ʃiː',ex:'pronoun' },{ syl:'him/her',ipa:'hɪm/hɜːr',ex:'object' },{ syl:'his/her',ipa:'hɪz/hɜːr',ex:'possessive' },
    { syl:'his/hers',ipa:'hɪz/hɜːrz',ex:'absolute' },{ syl:'they/em',ipa:'ðeɪ/əm',ex:'neutral' },
    { syl:'s/he',ipa:'ʃiː',ex:'combined' },{ syl:'(s)he',ipa:'ʃiː',ex:'optional' },
  ],
};

// === COMMON ONE-SYLLABLE WORDS (מילות קישור) ===
// Frequently used connector/function words - one keystroke insertion


// ═══════════════════════════════════════════════════════════════════════════════
// PART 16: HE_SYLLABLES_NIKUD & HE_SYLLABLES_PLAIN
// ═══════════════════════════════════════════════════════════════════════════════

const HE_SYLLABLES_NIKUD = {
  // --- CV (Consonant + Vowel) - Open syllables ---
  // Kamatz (-ָ)
  kamatz: ['בָּ','גָּ','דָּ','הָ','וָ','זָ','חָ','טָ','יָ','כָּ','לָ','מָ','נָ','סָ','עָ','פָּ','צָ','קָ','רָ','שָׁ','תָּ'],
  // Patach (-ַ)
  patach: ['בַּ','גַּ','דַּ','הַ','וַ','זַ','חַ','טַ','יַ','כַּ','לַ','מַ','נַ','סַ','עַ','פַּ','צַ','קַ','רַ','שַׁ','תַּ'],
  // Segol (-ֶ)
  segol: ['בֶּ','גֶּ','דֶּ','הֶ','וֶ','זֶ','חֶ','טֶ','יֶ','כֶּ','לֶ','מֶ','נֶ','סֶ','עֶ','פֶּ','צֶ','קֶ','רֶ','שֶׁ','תֶּ'],
  // Tzere (-ֵ)
  tzere: ['בֵּ','גֵּ','דֵּ','הֵ','וֵ','זֵ','חֵ','טֵ','יֵ','כֵּ','לֵ','מֵ','נֵ','סֵ','עֵ','פֵּ','צֵ','קֵ','רֵ','שֵׁ','תֵּ'],
  // Chirik (-ִ)
  chirik: ['בִּ','גִּ','דִּ','הִ','וִ','זִ','חִ','טִ','יִ','כִּ','לִ','מִ','נִ','סִ','עִ','פִּ','צִ','קִ','רִ','שִׁ','תִּ'],
  // Cholam (-ֹ)
  cholam: ['בֹּ','גֹּ','דֹּ','הֹ','וֹ','זֹ','חֹ','טֹ','יֹ','כֹּ','לֹ','מֹ','נֹ','סֹ','עֹ','פֹּ','צֹ','קֹ','רֹ','שֹׁ','תֹּ'],
  // Kubutz (-ֻ)
  kubutz: ['בֻּ','גֻּ','דֻּ','הֻ','וֻ','זֻ','חֻ','טֻ','יֻ','כֻּ','לֻ','מֻ','נֻ','סֻ','עֻ','פֻּ','צֻ','קֻ','רֻ','שֻׁ','תֻּ'],
  // Shuruk (-וּ)
  shuruk: ['בּוּ','גּוּ','דּוּ','הוּ','זוּ','חוּ','טוּ','יוּ','כּוּ','לוּ','מוּ','נוּ','סוּ','עוּ','פּוּ','צוּ','קוּ','רוּ','שׁוּ','תּוּ'],
  // Shva (-ְ)
  shva: ['בְּ','גְּ','דְּ','הְ','וְ','זְ','חְ','טְ','יְ','כְּ','לְ','מְ','נְ','סְ','עְ','פְּ','צְ','קְ','רְ','שְׁ','תְּ'],
  
  // --- Common endings (סיומות נפוצות) ---
  endings_m: ['ִים','ִין','ָן','וֹן','ַיִם'],      // Masculine plural
  endings_f: ['וֹת','ִית','ָה','ֶת','ַת'],          // Feminine
  endings_verb: ['תִּי','תָּ','תְּ','נוּ','תֶּם','תֶּן'], // Past tense
  endings_poss: ['ִי','ְךָ','ֵךְ','וֹ','ָהּ','ֵנוּ','ְכֶם','ְכֶן','ָם','ָן'], // Possessive
};

// === HEBREW SYLLABLES - WITHOUT NIKUD (לא מנוקד) ===
const HE_SYLLABLES_PLAIN = {
  // Common 2-letter combinations (צירופים נפוצים)
  ba: ['בא','בה','בו','בי','בע','בר','בת'],
  ga: ['גא','גב','גד','גז','גל','גם','גן','גר'],
  da: ['דא','דב','דג','דם','דן','דר','דש','דת'],
  ha: ['הא','הב','הד','הז','הי','הם','הן','הר','הש'],
  va: ['וא','וה','וו','וי','ול','ום','ון'],
  za: ['זא','זב','זה','זו','זי','זך','זל','זם','זן','זר'],
  kha: ['חא','חב','חד','חז','חי','חל','חם','חן','חר','חש','חת'],
  ta: ['טא','טב','טה','טו','טי','טל','טם','טן','טר'],
  ya: ['יא','יב','יד','יה','יו','יז','יח','יט','יך','יל','ים','ין','יע','יף','יץ','יק','יר','יש','ית'],
  ka: ['כא','כב','כה','כו','כי','כך','כל','כם','כן','כף','כר','כש','כת'],
  la: ['לא','לב','לה','לו','לי','לך','לל','לם','לן','לע','לף','לץ','לק','לר','לש','לת'],
  ma: ['מא','מב','מד','מה','מו','מז','מח','מי','מך','מל','מם','מן','מס','מע','מף','מץ','מק','מר','מש','מת'],
  na: ['נא','נב','נג','נד','נה','נו','נז','נח','ני','נך','נל','נם','נן','נס','נע','נף','נץ','נק','נר','נש','נת'],
  sa: ['סא','סב','סג','סד','סה','סו','סח','סי','סך','סל','סם','סן','סע','סף','סק','סר','סת'],
  aa: ['עא','עב','עד','עה','עו','עז','עי','על','עם','ען','עץ','עק','ער','עש','עת'],
  pa: ['פא','פה','פו','פי','פך','פל','פן','פץ','פר','פש','פת'],
  tza: ['צא','צב','צד','צה','צו','צי','צל','צם','צן','צר','צת'],
  qa: ['קא','קב','קד','קה','קו','קח','קי','קל','קם','קן','קץ','קר','קש','קת'],
  ra: ['רא','רב','רג','רד','רה','רו','רז','רח','רי','רך','רם','רן','רע','רף','רץ','רק','רש','רת'],
  sha: ['שא','שב','שג','שד','שה','שו','שז','שח','שי','שך','של','שם','שן','שע','שף','שק','שר','שת'],
  tha: ['תא','תב','תג','תד','תה','תו','תז','תח','תי','תך','תל','תם','תן','תע','תף','תק','תר','תש'],
  
  // Common word patterns (תבניות מילים נפוצות)
  patterns: {
    // CVC patterns
    cvc: ['בית','יום','לב','עם','שם','גם','כן','אם','כל','מה','זה','לא','כי','אל','על','אך'],
    // CVCC patterns  
    cvcc: ['ילד','ספר','דבר','מלך','עבד','קשר','חבר','סדר'],
    // CVCV patterns
    cvcv: ['מים','חיים','בוקר','ערב','לילה','יופי'],
  },
  
  // Common endings without nikud
  endings: {
    m_pl: ['ים','ין'],           // Masculine plural
    f_pl: ['ות'],                // Feminine plural
    f_sg: ['ה','ת','ית'],        // Feminine singular
    poss: ['י','ך','ו','ה','נו','כם','כן','ם','ן'], // Possessive
    verb: ['תי','ת','נו','תם','תן'], // Past tense
  },
};

// === ENGLISH SYLLABLES ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 17: EN_SYLLABLES
// ═══════════════════════════════════════════════════════════════════════════════

const EN_SYLLABLES = {
  // --- Vowel sounds (by IPA) ---
  'iː': ['ee','ea','ie','ei','ey','e_e','i_e'],  // see, eat, field, receive, key, theme, machine
  'ɪ': ['i','y','e','ui','u'],                   // sit, gym, pretty, built, busy
  'eɪ': ['a_e','ai','ay','ei','ey','ea'],        // make, rain, day, vein, they, great
  'ɛ': ['e','ea','ai','ie','a'],                 // bed, bread, said, friend, any
  'æ': ['a'],                                     // cat, bad, man
  'ɑː': ['a','ar','al','au'],                    // father, car, calm, aunt
  'ɒ': ['o','a','au','aw'],                      // hot, want, because, saw
  'ɔː': ['or','aw','au','al','our','oor'],       // for, saw, taught, all, four, door
  'oʊ': ['o','oa','ow','o_e','oe'],              // go, boat, know, home, toe
  'ʊ': ['oo','u','ou','o'],                      // book, put, could, wolf
  'uː': ['oo','u','ue','ew','o','ou'],           // moon, rule, blue, new, do, soup
  'ʌ': ['u','o','ou','oo'],                      // cup, son, touch, blood
  'ɜː': ['er','ir','ur','ear','or'],             // her, bird, turn, learn, word
  'ə': ['a','e','i','o','u'],                    // about, silent, pencil, lemon, circus
  
  // --- Diphthongs ---
  'aɪ': ['i_e','igh','y','ie','uy','eye'],       // time, high, my, tie, buy, eye
  'aʊ': ['ou','ow'],                              // out, now
  'ɔɪ': ['oi','oy'],                              // oil, boy
  
  // --- Common consonant clusters ---
  initial: ['bl','br','cl','cr','dr','fl','fr','gl','gr','pl','pr','sc','sk','sl','sm','sn','sp','st','str','sw','tr','tw','wr','shr','spl','spr','scr','thr'],
  final: ['ck','ct','ft','ld','lf','lk','lm','ln','lp','lt','mp','nd','ng','nk','nt','pt','rd','rk','rl','rm','rn','rp','rt','sk','sp','st','xt'],
  
  // --- Common endings ---
  endings: {
    verb: ['ing','ed','es','s'],
    noun: ['tion','sion','ment','ness','er','or','ist','ism','ity','ty'],
    adj: ['ful','less','ous','ive','al','ic','ly'],
    plural: ['s','es','ies','ves'],
    compare: ['er','est','ier','iest'],
  },
  
  // --- MG endings (Multi-Gender) ---
  mg: {
    'he/she': ['he','she'],
    'him/her': ['him','her'],
    'his/her': ['his','her'],
    'man/woman': ['man','woman'],
    '-er/-ess': ['er','ess'],
    '-or/-rix': ['or','rix'],
    '-man/-woman': ['man','woman'],
  },
};

// === IPA RHYME ENDINGS - The Bridge ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 18: IPA_RHYME_ENDINGS
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_RHYME_ENDINGS = {
  // === VOWELS ONLY ===
  'i':  { ipa: 'i',  he_n: 'לִי, מִי, כִּי', he_p: 'לי, מי, כי', en: 'be, see, key, free' },
  'e':  { ipa: 'e',  he_n: 'בֵּית, שֵׁם', he_p: 'בית, שם', en: 'say, day, way' },
  'a':  { ipa: 'a',  he_n: 'מַה, פֹּה', he_p: 'מה, פה', en: 'ma, pa, spa' },
  'ɑ':  { ipa: 'ɑ',  he_n: 'מָה, בָּא', he_p: 'מה, בא', en: 'car, far, star' },
  'o':  { ipa: 'o',  he_n: 'לֹא, בּוֹא', he_p: 'לא, בוא', en: 'go, know, show' },
  'u':  { ipa: 'u',  he_n: 'הוּא, לוּ', he_p: 'הוא, לו', en: 'too, blue, true' },
  
  // === CV (Consonant + Vowel) ===
  'li': { ipa: 'li', he_n: 'לִי, עָלַי', he_p: 'לי, עלי', en: 'lee, me, be' },
  'mi': { ipa: 'mi', he_n: 'מִי, כְּמוֹ', he_p: 'מי', en: 'me, sea' },
  'ki': { ipa: 'ki', he_n: 'כִּי, לָכֵן', he_p: 'כי', en: 'key, ski' },
  'vi': { ipa: 'vi', he_n: 'בִּי', he_p: 'בי', en: 'we, three' },
  'ra': { ipa: 'ra', he_n: 'רָא', he_p: 'רא', en: 'rah' },
  'la': { ipa: 'la', he_n: 'לָא', he_p: 'לא', en: 'la' },
  'ma': { ipa: 'ma', he_n: 'מָא', he_p: 'מא', en: 'ma' },
  'na': { ipa: 'na', he_n: 'נָא', he_p: 'נא', en: 'nah' },
  'ta': { ipa: 'ta', he_n: 'תָּא', he_p: 'תא', en: 'ta' },
  'da': { ipa: 'da', he_n: 'דָּא', he_p: 'דא', en: 'da' },
  'sha': { ipa: 'ʃa', he_n: 'שָׁא', he_p: 'שא', en: 'shah' },
  
  // === CVC (Consonant + Vowel + Consonant) ===
  // -am
  'am':  { ipa: 'am',  he_n: 'עַם, שָׁם, גַּם, יָם', he_p: 'עם, שם, גם, ים', en: 'am, ham, jam, slam' },
  'im':  { ipa: 'im',  he_n: 'מַיִם, יָמִים, שָׁמַיִם', he_p: 'מים, ימים, שמים', en: 'him, swim, dim, brim' },
  'om':  { ipa: 'om',  he_n: 'יוֹם, שָׁלוֹם, חֲלוֹם', he_p: 'יום, שלום, חלום', en: 'home, dome, chrome' },
  'um':  { ipa: 'um',  he_n: 'קוּם, שׁוּם', he_p: 'קום, שום', en: 'come, some, from' },
  
  // -an/-en/-in/-on/-un
  'an':  { ipa: 'an',  he_n: 'כָּאן, לָן, זָן', he_p: 'כאן', en: 'man, can, plan, ran' },
  'en':  { ipa: 'en',  he_n: 'הֵן, כֵּן, בֵּן', he_p: 'הן, כן, בן', en: 'men, pen, ten, when' },
  'in':  { ipa: 'in',  he_n: 'בֵּין, אֵין, דִּין', he_p: 'בין, אין, דין', en: 'in, win, begin, skin' },
  'on':  { ipa: 'on',  he_n: 'פֹּה, כֹּה', he_p: 'פה, כה', en: 'on, gone, dawn' },
  'un':  { ipa: 'un',  he_n: 'אָסוֹן', he_p: 'אסון', en: 'run, sun, fun, done' },
  
  // -av/-ev/-ov
  'av':  { ipa: 'av',  he_n: 'אָב, רָב, קָרוֹב', he_p: 'אב, רב, קרוב', en: 'love (approx)' },
  'ev':  { ipa: 'ev',  he_n: 'לֵב, חֵלֶב', he_p: 'לב, חלב', en: 'rev' },
  'ov':  { ipa: 'ov',  he_n: 'טוֹב, אוֹהֵב', he_p: 'טוב, אוהב', en: 'stove, drove' },
  
  // -al/-el/-ol
  'al':  { ipa: 'al',  he_n: 'כָּל, גָּדוֹל, מָזָל', he_p: 'כל, גדול, מזל', en: 'all, call, ball, fall' },
  'el':  { ipa: 'el',  he_n: 'אֵל, שֶׁל', he_p: 'אל, של', en: 'bell, tell, well, spell' },
  'ol':  { ipa: 'ol',  he_n: 'קוֹל, גּוֹל', he_p: 'קול, גול', en: 'pole, soul, role' },
  
  // -ar/-er/-or/-ir/-ur
  'ar':  { ipa: 'ar',  he_n: 'אוֹר, דָּבָר, נָהָר', he_p: 'אור, דבר, נהר', en: 'are, car, star, far' },
  'er':  { ipa: 'er',  he_n: 'סֵפֶר, עֵבֶר', he_p: 'ספר, עבר', en: 'her, were, blur' },
  'or':  { ipa: 'or',  he_n: 'מוֹר, אוֹר', he_p: 'מור, אור', en: 'or, for, more, door' },
  'ir':  { ipa: 'ir',  he_n: 'עִיר, שִׁיר', he_p: 'עיר, שיר', en: 'ear, hear, clear' },
  'ur':  { ipa: 'ur',  he_n: 'אוּר, נוּר', he_p: 'אור, נור', en: 'pure, sure, tour' },
  
  // -at/-et/-it/-ot/-ut
  'at':  { ipa: 'at',  he_n: 'אַתְּ, בַּת, מַת', he_p: 'את, בת, מת', en: 'at, cat, hat, that' },
  'et':  { ipa: 'et',  he_n: 'אֶת, בֵּית', he_p: 'את, בית', en: 'get, let, set, met' },
  'it':  { ipa: 'it',  he_n: 'בַּיִת, זַיִת', he_p: 'בית, זית', en: 'it, bit, sit, hit' },
  'ot':  { ipa: 'ot',  he_n: 'אוֹת, מוֹת', he_p: 'אות, מות', en: 'bought, thought' },
  'ut':  { ipa: 'ut',  he_n: 'אוּת', he_p: 'אות', en: 'but, cut, nut, hut' },
  
  // -ash/-esh/-ish/-osh
  'ash': { ipa: 'aʃ', he_n: 'אַשׁ, רַעַשׁ', he_p: 'אש, רעש', en: 'ash, cash, crash' },
  'esh': { ipa: 'eʃ', he_n: 'אֵשׁ, חֹדֶשׁ', he_p: 'אש, חודש', en: 'fresh, mesh' },
  'ish': { ipa: 'iʃ', he_n: 'אִישׁ, גִּישׁ', he_p: 'איש', en: 'fish, wish, dish' },
  'osh': { ipa: 'oʃ', he_n: 'רֹאשׁ, חֹשׁ', he_p: 'ראש, חוש', en: 'gosh, wash (BrE)' },
  
  // -akh/-ekh
  'ax':  { ipa: 'ax', he_n: 'אַךְ, רַק', he_p: 'אך, רק', en: 'Bach, loch' },
  'ex':  { ipa: 'ex', he_n: 'לֵךְ, דֶּרֶךְ', he_p: 'לך, דרך', en: 'tech' },
  
  // === DIPHTHONGS ===
  'aɪ':  { ipa: 'aɪ', he_n: 'חַי, דַּי', he_p: 'חי, די', en: 'my, why, sky, fly, high' },
  'eɪ':  { ipa: 'eɪ', he_n: 'יֵשׁ', he_p: 'יש', en: 'day, say, way, play, stay' },
  'oʊ':  { ipa: 'oʊ', he_n: 'אוֹ', he_p: 'או', en: 'go, no, so, know, show' },
  'aʊ':  { ipa: 'aʊ', he_n: 'אָו', he_p: 'או', en: 'now, how, cow, wow' },
  'ɔɪ':  { ipa: 'ɔɪ', he_n: 'גּוֹי, אוֹי', he_p: 'גוי, אוי', en: 'boy, joy, toy, enjoy' },
  
  // === COMMON SUFFIXES ===
  // Hebrew plural/gender
  'im':  { ipa: 'im',  he_n: 'יְלָדִים, סְפָרִים', he_p: 'ילדים, ספרים', en: 'him, dim, swim' },
  'ot':  { ipa: 'ot',  he_n: 'יְלָדוֹת, סִפְרוֹת', he_p: 'ילדות, ספרות', en: 'ought, bought' },
  'it':  { ipa: 'it',  he_n: 'יַלְדִּית, עִבְרִית', he_p: 'ילדית, עברית', en: 'it, bit, sit' },
  'a':   { ipa: 'a',   he_n: 'יַלְדָּה, סִפְרָה', he_p: 'ילדה, ספרה', en: 'ma, pa, spa' },
  
  // English suffixes
  'ɪŋ':  { ipa: 'ɪŋ',  he_n: '—', he_p: '—', en: '-ing: running, swimming' },
  'ʃən': { ipa: 'ʃən', he_n: '—', he_p: '—', en: '-tion: nation, station' },
  'mənt':{ ipa: 'mənt',he_n: '—', he_p: '—', en: '-ment: moment, treatment' },
  'nəs': { ipa: 'nəs', he_n: '—', he_p: '—', en: '-ness: happiness, darkness' },
  'li':  { ipa: 'li',  he_n: 'לִי', he_p: 'לי', en: '-ly: quickly, slowly' },
  'fəl': { ipa: 'fəl', he_n: '—', he_p: '—', en: '-ful: beautiful, wonderful' },
  'ləs': { ipa: 'ləs', he_n: '—', he_p: '—', en: '-less: endless, careless' },
};

// Backward compatibility alias

// ═══════════════════════════════════════════════════════════════════════════════
// PART 19: IPA_UNIKEYS (COMPREHENSIVE PHONETIC DATA)
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_UNIKEYS = {
  // ═══════════════════════════════════════════════════════════════════════
  // VOWELS - תנועות
  // ═══════════════════════════════════════════════════════════════════════
  
  // Front vowels
  'i': { ipa:'i', type:'vowel', name:'close front',
    he:'ִי', he_name:'חִירִיק', he_plain:'י',
    en:['ee','ea','ie','i','y'], en_ex:['see','eat','field','machine','happy'],
  },
  'ɪ': { ipa:'ɪ', type:'vowel', name:'near-close front',
    he:'ִ', he_name:'חִירִיק קצר', he_plain:'',
    en:['i','y','e'], en_ex:['sit','gym','pretty'],
  },
  'e': { ipa:'e', type:'vowel', name:'close-mid front',
    he:'ֵ', he_name:'צֵירֵי', he_plain:'',
    en:['a_e','ay','ai','ei'], en_ex:['make','day','rain','vein'],
  },
  'ɛ': { ipa:'ɛ', type:'vowel', name:'open-mid front',
    he:'ֶ', he_name:'סֶגוֹל', he_plain:'',
    en:['e','ea','ai'], en_ex:['bed','bread','said'],
  },
  'æ': { ipa:'æ', type:'vowel', name:'near-open front',
    he:'—', he_name:'—', he_plain:'',
    en:['a'], en_ex:['cat','bad','man'],
  },
  
  // Central vowels
  'ə': { ipa:'ə', type:'vowel', name:'schwa',
    he:'ְ', he_name:'שְׁוָא נָע', he_plain:'',
    en:['a','e','i','o','u'], en_ex:['about','silent','pencil','lemon','circus'],
  },
  'ʌ': { ipa:'ʌ', type:'vowel', name:'open-mid back unrounded',
    he:'ַ', he_name:'פַּתַח', he_plain:'',
    en:['u','o','ou'], en_ex:['cup','son','touch'],
  },
  
  // Back vowels
  'u': { ipa:'u', type:'vowel', name:'close back',
    he:'וּ', he_name:'שׁוּרוּק', he_plain:'ו',
    en:['oo','u','ue','ew'], en_ex:['moon','rule','blue','new'],
  },
  'ʊ': { ipa:'ʊ', type:'vowel', name:'near-close back',
    he:'ֻ', he_name:'קוּבּוּץ', he_plain:'',
    en:['oo','u','ou'], en_ex:['book','put','could'],
  },
  'o': { ipa:'o', type:'vowel', name:'close-mid back',
    he:'וֹ', he_name:'חוֹלָם', he_plain:'ו',
    en:['o','oa','ow','o_e'], en_ex:['go','boat','know','home'],
  },
  'ɔ': { ipa:'ɔ', type:'vowel', name:'open-mid back',
    he:'ָ', he_name:'קָמָץ קָטָן', he_plain:'',
    en:['aw','au','or','al'], en_ex:['saw','taught','for','all'],
  },
  'ɑ': { ipa:'ɑ', type:'vowel', name:'open back',
    he:'ָ', he_name:'קָמָץ', he_plain:'',
    en:['a','ar'], en_ex:['father','car'],
  },
  'a': { ipa:'a', type:'vowel', name:'open front',
    he:'ַ', he_name:'פַּתַח', he_plain:'',
    en:['a'], en_ex:['cat'],
  },

  // ═══════════════════════════════════════════════════════════════════════
  // DIPHTHONGS - דיפתונגים
  // ═══════════════════════════════════════════════════════════════════════
  
  'aɪ': { ipa:'aɪ', type:'diphthong', name:'PRICE',
    he:'ַי', he_name:'פַּתַח יוֹד', he_plain:'י',
    en:['i_e','igh','y','ie'], en_ex:['time','high','my','tie'],
    rhymes:{ he:['חַי','דַּי','שַׁי'], he_p:['חי','די','שי'], en:['my','sky','fly','why'] },
  },
  'aʊ': { ipa:'aʊ', type:'diphthong', name:'MOUTH',
    he:'ַו', he_name:'פַּתַח וָו', he_plain:'או',
    en:['ou','ow'], en_ex:['out','now'],
    rhymes:{ he:['אָו'], he_p:['או'], en:['now','how','cow','wow'] },
  },
  'ɔɪ': { ipa:'ɔɪ', type:'diphthong', name:'CHOICE',
    he:'וֹי', he_name:'חוֹלָם יוֹד', he_plain:'וי',
    en:['oi','oy'], en_ex:['oil','boy'],
    rhymes:{ he:['גּוֹי','אוֹי'], he_p:['גוי','אוי'], en:['boy','joy','toy'] },
  },
  'eɪ': { ipa:'eɪ', type:'diphthong', name:'FACE',
    he:'ֵי', he_name:'צֵירֵי יוֹד', he_plain:'י',
    en:['a_e','ai','ay','ei'], en_ex:['make','rain','day','vein'],
    rhymes:{ he:['יֵשׁ','בֵּית'], he_p:['יש','בית'], en:['day','say','way','play'] },
  },
  'oʊ': { ipa:'oʊ', type:'diphthong', name:'GOAT',
    he:'וֹ', he_name:'חוֹלָם', he_plain:'ו',
    en:['o','oa','ow','o_e'], en_ex:['go','boat','know','home'],
    rhymes:{ he:['לֹא','בּוֹא'], he_p:['לא','בוא'], en:['go','no','so','know'] },
  },

  // ═══════════════════════════════════════════════════════════════════════
  // CONSONANTS - עיצורים
  // ═══════════════════════════════════════════════════════════════════════
  
  // Stops
  'p': { ipa:'p', type:'consonant', name:'voiceless bilabial stop',
    he:'פּ', he_name:'פֵּא דגושה', he_plain:'פ', en:['p'], en_ex:['pen'] },
  'b': { ipa:'b', type:'consonant', name:'voiced bilabial stop',
    he:'בּ', he_name:'בֵּית דגושה', he_plain:'ב', en:['b'], en_ex:['bat'] },
  't': { ipa:'t', type:'consonant', name:'voiceless alveolar stop',
    he:'ת', he_name:'תָּו/טֵית', he_plain:'ת', en:['t'], en_ex:['top'] },
  'd': { ipa:'d', type:'consonant', name:'voiced alveolar stop',
    he:'ד', he_name:'דָּלֶת', he_plain:'ד', en:['d'], en_ex:['dog'] },
  'k': { ipa:'k', type:'consonant', name:'voiceless velar stop',
    he:'כּ', he_name:'כַּף דגושה/קוֹף', he_plain:'כ', en:['k','c','ck'], en_ex:['cat','king','back'] },
  'g': { ipa:'g', type:'consonant', name:'voiced velar stop',
    he:'ג', he_name:'גִּימֶל', he_plain:'ג', en:['g'], en_ex:['go'] },
  'ʔ': { ipa:'ʔ', type:'consonant', name:'glottal stop',
    he:'א', he_name:'אָלֶף/עַיִן', he_plain:'א', en:['—'], en_ex:['uh-oh'] },
  
  // Fricatives
  'f': { ipa:'f', type:'consonant', name:'voiceless labiodental',
    he:'פ', he_name:'פֵא רפויה', he_plain:'פ', en:['f','ph'], en_ex:['fan','phone'] },
  'v': { ipa:'v', type:'consonant', name:'voiced labiodental',
    he:'ב', he_name:'בֵית רפויה/וָו', he_plain:'ב', en:['v'], en_ex:['van'] },
  'θ': { ipa:'θ', type:'consonant', name:'voiceless dental',
    he:'—', he_name:'—', he_plain:'', en:['th'], en_ex:['thin'] },
  'ð': { ipa:'ð', type:'consonant', name:'voiced dental',
    he:'—', he_name:'—', he_plain:'', en:['th'], en_ex:['the'] },
  's': { ipa:'s', type:'consonant', name:'voiceless alveolar fricative',
    he:'ס', he_name:'סָמֶך/שִׂין', he_plain:'ס', en:['s','c','ss'], en_ex:['sun','city','miss'] },
  'z': { ipa:'z', type:'consonant', name:'voiced alveolar fricative',
    he:'ז', he_name:'זַיִן', he_plain:'ז', en:['z','s'], en_ex:['zoo','is'] },
  'ʃ': { ipa:'ʃ', type:'consonant', name:'voiceless postalveolar',
    he:'שׁ', he_name:'שִׁין', he_plain:'ש', en:['sh'], en_ex:['she'] },
  'ʒ': { ipa:'ʒ', type:'consonant', name:'voiced postalveolar',
    he:'ז׳', he_name:'זַיִן גרש', he_plain:'ז', en:['si','su'], en_ex:['vision','measure'] },
  'x': { ipa:'x', type:'consonant', name:'voiceless velar fricative',
    he:'כ', he_name:'כַף רפויה', he_plain:'כ', en:['ch'], en_ex:['loch'] },
  'ħ': { ipa:'ħ', type:'consonant', name:'voiceless pharyngeal',
    he:'ח', he_name:'חֵית', he_plain:'ח', en:['—'], en_ex:['—'] },
  'ʕ': { ipa:'ʕ', type:'consonant', name:'voiced pharyngeal',
    he:'ע', he_name:'עַיִן', he_plain:'ע', en:['—'], en_ex:['—'] },
  'h': { ipa:'h', type:'consonant', name:'voiceless glottal',
    he:'ה', he_name:'הֵא', he_plain:'ה', en:['h'], en_ex:['hat'] },
  
  // Affricates
  'ts': { ipa:'ts', type:'consonant', name:'voiceless alveolar affricate',
    he:'צ', he_name:'צָדִי', he_plain:'צ', en:['ts','tz'], en_ex:['cats','pizza'] },
  'tʃ': { ipa:'tʃ', type:'consonant', name:'voiceless postalveolar affricate',
    he:'צ׳', he_name:'צָדִי גרש', he_plain:'צ', en:['ch','tch'], en_ex:['chat','catch'] },
  'dʒ': { ipa:'dʒ', type:'consonant', name:'voiced postalveolar affricate',
    he:'ג׳', he_name:'גִּימֶל גרש', he_plain:'ג', en:['j','g','dge'], en_ex:['jam','age','edge'] },
  
  // Nasals
  'm': { ipa:'m', type:'consonant', name:'bilabial nasal',
    he:'מ', he_name:'מֵם', he_plain:'מ', en:['m'], en_ex:['man'] },
  'n': { ipa:'n', type:'consonant', name:'alveolar nasal',
    he:'נ', he_name:'נוּן', he_plain:'נ', en:['n'], en_ex:['no'] },
  'ŋ': { ipa:'ŋ', type:'consonant', name:'velar nasal',
    he:'—', he_name:'—', he_plain:'', en:['ng','n'], en_ex:['sing','think'] },
  
  // Approximants
  'l': { ipa:'l', type:'consonant', name:'alveolar lateral',
    he:'ל', he_name:'לָמֶד', he_plain:'ל', en:['l','ll'], en_ex:['let','bell'] },
  'r': { ipa:'r', type:'consonant', name:'alveolar/uvular',
    he:'ר', he_name:'רֵישׁ', he_plain:'ר', en:['r','rr'], en_ex:['red','carry'] },
  'j': { ipa:'j', type:'consonant', name:'palatal approximant',
    he:'י', he_name:'יוֹד', he_plain:'י', en:['y'], en_ex:['yes'] },
  'w': { ipa:'w', type:'consonant', name:'labial-velar approximant',
    he:'ו', he_name:'וָו', he_plain:'ו', en:['w'], en_ex:['we'] },

  // ═══════════════════════════════════════════════════════════════════════
  // SYLLABLES - הברות CV/CVC
  // ═══════════════════════════════════════════════════════════════════════
  
  // === -am ===
  'am': { ipa:'am', type:'syllable',
    he:['עַם','שָׁם','גַּם','יָם','תָּם'], he_plain:['עם','שם','גם','ים','תם'],
    en:['am','ham','jam','slam','dam'], mg:null },
  'ɑm': { ipa:'ɑm', type:'syllable',
    he:['קָם','שָׁם'], he_plain:['קם','שם'],
    en:['calm','palm','balm'], mg:null },
  
  // === -im ===
  'im': { ipa:'im', type:'syllable',
    he:['מַיִם','יָמִים','חַיִים','שָׁמַיִם'], he_plain:['מים','ימים','חיים','שמים'],
    en:['him','swim','dim','brim'], mg:null },
  
  // === -om ===
  'om': { ipa:'om', type:'syllable',
    he:['יוֹם','שָׁלוֹם','חֲלוֹם'], he_plain:['יום','שלום','חלום'],
    en:['home','dome','chrome','poem'], mg:null },
  
  // === -an ===
  'an': { ipa:'an', type:'syllable',
    he:['כָּאן','זָן','לָן'], he_plain:['כאן','זן'],
    en:['man','can','plan','ran','tan'], mg:{ en:['man/woman'], he:['אִישׁ/אִשָּׁה'] } },
  
  // === -en ===
  'en': { ipa:'en', type:'syllable',
    he:['הֵן','כֵּן','בֵּן'], he_plain:['הן','כן','בן'],
    en:['men','pen','ten','when','then'], mg:{ en:['men/women'], he:['אֲנָשִׁים/נָשִׁים'] } },
  
  // === -in ===
  'in': { ipa:'in', type:'syllable',
    he:['בֵּין','אֵין','דִּין','עַיִן'], he_plain:['בין','אין','דין','עין'],
    en:['in','win','begin','skin','thin'], mg:null },
  
  // === -on ===
  'on': { ipa:'on', type:'syllable',
    he:['אָסוֹן','רִאשׁוֹן','אַחֲרוֹן'], he_plain:['אסון','ראשון','אחרון'],
    en:['on','gone','dawn','drawn'], mg:null },
  
  // === -un ===
  'un': { ipa:'ʌn', type:'syllable',
    he:['—'], he_plain:['—'],
    en:['run','sun','fun','done','won'], mg:null },
  
  // === -av ===
  'av': { ipa:'av', type:'syllable',
    he:['אָב','רָב','קָרוֹב','אוֹהֵב'], he_plain:['אב','רב','קרוב','אוהב'],
    en:['—'], mg:null },
  
  // === -ev ===
  'ev': { ipa:'ev', type:'syllable',
    he:['לֵב','חֵלֶב','זְאֵב'], he_plain:['לב','חלב','זאב'],
    en:['rev'], mg:null },
  
  // === -ov ===
  'ov': { ipa:'ov', type:'syllable',
    he:['טוֹב','אוֹהֵב','כּוֹכָב'], he_plain:['טוב','אוהב','כוכב'],
    en:['stove','drove','wove'], mg:null },
  
  // === -al ===
  'al': { ipa:'al', type:'syllable',
    he:['כָּל','גָּדוֹל','מָזָל'], he_plain:['כל','גדול','מזל'],
    en:['all','call','ball','fall','tall'], mg:null },
  
  // === -el ===
  'el': { ipa:'el', type:'syllable',
    he:['אֵל','שֶׁל','גֶּבֶר'], he_plain:['אל','של','גבר'],
    en:['bell','tell','well','spell','sell'], mg:null },
  
  // === -ol ===
  'ol': { ipa:'ol', type:'syllable',
    he:['קוֹל','גּוֹל'], he_plain:['קול','גול'],
    en:['pole','soul','role','bowl'], mg:null },
  
  // === -ar ===
  'ar': { ipa:'ar', type:'syllable',
    he:['אוֹר','דָּבָר','נָהָר','בָּשָׂר'], he_plain:['אור','דבר','נהר','בשר'],
    en:['are','car','star','far','bar'], mg:null },
  
  // === -er ===
  'er': { ipa:'ɜr', type:'syllable',
    he:['סֵפֶר','עֵבֶר','חֵבֶר'], he_plain:['ספר','עבר','חבר'],
    en:['her','were','blur','stir'], mg:{ en:['him/her'], he:['אוֹתוֹ/אוֹתָהּ'] } },
  
  // === -or ===
  'or': { ipa:'ɔr', type:'syllable',
    he:['מוֹר','אוֹר','דּוֹר'], he_plain:['מור','אור','דור'],
    en:['or','for','more','door','floor'], mg:null },
  
  // === -ir ===
  'ir': { ipa:'ir', type:'syllable',
    he:['עִיר','שִׁיר','אָבִיר'], he_plain:['עיר','שיר','אביר'],
    en:['ear','hear','clear','fear','near'], mg:null },
  
  // === -at ===
  'at': { ipa:'at', type:'syllable',
    he:['אַתְּ','בַּת','מַת','דַּת'], he_plain:['את','בת','מת','דת'],
    en:['at','cat','hat','that','bat'], mg:null },
  
  // === -et ===
  'et': { ipa:'et', type:'syllable',
    he:['אֶת','בֵּת'], he_plain:['את','בת'],
    en:['get','let','set','met','bet'], mg:null },
  
  // === -it ===
  'it': { ipa:'it', type:'syllable',
    he:['בַּיִת','זַיִת'], he_plain:['בית','זית'],
    en:['it','bit','sit','hit','fit'], mg:null },
  
  // === -ot ===
  'ot': { ipa:'ot', type:'syllable',
    he:['אוֹת','מוֹת','דָּת'], he_plain:['אות','מות','דת'],
    en:['bought','thought','taught'], mg:null },
  
  // === -ash ===
  'aʃ': { ipa:'aʃ', type:'syllable',
    he:['אֵשׁ','רַעַשׁ'], he_plain:['אש','רעש'],
    en:['ash','cash','crash','flash','trash'], mg:null },
  
  // === -esh ===
  'eʃ': { ipa:'eʃ', type:'syllable',
    he:['חֹדֶשׁ','רֶגֶשׁ'], he_plain:['חודש','רגש'],
    en:['fresh','mesh'], mg:null },
  
  // === -ish ===
  'iʃ': { ipa:'iʃ', type:'syllable',
    he:['אִישׁ','גִּישׁ'], he_plain:['איש'],
    en:['fish','wish','dish'], mg:null },
  
  // === -ax (כ/ח) ===
  'ax': { ipa:'ax', type:'syllable',
    he:['אַךְ','רַק','אַף'], he_plain:['אך','רק','אף'],
    en:['Bach','loch'], mg:null },
  
  // === -ex (ך) ===
  'ex': { ipa:'ex', type:'syllable',
    he:['לֵךְ','דֶּרֶךְ','מֶלֶךְ'], he_plain:['לך','דרך','מלך'],
    en:['tech','check','deck'], mg:null },

  // ═══════════════════════════════════════════════════════════════════════
  // ENDINGS - סיומות
  // ═══════════════════════════════════════════════════════════════════════
  
  // Hebrew plural
  '-im': { ipa:'im', type:'ending',
    he:'ִים', he_name:'סיומת זכר רבים', he_plain:'ים',
    en:['—'], mg:{ he:['ִים/וֹת'], en:['s (neutral)'] } },
  '-ot': { ipa:'ot', type:'ending',
    he:'וֹת', he_name:'סיומת נקבה רבים', he_plain:'ות',
    en:['—'], mg:{ he:['וֹת/ִים'], en:['s (neutral)'] } },
  '-a': { ipa:'a', type:'ending',
    he:'ָה', he_name:'סיומת נקבה', he_plain:'ה',
    en:['—'], mg:{ he:['ָה/—'], en:['—'] } },
  '-it': { ipa:'it', type:'ending',
    he:'ִית', he_name:'סיומת נקבה תואר', he_plain:'ית',
    en:['—'], mg:null },
  '-an': { ipa:'an', type:'ending',
    he:'ָן', he_name:'סיומת שם פעולה', he_plain:'ן',
    en:['—'], mg:null },
  '-on': { ipa:'on', type:'ending',
    he:'וֹן', he_name:'סיומת הקטנה', he_plain:'ון',
    en:['—'], mg:null },
    
  // Hebrew verb
  '-ti': { ipa:'ti', type:'ending',
    he:'תִּי', he_name:'עבר גוף ראשון', he_plain:'תי',
    en:['—'], mg:null },
  '-ta': { ipa:'ta', type:'ending',
    he:'תָּ', he_name:'עבר גוף שני זכר', he_plain:'ת',
    en:['—'], mg:{ he:['תָּ/תְּ'], en:['—'] } },
  '-t': { ipa:'t', type:'ending',
    he:'תְּ', he_name:'עבר גוף שני נקבה', he_plain:'ת',
    en:['—'], mg:{ he:['תְּ/תָּ'], en:['—'] } },
  '-nu': { ipa:'nu', type:'ending',
    he:'נוּ', he_name:'עבר גוף ראשון רבים', he_plain:'נו',
    en:['—'], mg:null },
    
  // English endings
  '-ing': { ipa:'ɪŋ', type:'ending',
    he:'—', he_plain:'—',
    en:['-ing'], en_ex:['running','swimming','going'], mg:null },
  '-tion': { ipa:'ʃən', type:'ending',
    he:'—', he_plain:'—',
    en:['-tion','-sion'], en_ex:['nation','station','vision'], mg:null },
  '-ment': { ipa:'mənt', type:'ending',
    he:'—', he_plain:'—',
    en:['-ment'], en_ex:['moment','treatment','movement'], mg:null },
  '-ness': { ipa:'nəs', type:'ending',
    he:'—', he_plain:'—',
    en:['-ness'], en_ex:['happiness','darkness','kindness'], mg:null },
  '-ful': { ipa:'fəl', type:'ending',
    he:'—', he_plain:'—',
    en:['-ful'], en_ex:['beautiful','wonderful','careful'], mg:null },
  '-less': { ipa:'ləs', type:'ending',
    he:'—', he_plain:'—',
    en:['-less'], en_ex:['endless','careless','hopeless'], mg:null },
  '-ly': { ipa:'li', type:'ending',
    he:'—', he_plain:'—',
    en:['-ly'], en_ex:['quickly','slowly','happily'], mg:null },
  '-er': { ipa:'ər', type:'ending',
    he:'—', he_plain:'—',
    en:['-er','-or'], en_ex:['teacher','actor','bigger'], 
    mg:{ en:['-er/-ess','-or/-rix'], he:['—'] } },
  '-est': { ipa:'əst', type:'ending',
    he:'—', he_plain:'—',
    en:['-est'], en_ex:['biggest','fastest','best'], mg:null },
  '-ed': { ipa:'d', type:'ending',
    he:'—', he_plain:'—',
    en:['-ed'], en_ex:['played','walked','wanted'], mg:null },
  '-s': { ipa:'s', type:'ending',
    he:'—', he_plain:'—',
    en:['-s','-es'], en_ex:['cats','dogs','boxes'], mg:null },
};

// Helper: Get IPA_UNIKEY by IPA string
function getIpaUnikey(ipa) {
  return IPA_UNIKEYS[ipa] || null;
}

// Helper: Find all IPA_UNIKEYS matching a pattern
function findIpaUnikeys(pattern, options = {}) {
  const { type, hasHe = false, hasEn = false, hasMg = false } = options;
  return Object.values(IPA_UNIKEYS).filter(uk => {
    if (type && uk.type !== type) return false;
    if (hasHe && (!uk.he || uk.he === '—')) return false;
    if (hasEn && (!uk.en || uk.en[0] === '—')) return false;
    if (hasMg && !uk.mg) return false;
    if (pattern) {
      const regex = new RegExp(pattern, 'i');
      return regex.test(uk.ipa) || regex.test(uk.he) || (uk.en && uk.en.some(e => regex.test(e)));
    }
    return true;
  });
}

// Helper: Get Hebrew representation (with/without nikud)
function getIpaHeDisplay(ipa, withNikud = true) {
  const uk = IPA_UNIKEYS[ipa];
  if (!uk) return null;
  
  if (Array.isArray(uk.he)) {
    return withNikud ? uk.he : uk.he_plain;
  }
  return withNikud ? uk.he : uk.he_plain;
}

// Helper: Get English spellings
function getIpaEnSpellings(ipa) {
  const uk = IPA_UNIKEYS[ipa];
  return uk ? uk.en : null;
}


// ═══════════════════════════════════════════════════════════════════════════
// OPTIMIZED HEBREW NIKUD SYSTEM
// ═══════════════════════════════════════════════════════════════════════════
// Instead of storing every letter+nikud combo, we store:
// 1. NIKUD patterns (the vowel marks)
// 2. RULES for combining with any letter
// This reduces data significantly while enabling dynamic generation


// ═══════════════════════════════════════════════════════════════════════════════
// PART 20: NIKUD_RULES & NIKUD_VALIDITY
// ═══════════════════════════════════════════════════════════════════════════════

const NIKUD_RULES = {
  // bgdkpt letters change sound with dagesh
  bgdkpt: {
    'ב': { soft: 'v', hard: 'b' },
    'ג': { soft: 'g', hard: 'g' },  // Modern Hebrew: same
    'ד': { soft: 'd', hard: 'd' },  // Modern Hebrew: same
    'כ': { soft: 'x', hard: 'k' },
    'פ': { soft: 'f', hard: 'p' },
    'ת': { soft: 't', hard: 't' },  // Modern Hebrew: same
  },
  
  // Guttural letters take hataf instead of shva
  guttural: ['א', 'ה', 'ח', 'ע', 'ר'],
  
  // Final letters - limited nikud
  final_valid_nikud: {
    'ך': ['ְ', 'ָ', 'ֶ'],           // שְׁלְּךָ, אוֹתְךָ
    'ם': [],                         // Usually no nikud
    'ן': [],                         // Usually no nikud
    'ף': [],                         // Usually no nikud
    'ץ': [],                         // Usually no nikud
  },
  
  // Shin/Sin distinction
  shin_sin: {
    'ׁ': 'ʃ',  // Right dot = shin
    'ׂ': 's',  // Left dot = sin
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// VALIDITY RULES - אילו צירופים קיימים ואילו לא
// ═══════════════════════════════════════════════════════════════════════════

const NIKUD_VALIDITY = {
  // === אותיות סופיות - ניקוד מוגבל מאוד ===
  // Final letters appear at END of words, so most nikud is invalid
  final: {
    'ך': {
      valid: ['shva', 'kamatz', 'segol'],  // לָךְ, שֶׁלְּךָ, בָּךְ
      common: ['shva', 'kamatz'],
      never: ['chirik_m', 'cholam_m', 'shuruk', 'hataf_a', 'hataf_e', 'hataf_o'],
    },
    'ם': {
      valid: [],  // Almost never has direct nikud
      common: [],
      never: ['*'],  // Vowel goes on letter BEFORE ם
    },
    'ן': {
      valid: [],
      common: [],
      never: ['*'],
    },
    'ף': {
      valid: [],
      common: [],
      never: ['*'],
    },
    'ץ': {
      valid: [],
      common: [],
      never: ['*'],
    },
  },

  // === תנועות מלאות - רק עם אמות קריאה ===
  // These REQUIRE a mater lectionis (אם קריאה)
  full_vowels: {
    'shuruk': {
      requires: 'ו',       // וּ - always with vav
      standalone: false,   // Cannot appear alone on consonant
      examples: ['הוּא', 'שׁוּק', 'גּוּף'],
    },
    'cholam_m': {
      requires: 'ו',       // וֹ - cholam with vav
      standalone: false,
      examples: ['שָׁלוֹם', 'יוֹם', 'טוֹב'],
    },
    'chirik_m': {
      requires: 'י',       // ִי - chirik with yod
      standalone: false,
      examples: ['שִׁיר', 'עִיר', 'בִּית'],
    },
  },

  // === תנועות חסרות - בלי אם קריאה ===
  // These appear directly on consonants
  defective_vowels: {
    'chirik': { standalone: true, examples: ['מִן', 'אִם', 'בִּת'] },
    'cholam': { standalone: true, examples: ['כֹּל', 'עֹז', 'קֹדֶשׁ'] },
    'kubutz': { standalone: true, examples: ['קֻם', 'סֻכָּה', 'חֻקָּה'] },
  },

  // === חטפים - רק לגרוניות ===
  hataf: {
    valid_letters: ['א', 'ה', 'ח', 'ע'],  // ר sometimes
    never_letters: ['ב', 'ג', 'ד', 'ו', 'ז', 'ט', 'י', 'כ', 'ל', 'מ', 'נ', 'ס', 'פ', 'צ', 'ק', 'ש', 'ת'],
    rarely: ['ר'],  // Resh sometimes acts guttural
  },

  // === דגש ומפיק - כללים מלאים ===
  dagesh: {
    // ═══════════════════════════════════════════════════════════
    // דגש קל - Dagesh Kal (Lene)
    // ═══════════════════════════════════════════════════════════
    // Changes pronunciation in בג"ד כפ"ת letters
    // Appears: start of word, after shva nach, after consonant
    kal: {
      letters: ['ב', 'ג', 'ד', 'כ', 'פ', 'ת'],  // בג"ד כפ"ת only
      changes_sound: {
        'ב': { without: 'v', with: 'b' },
        'ג': { without: 'g', with: 'g' },  // Same in modern Hebrew
        'ד': { without: 'd', with: 'd' },  // Same in modern Hebrew  
        'כ': { without: 'x', with: 'k' },
        'פ': { without: 'f', with: 'p' },
        'ת': { without: 't', with: 't' },  // Same in modern Hebrew
      },
      when: [
        'word_start',           // בְּרֵאשִׁית - ב at start
        'after_shva_nach',      // מִשְׁפָּט - פ after shva nach
        'after_consonant',      // מַלְכָּה - כ after consonant
      ],
      examples: [
        { word: 'בְּרֵאשִׁית', letter: 'בּ', reason: 'word start' },
        { word: 'מִשְׁפָּט', letter: 'פּ', reason: 'after shva nach' },
        { word: 'מַלְכָּה', letter: 'כּ', reason: 'after lamed' },
        { word: 'כָּתַב', letter: 'כּ', reason: 'word start' },
      ],
      // When NOT to use dagesh kal
      not_when: [
        'after_vowel',          // הַבַּיִת - second ב has no dagesh
        'after_shva_na',        // מְבַקֵּשׁ - ב after shva na, no dagesh
      ],
    },
    
    // ═══════════════════════════════════════════════════════════
    // דגש חזק - Dagesh Chazak (Forte)
    // ═══════════════════════════════════════════════════════════
    // Doubles the consonant (historically)
    // Can appear in almost any letter except אהח"ע ר
    chazak: {
      letters: ['ב', 'ג', 'ד', 'ו', 'ז', 'ט', 'י', 'כ', 'ל', 'מ', 'נ', 'ס', 'פ', 'צ', 'ק', 'ש', 'ת'],
      never: ['א', 'ה', 'ח', 'ע', 'ר'],  // אהח"ע + ר never take dagesh
      types: {
        // דגש חזק משלים - compensatory
        mashlim: {
          note: 'Compensates for missing letter',
          examples: [
            { word: 'מַצָּה', from: 'מַצְיָה', reason: 'yod assimilated' },
            { word: 'הִנֵּה', from: 'הִנְאֵה', reason: 'alef assimilated' },
          ],
        },
        // דגש חזק מפריד - separating  
        mafrid: {
          note: 'Separates syllables',
          examples: [
            { word: 'הַלְּלוּיָהּ', letter: 'לּ', reason: 'emphasis' },
          ],
        },
        // דגש חזק בינוני - medium (binyan piel etc)
        binoni: {
          note: 'Part of verb pattern',
          binyanim: ['פִּעֵל', 'פֻּעַל', 'הִתְפַּעֵל'],
          examples: [
            { word: 'דִּבֵּר', pattern: 'פִּעֵל', reason: 'middle root letter' },
            { word: 'לִמֵּד', pattern: 'פִּעֵל', reason: 'middle root letter' },
            { word: 'סִפֵּר', pattern: 'פִּעֵל', reason: 'middle root letter' },
          ],
        },
      },
      when: [
        'after_vowel_no_shva',  // Always after vowel (not shva)
        'verb_pattern',         // Piel, Pual, Hitpael
        'assimilation',         // When letter assimilates
      ],
    },
    
    // ═══════════════════════════════════════════════════════════
    // מפיק - Mappiq
    // ═══════════════════════════════════════════════════════════
    // Dot in ה at end of word - makes it consonantal
    // NOT the same as dagesh!
    mappiq: {
      letter: 'ה',
      position: 'word_end_only',
      symbol: 'הּ',  // Looks like dagesh but is mappiq
      meaning: 'The ה is pronounced, not silent',
      ipa: 'h',  // Pronounced as /h/
      
      // Without mappiq - ה is silent (vowel marker)
      without: {
        examples: ['יָפָה', 'גָּדְלָה', 'בָּנָה'],
        pronunciation: 'ה is silent, just marks /a/ vowel',
      },
      
      // With mappiq - ה is pronounced
      with: {
        examples: [
          { word: 'גָּבַהּ', ipa: 'gavah', meaning: 'he was tall', note: 'final h pronounced' },
          { word: 'אָהֳלָהּ', ipa: 'oholah', meaning: 'her tent', note: 'possessive suffix' },
          { word: 'עָשָׂהּ', ipa: 'asah', meaning: 'he made it (f)', note: 'object suffix' },
          { word: 'בָּהּ', ipa: 'bah', meaning: 'in her', note: 'preposition + suffix' },
          { word: 'לָהּ', ipa: 'lah', meaning: 'to her', note: 'preposition + suffix' },
          { word: 'שְׁמָהּ', ipa: 'ʃmah', meaning: 'her name', note: 'possessive' },
        ],
      },
      
      // Common patterns with mappiq
      patterns: {
        possessive_her: {
          note: 'כינוי קניין נקבה - her',
          pattern: 'noun + הּ',
          examples: ['בֵּיתָהּ', 'שְׁמָהּ', 'יָדָהּ', 'אִמָּהּ'],
        },
        object_suffix_her: {
          note: 'כינוי מושא נקבה - her/it(f)',
          pattern: 'verb + הּ',
          examples: ['רָאָהּ', 'שְׁמָרָהּ', 'אֲהֵבָהּ'],
        },
        preposition_her: {
          note: 'מילת יחס + היא',
          pattern: 'prep + הּ',
          examples: ['בָּהּ', 'לָהּ', 'עָלֶיהָ', 'מִמֶּנָּהּ'],
        },
      },
    },
    
    // Summary: never dagesh
    never: ['א', 'ה', 'ח', 'ע', 'ר'],  // אהח"ע + ר
    // Note: הּ at word end is MAPPIQ, not dagesh!
  },

  // === שווא - נע או נח ===
  shva: {
    // שווא נע - בתחילת הברה
    na: {
      positions: ['word_start', 'after_long_vowel', 'second_of_two'],
      ipa: 'ə',
    },
    // שווא נח - בסוף הברה
    nach: {
      positions: ['word_end', 'before_consonant', 'first_of_two'],
      ipa: '',  // Silent
    },
  },

  // === צירופים בלתי אפשריים ===
  impossible: [
    // סופית + אם קריאה
    { letter: 'ך', nikud: 'cholam_m', reason: 'Final + mater' },
    { letter: 'ך', nikud: 'shuruk', reason: 'Final + mater' },
    { letter: 'ך', nikud: 'chirik_m', reason: 'Final + mater' },
    { letter: 'ם', nikud: '*', reason: 'Final mem rarely nikud' },
    { letter: 'ן', nikud: '*', reason: 'Final nun rarely nikud' },
    { letter: 'ף', nikud: '*', reason: 'Final pe rarely nikud' },
    { letter: 'ץ', nikud: '*', reason: 'Final tzadi rarely nikud' },
    
    // גרונית + דגש
    { letter: 'א', nikud: 'dagesh', reason: 'Guttural no dagesh' },
    { letter: 'ה', nikud: 'dagesh', reason: 'Guttural no dagesh' },
    { letter: 'ח', nikud: 'dagesh', reason: 'Guttural no dagesh' },
    { letter: 'ע', nikud: 'dagesh', reason: 'Guttural no dagesh' },
    { letter: 'ר', nikud: 'dagesh', reason: 'Resh no dagesh' },
    
    // לא גרונית + חטף
    { letter: 'ב', nikud: 'hataf_*', reason: 'Hataf only guttural' },
    { letter: 'ג', nikud: 'hataf_*', reason: 'Hataf only guttural' },
    // ... all non-gutturals
  ],

  // === צירופים נדירים אך אפשריים ===
  rare: [
    { letter: 'ר', nikud: 'hataf_a', example: 'רֲחֵלִים', note: 'Resh sometimes guttural' },
    { letter: 'ה', nikud: 'dagesh', example: 'הּ (mappiq)', note: 'Mappiq not dagesh' },
  ],
};

// === VALIDATION FUNCTION ===
function isValidNikud(letter, nikud) {
  const l = HE_LETTERS[letter];
  if (!l) return { valid: false, reason: 'Unknown letter' };
  
  const n = NIKUD[nikud];
  if (!n) return { valid: false, reason: 'Unknown nikud' };
  
  // Check final letters
  if (l.final) {
    const rules = NIKUD_VALIDITY.final[letter];
    if (rules) {
      if (rules.never.includes('*') || rules.never.includes(nikud)) {
        return { valid: false, reason: 'Invalid for final letter', rare: false };
      }
      if (!rules.valid.includes(nikud) && rules.valid.length > 0) {
        return { valid: false, reason: 'Not in valid list', rare: true };
      }
    }
  }
  
  // Check hataf - only gutturals
  if (nikud.startsWith('hataf')) {
    if (!NIKUD_VALIDITY.hataf.valid_letters.includes(letter)) {
      if (NIKUD_VALIDITY.hataf.rarely.includes(letter)) {
        return { valid: true, rare: true, reason: 'Rare but possible' };
      }
      return { valid: false, reason: 'Hataf only for gutturals' };
    }
  }
  
  // Check dagesh
  if (nikud === 'dagesh' || nikud.includes('dagesh')) {
    if (NIKUD_VALIDITY.dagesh.never.includes(letter)) {
      return { valid: false, reason: 'Letter never takes dagesh' };
    }
  }
  
  // Check full vowels (need mater lectionis)
  if (NIKUD_VALIDITY.full_vowels[nikud]) {
    // These are complex - they include the mater
    return { valid: true, complex: true, reason: 'Full vowel with mater' };
  }
  
  return { valid: true };
}

// === FILTER SYLLABLES ===
function getValidSyllables(letter, options = {}) {
  const { includeRare = false, includeComplex = true } = options;
  const all = buildAllSyllables(letter);
  
  return all.filter(syl => {
    // Extract nikud from syllable
    const nikudKey = Object.keys(NIKUD).find(k => syl.text.includes(NIKUD[k].n));
    if (!nikudKey) return true;
    
    const validity = isValidNikud(letter, nikudKey);
    if (!validity.valid) return false;
    if (validity.rare && !includeRare) return false;
    if (validity.complex && !includeComplex) return false;
    
    return true;
  });
}

// === COMMON SYLLABLES ONLY ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 21: COMMON_SYLLABLES
// ═══════════════════════════════════════════════════════════════════════════════

const COMMON_SYLLABLES = {
  // High frequency - show first
  high: {
    vowels: ['kamatz', 'patach', 'chirik', 'tzere', 'segol', 'cholam'],
    with_mater: ['chirik_m', 'cholam_m', 'shuruk'],
    shva: ['shva'],
  },
  // Medium frequency
  medium: {
    vowels: ['kubutz'],
    hataf: ['hataf_a', 'hataf_e', 'hataf_o'],  // Only for gutturals
  },
  // Low frequency - hide by default
  low: {
    dagesh_variants: true,  // Show dagesh only when relevant
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// IPA TEXT ANALYSIS & RHYME MATCHING
// ═══════════════════════════════════════════════════════════════════════════
// IPA is the universal key that unifies:
// - Hebrew with nikud (מלא)
// - Hebrew without nikud (חסר)
// - English
// This enables cross-language rhyme detection and spelling conversion

// === HEBREW SPELLING VARIANTS ===
// Maps between מלא (full) and חסר (defective) spellings

// ═══════════════════════════════════════════════════════════════════════════════
// PART 22: HE_SPELLING_VARIANTS & HE_SPELLING_CONVENTIONS
// ═══════════════════════════════════════════════════════════════════════════════

const HE_SPELLING_VARIANTS = {
  // IPA → { male: full spelling, haser: defective spelling }
  // IMPORTANT: Some conversions are technically correct but NOT conventional
  
  // /o/ sound - cholam
  'o': {
    male: 'וֹ',      // cholam male: שָׁלוֹם
    haser: 'ֹ',      // cholam haser: כֹּל
    plain_male: 'ו', // without nikud: שלום
    plain_haser: '', // without nikud: כל
  },
  
  // /u/ sound - shuruk/kubutz
  'u': {
    male: 'וּ',      // shuruk: הוּא
    haser: 'ֻ',      // kubutz: קֻם
    plain_male: 'ו', // without nikud: הוא
    plain_haser: '', // without nikud: קם
  },
  
  // /i/ sound - chirik
  'i': {
    male: 'ִי',      // chirik male: שִׁיר
    haser: 'ִ',      // chirik haser: מִן
    plain_male: 'י', // without nikud: שיר
    plain_haser: '', // without nikud: מן
  },
  
  // /e/ sound - tzere
  'e': {
    male: 'ֵי',      // tzere male: בֵּית (rare)
    haser: 'ֵ',      // tzere haser: בֵּן
    plain_male: 'י', // without nikud: בית
    plain_haser: '', // without nikud: בן
  },
  
  // /a/ sound - kamatz/patach (no male/haser distinction)
  'a': {
    nikud: 'ַ',      // patach
    kamatz: 'ָ',     // kamatz
    plain: '',       // no mater for /a/
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// SPELLING CONVENTIONS - מה מקובל לעומת מה אפשרי
// ═══════════════════════════════════════════════════════════════════════════
// Not every technically-correct spelling is conventionally used!
// Some words have FIXED spellings that don't follow rules

const HE_SPELLING_CONVENTIONS = {
  // === מילים עם כתיב קבוע - לא ניתן להמרה ===
  fixed: {
    // These words are ALWAYS spelled this way, regardless of מלא/חסר rules
    'הוא': { spelling: 'הוּא', ipa: 'hu', note: 'Always with shuruk, never הֻא' },
    'היא': { spelling: 'הִיא', ipa: 'hi', note: 'Always with chirik+alef' },
    'הם': { spelling: 'הֵם', ipa: 'hem', note: 'Never הים' },
    'הן': { spelling: 'הֵן', ipa: 'hen', note: 'Never הין' },
    'טוב': { spelling: 'טוֹב', ipa: 'tov', note: 'Always cholam male, never טֹב' },
    'יום': { spelling: 'יוֹם', ipa: 'jom', note: 'Always cholam male' },
    'לא': { spelling: 'לֹא', ipa: 'lo', note: 'Cholam haser + alef' },
    'כל': { spelling: 'כֹּל', ipa: 'kol', note: 'Always cholam haser' },
    'כול': { spelling: 'כּוֹל', ipa: 'kol', note: 'Alternative valid spelling' },
    'אם': { spelling: 'אִם', ipa: 'ʔim', note: 'Chirik haser' },
    'עם': { spelling: 'עִם', ipa: 'ʕim', note: 'Chirik haser' },
    'גם': { spelling: 'גַּם', ipa: 'gam', note: 'No mater for /a/' },
    'שם': { spelling: 'שָׁם', ipa: 'ʃam', note: 'No mater for /a/' },
    'זה': { spelling: 'זֶה', ipa: 'ze', note: 'Fixed segol' },
    'מה': { spelling: 'מָה', ipa: 'ma', note: 'Fixed kamatz' },
    'את': { spelling: 'אֶת', ipa: 'ʔet', note: 'Object marker, fixed' },
    'של': { spelling: 'שֶׁל', ipa: 'ʃel', note: 'Fixed segol' },
    'על': { spelling: 'עַל', ipa: 'ʕal', note: 'Fixed patach' },
    'אל': { spelling: 'אֶל', ipa: 'ʔel', note: 'Fixed segol' },
  },
  
  // === כללים מתי מלא ומתי חסר ===
  rules: {
    // When to use מלא (full spelling)
    prefer_male: [
      { context: 'word_end', vowel: 'o', note: 'שָׁלוֹם not שָׁלֹם' },
      { context: 'word_end', vowel: 'u', note: 'הוּא not הֻא' },
      { context: 'stressed', vowel: 'i', note: 'שִׁיר not שִׁר' },
      { context: 'closed_syllable', vowel: 'i', note: 'בִּית, עִיר - no shva after' },
    ],
    
    // When to use חסר (defective spelling)
    prefer_haser: [
      { context: 'unstressed', vowel: 'o', note: 'קֹדֶשׁ not קוֹדֶשׁ' },
      { context: 'prefix', vowel: 'u', note: 'לְקֻם not לְקוּם (rare)' },
      { context: 'short_word', vowel: 'o', note: 'כֹּל not כּוֹל' },
      { context: 'before_shva', vowel: 'i', note: 'יִשְׁמֹר not יִישְׁמֹר - shva na after' },
    ],
    
    // === CHIRIK RULES - חיריק מלא/חסר ===
    // The most complex vowel - depends on what follows
    chirik: {
      // חיריק מלא (ִי) - with yod
      male: {
        when: [
          'closed_syllable',      // הַבַּיִת - syllable ends with consonant
          'word_end',             // לִי, בִּי, שִׁירִי
          'before_consonant',     // שִׁיר, עִיר, גִּיל
          'stressed',             // אָנִי, הִיא
        ],
        examples: ['שִׁיר','עִיר','בַּיִת','לִי','אֲנִי','הִיא','גִּיל','צִיּוּן'],
        note: 'Yod is part of the syllable, not a separate consonant',
      },
      
      // חיריק חסר (ִ) - without yod  
      haser: {
        when: [
          'before_shva_na',       // יִשְׁמֹר - shva na follows
          'open_syllable',        // מִן, אִם, בִּת
          'unstressed_short',     // וְנִשְׁמַר
          'prefix_position',      // הִתְגַּלָּה
        ],
        examples: ['יִשְׁמֹר','יִכְתֹּב','מִן','אִם','בִּת','נִשְׁמַר','הִתְגַּלָּה'],
        note: 'No yod when followed by shva na or in open unstressed syllable',
      },
      
      // The key rule: שווא נע אחרי חיריק = חיריק חסר
      shva_rule: {
        pattern: 'CiC + shva_na',
        result: 'chirik_haser',
        examples: [
          { word: 'יִשְׁמֹר', structure: 'יִ-שְׁמֹר', note: 'shva na under shin' },
          { word: 'יִכְתֹּב', structure: 'יִ-כְתֹּב', note: 'shva na under kaf' },
          { word: 'תִּשְׁמֹרְנָה', structure: 'תִּ-שְׁמֹר-נָה', note: 'shva na' },
          { word: 'נִשְׁמַר', structure: 'נִ-שְׁמַר', note: 'shva na' },
        ],
        counter_examples: [
          { word: 'שִׁירִים', structure: 'שִׁי-רִים', note: 'no shva after chirik' },
          { word: 'עִירוֹנִי', structure: 'עִי-רוֹ-נִי', note: 'yod is consonant of syllable' },
        ],
      },
      
      // Exceptions
      exceptions: [
        { word: 'בִּירָה', note: 'Loan word - keeps yod' },
        { word: 'פִּיצָה', note: 'Loan word - keeps yod' },
        { word: 'סִירָה', note: 'Established spelling' },
      ],
    },
    
    // Academy standard (האקדמיה ללשון העברית)
    academy: {
      modern_hebrew: 'Prefer מלא in most cases',
      biblical: 'Usually חסר',
      poetry: 'Flexible for meter/rhyme',
    },
  },
  
  // === המרות לא מקובלות ===
  // Technically correct but never/rarely used
  unconventional: [
    { from: 'הוּא', to: 'הֻא', status: 'NEVER', note: 'Kubutz form not used' },
    { from: 'טוֹב', to: 'טֹב', status: 'NEVER', note: 'Haser form not used' },
    { from: 'יוֹם', to: 'יֹם', status: 'ARCHAIC', note: 'Only in biblical texts' },
    { from: 'שָׁלוֹם', to: 'שָׁלֹם', status: 'RARE', note: 'Seen in poetry' },
    { from: 'שִׁיר', to: 'שִׁר', status: 'NEVER', note: 'Looks like different word' },
    { from: 'עוֹלָם', to: 'עֹלָם', status: 'RARE', note: 'Biblical only' },
    { from: 'חַיִּים', to: 'חַיִם', status: 'NEVER', note: 'Double yod required' },
  ],
  
  // === מילים שנכתבות אחרת בלי ניקוד ===
  // Plain spelling differs from nikud logic
  plain_exceptions: {
    'הוא': { nikud: 'הוּא', plain: 'הוא', note: 'Vav kept in plain' },
    'היא': { nikud: 'הִיא', plain: 'היא', note: 'Yod+Alef kept' },
    'הם': { nikud: 'הֵם', plain: 'הם', note: 'No yod added in plain' },
    'לא': { nikud: 'לֹא', plain: 'לא', note: 'Alef kept, no vav' },
    'כל': { nikud: 'כֹּל', plain: 'כל', note: 'No vav in plain' },
    'אם': { nikud: 'אִם', plain: 'אם', note: 'No yod in plain' },
  },
};

// Check if a spelling conversion is conventional
function isConventionalSpelling(word, targetSpelling) {
  // Check fixed words
  const fixed = HE_SPELLING_CONVENTIONS.fixed[stripNikud(word)];
  if (fixed) {
    // This word has a fixed spelling
    return false; // Don't convert fixed words
  }
  
  // Check unconventional list
  const unconventional = HE_SPELLING_CONVENTIONS.unconventional.find(
    u => u.from === word || u.to === word
  );
  if (unconventional) {
    return unconventional.status === 'RARE' || unconventional.status === 'ARCHAIC';
  }
  
  return true;
}

// Get the conventional spelling for a word
function getConventionalSpelling(word, options = {}) {
  const { preferMale = true, withNikud = true } = options;
  const plain = stripNikud(word);
  
  // Check if fixed
  const fixed = HE_SPELLING_CONVENTIONS.fixed[plain];
  if (fixed) {
    return withNikud ? fixed.spelling : plain;
  }
  
  // Check plain exceptions
  if (!withNikud) {
    const exception = HE_SPELLING_CONVENTIONS.plain_exceptions[plain];
    if (exception) {
      return exception.plain;
    }
  }
  
  // Otherwise use IPA-based conversion
  const ipa = hebrewTextToIpa(word) || hebrewPlainToIpa(word);
  return ipaToHebrew(ipa, { 
    spelling: preferMale ? 'male' : 'haser',
    withNikud 
  });
}

// Determine if chirik should be male (ִי) or haser (ִ) based on context
function getChirikType(word, position) {
  const chars = [...word];
  const nextChar = chars[position + 1] || '';
  const nextNext = chars[position + 2] || '';
  
  // Check if followed by shva na (שווא נע)
  // Shva na = shva at start of syllable, followed by consonant with vowel
  if (nextChar && nextNext) {
    // Look for pattern: consonant + shva + consonant + vowel
    const isShva = nextNext === 'ְ';
    if (isShva) {
      // Check if shva is na (mobile) or nach (silent)
      // Shva na: start of word, after long vowel, second of two shvas
      const afterLongVowel = /[ֵָֹוּ]/.test(chars[position - 1] || '');
      const isWordStart = position <= 1;
      
      if (isWordStart || afterLongVowel) {
        return 'haser'; // חיריק חסר before shva na
      }
    }
  }
  
  // Check if at word end
  const isWordEnd = position >= chars.length - 2;
  if (isWordEnd) {
    return 'male'; // חיריק מלא at word end: לִי, בִּי
  }
  
  // Check if in closed syllable (consonant follows without shva)
  const nextIsConsonant = /[א-ת]/.test(nextChar);
  const nextHasVowel = /[ְ-ּ]/.test(nextNext);
  if (nextIsConsonant && !nextHasVowel) {
    return 'male'; // Closed syllable: שִׁיר, עִיר
  }
  
  // Default to context-based heuristic
  return 'male'; // Default to male when unclear
}

// Check if a shva is na (mobile) or nach (silent)
function isShvaNa(word, position) {
  const chars = [...word];
  const char = chars[position];
  
  // Must be shva
  if (char !== 'ְ') return null;
  
  // Rule 1: Shva at start of word is always na
  const consonantBefore = chars[position - 1];
  if (position === 1 || (position === 2 && /[ּׁׂ]/.test(consonantBefore))) {
    return true;
  }
  
  // Rule 2: Two shvas in a row - first is nach, second is na
  const prevIsShva = chars[position - 2] === 'ְ';
  if (prevIsShva) {
    return true;
  }
  
  // Rule 3: Shva after long vowel (kamatz, tzere, cholam, etc.) is na
  const vowelBefore = chars[position - 2] || '';
  const longVowels = ['ָ', 'ֵ', 'ֹ', 'וֹ', 'וּ', 'ִי'];
  if (longVowels.some(v => vowelBefore.includes(v))) {
    return true;
  }
  
  // Rule 4: Shva under letter with dagesh chazak (doubling) - the second is na
  const hasDagesh = chars[position - 1] === 'ּ';
  if (hasDagesh) {
    return true;
  }
  
  // Default: nach (silent)
  return false;
}

// Analyze word structure for spelling decisions
function analyzeWordStructure(word) {
  const chars = [...word];
  const syllables = [];
  let currentSyllable = { consonants: [], vowel: null, type: null };
  
  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    
    // Hebrew consonant
    if (/[א-ת]/.test(char)) {
      if (currentSyllable.vowel) {
        // New syllable
        syllables.push(currentSyllable);
        currentSyllable = { consonants: [char], vowel: null, type: null };
      } else {
        currentSyllable.consonants.push(char);
      }
    }
    // Vowel (nikud)
    else if (/[ְ-ּ]/.test(char)) {
      currentSyllable.vowel = char;
      
      // Determine syllable type
      if (char === 'ְ') {
        currentSyllable.type = isShvaNa(word, i) ? 'shva_na' : 'shva_nach';
      } else if (['ָ', 'ֵ', 'ֹ'].includes(char)) {
        currentSyllable.type = 'long';
      } else if (['ַ', 'ֶ', 'ִ', 'ֻ'].includes(char)) {
        currentSyllable.type = 'short';
      }
    }
    // Dagesh or shin/sin dot
    else if (/[ּׁׂ]/.test(char)) {
      // Modifier, attach to current consonant
    }
  }
  
  // Push last syllable
  if (currentSyllable.consonants.length > 0) {
    syllables.push(currentSyllable);
  }
  
  return {
    syllables,
    hasShvaNa: syllables.some(s => s.type === 'shva_na'),
    structure: syllables.map(s => s.type || 'unknown').join('-'),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// DAGESH & MAPPIQ FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

// Determine dagesh type: kal, chazak, mappiq, or none
function getDageshType(word, position) {
  const chars = [...word];
  const letter = chars[position];
  const dageshPos = position + 1;
  const hasDagesh = chars[dageshPos] === 'ּ';
  
  if (!hasDagesh) return { type: 'none', hasDagesh: false };
  
  const rules = NIKUD_VALIDITY.dagesh;
  
  // Check for mappiq (הּ at word end)
  if (letter === 'ה') {
    // Is this at word end?
    const remaining = chars.slice(dageshPos + 1).filter(c => /[א-ת]/.test(c));
    if (remaining.length === 0) {
      return { 
        type: 'mappiq', 
        hasDagesh: true, 
        note: 'Final ה with dot = mappiq (pronounced h)',
        ipa: 'h',
      };
    }
  }
  
  // Check if letter can take dagesh at all
  if (rules.never.includes(letter)) {
    return { 
      type: 'invalid', 
      hasDagesh: true, 
      note: `${letter} never takes dagesh (אהח"ע ר)`,
    };
  }
  
  // בג"ד כפ"ת - could be kal or chazak
  const isBgdkpt = rules.kal.letters.includes(letter);
  
  // Check context for kal vs chazak
  const prevChar = chars[position - 1] || '';
  const prevPrev = chars[position - 2] || '';
  
  // At word start = dagesh kal
  if (position === 0) {
    if (isBgdkpt) {
      const soundChange = rules.kal.changes_sound[letter];
      return {
        type: 'kal',
        hasDagesh: true,
        reason: 'word_start',
        ipa: soundChange?.with || letter,
        note: `בג"ד כפ"ת at word start`,
      };
    }
  }
  
  // After shva - need to determine if nach or na
  if (prevChar === 'ְ') {
    const isNa = isShvaNa(word, position - 1);
    if (!isNa && isBgdkpt) {
      // After shva nach = dagesh kal
      const soundChange = rules.kal.changes_sound[letter];
      return {
        type: 'kal',
        hasDagesh: true,
        reason: 'after_shva_nach',
        ipa: soundChange?.with || letter,
        note: 'After shva nach',
      };
    }
  }
  
  // After vowel (not shva) = dagesh chazak
  const vowels = ['ַ', 'ָ', 'ֵ', 'ֶ', 'ִ', 'ֹ', 'ֻ'];
  if (vowels.includes(prevChar) || vowels.includes(prevPrev)) {
    return {
      type: 'chazak',
      hasDagesh: true,
      reason: 'after_vowel',
      note: 'Dagesh chazak (doubling)',
      doubles: true,
    };
  }
  
  // Default for בג"ד כפ"ת
  if (isBgdkpt) {
    const soundChange = rules.kal.changes_sound[letter];
    return {
      type: 'kal',
      hasDagesh: true,
      ipa: soundChange?.with,
    };
  }
  
  // Other letters with dagesh = chazak
  return {
    type: 'chazak',
    hasDagesh: true,
    note: 'Dagesh chazak (doubling)',
  };
}

// Check if a word has mappiq (הּ at end)
function hasMappiq(word) {
  const chars = [...word];
  
  // Look for הּ pattern at end
  for (let i = chars.length - 1; i >= 0; i--) {
    const char = chars[i];
    
    // Skip non-Hebrew
    if (!/[א-תּ]/.test(char)) continue;
    
    // Found ה with dagesh at end = mappiq
    if (char === 'ּ' && chars[i - 1] === 'ה') {
      return {
        hasMappiq: true,
        position: i - 1,
        meaning: 'Pronounced final ה',
        likely: 'possessive_her or object_suffix',
      };
    }
    
    // Found consonant - check if it's ה with dagesh after
    if (char === 'ה' && chars[i + 1] === 'ּ') {
      // Check if this is really at word end
      const after = chars.slice(i + 2).filter(c => /[א-ת]/.test(c));
      if (after.length === 0) {
        return {
          hasMappiq: true,
          position: i,
          meaning: 'Pronounced final ה',
          likely: 'possessive_her or object_suffix',
        };
      }
    }
    
    // Found other consonant at end
    if (/[א-ת]/.test(char) && char !== 'ה') {
      break;
    }
  }
  
  return { hasMappiq: false };
}

// Get IPA for letter considering dagesh
function getLetterIpa(letter, hasDagesh, context = {}) {
  const letterInfo = HE_LETTERS[letter];
  if (!letterInfo) return null;
  
  // בג"ד כפ"ת with dagesh
  if (hasDagesh && letterInfo.ipa_dagesh) {
    return letterInfo.ipa_dagesh;
  }
  
  // שׁין/שׂין
  if (letter === 'ש' && context.shinDot) {
    return context.shinDot === 'shin' ? 'ʃ' : 's';
  }
  
  return letterInfo.ipa;
}

// Determine if dagesh is needed based on position
function shouldHaveDagesh(word, position, letter) {
  const rules = NIKUD_VALIDITY.dagesh;
  
  // Never for אהח"ע ר
  if (rules.never.includes(letter)) {
    return { should: false, reason: 'Letter never takes dagesh' };
  }
  
  // Only בג"ד כפ"ת take dagesh kal
  const isBgdkpt = rules.kal.letters.includes(letter);
  
  // At word start
  if (position === 0 && isBgdkpt) {
    return { should: true, type: 'kal', reason: 'word_start' };
  }
  
  // After shva nach
  const chars = [...word];
  const prev = chars[position - 1];
  if (prev === 'ְ' && !isShvaNa(word, position - 1) && isBgdkpt) {
    return { should: true, type: 'kal', reason: 'after_shva_nach' };
  }
  
  // Context for chazak would require knowing verb pattern etc.
  return { should: false, reason: 'No dagesh rule applies' };
}

// Smart spelling conversion that respects conventions
function convertSpellingSmart(text, options = {}) {
  const { toMale = true, withNikud = true, forceConvert = false } = options;
  const words = text.split(/\s+/);
  
  return words.map(word => {
    // Skip non-Hebrew
    if (!/[\u0590-\u05FF]/.test(word)) return word;
    
    const plain = stripNikud(word);
    
    // Check if fixed (don't convert)
    if (!forceConvert && HE_SPELLING_CONVENTIONS.fixed[plain]) {
      const fixed = HE_SPELLING_CONVENTIONS.fixed[plain];
      return withNikud ? fixed.spelling : plain;
    }
    
    // Check if conversion would be unconventional
    if (!forceConvert) {
      const ipa = hebrewTextToIpa(word) || hebrewPlainToIpa(word);
      const target = ipaToHebrew(ipa, { spelling: toMale ? 'male' : 'haser', withNikud });
      
      const isUnconv = HE_SPELLING_CONVENTIONS.unconventional.find(
        u => u.to === target && (u.status === 'NEVER' || u.status === 'ARCHAIC')
      );
      
      if (isUnconv) {
        // Return original or fixed form
        return withNikud ? word : plain;
      }
      
      return target;
    }
    
    // Force convert (ignores conventions)
    const ipa = hebrewTextToIpa(word) || hebrewPlainToIpa(word);
    return ipaToHebrew(ipa, { spelling: toMale ? 'male' : 'haser', withNikud });
  }).join(' ');
}

// === TEXT TO IPA CONVERSION ===

// Hebrew text → IPA (handles nikud and plain)
function hebrewTextToIpa(text) {
  const result = [];
  const chars = [...text];
  let i = 0;
  
  while (i < chars.length) {
    const char = chars[i];
    const next = chars[i + 1] || '';
    const next2 = chars[i + 2] || '';
    
    // Skip non-Hebrew
    if (!/[֐-׿]/.test(char)) {
      i++;
      continue;
    }
    
    // Get base letter
    const letter = HE_LETTERS[char];
    if (!letter) {
      i++;
      continue;
    }
    
    let ipa = letter.ipa;
    let vowelIpa = '';
    let consumed = 1;
    
    // Check for shin/sin dot
    if (char === 'ש') {
      if (next === 'ׁ') { ipa = 'ʃ'; consumed++; }
      else if (next === 'ׂ') { ipa = 's'; consumed++; }
      else ipa = 'ʃ'; // Default to shin
    }
    
    // Check for dagesh (changes bgdkpt)
    const afterDot = chars[i + consumed] || '';
    if (afterDot === 'ּ' && letter.ipa_dagesh) {
      ipa = letter.ipa_dagesh;
      consumed++;
    }
    
    // Check for nikud (vowel)
    const nikudChar = chars[i + consumed] || '';
    const nikudEntry = Object.entries(NIKUD).find(([k, v]) => v.n === nikudChar);
    if (nikudEntry) {
      vowelIpa = nikudEntry[1].ipa || '';
      consumed++;
      
      // Check for mater lectionis after nikud
      const mater = chars[i + consumed] || '';
      if (nikudChar === 'ִ' && mater === 'י') { // chirik + yod = /i/
        consumed++;
      } else if (nikudChar === 'ֵ' && mater === 'י') { // tzere + yod = /e/
        consumed++;
      }
    }
    
    // Check for vav as vowel (שורוק/חולם מלא)
    if (char === 'ו') {
      if (next === 'ּ') { // שורוק
        ipa = '';
        vowelIpa = 'u';
        consumed = 2;
      } else if (next === 'ֹ' || chars[i - 1] === 'ֹ') { // חולם מלא
        ipa = '';
        vowelIpa = 'o';
        consumed = next === 'ֹ' ? 2 : 1;
      }
    }
    
    // Check for yod as vowel
    if (char === 'י' && !vowelIpa) {
      const prev = result[result.length - 1] || '';
      if (prev.endsWith('i') || prev.endsWith('e')) {
        // Part of previous vowel, skip
        i += consumed;
        continue;
      }
    }
    
    result.push(ipa + vowelIpa);
    i += consumed;
  }
  
  return result.join('');
}

// Hebrew plain text → IPA (guesses vowels from common patterns)
function hebrewPlainToIpa(text) {
  // Common word patterns for plain Hebrew
  const patterns = {
    // CVC patterns
    'של': 'ʃel', 'על': 'ʕal', 'אל': 'ʔel', 'כל': 'kol',
    'עם': 'ʕim', 'שם': 'ʃam', 'גם': 'gam', 'יום': 'jom',
    'טוב': 'tov', 'רב': 'rav', 'לב': 'lev', 'אב': 'ʔav',
    'בן': 'ben', 'כן': 'ken', 'הן': 'hen', 'מן': 'min',
    'לא': 'lo', 'מה': 'ma', 'זה': 'ze', 'אם': 'ʔim',
    
    // CVCV patterns
    'שלום': 'ʃalom', 'בית': 'bajit', 'חיים': 'ħajim',
    'מים': 'majim', 'ילד': 'jeled', 'ספר': 'sefer',
    'דבר': 'davar', 'מלך': 'melex', 'עבד': 'ʕeved',
    
    // Common words
    'אני': 'ʔani', 'אתה': 'ʔata', 'היא': 'hi', 'הוא': 'hu',
    'הם': 'hem', 'הן': 'hen', 'אנחנו': 'ʔanaħnu',
    'את': 'ʔet', 'של': 'ʃel', 'עם': 'ʕim',
  };
  
  // Try exact match first
  if (patterns[text]) return patterns[text];
  
  // Otherwise, basic letter-by-letter (less accurate)
  let ipa = '';
  for (const char of text) {
    const letter = HE_LETTERS[char];
    if (letter) ipa += letter.ipa;
  }
  return ipa;
}

// English text → IPA (simplified)
function englishTextToIpa(text) {
  let result = text.toLowerCase();
  
  // Multi-character patterns first (order matters!)
  const patterns = [
    // Vowel digraphs
    [/ough/g, 'oʊ'], // though (simplified, actually varies)
    [/tion/g, 'ʃən'],
    [/sion/g, 'ʒən'],
    [/ious/g, 'iəs'],
    [/eous/g, 'iəs'],
    [/eigh/g, 'eɪ'],
    [/ight/g, 'aɪt'],
    [/ould/g, 'ʊd'],
    
    // Vowel combinations
    [/ee/g, 'iː'],
    [/ea(?![r])/g, 'iː'],
    [/ear/g, 'ɪr'],
    [/oo/g, 'uː'],
    [/oa/g, 'oʊ'],
    [/ai/g, 'eɪ'],
    [/ay/g, 'eɪ'],
    [/oi/g, 'ɔɪ'],
    [/oy/g, 'ɔɪ'],
    [/ou/g, 'aʊ'],
    [/ow(?![n])/g, 'oʊ'],
    [/ow(?=n)/g, 'aʊ'],
    [/au/g, 'ɔː'],
    [/aw/g, 'ɔː'],
    [/ew/g, 'uː'],
    [/ie$/g, 'i'],
    [/ie/g, 'aɪ'],
    
    // Consonant digraphs
    [/th(?=[eaiouy])/g, 'ð'],
    [/th/g, 'θ'],
    [/sh/g, 'ʃ'],
    [/ch/g, 'tʃ'],
    [/ph/g, 'f'],
    [/wh/g, 'w'],
    [/ng/g, 'ŋ'],
    [/ck/g, 'k'],
    [/qu/g, 'kw'],
    [/dge/g, 'dʒ'],
    [/tch/g, 'tʃ'],
    
    // Silent letters
    [/kn/g, 'n'],
    [/wr/g, 'r'],
    [/gn/g, 'n'],
    [/mb$/g, 'm'],
    [/mn$/g, 'm'],
    
    // Single vowels (context-dependent, simplified)
    [/i_e/g, 'aɪ'], // like "time"
    [/a_e/g, 'eɪ'], // like "make"
    [/o_e/g, 'oʊ'], // like "home"
    [/u_e/g, 'uː'], // like "rule"
    [/e_e/g, 'iː'], // like "these"
    
    // Final e (usually silent)
    [/e$/g, ''],
    
    // Remaining single letters
    [/a(?=[^eiou])/g, 'æ'],
    [/e(?=[^eiou])/g, 'ɛ'],
    [/i(?=[^eiou])/g, 'ɪ'],
    [/o(?=[^eiou])/g, 'ɒ'],
    [/u(?=[^eiou])/g, 'ʌ'],
    [/y$/g, 'i'],
    [/y/g, 'j'],
    
    // Consonants (same as IPA mostly)
    [/c(?=[eiy])/g, 's'],
    [/c/g, 'k'],
    [/g(?=[eiy])/g, 'dʒ'],
    [/x/g, 'ks'],
  ];
  
  for (const [pattern, replacement] of patterns) {
    result = result.replace(pattern, replacement);
  }
  
  return result;
}

// === IPA TO HEBREW CONVERSION ===

// IPA → Hebrew with nikud (מלא or חסר)
function ipaToHebrew(ipa, options = {}) {
  const { spelling = 'male', withNikud = true } = options;
  
  // IPA vowel to nikud mapping
  const vowelMap = {
    'a': withNikud ? 'ַ' : '', // patach
    'ɑ': withNikud ? 'ָ' : '', // kamatz
    'e': withNikud ? 'ֵ' : '', // tzere
    'ɛ': withNikud ? 'ֶ' : '', // segol
    'i': spelling === 'male' ? (withNikud ? 'ִי' : 'י') : (withNikud ? 'ִ' : ''),
    'o': spelling === 'male' ? (withNikud ? 'וֹ' : 'ו') : (withNikud ? 'ֹ' : ''),
    'u': spelling === 'male' ? (withNikud ? 'וּ' : 'ו') : (withNikud ? 'ֻ' : ''),
    'ə': withNikud ? 'ְ' : '', // shva
  };
  
  // IPA consonant to Hebrew
  const consMap = {
    'ʔ': 'א', 'b': 'בּ', 'v': 'ב', 'g': 'ג', 'd': 'ד',
    'h': 'ה', 'z': 'ז', 'ħ': 'ח', 't': 'ת', 'j': 'י',
    'k': 'כּ', 'x': 'כ', 'l': 'ל', 'm': 'מ', 'n': 'נ',
    's': 'ס', 'ʕ': 'ע', 'p': 'פּ', 'f': 'פ', 'ts': 'צ',
    'r': 'ר', 'ʃ': 'שׁ', 'w': 'ו',
  };
  
  let result = '';
  let i = 0;
  
  while (i < ipa.length) {
    const char = ipa[i];
    const next = ipa[i + 1] || '';
    
    // Two-char consonants
    if (char === 't' && next === 's') {
      result += consMap['ts'];
      i += 2;
      continue;
    }
    
    // Consonant
    if (consMap[char]) {
      result += consMap[char];
      i++;
      continue;
    }
    
    // Vowel
    if (vowelMap[char]) {
      result += vowelMap[char];
      i++;
      continue;
    }
    
    // Unknown, skip
    i++;
  }
  
  return result;
}

// === RHYME DETECTION ===

// Get rhyme ending (last vowel + everything after)
function getRhymeEnding(ipa, syllables = 1) {
  // Find the last N vowels and everything after
  const vowelPattern = /[aeiouɑɛɪɔʊəæʌ]/gi;
  const matches = [...ipa.matchAll(vowelPattern)];
  
  if (matches.length === 0) return null;
  
  // Get position of Nth vowel from end
  const targetIndex = Math.max(0, matches.length - syllables);
  const startPos = matches[targetIndex].index;
  
  return ipa.slice(startPos);
}

// Check if two IPAs rhyme
function doTheyRhyme(ipa1, ipa2, options = {}) {
  const { syllables = 1, exact = false } = options;
  
  const ending1 = getRhymeEnding(ipa1, syllables);
  const ending2 = getRhymeEnding(ipa2, syllables);
  
  if (!ending1 || !ending2) return false;
  
  if (exact) {
    return ending1 === ending2;
  }
  
  // Approximate match (allow similar sounds)
  const similar = {
    'a': ['ɑ', 'æ'], 'ɑ': ['a', 'ɔ'], 'æ': ['a', 'ɛ'],
    'e': ['ɛ', 'eɪ'], 'ɛ': ['e', 'æ'],
    'i': ['ɪ', 'iː'], 'ɪ': ['i', 'ə'],
    'o': ['ɔ', 'oʊ'], 'ɔ': ['o', 'ɑ'],
    'u': ['ʊ', 'uː'], 'ʊ': ['u', 'ə'],
  };
  
  // Simple: endings are similar if they differ only in similar vowels
  if (ending1 === ending2) return true;
  if (ending1.length !== ending2.length) return false;
  
  for (let i = 0; i < ending1.length; i++) {
    if (ending1[i] === ending2[i]) continue;
    if (similar[ending1[i]]?.includes(ending2[i])) continue;
    if (similar[ending2[i]]?.includes(ending1[i])) continue;
    return false;
  }
  
  return true;
}

// === MIXED TEXT ANALYSIS ===

// Analyze mixed Hebrew/English text, return words with IPA
function analyzeText(text) {
  const words = text.split(/\s+/);
  const analyzed = [];
  
  for (const word of words) {
    if (!word) continue;
    
    // Detect language
    const hasHebrew = /[֐-׿]/.test(word);
    const hasEnglish = /[a-zA-Z]/.test(word);
    const hasNikud = /[ְ-ׇ]/.test(word);
    
    let lang, ipa;
    
    if (hasHebrew) {
      lang = 'he';
      ipa = hasNikud ? hebrewTextToIpa(word) : hebrewPlainToIpa(word);
    } else if (hasEnglish) {
      lang = 'en';
      ipa = englishTextToIpa(word);
    } else {
      continue;
    }
    
    analyzed.push({
      word,
      lang,
      ipa,
      rhyme: getRhymeEnding(ipa, 1),
      hasNikud,
    });
  }
  
  return analyzed;
}

// Find rhyming words in analyzed text
function findRhymingWords(analyzed, options = {}) {
  const { crossLanguage = true, syllables = 1 } = options;
  const groups = {};
  
  for (const item of analyzed) {
    if (!item.rhyme) continue;
    
    // Normalize rhyme ending
    const key = item.rhyme;
    
    if (!groups[key]) groups[key] = [];
    groups[key].push(item);
  }
  
  // Filter groups with multiple words
  const rhymeGroups = Object.entries(groups)
    .filter(([key, items]) => items.length > 1)
    .map(([key, items]) => ({
      ending: key,
      words: items,
      isCrossLanguage: new Set(items.map(i => i.lang)).size > 1,
    }));
  
  if (!crossLanguage) {
    return rhymeGroups.filter(g => !g.isCrossLanguage);
  }
  
  return rhymeGroups;
}

// === SPELLING CONVERSION ===

// Convert between מלא and חסר
function convertSpelling(hebrewText, toSpelling = 'male') {
  const analyzed = analyzeText(hebrewText);
  
  return analyzed.map(item => {
    if (item.lang !== 'he') return item.word;
    
    // Convert via IPA
    return ipaToHebrew(item.ipa, { 
      spelling: toSpelling, 
      withNikud: item.hasNikud 
    });
  }).join(' ');
}

// === SYLLABLE PATTERNS (תבניות הברה) ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 23: SYLLABLE_PATTERNS
// ═══════════════════════════════════════════════════════════════════════════════

const SYLLABLE_PATTERNS = {
  // CV - Consonant + Vowel (open syllable)
  cv: { pattern: 'CV', ipa: (c, v) => c + v },
  
  // CVC - Consonant + Vowel + Consonant (closed syllable)
  cvc: { pattern: 'CVC', ipa: (c1, v, c2) => c1 + v + c2 },
  
  // CCV - Cluster + Vowel
  ccv: { pattern: 'CCV', ipa: (c1, c2, v) => c1 + c2 + v },
  
  // CVCC - Vowel + Cluster end
  cvcc: { pattern: 'CVCC', ipa: (c1, v, c2, c3) => c1 + v + c2 + c3 },
};

// === GENERATE SYLLABLE ===
// Combine letter + nikud dynamically

function buildSyllable(letter, nikud, options = {}) {
  const { dagesh = false, shinDot = null } = options;
  const l = HE_LETTERS[letter];
  const n = NIKUD[nikud];
  
  if (!l || !n) return null;
  
  // Build the display text
  let text = letter;
  if (l.type === 'shin' && shinDot) {
    text += shinDot === 'shin' ? NIKUD.shin_dot.n : NIKUD.sin_dot.n;
  }
  if (dagesh && l.type === 'bgdkpt') {
    text += NIKUD.dagesh.n;
  }
  text += n.n;
  
  // Build IPA
  let ipa = l.ipa;
  if (dagesh && l.ipa_dagesh) {
    ipa = l.ipa_dagesh;
  }
  if (l.type === 'shin') {
    ipa = shinDot === 'sin' ? 's' : 'ʃ';
  }
  ipa += n.ipa;
  
  return {
    text,
    ipa,
    letter: l.name,
    nikud: n.name,
    plain: letter,  // Without nikud
  };
}

// Generate all syllables for a letter (with validity checking)
function buildAllSyllables(letter, options = {}) {
  const { includeRare = false, onlyCommon = false } = options;
  const syllables = [];
  const l = HE_LETTERS[letter];
  if (!l) return syllables;
  
  // === FINAL LETTERS - very limited nikud ===
  if (l.final) {
    const rules = NIKUD_VALIDITY.final[letter];
    if (rules && rules.valid.length > 0) {
      rules.valid.forEach(nikud => {
        const syl = buildSyllable(letter, nikud);
        if (syl) {
          syl.common = rules.common.includes(nikud);
          syllables.push(syl);
        }
      });
    }
    // Plain letter without nikud
    syllables.unshift({ text: letter, ipa: l.ipa, plain: letter, nikud: 'none', common: true });
    return syllables;
  }
  
  // === REGULAR LETTERS ===
  
  // Defective vowels (חסר) - direct on consonant
  const defective = ['kamatz', 'patach', 'tzere', 'segol', 'chirik', 'cholam', 'kubutz'];
  defective.forEach(nikud => {
    const syl = buildSyllable(letter, nikud);
    if (syl) {
      syl.common = COMMON_SYLLABLES.high.vowels.includes(nikud);
      syllables.push(syl);
    }
  });
  
  // Shva
  const shvaSyl = buildSyllable(letter, 'shva');
  if (shvaSyl) {
    shvaSyl.common = true;
    syllables.push(shvaSyl);
  }
  
  // === DAGESH - only for בגד כפת ===
  if (l.type === 'bgdkpt' && !NIKUD_VALIDITY.dagesh.never.includes(letter)) {
    defective.forEach(nikud => {
      const syl = buildSyllable(letter, nikud, { dagesh: true });
      if (syl) {
        syl.common = ['kamatz', 'patach', 'chirik', 'tzere'].includes(nikud);
        syl.hasDagesh = true;
        syllables.push(syl);
      }
    });
    // Shva with dagesh
    const shvaDagesh = buildSyllable(letter, 'shva', { dagesh: true });
    if (shvaDagesh) {
      shvaDagesh.common = true;
      shvaDagesh.hasDagesh = true;
      syllables.push(shvaDagesh);
    }
  }
  
  // === SHIN/SIN - two letters! ===
  if (l.type === 'shin') {
    defective.forEach(nikud => {
      // שׁין (right dot)
      const shinSyl = buildSyllable(letter, nikud, { shinDot: 'shin' });
      if (shinSyl) {
        shinSyl.common = true;
        shinSyl.isShin = true;
        syllables.push(shinSyl);
      }
      // שׂין (left dot)
      const sinSyl = buildSyllable(letter, nikud, { shinDot: 'sin' });
      if (sinSyl) {
        sinSyl.common = ['kamatz', 'segol', 'chirik'].includes(nikud); // Less common
        sinSyl.isSin = true;
        syllables.push(sinSyl);
      }
    });
  }
  
  // === HATAF - only for gutturals אהח"ע (ר rarely) ===
  if (l.type === 'guttural' || (includeRare && letter === 'ר')) {
    ['hataf_a', 'hataf_e', 'hataf_o'].forEach(nikud => {
      const syl = buildSyllable(letter, nikud);
      if (syl) {
        syl.common = nikud === 'hataf_a';  // hataf patach most common
        syl.isHataf = true;
        if (letter === 'ר') syl.rare = true;
        syllables.push(syl);
      }
    });
  }
  
  // === FULL VOWELS (מלא) - with mater lectionis ===
  // These are special: the vowel INCLUDES the mater (ו or י)
  if (!onlyCommon) {
    // חיריק מלא: consonant + ִי
    const chirikM = buildSyllable(letter, 'chirik_m');
    if (chirikM) {
      chirikM.common = true;
      chirikM.isMale = true;
      syllables.push(chirikM);
    }
    
    // Note: cholam male (וֹ) and shuruk (וּ) are usually separate words
    // They appear AFTER the consonant as a separate unit
    // e.g., שָׁלוֹם = שָׁ + לוֹם, not שָׁל + וֹם
  }
  
  // Filter if onlyCommon requested
  if (onlyCommon) {
    return syllables.filter(s => s.common);
  }
  
  return syllables.filter(s => s !== null);
}

// === IPA TO NIKUD MAPPING ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 24: IPA_ENDING_TO_HE
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_ENDING_TO_HE = {
  'am': { nikud: 'patach', final: 'ם', pattern: 'CVC' },
  'im': { nikud: 'chirik', final: 'ם', pattern: 'CVC', prefix_nikud: 'patach' },
  'om': { nikud: 'cholam_m', final: 'ם', pattern: 'CVC' },
  'an': { nikud: 'kamatz', final: 'ן', pattern: 'CVC' },
  'en': { nikud: 'tzere', final: 'ן', pattern: 'CVC' },
  'in': { nikud: 'chirik', final: 'ן', pattern: 'CVC' },
  'on': { nikud: 'cholam_m', final: 'ן', pattern: 'CVC' },
  'av': { nikud: 'kamatz', final: 'ב', pattern: 'CVC' },
  'ev': { nikud: 'tzere', final: 'ב', pattern: 'CVC' },
  'ov': { nikud: 'cholam_m', final: 'ב', pattern: 'CVC' },
  'al': { nikud: 'kamatz', final: 'ל', pattern: 'CVC' },
  'el': { nikud: 'tzere', final: 'ל', pattern: 'CVC' },
  'ar': { nikud: 'kamatz', final: 'ר', pattern: 'CVC' },
  'er': { nikud: 'segol', final: 'ר', pattern: 'CVC' },
  'or': { nikud: 'cholam_m', final: 'ר', pattern: 'CVC' },
  'ir': { nikud: 'chirik_m', final: 'ר', pattern: 'CVC' },
  'at': { nikud: 'patach', final: 'ת', pattern: 'CVC' },
  'et': { nikud: 'segol', final: 'ת', pattern: 'CVC' },
  'it': { nikud: 'chirik', final: 'ת', pattern: 'CVC' },
  'ax': { nikud: 'patach', final: 'ך', pattern: 'CVC' },
  'ex': { nikud: 'segol', final: 'ך', pattern: 'CVC' },
  'aʃ': { nikud: 'patach', final: 'ש', shinDot: 'shin', pattern: 'CVC' },
  'eʃ': { nikud: 'segol', final: 'ש', shinDot: 'shin', pattern: 'CVC' },
  'iʃ': { nikud: 'chirik', final: 'ש', shinDot: 'shin', pattern: 'CVC' },
};

// Generate Hebrew word pattern from IPA ending
function generateHeFromIpaEnding(ipaEnding, consonant = 'X') {
  const pattern = IPA_ENDING_TO_HE[ipaEnding];
  if (!pattern) return null;
  
  const nikud = NIKUD[pattern.nikud];
  if (!nikud) return null;
  
  // Build: consonant + nikud + final
  let text = consonant + nikud.n;
  if (pattern.shinDot && consonant === 'ש') {
    text = consonant + (pattern.shinDot === 'shin' ? NIKUD.shin_dot.n : NIKUD.sin_dot.n) + nikud.n;
  }
  text += pattern.final;
  
  return {
    text,
    pattern: pattern.pattern,
    nikud: pattern.nikud,
    ipa: consonant === 'X' ? '?' + ipaEnding : HE_LETTERS[consonant]?.ipa + ipaEnding,
  };
}


// === IPA KEYBOARD LAYOUT ===
// Bilingual IPA keyboard for phonetic input


// ═══════════════════════════════════════════════════════════════════════════════
// PART 25: IPA_KEYBOARD
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_KEYBOARD = {
  // Row 1: Vowels
  vowels: [
    { ipa: 'i', key: 'i', label: 'i', he: 'חִירִיק', en: 'ee' },
    { ipa: 'ɪ', key: 'I', label: 'ɪ', he: 'חִירִיק קצר', en: 'i' },
    { ipa: 'e', key: 'e', label: 'e', he: 'צֵירֵי', en: 'ay' },
    { ipa: 'ɛ', key: 'E', label: 'ɛ', he: 'סֶגוֹל', en: 'e' },
    { ipa: 'æ', key: 'A', label: 'æ', he: '—', en: 'a (cat)' },
    { ipa: 'ə', key: '@', label: 'ə', he: 'שְׁוָא', en: 'schwa' },
    { ipa: 'a', key: 'a', label: 'a', he: 'פַּתַח', en: 'ah' },
    { ipa: 'ɑ', key: 'A', label: 'ɑ', he: 'קָמָץ', en: 'ar' },
    { ipa: 'ɔ', key: 'O', label: 'ɔ', he: 'קָמָץ קָטָן', en: 'aw' },
    { ipa: 'o', key: 'o', label: 'o', he: 'חוֹלָם', en: 'oh' },
    { ipa: 'ʊ', key: 'U', label: 'ʊ', he: 'קוּבּוּץ קצר', en: 'oo (book)' },
    { ipa: 'u', key: 'u', label: 'u', he: 'שׁוּרוּק', en: 'oo (moon)' },
  ],
  
  // Row 2: Diphthongs
  diphthongs: [
    { ipa: 'aɪ', key: 'ai', label: 'aɪ', he: 'אַי', en: 'my' },
    { ipa: 'aʊ', key: 'au', label: 'aʊ', he: 'אַו', en: 'now' },
    { ipa: 'ɔɪ', key: 'oi', label: 'ɔɪ', he: 'אוֹי', en: 'boy' },
    { ipa: 'eɪ', key: 'ei', label: 'eɪ', he: 'אֵי', en: 'day' },
    { ipa: 'oʊ', key: 'ou', label: 'oʊ', he: 'אוֹ', en: 'go' },
    { ipa: 'ɪə', key: 'ie', label: 'ɪə', he: '—', en: 'ear' },
    { ipa: 'eə', key: 'ea', label: 'eə', he: '—', en: 'air' },
    { ipa: 'ʊə', key: 'ue', label: 'ʊə', he: '—', en: 'tour' },
  ],
  
  // Row 3: Stops
  stops: [
    { ipa: 'p', key: 'p', label: 'p', he: 'פּ', en: 'p' },
    { ipa: 'b', key: 'b', label: 'b', he: 'בּ', en: 'b' },
    { ipa: 't', key: 't', label: 't', he: 'ת/ט', en: 't' },
    { ipa: 'd', key: 'd', label: 'd', he: 'ד', en: 'd' },
    { ipa: 'k', key: 'k', label: 'k', he: 'כּ/ק', en: 'k' },
    { ipa: 'g', key: 'g', label: 'g', he: 'ג', en: 'g' },
    { ipa: 'ʔ', key: '?', label: 'ʔ', he: 'א/ע', en: 'glottal' },
  ],
  
  // Row 4: Fricatives
  fricatives: [
    { ipa: 'f', key: 'f', label: 'f', he: 'פ', en: 'f' },
    { ipa: 'v', key: 'v', label: 'v', he: 'ב/ו', en: 'v' },
    { ipa: 'θ', key: 'T', label: 'θ', he: '—', en: 'th (thin)' },
    { ipa: 'ð', key: 'D', label: 'ð', he: '—', en: 'th (the)' },
    { ipa: 's', key: 's', label: 's', he: 'ס/שׂ', en: 's' },
    { ipa: 'z', key: 'z', label: 'z', he: 'ז', en: 'z' },
    { ipa: 'ʃ', key: 'S', label: 'ʃ', he: 'שׁ', en: 'sh' },
    { ipa: 'ʒ', key: 'Z', label: 'ʒ', he: 'ז׳', en: 'zh' },
    { ipa: 'x', key: 'x', label: 'x', he: 'כ/ח', en: 'ch (loch)' },
    { ipa: 'ħ', key: 'H', label: 'ħ', he: 'ח', en: '—' },
    { ipa: 'ʕ', key: 'Q', label: 'ʕ', he: 'ע', en: '—' },
    { ipa: 'h', key: 'h', label: 'h', he: 'ה', en: 'h' },
  ],
  
  // Row 5: Affricates & Nasals
  other: [
    { ipa: 'ts', key: 'c', label: 'ts', he: 'צ', en: 'ts' },
    { ipa: 'tʃ', key: 'C', label: 'tʃ', he: 'צ׳', en: 'ch' },
    { ipa: 'dʒ', key: 'J', label: 'dʒ', he: 'ג׳', en: 'j' },
    { ipa: 'm', key: 'm', label: 'm', he: 'מ', en: 'm' },
    { ipa: 'n', key: 'n', label: 'n', he: 'נ', en: 'n' },
    { ipa: 'ŋ', key: 'N', label: 'ŋ', he: '—', en: 'ng' },
    { ipa: 'l', key: 'l', label: 'l', he: 'ל', en: 'l' },
    { ipa: 'r', key: 'r', label: 'r', he: 'ר', en: 'r' },
    { ipa: 'j', key: 'y', label: 'j', he: 'י', en: 'y' },
    { ipa: 'w', key: 'w', label: 'w', he: 'ו', en: 'w' },
  ],
  
  // Special markers
  markers: [
    { ipa: 'ˈ', key: "'", label: 'ˈ', desc: 'primary stress' },
    { ipa: 'ˌ', key: ',', label: 'ˌ', desc: 'secondary stress' },
    { ipa: 'ː', key: ':', label: 'ː', desc: 'long vowel' },
    { ipa: '.', key: '.', label: '.', desc: 'syllable break' },
  ],
};

// Convert Hebrew text to IPA
function hebrewToIpa(text) {
  // Map of nikud to IPA
  const nikudMap = {
    'ַ': 'a', 'ָ': 'ɑ', 'ֶ': 'ɛ', 'ֵ': 'e', 'ִ': 'i',
    'ֹ': 'o', 'ֻ': 'u', 'וּ': 'u', 'וֹ': 'o', 'ְ': 'ə',
    'ֲ': 'a', 'ֱ': 'ɛ', 'ֳ': 'o',
  };
  
  const letterMap = {
    'א': 'ʔ', 'ב': 'v', 'בּ': 'b', 'ג': 'g', 'גּ': 'g',
    'ד': 'd', 'דּ': 'd', 'ה': 'h', 'ו': 'v', 'ז': 'z',
    'ח': 'ħ', 'ט': 't', 'י': 'j', 'כ': 'x', 'כּ': 'k',
    'ך': 'x', 'ל': 'l', 'מ': 'm', 'ם': 'm', 'נ': 'n',
    'ן': 'n', 'ס': 's', 'ע': 'ʕ', 'פ': 'f', 'פּ': 'p',
    'ף': 'f', 'צ': 'ts', 'ץ': 'ts', 'ק': 'k', 'ר': 'r',
    'שׁ': 'ʃ', 'שׂ': 's', 'ש': 'ʃ', 'ת': 't', 'תּ': 't',
  };
  
  let ipa = '';
  const chars = [...text];
  
  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    const next = chars[i + 1] || '';
    
    // Check for shin/sin dot
    if (char === 'ש') {
      if (next === 'ׁ') { ipa += 'ʃ'; i++; continue; }
      if (next === 'ׂ') { ipa += 's'; i++; continue; }
      ipa += 'ʃ'; // Default to shin
      continue;
    }
    
    // Check for dagesh
    if (next === 'ּ') {
      const dageshMap = { 'ב': 'b', 'כ': 'k', 'פ': 'p', 'ג': 'g', 'ד': 'd', 'ת': 't' };
      if (dageshMap[char]) { ipa += dageshMap[char]; i++; continue; }
    }
    
    // Nikud
    if (nikudMap[char]) { ipa += nikudMap[char]; continue; }
    
    // Letters
    if (letterMap[char]) { ipa += letterMap[char]; continue; }
  }
  
  return ipa;
}

// Convert English text to IPA (simplified)
function englishToIpa(text) {
  // Common patterns - simplified phonetic conversion
  const patterns = [
    // Vowels
    [/ee|ea(?!r)/g, 'iː'], [/oo/g, 'uː'], [/oa/g, 'oʊ'],
    [/ou(?!gh)/g, 'aʊ'], [/ow(?!n)/g, 'oʊ'], [/oi|oy/g, 'ɔɪ'],
    [/ai|ay/g, 'eɪ'], [/au|aw/g, 'ɔː'],
    [/igh|ie$/g, 'aɪ'], [/y$/g, 'i'],
    
    // Consonants
    [/th(?=e|a|i|o|u)/g, 'ð'], [/th/g, 'θ'],
    [/sh/g, 'ʃ'], [/ch/g, 'tʃ'], [/ng/g, 'ŋ'],
    [/ph/g, 'f'], [/wh/g, 'w'], [/ck/g, 'k'],
    [/qu/g, 'kw'], [/x/g, 'ks'],
    
    // Silent letters
    [/kn/g, 'n'], [/wr/g, 'r'], [/gn/g, 'n'],
    [/mb$/g, 'm'], [/mn$/g, 'm'],
  ];
  
  let result = text.toLowerCase();
  patterns.forEach(([pattern, replacement]) => {
    result = result.replace(pattern, replacement);
  });
  
  return result;
}

// Render IPA keyboard
function renderBilingualIpaKeyboard(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  container.innerHTML = '';
  container.className = 'ipa-keyboard';
  
  const rows = [
    { name: 'Vowels תנועות', keys: IPA_KEYBOARD.vowels },
    { name: 'Diphthongs דיפתונגים', keys: IPA_KEYBOARD.diphthongs },
    { name: 'Stops עיצורים סותמים', keys: IPA_KEYBOARD.stops },
    { name: 'Fricatives חוכמים', keys: IPA_KEYBOARD.fricatives },
    { name: 'Other אחרים', keys: IPA_KEYBOARD.other },
    { name: 'Markers סימנים', keys: IPA_KEYBOARD.markers },
  ];
  
  rows.forEach(row => {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'ipa-row';
    
    const label = document.createElement('span');
    label.className = 'ipa-row-label';
    label.textContent = row.name;
    rowDiv.appendChild(label);
    
    row.keys.forEach(k => {
      const btn = document.createElement('button');
      btn.className = 'ipa-key';
      btn.innerHTML = `<span class="ipa-symbol">${k.label}</span>`;
      if (k.he) btn.innerHTML += `<span class="ipa-he">${k.he}</span>`;
      if (k.en) btn.innerHTML += `<span class="ipa-en">${k.en}</span>`;
      btn.onclick = () => insertIpa(k.ipa);
      btn.title = k.desc || `${k.he || ''} / ${k.en || ''}`;
      rowDiv.appendChild(btn);
    });
    
    container.appendChild(rowDiv);
  });
}

function insertIpa(ipa) {
  const target = document.activeElement;
  if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
    const start = target.selectionStart;
    const end = target.selectionEnd;
    const text = target.value;
    target.value = text.slice(0, start) + ipa + text.slice(end);
    target.selectionStart = target.selectionEnd = start + ipa.length;
    target.focus();
  }
}

// Build Hebrew syllables
function ukBuildHeSyl(letter, ipa, opts = {}) {
  const { dagesh, shin, guttural } = opts;
  const syl = [];
  UK_HE_VOWELS.forEach(v => syl.push({ text: letter + v.n, name: v.name, ipa: ipa + v.ipa, type: 'vowel' }));
  UK_HE_MALE.forEach(m => syl.push({ text: letter + m.n, name: m.name, ipa: ipa + m.ipa, type: 'male' }));
  if (dagesh) UK_HE_VOWELS.forEach(v => syl.push({ text: letter + 'ּ' + v.n, name: v.name + ' דגש', ipa: dagesh + v.ipa, type: 'dagesh' }));
  if (shin) {
    UK_HE_VOWELS.forEach(v => {
      syl.push({ text: 'שׁ' + v.n, name: 'שִׁין ' + v.name, ipa: 'ʃ' + v.ipa, type: 'shin' });
      syl.push({ text: 'שׂ' + v.n, name: 'שִׂין ' + v.name, ipa: 's' + v.ipa, type: 'sin' });
    });
  }
  if (guttural) UK_HE_HATAF.forEach(h => syl.push({ text: letter + h.n, name: h.name, ipa: ipa + h.ipa, type: 'hataf' }));
  return syl;
}
// Build syllables for FINAL letters (אותיות סופיות) - limited nikud
// Final letters appear at end of words, so only certain vowels are valid
function ukBuildHeSylFinal(letter, ipa) {
  const syl = [];
  
  // Final letters (אותיות סופיות) - very limited nikud
  // Most final letters DON'T take direct vowels - vowels go on preceding letters
  // Only ך commonly takes shva (ְ) or kamatz (ָ)
  
  const patterns = {
    // === ך - הסופית היחידה שמקבלת ניקוד ישיר ===
    'ך': [
      { n: 'ְ', name: 'שְׁוָא', ipa: 'x', ex: 'לָךְ, בָּךְ, מִמְּךְ' },
      { n: 'ָ', name: 'קָמָץ', ipa: 'xa', ex: 'שֶׁלְּךָ, אוֹתְךָ, לְךָ' },
    ],
    // === ם ן ף ץ - לא מקבלות ניקוד ישיר! ===
    // הניקוד תמיד על האות שלפניהן
    'ם': [], // הֵם, לָהֶם - הניקוד על ה/ל
    'ן': [], // הֵן, כֵּן - הניקוד על ה/כ  
    'ף': [], // אַף, גּוּף - הניקוד על א/ג
    'ץ': [], // קֵץ, עֵץ - הניקוד על ק/ע
  };
  
  // Common WORD ENDINGS - הניקוד על האות הקודמת, לא על הסופית!
  // These show the PRECEDING letter's vowel + final letter
  const suffixes = {
    // === ך - יכולה לקבל ניקוד ישיר ===
    'ך': [
      { text: 'ְךָ', name: '-ְךָ (שלך ז)', ipa: 'əxa', ex: 'שֶׁלְּךָ' },
      { text: 'ֵךְ', name: '-ֵךְ (שלך נ)', ipa: 'ex', ex: 'שֶׁלֵּךְ' },
      { text: 'ָךְ', name: '-ָךְ (לך)', ipa: 'ax', ex: 'לָךְ, בָּךְ' },
    ],
    // === ם ן ף ץ - הניקוד על האות שלפני! ===
    'ם': [
      // הניקוד הוא על האות שלפני ם, לא על ם עצמה
      { text: 'ֶם', name: 'Xֶם (להם)', ipa: 'ɛm', ex: 'לָהֶם, בָּהֶם' },
      { text: 'ָם', name: 'Xָם (אותם)', ipa: 'am', ex: 'אוֹתָם, שָׁם' },
      { text: 'ִים', name: '-ִים (רבים)', ipa: 'im', ex: 'יְלָדִים, סְפָרִים' },
    ],
    'ן': [
      { text: 'ֶן', name: 'Xֶן (להן)', ipa: 'ɛn', ex: 'לָהֶן, בָּהֶן' },
      { text: 'ָן', name: 'Xָן', ipa: 'an', ex: 'שֶׁלָּהֶן' },
      { text: 'ֵן', name: 'Xֵן (הן/כן)', ipa: 'en', ex: 'הֵן, כֵּן' },
    ],
    // ף - לא מקבלת ניקוד ישיר, הניקוד על האות שלפניה
    'ף': [],  // אַף = א+patach + ף (הפתח על א, לא על ף)
    // ץ - לא מקבלת ניקוד ישיר, הניקוד על האות שלפניה
    'ץ': [],  // קֵץ = ק+tzere + ץ (הצירה על ק, לא על ץ)
  };
  
  // Add basic patterns (letter with direct vowel)
  const letterPatterns = patterns[letter] || [];
  
  const letterSuffixes = suffixes[letter] || [];
  
  // אותיות סופיות שלא מקבלות ניקוד (ף ץ) - לא מציגים popup
  if (letterPatterns.length === 0 && letterSuffixes.length === 0) {
    return []; // No popup needed - letter doesn't take nikud
  }
  
  // ך מקבלת ניקוד ישיר
  if (letterPatterns.length > 0) {
    letterPatterns.forEach(v => {
      syl.push({ text: letter + v.n, name: v.name, ipa: v.ipa, ex: v.ex, type: 'vowel' });
    });
  }
  
  // ם ן - תבניות סיומת (הניקוד על האות הקודמת)
  letterSuffixes.forEach(s => {
    syl.push({ text: s.text, name: s.name, ipa: s.ipa || ipa, ex: s.ex, type: 'suffix' });
  });
  
  return syl;
}

// Build syllables for ש (Shin/Sin) - TWO different letters!
// שׁ (shin, right dot) = ʃ sound (שָׁלוֹם)
// שׂ (sin, left dot) = s sound (שָׂרָה)
// In proper nikud, ש ALWAYS has a dot - either right or left
function ukBuildHeSylShin() {
  const syl = [];
  
  // === שׁ (SHIN - נקודה ימנית) - /ʃ/ sound ===
  UK_HE_VOWELS.forEach(v => syl.push({ 
    text: 'שׁ' + v.n, 
    name: 'שִׁין ' + v.name, 
    ipa: 'ʃ' + v.ipa, 
    type: 'shin' 
  }));
  
  // === שׂ (SIN - נקודה שמאלית) - /s/ sound ===
  UK_HE_VOWELS.forEach(v => syl.push({ 
    text: 'שׂ' + v.n, 
    name: 'שִׂין ' + v.name, 
    ipa: 's' + v.ipa, 
    type: 'sin' 
  }));
  
  // Common words/patterns with ש
  const patterns = [
    // שׁין patterns
    { text: 'שֶׁ', name: 'שֶׁ- (that/which)', ipa: 'ʃɛ', ex: 'שֶׁאָמַרְתִּי', type: 'shin' },
    { text: 'שָׁ', name: 'שָׁ- prefix', ipa: 'ʃa', ex: 'שָׁם, שָׁנָה', type: 'shin' },
    { text: 'שׁוֹ', name: 'שׁוֹ- (his)', ipa: 'ʃo', ex: 'שְׁמוֹ', type: 'shin' },
    
    // שׂין patterns  
    { text: 'שָׂ', name: 'שָׂ- (field)', ipa: 'sa', ex: 'שָׂדֶה, שָׂרָה', type: 'sin' },
    { text: 'שְׂ', name: 'שְׂ- (left)', ipa: 'sə', ex: 'שְׂמֹאל', type: 'sin' },
  ];
  
  patterns.forEach(p => syl.push(p));
  
  return syl;
}

// Build syllables for ת (Tav) - full nikud PLUS common word endings
// ת is NOT a final letter but appears often at word endings with specific patterns
function ukBuildHeSylTav() {
  const syl = [];
  const letter = 'ת';
  const ipa = 't';
  
  // Basic vowels (ת can take all vowels when not at end)
  UK_HE_VOWELS.forEach(v => syl.push({ text: letter + v.n, name: v.name, ipa: ipa + v.ipa, type: 'vowel' }));
  
  // Dagesh (תּ vs ת)
  UK_HE_VOWELS.forEach(v => syl.push({ text: 'תּ' + v.n, name: v.name + ' דגש', ipa: 't' + v.ipa, type: 'dagesh' }));
  
  // Common WORD ENDINGS with ת - very frequent in Hebrew
  const endings = [
    // Pronouns & Possessives
    { text: 'תָּ', name: 'אַתָּה', ipa: 'ta', ex: 'you (m.sg.)' },
    { text: 'תְּ', name: 'אַתְּ', ipa: 'tə', ex: 'you (f.sg.)' },
    { text: 'תִּי', name: '-תִּי', ipa: 'ti', ex: 'הָלַכְתִּי (I went)' },
    { text: 'תָּה', name: '-תָּה', ipa: 'ta', ex: 'הָלַכְתָּ (you m. went)' },
    { text: 'תְּ', name: '-תְּ', ipa: 'tə', ex: 'הָלַכְתְּ (you f. went)' },
    
    // Feminine endings
    { text: 'ת', name: 'נקבה', ipa: 't', ex: 'בַּת, אֵת' },
    { text: 'וֹת', name: 'רבות', ipa: 'ot', ex: 'יְלָדוֹת (girls)' },
    { text: 'ֶת', name: 'סמיכות', ipa: 'ɛt', ex: 'בַּת → בַּת־' },
    { text: 'ַת', name: 'פועל', ipa: 'at', ex: 'יוֹדַעַת (knows f.)' },
    
    // Construct state (סמיכות)
    { text: 'ַת', name: 'סמיכות', ipa: 'at', ex: 'מַלְכַּת (queen of)' },
    { text: 'ֶת', name: 'סמיכות', ipa: 'ɛt', ex: 'בֵּית → בֵּת' },
  ];
  
  endings.forEach(e => syl.push({ text: e.text, name: e.name, ipa: e.ipa || ipa, ex: e.ex, type: 'ending' }));
  
  return syl;
}

// Build MG data - Unified Ivrita notation for Hebrew AND English
// All MG patterns: pronouns, family, Hebrew suffixes
// Same slash/dot notation principles work in both languages

// === MG SYLLABLES DATA - organized by first Hebrew letter ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 26: MG_SYL_DATA (Multi-Gender Syllables)
// ═══════════════════════════════════════════════════════════════════════════════

const MG_SYL_DATA = {
  // ═══════════════════════════════════════════════════════════════
  // MG SUFFIX PAIRS - organized by first letter
  // plain: non-nikud (Alt), nikud: with nikud (Alt+Shift)
  // ═══════════════════════════════════════════════════════════════
  
  // ו/ה - 3rd person singular
  'ו': {
    plain: [
      { m: 'ו', f: 'ה', mf: 'ו/ה', ipa: 'o/a' },
      { m: 'יו', f: 'יה', mf: 'יו/יה', ipa: 'av/a' },
    ],
    nikud: [
      { m: 'וֹ', f: 'הּ', mf: 'וֹ/הּ', ipa: 'o/a' },
      { m: 'ָיו', f: 'ֶיהָ', mf: 'ָיו/ֶיהָ', ipa: 'av/eha' },
    ],
  },
  'ה': 'ו',
  
  // ם/ן - 3rd person plural
  'ם': {
    plain: [
      { m: 'ם', f: 'ן', mf: 'ם/ן', ipa: 'm/n' },
      { m: 'הם', f: 'הן', mf: 'הם/הן', ipa: 'hem/hen' },
      { m: 'יהם', f: 'יהן', mf: 'יהם/יהן', ipa: 'ehem/ehen' },
    ],
    nikud: [
      { m: 'ָם', f: 'ָן', mf: 'ָם/ָן', ipa: 'am/an' },
      { m: 'הֶם', f: 'הֶן', mf: 'הֶם/הֶן', ipa: 'hem/hen' },
      { m: 'ֵיהֶם', f: 'ֵיהֶן', mf: 'ֵיהֶם/ֵיהֶן', ipa: 'ehem/ehen' },
    ],
  },
  'ן': 'ם',
  
  // ך - 2nd person singular
  'ך': {
    plain: [
      { m: 'ך', f: 'ך', mf: 'ךָ/ךְ', ipa: 'xa/ex' },
      { m: 'יך', f: 'יך', mf: 'יךָ/יךְ', ipa: 'exa/aix' },
      { m: 'כם', f: 'כן', mf: 'כם/כן', ipa: 'xem/xen' },
    ],
    nikud: [
      { m: 'ְךָ', f: 'ֵךְ', mf: 'ְךָ/ֵךְ', ipa: 'xa/ex' },
      { m: 'ֶיךָ', f: 'ַיִךְ', mf: 'ֶיךָ/ַיִךְ', ipa: 'exa/aix' },
      { m: 'כֶם', f: 'כֶן', mf: 'כֶם/כֶן', ipa: 'xem/xen' },
    ],
  },
  'כ': 'ך',
  
  // ד/ת - present tense (בינוני)
  'ד': {
    plain: [
      { m: 'ד', f: 'ת', mf: 'ד/ת', ipa: 'd/t' },
    ],
    nikud: [
      { m: 'ֵד', f: 'ֶת', mf: 'ֵד/ֶת', ipa: 'ed/et' },
    ],
  },
  'ת': 'd',
  
  // ה/ה - present (רואֶה/רואָה)
  'ס': {
    plain: [
      { m: 'ה', f: 'ה', mf: 'ה/ה', ipa: 'e/a' },
    ],
    nikud: [
      { m: 'ֶה', f: 'ָה', mf: 'ֶה/ָה', ipa: 'e/a' },
    ],
  },
  
  // ים/ות - plural
  'ר': {
    plain: [
      { m: 'ים', f: 'ות', mf: 'ים/ות', ipa: 'im/ot' },
      { m: 'ין', f: 'ות', mf: 'ין/ות', ipa: 'in/ot' },
    ],
    nikud: [
      { m: 'ִים', f: 'וֹת', mf: 'ִים/וֹת', ipa: 'im/ot' },
      { m: 'ִין', f: 'וֹת', mf: 'ִין/וֹת', ipa: 'in/ot' },
    ],
  },
  'ג': 'ר',
  
  // י/ית - gentilic
  'י': {
    plain: [
      { m: 'י', f: 'ית', mf: 'י/ית', ipa: 'i/it' },
      { m: 'אי', f: 'ית', mf: 'אי/ית', ipa: 'ai/it' },
    ],
    nikud: [
      { m: 'ִי', f: 'ִית', mf: 'ִי/ִית', ipa: 'i/it' },
      { m: 'אִי', f: 'ִית', mf: 'אִי/ִית', ipa: 'ai/it' },
    ],
  },
  
  // ן/ת - adjective
  'נ': {
    plain: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ן', f: 'נה', mf: 'ן/נה', ipa: 'n/na' },
    ],
    nikud: [
      { m: 'ָן', f: 'ֶת', mf: 'ָן/ֶת', ipa: 'an/et' },
      { m: 'ן', f: 'נָה', mf: 'ן/נָה', ipa: 'n/na' },
    ],
  },
  
  // בן/בת, ילד/ילדה
  'ב': {
    plain: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ד', f: 'דה', mf: 'ד/דה', ipa: 'd/da' },
    ],
    nikud: [
      { m: 'ן', f: 'ת', mf: 'ן/ת', ipa: 'n/t' },
      { m: 'ד', f: 'דָה', mf: 'ד/דָה', ipa: 'd/da' },
    ],
  },
  'ל': 'ב',
  
  // איש/אישה
  'א': {
    plain: [
      { m: 'יש', f: 'ישה', mf: 'יש/ישה', ipa: 'ish/isha' },
    ],
    nikud: [
      { m: 'יש', f: 'ישָׁה', mf: 'יש/ישָׁה', ipa: 'ish/isha' },
    ],
  },
  
  // ═══════════════════════════════════════════════════════════════
  // ENGLISH - same for plain/nikud (no nikud in English)
  // ═══════════════════════════════════════════════════════════════
  
  't': {
    plain: [{ m: 'ey', f: 'em', mf: 'ey/em', ipa: 'eɪ/əm' }],
    nikud: [{ m: 'ey', f: 'em', mf: 'ey/em', ipa: 'eɪ/əm' }],
  },
  
  'h': {
    plain: [
      { m: 'e', f: 'she', mf: 'e/she', ipa: 'i/ʃi' },
      { m: 'is', f: 'er', mf: 'is/er', ipa: 'ɪz/ɜr' },
      { m: 'im', f: 'er', mf: 'im/er', ipa: 'ɪm/ɜr' },
    ],
    nikud: [
      { m: 'e', f: 'she', mf: 'e/she', ipa: 'i/ʃi' },
      { m: 'is', f: 'er', mf: 'is/er', ipa: 'ɪz/ɜr' },
      { m: 'im', f: 'er', mf: 'im/er', ipa: 'ɪm/ɜr' },
    ],
  },
  
  's': {
    plain: [{ m: 'imself', f: 'erself', mf: 'imself/erself', ipa: 'self' }],
    nikud: [{ m: 'imself', f: 'erself', mf: 'imself/erself', ipa: 'self' }],
  },
  
  'w': {
    plain: [
      { m: 'an', f: 'oman', mf: 'an/oman', ipa: 'æn/ʊmən' },
      { m: 'en', f: 'omen', mf: 'en/omen', ipa: 'ɛn/ɪmən' },
    ],
    nikud: [
      { m: 'an', f: 'oman', mf: 'an/oman', ipa: 'æn/ʊmən' },
      { m: 'en', f: 'omen', mf: 'en/omen', ipa: 'ɛn/ɪmən' },
    ],
  },
  
  'c': {
    plain: [
      { m: 'on', f: 'aughter', mf: 'on/aughter', ipa: 'ʌn/ɔtər' },
      { m: 'oy', f: 'irl', mf: 'oy/irl', ipa: 'ɔɪ/ɜrl' },
    ],
    nikud: [
      { m: 'on', f: 'aughter', mf: 'on/aughter', ipa: 'ʌn/ɔtər' },
      { m: 'oy', f: 'irl', mf: 'oy/irl', ipa: 'ɔɪ/ɜrl' },
    ],
  },
  
  'p': {
    plain: [
      { m: 'rother', f: 'ister', mf: 'rother/ister', ipa: 'rʌðər/ɪstər' },
      { m: 'ather', f: 'other', mf: 'ather/other', ipa: 'æðər/ʌðər' },
    ],
    nikud: [
      { m: 'rother', f: 'ister', mf: 'rother/ister', ipa: 'rʌðər/ɪstər' },
      { m: 'ather', f: 'other', mf: 'ather/other', ipa: 'æðər/ʌðər' },
    ],
  },
  
  'k': {
    plain: [
      { m: 'ing', f: 'ueen', mf: 'ing/ueen', ipa: 'ɪŋ/in' },
      { m: 'r.', f: 's.', mf: 'r./s.', ipa: 'r/s' },
    ],
    nikud: [
      { m: 'ing', f: 'ueen', mf: 'ing/ueen', ipa: 'ɪŋ/in' },
      { m: 'r.', f: 's.', mf: 'r./s.', ipa: 'r/s' },
    ],
  },
  
  // === Aliases ===
  'ש': 'ו', 'ע': 'ו', 'מ': 'ם', 'ז': 'ב', 'ט': 'ד',
  'ף': 'ו', 'ץ': 'ר', 'ק': 'ר', 'פ': 'ו', 'ח': 'ב', 'צ': 'ר',
};

// Build MG syllables for a Hebrew letter (handles aliases)
function ukBuildMgSyl(key, withNikud = false) {
  let data = MG_SYL_DATA[key];
  // Follow alias chain
  while (typeof data === 'string') {
    data = MG_SYL_DATA[data];
  }
  if (!data) return [];
  // Return plain or nikud array based on parameter
  if (data.plain && data.nikud) {
    return withNikud ? data.nikud : data.plain;
  }
  // Legacy format (just array)
  return Array.isArray(data) ? data : [];
}

// Get all MG syllables (both plain and nikud combined)
function ukGetAllMgSyl(key) {
  let data = MG_SYL_DATA[key];
  while (typeof data === 'string') {
    data = MG_SYL_DATA[data];
  }
  if (!data) return [];
  if (data.plain && data.nikud) {
    return [...data.plain, ...data.nikud];
  }
  return Array.isArray(data) ? data : [];
}


function ukBuildMg(he, enKey = null) {
  // MG mappings - keyed by ENGLISH key for semantic meaning
  // Hebrew uses same key position, English uses semantic key (h=he/she, t=they/them)
  const mgByEnKey = {
    // === PRONOUNS - Semantic English keys ===
    'h': { he: ['הוא','היא'], en: ['he','she'] },           // H: he/she subject
    'o': { he: ['שלו','שלה'], en: ['his','her'] },          // O: his/her possessive adj (O for Own)
    'l': { he: ['אותו','אותה'], en: ['him','her'] },        // L: him/her object (L for heLm)
    't': { he: ['הם','הן'], en: ['they','them'] },          // T: they/them
    'i': { he: ['שלהם','שלהן'], en: ['their','theirs'] },   // I: their/theirs
    'y': { he: ['אתה','את'], en: ['you','you'] },           // Y: you singular
    'u': { he: ['אתם','אתן'], en: ["y'all","y'all"] },      // U: you plural
    'm': { he: ['אני','אני'], en: ['me','me'] },            // M: me
    'r': { he: ['עצמו','עצמה'], en: ['himself','herself'] }, // R: Reflexive
    
    // === PEOPLE & FAMILY ===
    'p': { he: ['איש','אישה'], en: ['man','woman'] },       // P: Person
    'c': { he: ['ילד','ילדה'], en: ['boy','girl'] },        // C: Child
    's': { he: ['בן','בת'], en: ['son','daughter'] },       // S: Son/daughter
    'd': { he: ['אב','אם'], en: ['father','mother'] },      // D: Dad/mom
    'b': { he: ['אח','אחות'], en: ['brother','sister'] },   // B: Brother/sister
    'w': { he: ['בעל','אישה'], en: ['husband','wife'] },    // W: Wedding partner
    'a': { he: ['דוד','דודה'], en: ['uncle','aunt'] },      // A: Aunt/uncle
    'n': { he: ['מר','גברת'], en: ['Mr.','Ms.'] },          // N: Name title
    'k': { he: ['מלך','מלכה'], en: ['king','queen'] },      // K: King/queen
    
    // === HEBREW-ONLY SUFFIXES ===
    'g': { he: ['ים','ות'], en: null },    // G: Grammar plural
    'j': { he: ['ד','ת'], en: null },      // J: present עומד/ת
    'f': { he: ['ן','ת'], en: null },      // F: suffix ישן/ת
    'v': { he: ['י','ת'], en: null },      // V: Verb suffix עברי/ת
    'x': { he: ['ה','ת'], en: null },      // X: suffix יפה/ת
    'z': { he: ['','ת'], en: null },       // Z: suffix רופא/ת
    'e': { he: ['ו','ה'], en: null },      // E: suffix שלו/ה
    'q': { he: ['בּ','ב'], en: null },     // Q: dagesh (Qal)
  };
  
  // Also keep Hebrew letter lookup for backwards compatibility
  const mgByHe = {
    'ה': 'h', 'ו': 'o', 'ך': 'l', 'ם': 't', 'ן': 'i',
    'פ': 'o', 'מ': 'u', 'נ': 'y', 'א': 'm', 'ף': 'r',
    'כ': 'p', 'ל': 's', 'צ': 'c', 'ג': 'd', 'ד': 'b',
    'ז': 'w', 'ש': 'a', 'ת': 'n', 'ר': 'g', 'ח': 'j',
    'י': 'f', 'ע': 'v', 'ס': 'x', 'ט': 'z', 'ק': 'e', 'ב': 'q',
  };
  
  // Determine which key to use
  const key = enKey || mgByHe[he] || he;
  const data = mgByEnKey[key];
  if (!data) return null;
  
  const [m, f] = data.he;
  const [m_en, f_en] = data.en || ['', ''];
  const mf = m && f && m !== f ? m + '/' + f : (m || f);
  const fm = m && f && m !== f ? f + '/' + m : (f || m);
  const mf_en = m_en && f_en && m_en !== f_en ? m_en + '/' + f_en : (m_en || f_en);
  const fm_en = m_en && f_en && m_en !== f_en ? f_en + '/' + m_en : (f_en || m_en);
  return { m, f, m_en, f_en, mf, fm, mf_en, fm_en };
}


// Open MG popup (Alt+letter) - returns true if handled
function openMgPopup(key) {
  const uk = getUniKey(key) || getUniKeyByHe(key) || getUniKeyByEn(key);
  if (!uk) return false;
  
  const mode = getCurrentUkMode();
  const isHebrew = mode === 'he';
  
  // Get MG syllables - use plain or nikud based on Shift state
  const withNikud = nikudMode || shiftHeld;
  const mgSyl = uk.he ? ukBuildMgSyl(uk.he, withNikud) : [];
  
  if (mgSyl.length === 0) {
    // No mgSyl data - just insert single MG if available
    if (uk.mg) {
      const mg = uk.getMg(mode, nikudMode || shiftHeld);
      if (mg) {
        insertAtCursor(mg.display);
        return true;
      }
    }
    return false; // Not handled
  }
  
  // Close any existing popup
  closeMgPopup();
  
  // Create popup
  const popup = document.createElement('div');
  popup.id = 'mg-popup';
  popup.style.cssText = `
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    background: var(--theme-bg-primary); border: 2px solid #059669;
    border-radius: 12px; padding: 16px; z-index: 10000;
    display: flex; flex-direction: column; gap: 8px;
    max-width: min(450px, 90vw); max-height: 80vh; overflow-y: auto;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
  `;
  
  // Title
  const title = document.createElement('div');
  title.style.cssText = 'width: 100%; text-align: center; margin-bottom: 8px; color: var(--theme-text-muted); font-size: 12px;';
  const nikudLabel = withNikud ? ' (מנוקד)' : ' (לא מנוקד)';
  title.textContent = isHebrew ? `בחר/י: זכר | נקבה | אדם${nikudLabel}` : `Choose: Male | Female | Person`;
  popup.appendChild(title);
  
  // Each suffix pair gets a row with 3 buttons
  mgSyl.forEach(opt => {
    const row = document.createElement('div');
    row.style.cssText = `
      display: grid; grid-template-columns: 1fr 1fr 1fr 80px;
      gap: 4px; align-items: center;
    `;
    
    // Helper to create button
    const makeBtn = (text, color, tooltip) => {
      const btn = document.createElement('button');
      btn.style.cssText = `
        padding: 8px 4px; background: ${color}; color: white;
        border: none; border-radius: 6px; cursor: pointer;
        font-size: 16px; font-family: var(--font-hebrew);
        direction: rtl; text-align: center;
        transition: transform 0.1s;
      `;
      btn.textContent = text;
      btn.title = tooltip;
      btn.onmouseenter = () => btn.style.transform = 'scale(1.05)';
      btn.onmouseleave = () => btn.style.transform = 'scale(1)';
      btn.onclick = () => {
        insertAtCursor(text);
        closeMgPopup();
      };
      return btn;
    };
    
    // Male button (blue)
    row.appendChild(makeBtn(opt.m, '#3b82f6', 'זכר'));
    
    // Female button (pink)
    row.appendChild(makeBtn(opt.f, '#ec4899', 'נקבה'));
    
    // Person/combined button (green) - Ivrita notation
    row.appendChild(makeBtn(opt.mf, '#059669', 'אדם'));
    
    // IPA label
    const ipaLabel = document.createElement('span');
    ipaLabel.style.cssText = 'font-size: 11px; color: #60a5fa; text-align: center;';
    ipaLabel.textContent = `/${opt.ipa || ''}/`;
    row.appendChild(ipaLabel);
    
    popup.appendChild(row);
  });
  
  // Close button
  const closeBtn = document.createElement('button');
  closeBtn.style.cssText = `
    position: absolute; top: 4px; right: 4px; background: #ef4444; color: white;
    border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer;
    font-size: 14px; line-height: 1;
  `;
  closeBtn.textContent = '×';
  closeBtn.onclick = closeMgPopup;
  popup.appendChild(closeBtn);
  
  document.body.appendChild(popup);
  
  // Close on click outside
  setTimeout(() => {
    document.addEventListener('click', closeMgPopupOnOutside);
  }, 100);
  
  return true; // Popup was created
}

function closeMgPopup() {
  const popup = document.getElementById('mg-popup');
  if (popup) popup.remove();
  document.removeEventListener('click', closeMgPopupOnOutside);
}

function closeMgPopupOnOutside(e) {
  const popup = document.getElementById('mg-popup');
  if (popup && !popup.contains(e.target)) {
    closeMgPopup();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NUMBER POPUP - Show number variants (circled, keycap, roman, etc.)
// ═══════════════════════════════════════════════════════════════════════════

function openNumberPopup(digit, anchorEl) {
  const variants = NUMBER_VARIANTS[digit];
  if (!variants || variants.length === 0) return false;
  
  // Close any existing popup
  closeNumberPopup();
  
  // Create popup
  const popup = document.createElement('div');
  popup.id = 'number-popup';
  popup.style.cssText = `
    position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
    background: var(--theme-bg-primary); border: 2px solid #3b82f6;
    border-radius: 12px; padding: 16px; z-index: 10000;
    display: flex; flex-direction: column; gap: 8px;
    max-width: min(500px, 95vw); max-height: 80vh; overflow-y: auto;
    box-shadow: 0 8px 32px rgba(0,0,0,0.5);
  `;
  
  // Title
  const title = document.createElement('div');
  title.style.cssText = 'width: 100%; text-align: center; margin-bottom: 8px; color: var(--theme-text-muted); font-size: 14px; font-weight: 600;';
  title.textContent = `Number Variants: ${digit}`;
  popup.appendChild(title);
  
  // Group by category
  const groups = {};
  variants.forEach(v => {
    if (!groups[v.cat]) groups[v.cat] = [];
    groups[v.cat].push(v);
  });
  
  // Render groups
  Object.entries(groups).forEach(([cat, items]) => {
    const catColor = NUMBER_CAT_COLORS[cat] || '#6b7280';
    
    // Category label
    const label = document.createElement('div');
    label.style.cssText = `font-size: 11px; color: ${catColor}; text-transform: uppercase; letter-spacing: 1px; margin-top: 4px;`;
    label.textContent = cat;
    popup.appendChild(label);
    
    // Buttons row
    const row = document.createElement('div');
    row.style.cssText = 'display: flex; flex-wrap: wrap; gap: 4px;';
    
    items.forEach(v => {
      const btn = document.createElement('button');
      btn.style.cssText = `
        padding: 8px 12px; background: var(--theme-bg-secondary); color: var(--theme-text-primary);
        border: 2px solid ${catColor}; border-radius: 8px; cursor: pointer;
        font-size: 20px; font-family: var(--symbol-font, var(--key-font-family));
        min-width: 48px; transition: all 0.15s;
      `;
      btn.textContent = v.s;
      btn.title = v.n;
      btn.onmouseenter = () => {
        btn.style.background = catColor;
        btn.style.color = 'white';
        btn.style.transform = 'scale(1.1)';
      };
      btn.onmouseleave = () => {
        btn.style.background = 'var(--theme-bg-secondary)';
        btn.style.color = 'var(--theme-text-primary)';
        btn.style.transform = 'scale(1)';
      };
      btn.onclick = () => {
        insertAtCursor(v.s);
        closeNumberPopup();
      };
      row.appendChild(btn);
    });
    
    popup.appendChild(row);
  });
  
  // Close button
  const closeBtn = document.createElement('button');
  closeBtn.style.cssText = `
    position: absolute; top: 4px; right: 4px; background: #ef4444; color: white;
    border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer;
    font-size: 14px; line-height: 1;
  `;
  closeBtn.textContent = '×';
  closeBtn.onclick = closeNumberPopup;
  popup.appendChild(closeBtn);
  
  document.body.appendChild(popup);
  
  // Close on click outside
  setTimeout(() => {
    document.addEventListener('click', closeNumberPopupOnOutside);
  }, 100);
  
  return true;
}

function closeNumberPopup() {
  const popup = document.getElementById('number-popup');
  if (popup) popup.remove();
  document.removeEventListener('click', closeNumberPopupOnOutside);
}

function closeNumberPopupOnOutside(e) {
  const popup = document.getElementById('number-popup');
  if (popup && !popup.contains(e.target)) {
    closeNumberPopup();
  }
}

// Check if a key is a number that should have popup
function isNumberKey(key) {
  return NUMBER_VARIANTS.hasOwnProperty(key);
}

// English Ivrita notation rules (similar to Hebrew Ivrita)
// Syntax: word.suffix or word/suffix
// Examples: they.em (they/them), his.er (his/her), actor.ress (actor/actress)
// === ENGLISH IVRITA - Multi-Gender Notation for English ===
// Extends Ivrita principles to English using dot/slash notation
// Works with ANY font - no special font required
// Syntax: male.female or male/female
// Examples: he.she → "he/she", his.er → "his/her", actor.ress → "actor/actress"


// ═══════════════════════════════════════════════════════════════════════════════
// PART 27: EN_IVRITA_RULES
// ═══════════════════════════════════════════════════════════════════════════════

const EN_IVRITA_RULES = {
  // === PRONOUNS ===
  // Subject pronouns
  'he.she': { m: 'he', f: 'she', neutral: 'they', notation: 'he/she' },
  's.he': { m: 'he', f: 'she', neutral: 'they', notation: 's/he' },
  // Object pronouns  
  'him.er': { m: 'him', f: 'her', neutral: 'them', notation: 'him/her' },
  'him.her': { m: 'him', f: 'her', neutral: 'them', notation: 'him/her' },
  // Possessive adjectives
  'his.er': { m: 'his', f: 'her', neutral: 'their', notation: 'his/her' },
  'his.her': { m: 'his', f: 'her', neutral: 'their', notation: 'his/her' },
  // Possessive pronouns
  'his.ers': { m: 'his', f: 'hers', neutral: 'theirs', notation: 'his/hers' },
  'his.hers': { m: 'his', f: 'hers', neutral: 'theirs', notation: 'his/hers' },
  // Reflexive pronouns
  'himself.erself': { m: 'himself', f: 'herself', neutral: 'themself', notation: 'himself/herself' },
  'himself.herself': { m: 'himself', f: 'herself', neutral: 'themself', notation: 'himself/herself' },
  // They/them notation
  'they.em': { m: 'he', f: 'she', neutral: 'they', obj: 'them', notation: 'they/them' },
  
  // === PEOPLE & FAMILY ===
  'man.woman': { m: 'man', f: 'woman', neutral: 'person', notation: 'man/woman' },
  'men.women': { m: 'men', f: 'women', neutral: 'people', notation: 'men/women' },
  'boy.girl': { m: 'boy', f: 'girl', neutral: 'child', notation: 'boy/girl' },
  'son.daughter': { m: 'son', f: 'daughter', neutral: 'child', notation: 'son/daughter' },
  'brother.sister': { m: 'brother', f: 'sister', neutral: 'sibling', notation: 'brother/sister' },
  'father.mother': { m: 'father', f: 'mother', neutral: 'parent', notation: 'father/mother' },
  'dad.mom': { m: 'dad', f: 'mom', neutral: 'parent', notation: 'dad/mom' },
  'husband.wife': { m: 'husband', f: 'wife', neutral: 'spouse', notation: 'husband/wife' },
  'uncle.aunt': { m: 'uncle', f: 'aunt', neutral: 'pibling', notation: 'uncle/aunt' },
  'nephew.niece': { m: 'nephew', f: 'niece', neutral: 'nibling', notation: 'nephew/niece' },
  'grandfather.mother': { m: 'grandfather', f: 'grandmother', neutral: 'grandparent', notation: 'grandfather/grandmother' },
  'grandson.daughter': { m: 'grandson', f: 'granddaughter', neutral: 'grandchild', notation: 'grandson/granddaughter' },
  
  // === TITLES ===
  'mr.ms': { m: 'Mr.', f: 'Ms.', neutral: 'Mx.', notation: 'Mr./Ms.' },
  'mr.mrs': { m: 'Mr.', f: 'Mrs.', neutral: 'Mx.', notation: 'Mr./Mrs.' },
  'sir.madam': { m: 'Sir', f: 'Madam', neutral: 'Ser', notation: 'Sir/Madam' },
  'king.queen': { m: 'king', f: 'queen', neutral: 'monarch', notation: 'king/queen' },
  'prince.ess': { m: 'prince', f: 'princess', neutral: 'royal', notation: 'prince/princess' },
  'lord.lady': { m: 'lord', f: 'lady', neutral: 'liege', notation: 'lord/lady' },
  
  // === PROFESSION SUFFIXES ===
  // -or/-ress pattern
  'actor.ress': { m: 'actor', f: 'actress', neutral: 'actor', notation: 'actor/actress' },
  'waiter.ress': { m: 'waiter', f: 'waitress', neutral: 'server', notation: 'waiter/waitress' },
  // -er/-ress pattern
  'host.ess': { m: 'host', f: 'hostess', neutral: 'host', notation: 'host/hostess' },
  'heir.ess': { m: 'heir', f: 'heiress', neutral: 'heir', notation: 'heir/heiress' },
  'steward.ess': { m: 'steward', f: 'stewardess', neutral: 'flight attendant', notation: 'steward/stewardess' },
  // -man/-woman pattern
  'fire.man.woman': { m: 'fireman', f: 'firewoman', neutral: 'firefighter', notation: 'fireman/firewoman' },
  'police.man.woman': { m: 'policeman', f: 'policewoman', neutral: 'police officer', notation: 'policeman/policewoman' },
  'business.man.woman': { m: 'businessman', f: 'businesswoman', neutral: 'businessperson', notation: 'businessman/businesswoman' },
  'chair.man.woman': { m: 'chairman', f: 'chairwoman', neutral: 'chairperson', notation: 'chairman/chairwoman' },
  'congress.man.woman': { m: 'congressman', f: 'congresswoman', neutral: 'congressperson', notation: 'congressman/congresswoman' },
  'sales.man.woman': { m: 'salesman', f: 'saleswoman', neutral: 'salesperson', notation: 'salesman/saleswoman' },
  'spokesman.woman': { m: 'spokesman', f: 'spokeswoman', neutral: 'spokesperson', notation: 'spokesman/spokeswoman' },
  
  // === LATINO/SPANISH-INFLUENCED ===
  'latino.a': { m: 'Latino', f: 'Latina', neutral: 'Latinx', notation: 'Latino/a' },
  'amigo.a': { m: 'amigo', f: 'amiga', neutral: 'amigue', notation: 'amigo/a' },
  
  // === MISC ===
  'guy.gal': { m: 'guy', f: 'gal', neutral: 'folks', notation: 'guy/gal' },
  'dude.ette': { m: 'dude', f: 'dudette', neutral: 'dude', notation: 'dude/dudette' },
  'hero.ine': { m: 'hero', f: 'heroine', neutral: 'hero', notation: 'hero/heroine' },
  'blond.e': { m: 'blond', f: 'blonde', neutral: 'blonde', notation: 'blond/blonde' },
  'fiance.e': { m: 'fiancé', f: 'fiancée', neutral: 'fiancé', notation: 'fiancé/fiancée' },
};

// English Ivrita conversion functions (work with any font)
function enIvritaToMale(text) {
  // Convert notation to male form: "he.she went" → "he went"
  let result = text;
  for (const [pattern, rule] of Object.entries(EN_IVRITA_RULES)) {
    const regex = new RegExp(pattern.replace(/\./g, '[./]'), 'gi');
    result = result.replace(regex, rule.m);
  }
  // Handle generic X.Y patterns (take first part)
  result = result.replace(/(\w+)[./](\w+)/g, '$1');
  return result;
}

function enIvritaToFemale(text) {
  // Convert notation to female form: "he.she went" → "she went"
  let result = text;
  for (const [pattern, rule] of Object.entries(EN_IVRITA_RULES)) {
    const regex = new RegExp(pattern.replace(/\./g, '[./]'), 'gi');
    result = result.replace(regex, rule.f);
  }
  // Handle generic X.Y patterns (take second part)
  result = result.replace(/(\w+)[./](\w+)/g, '$2');
  return result;
}

function enIvritaToNeutral(text) {
  // Convert notation to neutral form: "he.she went" → "they went"
  let result = text;
  for (const [pattern, rule] of Object.entries(EN_IVRITA_RULES)) {
    if (rule.neutral) {
      const regex = new RegExp(pattern.replace(/\./g, '[./]'), 'gi');
      result = result.replace(regex, rule.neutral);
    }
  }
  // Handle generic X.Y patterns (keep as slash notation or use first)
  result = result.replace(/(\w+)[.](\w+)/g, '$1/$2');
  return result;
}

function enIvritaExpand(text) {
  // Expand notation to full form: "his.er" → "his/her"
  let result = text;
  for (const [pattern, rule] of Object.entries(EN_IVRITA_RULES)) {
    if (rule.notation) {
      const regex = new RegExp(pattern.replace(/\./g, '\\.'), 'gi');
      result = result.replace(regex, rule.notation);
    }
  }
  // Handle generic X.Y patterns → X/Y
  result = result.replace(/(\w+)\.(\w+)/g, '$1/$2');
  return result;
}

// Toggle gender in English text
function enIvritaToggleGender(text, currentGender = 'neutral') {
  const genders = ['male', 'female', 'neutral'];
  const idx = genders.indexOf(currentGender);
  const nextGender = genders[(idx + 1) % 3];
  switch (nextGender) {
    case 'male': return enIvritaToMale(text);
    case 'female': return enIvritaToFemale(text);
    default: return enIvritaToNeutral(text);
  }
}

// UniKey instances

// ═══════════════════════════════════════════════════════════════════════════════
// PART 28: UNIKEYS (Keyboard Mapping)
// ═══════════════════════════════════════════════════════════════════════════════

const UNIKEYS = {
  t: UK({ id:'t', en:'t', EN:'T', he:'א', ipa:'ʔ', syl:ukBuildHeSyl('א','ʔ',{guttural:true}), enSyl:UK_EN_VOWELS.t, mg:ukBuildMg('א','t'), mgSyl:ukBuildMgSyl('א') }),
  c: UK({ id:'c', en:'c', EN:'C', he:'ב', ipa:'v', syl:ukBuildHeSyl('ב','v',{dagesh:'b'}), enSyl:UK_EN_VOWELS.c, mg:ukBuildMg('ב','c'), mgSyl:ukBuildMgSyl('ב') }),
  d: UK({ id:'d', en:'d', EN:'D', he:'ג', ipa:'g', syl:ukBuildHeSyl('ג','g'), enSyl:UK_EN_VOWELS.d, mg:ukBuildMg('ג','d'), mgSyl:ukBuildMgSyl('ג') }),
  s: UK({ id:'s', en:'s', EN:'S', he:'ד', ipa:'d', syl:ukBuildHeSyl('ד','d'), enSyl:UK_EN_VOWELS.s, mg:ukBuildMg('ד','s'), mgSyl:ukBuildMgSyl('ד') }),
  v: UK({ id:'v', en:'v', EN:'V', he:'ה', ipa:'h', syl:ukBuildHeSyl('ה','h',{guttural:true}), enSyl:UK_EN_VOWELS.v, mg:ukBuildMg('ה','v'), mgSyl:ukBuildMgSyl('ה') }),
  u: UK({ id:'u', en:'u', EN:'U', he:'ו', ipa:'v', syl:ukBuildHeSyl('ו','v'), enSyl:UK_EN_VOWELS.u, mg:ukBuildMg('ו','u'), mgSyl:ukBuildMgSyl('ו') }),
  z: UK({ id:'z', en:'z', EN:'Z', he:'ז', ipa:'z', syl:ukBuildHeSyl('ז','z'), enSyl:UK_EN_VOWELS.z, mg:ukBuildMg('ז','z'), mgSyl:ukBuildMgSyl('ז') }),
  j: UK({ id:'j', en:'j', EN:'J', he:'ח', ipa:'ħ', syl:ukBuildHeSyl('ח','ħ',{guttural:true}), enSyl:UK_EN_VOWELS.j, mg:ukBuildMg('ח','j'), mgSyl:ukBuildMgSyl('ח') }),
  y: UK({ id:'y', en:'y', EN:'Y', he:'ט', ipa:'t', syl:ukBuildHeSyl('ט','t'), enSyl:UK_EN_VOWELS.y, mg:ukBuildMg('ט','y'), mgSyl:ukBuildMgSyl('ט') }),
  h: UK({ id:'h', en:'h', EN:'H', he:'י', ipa:'j', syl:ukBuildHeSyl('י','j'), enSyl:UK_EN_VOWELS.h, mg:ukBuildMg('י','h'), mgSyl:ukBuildMgSyl('י') }),
  f: UK({ id:'f', en:'f', EN:'F', he:'כ', ipa:'x', syl:ukBuildHeSyl('כ','x',{dagesh:'k'}), enSyl:UK_EN_VOWELS.f, mg:ukBuildMg('כ','f'), mgSyl:ukBuildMgSyl('כ') }),
  l: UK({ id:'l', en:'l', EN:'L', he:'ך', ipa:'x', syl:ukBuildHeSylFinal('ך','x'), enSyl:UK_EN_VOWELS.l, mg:ukBuildMg('ך','l'), mgSyl:ukBuildMgSyl('ך') }),
  k: UK({ id:'k', en:'k', EN:'K', he:'ל', ipa:'l', syl:ukBuildHeSyl('ל','l'), enSyl:UK_EN_VOWELS.k, mg:ukBuildMg('ל','k'), mgSyl:ukBuildMgSyl('ל') }),
  n: UK({ id:'n', en:'n', EN:'N', he:'מ', ipa:'m', syl:ukBuildHeSyl('מ','m'), enSyl:UK_EN_VOWELS.n, mg:ukBuildMg('מ','n'), mgSyl:ukBuildMgSyl('מ') }),
  o: UK({ id:'o', en:'o', EN:'O', he:'ם', ipa:'m', syl:ukBuildHeSylFinal('ם','m'), enSyl:UK_EN_VOWELS.o, mg:ukBuildMg('ם','o'), mgSyl:ukBuildMgSyl('ם') }),
  b: UK({ id:'b', en:'b', EN:'B', he:'נ', ipa:'n', syl:ukBuildHeSyl('נ','n'), enSyl:UK_EN_VOWELS.b, mg:ukBuildMg('נ','b'), mgSyl:ukBuildMgSyl('נ') }),
  i: UK({ id:'i', en:'i', EN:'I', he:'ן', ipa:'n', syl:ukBuildHeSylFinal('ן','n'), enSyl:UK_EN_VOWELS.i, mg:ukBuildMg('ן','i'), mgSyl:ukBuildMgSyl('ן') }),
  x: UK({ id:'x', en:'x', EN:'X', he:'ס', ipa:'s', syl:ukBuildHeSyl('ס','s'), enSyl:UK_EN_VOWELS.x, mg:ukBuildMg('ס','x'), mgSyl:ukBuildMgSyl('ס') }),
  g: UK({ id:'g', en:'g', EN:'G', he:'ע', ipa:'ʕ', syl:ukBuildHeSyl('ע','ʕ',{guttural:true}), enSyl:UK_EN_VOWELS.g, mg:ukBuildMg('ע','g'), mgSyl:ukBuildMgSyl('ע') }),
  p: UK({ id:'p', en:'p', EN:'P', he:'פ', ipa:'f', syl:ukBuildHeSyl('פ','f',{dagesh:'p'}), enSyl:UK_EN_VOWELS.p, mg:ukBuildMg('פ','p') }),
  ';': UK({ id:';', en:';', EN:':', shift:':', he:'ף', heShift:':', ipa:'f', syl:ukBuildHeSylFinal('ף','f'), mg:ukBuildMg('ף',';') }),
  m: UK({ id:'m', en:'m', EN:'M', he:'צ', ipa:'ts', syl:ukBuildHeSyl('צ','ts'), enSyl:UK_EN_VOWELS.m, mg:ukBuildMg('צ','m'), mgSyl:ukBuildMgSyl('צ') }),
  '.': UK({ id:'.', en:'.', EN:'>', shift:'>', he:'ץ', heShift:'>', ipa:'ts', syl:ukBuildHeSylFinal('ץ','ts') }),
  e: UK({ id:'e', en:'e', EN:'E', he:'ק', ipa:'k', syl:ukBuildHeSyl('ק','k'), enSyl:UK_EN_VOWELS.e, mg:ukBuildMg('ק','e'), mgSyl:ukBuildMgSyl('ק') }),
  r: UK({ id:'r', en:'r', EN:'R', he:'ר', ipa:'ʁ', syl:ukBuildHeSyl('ר','ʁ'), enSyl:UK_EN_VOWELS.r, mg:ukBuildMg('ר','r'), mgSyl:ukBuildMgSyl('ר') }),
  a: UK({ id:'a', en:'a', EN:'A', he:'ש', ipa:'ʃ', syl:ukBuildHeSylShin(), enSyl:UK_EN_VOWELS.a, mg:ukBuildMg('ש','a'), mgSyl:ukBuildMgSyl('ש') }),
  ',': UK({ id:',', en:',', EN:'<', shift:'<', he:'ת', heShift:'<', ipa:'t', syl:ukBuildHeSylTav(), mg:ukBuildMg('ת',','), mgSyl:ukBuildMgSyl('ת') }),
  q: UK({ id:'q', en:'q', EN:'Q', he:'/', ipa:'kw', enSyl:UK_EN_VOWELS.q, mg:ukBuildMg(null,'q') }),
  w: UK({ id:'w', en:'w', EN:'W', he:"'", ipa:'w', enSyl:UK_EN_VOWELS.w, mg:ukBuildMg(null,'w') }),
  '/': UK({ id:'/', en:'/', EN:'?', shift:'?', he:'.', heShift:'?' }),
  "'": UK({ id:"'", en:"'", EN:'"', shift:'"', he:',', heShift:'"' }),
  '`': UK({ id:'`', en:'`', EN:'~', shift:'~', he:'`', heShift:'~' }),
  '1': UK({ id:'1', en:'1', EN:'!', shift:'!', he:'1', heShift:'!' }),
  '2': UK({ id:'2', en:'2', EN:'@', shift:'@', he:'2', heShift:'@' }),
  '3': UK({ id:'3', en:'3', EN:'#', shift:'#', he:'3', heShift:'#' }),
  '4': UK({ id:'4', en:'4', EN:'$', shift:'$', he:'4', heShift:'₪' }),
  '5': UK({ id:'5', en:'5', EN:'%', shift:'%', he:'5', heShift:'%' }),
  '6': UK({ id:'6', en:'6', EN:'^', shift:'^', he:'6', heShift:'^' }),
  '7': UK({ id:'7', en:'7', EN:'&', shift:'&', he:'7', heShift:'&' }),
  '8': UK({ id:'8', en:'8', EN:'*', shift:'*', he:'8', heShift:'*' }),
  '9': UK({ id:'9', en:'9', EN:'(', shift:'(', he:'9', heShift:')' }),
  '0': UK({ id:'0', en:'0', EN:')', shift:')', he:'0', heShift:'(' }),
  '-': UK({ id:'-', en:'-', EN:'_', shift:'_', he:'-', heShift:'_' }),
  '=': UK({ id:'=', en:'=', EN:'+', shift:'+', he:'=', heShift:'+' }),
  '[': UK({ id:'[', en:'[', EN:'{', shift:'{', he:'[', heShift:'{' }),
  ']': UK({ id:']', en:']', EN:'}', shift:'}', he:']', heShift:'}' }),
  '\\': UK({ id:'\\', en:'\\', EN:'|', shift:'|', he:'\\', heShift:'|' }),
};

// UniKey API
function getUniKey(id) { return UNIKEYS[id]; }
function getUniKeyByHe(he) { return Object.values(UNIKEYS).find(k => k.he === he); }
function getUniKeyByEn(en) { return Object.values(UNIKEYS).find(k => k.en === en); }

// Mode management (Caps cycles through)

// ═══════════════════════════════════════════════════════════════════════════════
// PART 29: EN_TO_IPA_PATTERNS
// ═══════════════════════════════════════════════════════════════════════════════

const EN_TO_IPA_PATTERNS = {
  // Common letter patterns
  'a': ['æ', 'eɪ', 'ɑ', 'ə'], 'ai': ['eɪ'], 'ay': ['eɪ'],
  'au': ['ɔ'], 'aw': ['ɔ'], 'e': ['ɛ', 'i', 'ə'], 'ea': ['i', 'ɛ'],
  'ee': ['i'], 'ei': ['eɪ', 'aɪ'], 'ey': ['eɪ', 'i'],
  'i': ['ɪ', 'aɪ', 'i'], 'ie': ['i', 'aɪ'], 'o': ['ɑ', 'oʊ', 'ə'],
  'oa': ['oʊ'], 'oe': ['oʊ'], 'oi': ['ɔɪ'], 'oo': ['u', 'ʊ'],
  'ou': ['aʊ', 'u'], 'ow': ['aʊ', 'oʊ'], 'oy': ['ɔɪ'],
  'u': ['ʌ', 'u', 'ʊ'], 'ue': ['u'], 'ui': ['u', 'ɪ'],
  // Consonants
  'b': ['b'], 'c': ['k', 's'], 'ch': ['tʃ'], 'd': ['d'],
  'f': ['f'], 'g': ['g', 'dʒ'], 'gh': ['g', 'f', ''], 'h': ['h'],
  'j': ['dʒ'], 'k': ['k'], 'l': ['l'], 'm': ['m'], 'n': ['n'],
  'ng': ['ŋ'], 'p': ['p'], 'ph': ['f'], 'qu': ['kw'],
  'r': ['ɹ'], 's': ['s', 'z'], 'sh': ['ʃ'], 't': ['t'],
  'th': ['θ', 'ð'], 'v': ['v'], 'w': ['w'], 'wh': ['w', 'ʍ'],
  'x': ['ks', 'z'], 'y': ['j', 'i', 'aɪ'], 'z': ['z'], 'zh': ['ʒ']
};

// IPA → rhyme ending patterns (for matching)
function getIpaRhymeEnding(ipaString, syllables = 1) {
  // Get the last N vowel+consonant clusters for rhyming
  const vowelPattern = /[aɑæɐeɛəɪioɔøœuʊʌɒyʉɨɯ]/g;
  const matches = [...ipaString.matchAll(vowelPattern)];
  if (matches.length === 0) return ipaString;
  
  const lastVowelIndex = matches[Math.max(0, matches.length - syllables)].index;
  return ipaString.slice(lastVowelIndex);
}

// Convert Hebrew word with nikud to IPA
function hebrewToIpaLegacy(text) {
  // Legacy version - uses lookup tables
  let ipa = '';
  let i = 0;
  while (i < text.length) {
    const char = text[i];
    const nextChar = text[i + 1] || '';
    
    // Check for consonant + dagesh combinations
    const combined = char + nextChar;
    if (typeof hebrewConsonantsToIpa !== 'undefined' && hebrewConsonantsToIpa[combined]) {
      ipa += hebrewConsonantsToIpa[combined];
      i += 2;
      continue;
    }
    
    // Check single consonant
    if (typeof hebrewConsonantsToIpa !== 'undefined' && hebrewConsonantsToIpa[char]) {
      ipa += hebrewConsonantsToIpa[char];
      i++;
      continue;
    }
    
    // Check nikud
    if (typeof hebrewNikudToIpa !== 'undefined' && hebrewNikudToIpa[char]) {
      ipa += hebrewNikudToIpa[char].ipa;
      i++;
      continue;
    }
    
    // Check special combinations (shuruk, cholam male)
    if (typeof hebrewNikudToIpa !== 'undefined' && hebrewNikudToIpa[combined]) {
      ipa += hebrewNikudToIpa[combined].ipa;
      i += 2;
      continue;
    }
    
    i++;
  }
  return ipa;
}

// Convert English word to approximate IPA
function englishToIpaApprox(text) {
  let ipa = '';
  let i = 0;
  const lower = text.toLowerCase();
  
  while (i < lower.length) {
    // Try longer patterns first
    let matched = false;
    for (let len = 3; len >= 1; len--) {
      const pattern = lower.slice(i, i + len);
      if (EN_TO_IPA_PATTERNS[pattern]) {
        ipa += EN_TO_IPA_PATTERNS[pattern][0]; // Use first/most common pronunciation
        i += len;
        matched = true;
        break;
      }
    }
    if (!matched) i++;
  }
  return ipa;
}

// IPA state
let currentIpaTab = 'live';

// === SKIN TONES ===
const skinTones = [
  { code: '', label: 'Default', color: '#FFCC4D' },
  { code: '\u{1F3FB}', label: 'Light', color: '#FFDAB8' },
  { code: '\u{1F3FC}', label: 'Medium-Light', color: '#E0BB95' },
  { code: '\u{1F3FD}', label: 'Medium', color: '#BF8F68' },
  { code: '\u{1F3FE}', label: 'Medium-Dark', color: '#9B643D' },
  { code: '\u{1F3FF}', label: 'Dark', color: '#594539' }
];

// === EMOJI CATEGORIES ===
const emojiCategories = {
  recent: { icon: '🕐', name: 'Recent' },
  smileys: { icon: '😀', name: 'Smileys' },
  people: { icon: '👋', name: 'People' },
  animals: { icon: '🐶', name: 'Animals' },
  food: { icon: '🍎', name: 'Food' },
  travel: { icon: '✈️', name: 'Travel' },
  activities: { icon: '⚽', name: 'Activities' },
  objects: { icon: '💡', name: 'Objects' },
  symbols: { icon: '❤️', name: 'Symbols' },
  flags: { icon: '🏳️', name: 'Flags' }
};

const groupToCategory = {
  'Smileys & Emotion': 'smileys',
  'People & Body': 'people',
  'Component': null,
  'Animals & Nature': 'animals',
  'Food & Drink': 'food',
  'Travel & Places': 'travel',
  'Activities': 'activities',
  'Objects': 'objects',
  'Symbols': 'symbols',
  'Flags': 'flags'
};

const skinToneCodes = new Set(['1F3FB', '1F3FC', '1F3FD', '1F3FE', '1F3FF']);

// === FALLBACK EMOJI DATA ===

// ═══════════════════════════════════════════════════════════════════════════════
// PART 30: HELPER FUNCTIONS (from HTML)
// ═══════════════════════════════════════════════════════════════════════════════


// ═══════════════════════════════════════════════════════════════════════════════
// COMPREHENSIVE TEST & DATA COUNTS
// ═══════════════════════════════════════════════════════════════════════════════

console.log('\n═══════════════════════════════════════════════════════════════════════════════════');
console.log('ADDITIONAL DATA STRUCTURES:');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('SYLLABLE DATA:');
try { console.log('  UK_EN_VOWELS:', Object.keys(UK_EN_VOWELS).length, 'categories'); } catch(e) { console.log('  UK_EN_VOWELS: not loaded'); }
try { console.log('  HE_SYLLABLES_NIKUD:', Object.keys(HE_SYLLABLES_NIKUD).length, 'letters'); } catch(e) { console.log('  HE_SYLLABLES_NIKUD: not loaded'); }
try { console.log('  HE_SYLLABLES_PLAIN:', Object.keys(HE_SYLLABLES_PLAIN).length, 'letters'); } catch(e) { console.log('  HE_SYLLABLES_PLAIN: not loaded'); }
try { console.log('  EN_SYLLABLES:', Object.keys(EN_SYLLABLES).length, 'letters'); } catch(e) { console.log('  EN_SYLLABLES: not loaded'); }
try { console.log('  IPA_UNIKEYS:', Object.keys(IPA_UNIKEYS).length, 'phonemes'); } catch(e) { console.log('  IPA_UNIKEYS: not loaded'); }

console.log('\nRHYME DATA:');
try { console.log('  IPA_RHYME_ENDINGS:', Object.keys(IPA_RHYME_ENDINGS).length, 'endings'); } catch(e) { console.log('  IPA_RHYME_ENDINGS: not loaded'); }
try { console.log('  COMMON_SYLLABLES:', Object.keys(COMMON_SYLLABLES).length, 'patterns'); } catch(e) { console.log('  COMMON_SYLLABLES: not loaded'); }

console.log('\nNIKUD RULES:');
try { console.log('  NIKUD_RULES:', Object.keys(NIKUD_RULES).length, 'rule sets'); } catch(e) { console.log('  NIKUD_RULES: not loaded'); }
try { console.log('  NIKUD_VALIDITY:', Object.keys(NIKUD_VALIDITY).length, 'categories'); } catch(e) { console.log('  NIKUD_VALIDITY: not loaded'); }

console.log('\nKEYBOARD DATA:');
try { console.log('  IPA_KEYBOARD:', Object.keys(IPA_KEYBOARD).length, 'rows'); } catch(e) { console.log('  IPA_KEYBOARD: not loaded'); }
try { console.log('  UNIKEYS:', Object.keys(UNIKEYS).length, 'keys'); } catch(e) { console.log('  UNIKEYS: not loaded'); }

console.log('\nSPELLING DATA:');
try { console.log('  HE_SPELLING_VARIANTS:', Object.keys(HE_SPELLING_VARIANTS).length, 'entries'); } catch(e) { console.log('  HE_SPELLING_VARIANTS: not loaded'); }
try { console.log('  HE_SPELLING_CONVENTIONS:', Object.keys(HE_SPELLING_CONVENTIONS).length, 'rules'); } catch(e) { console.log('  HE_SPELLING_CONVENTIONS: not loaded'); }
try { console.log('  SYLLABLE_PATTERNS:', Object.keys(SYLLABLE_PATTERNS).length, 'patterns'); } catch(e) { console.log('  SYLLABLE_PATTERNS: not loaded'); }
try { console.log('  EN_TO_IPA_PATTERNS:', Object.keys(EN_TO_IPA_PATTERNS).length, 'patterns'); } catch(e) { console.log('  EN_TO_IPA_PATTERNS: not loaded'); }

console.log('\nMULTI-GENDER DATA:');
try { console.log('  MG_SYL_DATA:', Object.keys(MG_SYL_DATA).length, 'entries'); } catch(e) { console.log('  MG_SYL_DATA: not loaded'); }
try { console.log('  EN_IVRITA_RULES:', Object.keys(EN_IVRITA_RULES).length, 'rules'); } catch(e) { console.log('  EN_IVRITA_RULES: not loaded'); }

console.log('\nOTHER:');
try { console.log('  IPA_ENDING_TO_HE:', Object.keys(IPA_ENDING_TO_HE).length, 'mappings'); } catch(e) { console.log('  IPA_ENDING_TO_HE: not loaded'); }


// ═══════════════════════════════════════════════════════════════════════════════
// PART 31: UK_MODES & COMMON_RHYME_ENDINGS
// ═══════════════════════════════════════════════════════════════════════════════

const UK_MODES = ['he', 'en', 'EN'];
let ukModeIndex = 0;
function getUkMode() { return UK_MODES[ukModeIndex]; }
function setUkMode(mode) { const idx = UK_MODES.indexOf(mode); if (idx >= 0) ukModeIndex = idx; return getUkMode(); }
function cycleUkMode() { ukModeIndex = (ukModeIndex + 1) % UK_MODES.length; return getUkMode(); }

const COMMON_RHYME_ENDINGS = IPA_RHYME_ENDINGS;

// ═══════════════════════════════════════════════════════════════════════════════
// PART 32: MG_BRIDGE (Multi-Gender Bridge Data)
// ═══════════════════════════════════════════════════════════════════════════════

const MG_BRIDGE = {
  // === PRONOUNS (work in both languages) ===
  'yuv':  { he: ['הוא','היא'],    en: ['he','she'],    cat: 'pronoun' },
  'nem':  { he: ['הם','הן'],      en: ['they','they'], cat: 'pronoun' },
  'vah':  { he: ['שלו','שלה'],    en: ['his','her'],   cat: 'possessive' },
  
  // === HEBREW-ONLY SUFFIXES (no English equivalent) ===
  'tem':  { he: ['ים','ות'],      en: null, cat: 'he-plural' },   // מורים/ות
  'tad':  { he: ['ד','ת'],        en: null, cat: 'he-present' },  // עומד/ת
  'nat':  { he: ['ן','ת'],        en: null, cat: 'he-suffix' },   // ישן/ת
  'yat':  { he: ['י','ת'],        en: null, cat: 'he-suffix' },   // עברי/ת
  'hat':  { he: ['ה','ת'],        en: null, cat: 'he-suffix' },   // יפה/ת
  'an':   { he: ['א',''],         en: null, cat: 'he-partial' },  // א.נשים
  'tah':  { he: ['','ת'],         en: null, cat: 'he-suffix' },   // רופא/ת
  'nit':  { he: ['ן','נית'],      en: null, cat: 'he-suffix' },   // זמרן/ית
  'rev':  { he: ['',''],          en: null, cat: 'nikud' },       // vowel swap
};





// Convert Ivrita notation between Hebrew and English
function mgBridgeHeToEn(heText) {
  let result = heText;
  for (const [key, bridge] of Object.entries(MG_BRIDGE)) {
    const [heM, heF] = bridge.he;
    const [enM, enF] = bridge.en;
    if (heM && heF && enM && enF) {
      // Replace Hebrew M/F with English M/F
      result = result.replace(new RegExp(heM + '[./]' + heF, 'g'), enM + '/' + enF);
      result = result.replace(new RegExp(heF + '[./]' + heM, 'g'), enF + '/' + enM);
    }
  }
  return result;
}

function mgBridgeEnToHe(enText) {
  let result = enText;
  for (const [key, bridge] of Object.entries(MG_BRIDGE)) {
    const [heM, heF] = bridge.he;
    const [enM, enF] = bridge.en;
    if (heM && heF && enM && enF) {
      // Replace English M/F with Hebrew M/F
      result = result.replace(new RegExp(enM + '[./]' + enF, 'gi'), heM + '/' + heF);
      result = result.replace(new RegExp(enF + '[./]' + enM, 'gi'), heF + '/' + heM);
    }
  }
  return result;
}

