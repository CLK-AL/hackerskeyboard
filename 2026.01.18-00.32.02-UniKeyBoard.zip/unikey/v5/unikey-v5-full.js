// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY V5 FULL - COMPLETE DATA EXTRACTION FROM unikeyboard.html
// ═══════════════════════════════════════════════════════════════════════════════
// Generated: $(date)
// Source: unikeyboard.html (13,960 lines)
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// PART 1: CORE CLASS
// ═══════════════════════════════════════════════════════════════════════════════

class UniKey {
  constructor(data) { Object.assign(this, data); }
  
  label(mode, mods = {}) {
    const { shift, alt, ctrl } = mods;
    if (ctrl) return this.ipa || '';
    if (alt && this.mg) {
      const mf = shift;
      if (mode === 'en' || mode === 'EN') return mf ? this.mg.fm_en : this.mg.mf_en;
      return mf ? this.mg.fm : this.mg.mf;
    }
    if (shift && !alt) {
      if (mode === 'he') {
        if (this.syl && this.syl.length > 0) return this.he + '·';
        return this.he;
      }
      if ((mode === 'en' || mode === 'EN') && this.enSyl && this.enSyl.length > 0) return this.en + '·';
      if (mode === 'en') return this.EN || this.en?.toUpperCase() || this.shift;
      if (mode === 'EN') return this.shift || this.EN;
    }
    if (mode === 'en') return this.en;
    if (mode === 'EN') return this.EN || this.en?.toUpperCase();
    if (mode === 'he') return this.he;
    return this.en;
  }
  
  getSyllables(mode) {
    if (mode === 'he') return this.syl || [];
    if (mode === 'en' || mode === 'EN') return this.enSyl || [];
    return [];
  }
  
  getMg(mode, femaleFirst = false) {
    if (!this.mg) return null;
    const isEn = mode === 'en' || mode === 'EN';
    return {
      display: femaleFirst ? (isEn ? this.mg.fm_en : this.mg.fm) : (isEn ? this.mg.mf_en : this.mg.mf),
      male: isEn ? this.mg.m_en : this.mg.m,
      female: isEn ? this.mg.f_en : this.mg.f,
    };
  }
}

// Factory
const UK = (data) => new UniKey(data);

// ═══════════════════════════════════════════════════════════════════════════════
// PART 2: HEBREW VOWELS (NIKUD)
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_VOWELS = [
  { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  { n: 'ָ', name: 'קָמָץ', ipa: 'ɑ' },
  { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  { n: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
];

const UK_HE_HATAF = [
  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
];

const UK_HE_MALE = [
  { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  { n: 'ֵי', name: 'צֵירֵי מָלֵא', ipa: 'ej' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// PART 3: NIKUD COMPLETE
// ═══════════════════════════════════════════════════════════════════════════════

const NIKUD = {
  // תנועות גדולות
  kamatz:   { n: 'ָ', name: 'קָמָץ', ipa: 'a', ipa_alt: 'o' },
  patach:   { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  tzere:    { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  segol:    { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  chirik:   { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  cholam:   { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  kubutz:   { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  
  // תנועות עם אם קריאה
  chirik_m: { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i' },
  cholam_m: { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  shuruk:   { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u' },
  
  // שווא וחטפים
  shva:     { n: 'ְ', name: 'שְׁוָא', ipa: 'ə', ipa_silent: '' },
  hataf_a:  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'a' },
  hataf_e:  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ɛ' },
  hataf_o:  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'o' },
  
  // דגש ונקודות
  dagesh:   { n: 'ּ', name: 'דָּגֵשׁ', mod: 'double/hard' },
  shin_dot: { n: 'ׁ', name: 'נְקֻדַּת שִׁין', ipa: 'ʃ' },
  sin_dot:  { n: 'ׂ', name: 'נְקֻדַּת שִׂין', ipa: 's' },
  rafe:     { n: 'ֿ', name: 'רָפֶה', mod: 'soft' },
  mappiq:   { n: 'ּ', name: 'מַפִּיק', mod: 'pronounced ה' },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 4: HEBREW LETTERS
// ═══════════════════════════════════════════════════════════════════════════════

const HE_LETTERS = {
  'א': { ipa: 'ʔ', name: 'אָלֶף', type: 'guttural', silent_end: true, en: "'" },
  'ב': { ipa: 'v', ipa_dagesh: 'b', name: 'בֵּית', type: 'bgdkpt', en: 'v', en_dagesh: 'b' },
  'ג': { ipa: 'g', name: 'גִּימֶל', type: 'bgdkpt', en: 'g' },
  'ד': { ipa: 'd', name: 'דָּלֶת', type: 'bgdkpt', en: 'd' },
  'ה': { ipa: 'h', name: 'הֵא', type: 'guttural', silent_end: true, en: 'h' },
  'ו': { ipa: 'v', name: 'וָו', type: 'weak', en: 'v' },
  'ז': { ipa: 'z', name: 'זַיִן', en: 'z' },
  'ח': { ipa: 'ħ', name: 'חֵית', type: 'guttural', en: "ḥ'" },
  'ט': { ipa: 't', name: 'טֵית', type: 'emphatic', en: 't' },
  'י': { ipa: 'j', name: 'יוֹד', type: 'weak', en: 'y' },
  'כ': { ipa: 'x', ipa_dagesh: 'k', name: 'כַּף', type: 'bgdkpt', en: "kh'", en_dagesh: 'k' },
  'ל': { ipa: 'l', name: 'לָמֶד', en: 'l' },
  'מ': { ipa: 'm', name: 'מֵם', en: 'm' },
  'נ': { ipa: 'n', name: 'נוּן', en: 'n' },
  'ס': { ipa: 's', name: 'סָמֶך', en: 's' },
  'ע': { ipa: 'ʕ', name: 'עַיִן', type: 'guttural', en: "'" },
  'פ': { ipa: 'f', ipa_dagesh: 'p', name: 'פֵּא', type: 'bgdkpt', en: 'f', en_dagesh: 'p' },
  'צ': { ipa: 'ts', name: 'צָדִי', type: 'emphatic', en: "ts'" },
  'ק': { ipa: 'k', name: 'קוֹף', type: 'emphatic', en: "k'" },
  'ר': { ipa: 'ʁ', name: 'רֵישׁ', type: 'guttural', en: "r'" },
  'ש': { ipa: 'ʃ', ipa_sin: 's', name: 'שִׁין/שִׂין', type: 'shin', en: 'sh', en_sin: 's' },
  'ת': { ipa: 't', name: 'תָּו', type: 'bgdkpt', en: 't' },
  // Finals
  'ך': { ipa: 'x', base: 'כ', name: 'כַּף סוֹפִית', final: true, en: "kh'" },
  'ם': { ipa: 'm', base: 'מ', name: 'מֵם סוֹפִית', final: true, en: 'm' },
  'ן': { ipa: 'n', base: 'נ', name: 'נוּן סוֹפִית', final: true, en: 'n' },
  'ף': { ipa: 'f', base: 'פ', name: 'פֵּא סוֹפִית', final: true, en: 'f' },
  'ץ': { ipa: 'ts', base: 'צ', name: 'צָדִי סוֹפִית', final: true, en: "ts'" },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 5: IPA VOWELS WITH QUALITY
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_VOWELS = {
  // EXACT MATCHES
  'i': { name: 'close front', he: 'חִירִיק', nikud: 'ִ', male: 'ִי', en: 'ee/ea', quality: 'exact', ex: { he: 'מִי', en: 'see' } },
  'e': { name: 'close-mid front', he: 'צֵירֵי', nikud: 'ֵ', male: 'ֵי', en: 'ay/ei', quality: 'exact', ex: { he: 'בֵּית', en: 'say' } },
  'ɛ': { name: 'open-mid front', he: 'סֶגוֹל', nikud: 'ֶ', en: 'e', quality: 'exact', ex: { he: 'אֶת', en: 'bed' } },
  'a': { name: 'open', he: 'פַּתַח', nikud: 'ַ', en: 'a', quality: 'exact', ex: { he: 'אַב', en: 'father' } },
  'u': { name: 'close back', he: 'שׁוּרוּק', nikud: 'ֻ', male: 'וּ', en: 'oo', quality: 'exact', ex: { he: 'הוּא', en: 'moon' } },
  'o': { name: 'close-mid back', he: 'חוֹלָם', nikud: 'ֹ', male: 'וֹ', en: 'o', quality: 'exact', ex: { he: 'לֹא', en: 'go' } },
  'ə': { name: 'schwa', he: 'שְׁוָא', nikud: 'ְ', en: 'a/u', quality: 'exact', ex: { he: 'בְּ', en: 'about' } },
  
  // APPROXIMATIONS
  'ɪ': { name: 'near-close front', he: 'חִירִיק', nikud: 'ִ', en: 'i', quality: 'approx', warning: '⚠️', ex: { he: 'אִם', en: 'sit' } },
  'æ': { name: 'near-open front', he: '—', nikud: 'ֶ', alt: 'ַ', en: 'a', quality: 'approx', warning: '⚠️ לא קיים בעברית', ex: { en: 'cat' } },
  'ʌ': { name: 'open-mid back', he: 'פַּתַח', nikud: 'ַ', en: 'u', quality: 'approx', warning: '⚠️', ex: { en: 'cup' } },
  'ʊ': { name: 'near-close back', he: 'קֻבּוּץ', nikud: 'ֻ', en: 'oo', quality: 'approx', warning: '⚠️', ex: { he: 'קֻם', en: 'book' } },
  'ɔ': { name: 'open-mid back', he: 'קָמָץ קָטָן', nikud: 'ָ', en: 'aw', quality: 'approx', ex: { he: 'כָּל', en: 'law' } },
  'ɑ': { name: 'open back', he: 'קָמָץ', nikud: 'ָ', en: 'ar', quality: 'near-exact', ex: { he: 'אָב', en: 'father' } },
  'ɜː': { name: 'open-mid central', he: 'סֶגוֹל', nikud: 'ֶ', en: 'er', quality: 'approx', warning: '⚠️⚠️', ex: { en: 'bird' } },
  
  // DIPHTHONGS
  'aɪ': { name: 'diphthong', he: 'פַּתַח+יוֹד', nikud: 'ַי', en: 'i/y/igh', quality: 'near-exact', ex: { he: 'בַּיִת', en: 'my' } },
  'aʊ': { name: 'diphthong', he: 'פַּתַח+וָו', nikud: 'ָאוּ', en: 'ou/ow', quality: 'near-exact', ex: { he: 'אָו', en: 'now' } },
  'ɔɪ': { name: 'diphthong', he: 'חוֹלָם+יוֹד', nikud: 'וֹי', en: 'oi/oy', quality: 'near-exact', ex: { he: 'גּוֹי', en: 'boy' } },
  'eɪ': { name: 'diphthong', he: 'צֵירֵי+יוֹד', nikud: 'ֵי', en: 'ay/ai', quality: 'near-exact', ex: { he: 'יֵשׁ', en: 'day' } },
  'oʊ': { name: 'diphthong', he: 'חוֹלָם', nikud: 'וֹ', en: 'o/ow', quality: 'approx', ex: { he: 'אוֹ', en: 'go' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 6: IPA CONSONANTS
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_CONSONANTS = {
  // Stops
  'p': { name: 'voiceless bilabial', he: 'פּ', en: 'p', ex: { he: 'פֹּה', en: 'pen' } },
  'b': { name: 'voiced bilabial', he: 'בּ', en: 'b', ex: { he: 'בַּיִת', en: 'bat' } },
  't': { name: 'voiceless alveolar', he: 'ת/ט', en: 't', ex: { he: 'תַּם', en: 'top' } },
  'd': { name: 'voiced alveolar', he: 'ד', en: 'd', ex: { he: 'דָּג', en: 'dog' } },
  'k': { name: 'voiceless velar', he: 'כּ/ק', en: 'k', ex: { he: 'כֹּל', en: 'cat' } },
  'g': { name: 'voiced velar', he: 'ג', en: 'g', ex: { he: 'גַּם', en: 'go' } },
  'ʔ': { name: 'glottal stop', he: 'א/ע', en: '—', ex: { he: 'אָב', en: 'uh-oh' } },
  
  // Fricatives
  'f': { name: 'voiceless labiodental', he: 'פ', en: 'f', ex: { he: 'סוֹף', en: 'fan' } },
  'v': { name: 'voiced labiodental', he: 'ב/ו', en: 'v', ex: { he: 'טוֹב', en: 'van' } },
  's': { name: 'voiceless alveolar', he: 'ס/שׂ', en: 's', ex: { he: 'סוּס', en: 'sun' } },
  'z': { name: 'voiced alveolar', he: 'ז', en: 'z', ex: { he: 'זֶה', en: 'zoo' } },
  'ʃ': { name: 'voiceless postalveolar', he: 'שׁ', en: 'sh', ex: { he: 'שָׁם', en: 'she' } },
  'ʒ': { name: 'voiced postalveolar', he: 'ז׳', en: 'si', geresh: true, ex: { en: 'vision' } },
  'x': { name: 'voiceless velar', he: 'כ/ח', en: "kh'", he_unique: true, ex: { he: 'לֶךְ' } },
  'ħ': { name: 'voiceless pharyngeal', he: 'ח', en: "ḥ'", he_unique: true, ex: { he: 'חַם' } },
  'ʕ': { name: 'voiced pharyngeal', he: 'ע', en: "'", he_unique: true, ex: { he: 'עַם' } },
  'h': { name: 'voiceless glottal', he: 'ה', en: 'h', ex: { he: 'הוּא', en: 'hat' } },
  
  // English unique (need geresh in Hebrew)
  'θ': { name: 'voiceless dental', he: 'ת׳', en: 'th', geresh: true, warning: '⚠️', ex: { en: 'thin' } },
  'ð': { name: 'voiced dental', he: 'ד׳', en: 'th', geresh: true, warning: '⚠️', ex: { en: 'the' } },
  
  // Affricates
  'ts': { name: 'voiceless alveolar affricate', he: 'צ', en: "ts'", he_unique: true, ex: { he: 'צַד', en: 'cats' } },
  'tʃ': { name: 'voiceless postalveolar affricate', he: 'צ׳', en: 'ch', geresh: true, ex: { he: 'צ׳יפּ', en: 'chat' } },
  'dʒ': { name: 'voiced postalveolar affricate', he: 'ג׳', en: 'j', geresh: true, ex: { he: 'ג׳ינס', en: 'jam' } },
  
  // Nasals
  'm': { name: 'bilabial nasal', he: 'מ', en: 'm', ex: { he: 'מָה', en: 'man' } },
  'n': { name: 'alveolar nasal', he: 'נ', en: 'n', ex: { he: 'נָא', en: 'no' } },
  'ŋ': { name: 'velar nasal', he: 'נג', en: 'ng', ex: { en: 'sing' } },
  
  // Approximants
  'l': { name: 'alveolar lateral', he: 'ל', en: 'l', ex: { he: 'לֹא', en: 'let' } },
  'ʁ': { name: 'uvular fricative', he: 'ר', en: "r'", he_unique: true, ex: { he: 'רֹאשׁ' } },
  'r': { name: 'alveolar approximant', he: 'ר׳', en: 'r', different_he: true, ex: { en: 'red' } },
  'j': { name: 'palatal approximant', he: 'י', en: 'y', ex: { he: 'יָד', en: 'yes' } },
  'w': { name: 'labio-velar', he: 'ו׳', en: 'w', geresh: true, warning: 'W≠V', ex: { en: 'we' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 7: GERESH MARKING
// ═══════════════════════════════════════════════════════════════════════════════

const GERESH = {
  he_to_en: {
    'צ': { ipa: 'ts', en: "ts'", note: 'צִפּוֹר→ts\'ipor' },
    'ח': { ipa: 'ħ', en: "ḥ'", note: 'חַיִים→ḥ\'ayim' },
    'כ': { ipa: 'x', en: "kh'", note: 'מֶלֶךְ→melekh\'' },
    'ע': { ipa: 'ʕ', en: "'", note: 'עַיִן→\'ayin' },
    'ר': { ipa: 'ʁ', en: "r'", note: 'רֹאשׁ→r\'osh' },
    'ק': { ipa: 'k', en: "k'", note: 'קוֹל→k\'ol' },
  },
  en_to_he: {
    'θ': { en: 'th (voiceless)', he: 'ת׳', ex: ['think→ת׳ִינק', 'three→ת׳רִי'] },
    'ð': { en: 'th (voiced)', he: 'ד׳', ex: ['the→ד׳ָה', 'this→ד׳ִיס'] },
    'tʃ': { en: 'ch', he: 'צ׳', ex: ['chair→צ׳ֵיר', 'child→צ׳ַיילד'] },
    'dʒ': { en: 'j', he: 'ג׳', ex: ['jam→ג׳ֶם', 'judge→ג׳ַדג׳'] },
    'ʒ': { en: 'zh', he: 'ז׳', ex: ['vision→וִיז׳ָן'] },
    'w': { en: 'w', he: 'ו׳', alt: 'וו', ex: ['water→ווֹטֶר'] },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 8: SILENT LETTERS
// ═══════════════════════════════════════════════════════════════════════════════

const SILENT = {
  hebrew: {
    mater_lectionis: {
      'א': { when: 'סוף מילה', ex: ['הוּא', 'קָרָא'] },
      'ה': { when: 'ה סיומת', ex: ['יָפָה', 'גְּדוֹלָה'], voiced: 'הּ' },
      'ו': { when: 'וֹ/וּ', ex: ['אוֹר', 'שׁוּק'] },
      'י': { when: 'ִי/ֵי', ex: ['שִׁיר', 'בֵּית'] },
    },
    shva: {
      na: { mark: 'ְ', ipa: 'ə', ex: ['בְּ', 'שְׁמוֹ'] },
      nach: { mark: 'ְ', ipa: '', ex: ['מֶלֶךְ', 'כָּתְבָה'] },
    },
  },
  english: {
    'kn': { silent: 'k', ipa: '/n/', ex: ['knight', 'knife', 'know'], he: ['נַייט', 'נַייף', 'נוֹ'] },
    'gn': { silent: 'g', ipa: '/n/', ex: ['gnome', 'sign'], he: ['נוֹם', 'סַיין'] },
    'wr': { silent: 'w', ipa: '/r/', ex: ['write', 'wrong'], he: ['רַייט', 'רוֹנג'] },
    'mb': { silent: 'b', ipa: '/m/', ex: ['lamb', 'climb'], he: ['לֶם', 'קְלַיים'] },
    'bt': { silent: 'b', ipa: '/t/', ex: ['debt', 'doubt'], he: ['דֶט', 'דַאוּט'] },
    'igh': { silent: 'gh', ipa: '/aɪ/', ex: ['night', 'light', 'high'], he: ['נַייט', 'לַייט', 'הַיי'] },
    'ough': { silent: 'gh', ipa: 'varies', ex: ['though', 'through', 'thought'] },
    'alk': { silent: 'l', ipa: '/ɔːk/', ex: ['walk', 'talk'], he: ['ווֹק', 'טוֹק'] },
    'alm': { silent: 'l', ipa: '/ɑːm/', ex: ['calm', 'palm'], he: ['קָאם', 'פָּאם'] },
    'ps': { silent: 'p', ipa: '/s/', ex: ['psychology', 'psalm'] },
    'sten': { silent: 't', ipa: '/sn/', ex: ['listen', 'fasten'] },
    'stle': { silent: 't', ipa: '/sl/', ex: ['castle', 'whistle'] },
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 9: MAPPIQ
// ═══════════════════════════════════════════════════════════════════════════════

const MAPPIQ = {
  mark: 'הּ',
  ipa: 'h',
  rule: 'ה נשמעת בסוף מילה',
  examples: {
    with: [
      { he: 'שֶׁלָּהּ', en: "shela'", meaning: 'שלה (נקבה)' },
      { he: 'גָּבֹהַּ', en: "gavoah'", meaning: 'גבוה' },
      { he: 'בֵּיתָהּ', en: "beta'", meaning: 'ביתה' },
    ],
    without: [
      { he: 'יָפָה', en: 'yafa', meaning: 'יפה' },
      { he: 'גְּדוֹלָה', en: 'gdola', meaning: 'גדולה' },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 10: BGDKPT
// ═══════════════════════════════════════════════════════════════════════════════

const BGDKPT = {
  'ב': { with: { letter: 'בּ', ipa: 'b', en: 'b' }, without: { letter: 'ב', ipa: 'v', en: 'v' } },
  'ג': { with: { letter: 'גּ', ipa: 'g', en: 'g' }, without: { letter: 'ג', ipa: 'g', en: 'g' }, classical: { without_ipa: 'ɣ' } },
  'ד': { with: { letter: 'דּ', ipa: 'd', en: 'd' }, without: { letter: 'ד', ipa: 'd', en: 'd' }, classical: { without_ipa: 'ð' } },
  'כ': { with: { letter: 'כּ', ipa: 'k', en: 'k' }, without: { letter: 'כ', ipa: 'x', en: "kh'" } },
  'פ': { with: { letter: 'פּ', ipa: 'p', en: 'p' }, without: { letter: 'פ', ipa: 'f', en: 'f' } },
  'ת': { with: { letter: 'תּ', ipa: 't', en: 't' }, without: { letter: 'ת', ipa: 't', en: 't' }, classical: { without_ipa: 'θ' } },
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 11: ENGLISH CONNECTORS
// ═══════════════════════════════════════════════════════════════════════════════

const UK_EN_CONNECTORS = {
  conj: [
    { word:'and',ipa:'ænd' },{ word:'or',ipa:'ɔːr' },{ word:'but',ipa:'bʌt' },{ word:'so',ipa:'soʊ' },
    { word:'if',ipa:'ɪf' },{ word:'as',ipa:'æz' },{ word:'for',ipa:'fɔːr' },{ word:'yet',ipa:'jet' },
  ],
  prep: [
    { word:'in',ipa:'ɪn' },{ word:'on',ipa:'ɒn' },{ word:'at',ipa:'æt' },{ word:'to',ipa:'tuː' },
    { word:'of',ipa:'ɒv' },{ word:'by',ipa:'baɪ' },{ word:'up',ipa:'ʌp' },{ word:'off',ipa:'ɒf' },
    { word:'with',ipa:'wɪð' },{ word:'from',ipa:'frɒm' },
  ],
  det: [
    { word:'the',ipa:'ðə' },{ word:'a',ipa:'ə' },{ word:'an',ipa:'æn' },
    { word:'this',ipa:'ðɪs' },{ word:'that',ipa:'ðæt' },{ word:'some',ipa:'sʌm' },
  ],
  pron: [
    { word:'I',ipa:'aɪ' },{ word:'you',ipa:'juː' },{ word:'he',ipa:'hiː' },{ word:'she',ipa:'ʃiː' },
    { word:'it',ipa:'ɪt' },{ word:'we',ipa:'wiː' },{ word:'they',ipa:'ðeɪ' },
    { word:'me',ipa:'miː' },{ word:'him',ipa:'hɪm' },{ word:'her',ipa:'hɜːr' },
  ],
  verb: [
    { word:'is',ipa:'ɪz' },{ word:'am',ipa:'æm' },{ word:'are',ipa:'ɑːr' },{ word:'was',ipa:'wɒz' },
    { word:'be',ipa:'biː' },{ word:'have',ipa:'hæv' },{ word:'has',ipa:'hæz' },{ word:'do',ipa:'duː' },
    { word:'can',ipa:'kæn' },{ word:'will',ipa:'wɪl' },{ word:'would',ipa:'wʊd' },{ word:'could',ipa:'kʊd' },
  ],
  quest: [
    { word:'who',ipa:'huː' },{ word:'what',ipa:'wɒt' },{ word:'when',ipa:'wɛn' },{ word:'where',ipa:'wɛr' },
    { word:'why',ipa:'waɪ' },{ word:'how',ipa:'haʊ' },{ word:'which',ipa:'wɪtʃ' },
  ],
  adv: [
    { word:'not',ipa:'nɒt' },{ word:'just',ipa:'dʒʌst' },{ word:'now',ipa:'naʊ' },{ word:'then',ipa:'ðɛn' },
    { word:'here',ipa:'hɪr' },{ word:'there',ipa:'ðɛr' },{ word:'very',ipa:'vɛri' },{ word:'too',ipa:'tuː' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 12: HEBREW CONNECTORS
// ═══════════════════════════════════════════════════════════════════════════════

const UK_HE_CONNECTORS = {
  prefix: [
    { word:'וְ',name:'ו החיבור',ex:'and',ipa:'ve' },
    { word:'בְּ',name:'ב היחס',ex:'in',ipa:'be' },
    { word:'לְ',name:'ל היחס',ex:'to',ipa:'le' },
    { word:'מִ',name:'מ היחס',ex:'from',ipa:'mi' },
    { word:'כְּ',name:'כ הדימוי',ex:'like',ipa:'ke' },
    { word:'הַ',name:'ה הידיעה',ex:'the',ipa:'ha' },
    { word:'שֶׁ',name:'ש הזיקה',ex:'that',ipa:'ʃe' },
  ],
  prep: [
    { word:'אֶל',name:'אל',ex:'to',ipa:'ʔel' },
    { word:'עַל',name:'על',ex:'on',ipa:'ʔal' },
    { word:'עִם',name:'עם',ex:'with',ipa:'ʔim' },
    { word:'אֶת',name:'את',ex:'(obj)',ipa:'ʔet' },
    { word:'בֵּין',name:'בין',ex:'between',ipa:'ben' },
    { word:'עַד',name:'עד',ex:'until',ipa:'ʔad' },
  ],
  conj: [
    { word:'כִּי',name:'כי',ex:'because',ipa:'ki' },
    { word:'אִם',name:'אם',ex:'if',ipa:'ʔim' },
    { word:'אוֹ',name:'או',ex:'or',ipa:'ʔo' },
    { word:'גַּם',name:'גם',ex:'also',ipa:'gam' },
    { word:'אֲבָל',name:'אבל',ex:'but',ipa:'ʔaval' },
  ],
  pron: [
    { word:'אֲנִי',name:'אני',ex:'I',ipa:'ʔani' },
    { word:'אַתָּה',name:'אתה',ex:'you(m)',ipa:'ʔata' },
    { word:'אַתְּ',name:'את',ex:'you(f)',ipa:'ʔat' },
    { word:'הוּא',name:'הוא',ex:'he',ipa:'hu' },
    { word:'הִיא',name:'היא',ex:'she',ipa:'hi' },
    { word:'אֲנַחְנוּ',name:'אנחנו',ex:'we',ipa:'ʔanaħnu' },
    { word:'הֵם',name:'הם',ex:'they(m)',ipa:'hem' },
    { word:'הֵן',name:'הן',ex:'they(f)',ipa:'hen' },
  ],
  quest: [
    { word:'מִי',name:'מי',ex:'who',ipa:'mi' },
    { word:'מָה',name:'מה',ex:'what',ipa:'ma' },
    { word:'אֵיפֹה',name:'איפה',ex:'where',ipa:'ʔefo' },
    { word:'מָתַי',name:'מתי',ex:'when',ipa:'mataj' },
    { word:'לָמָּה',name:'למה',ex:'why',ipa:'lama' },
    { word:'אֵיךְ',name:'איך',ex:'how',ipa:'ʔex' },
  ],
  adv: [
    { word:'לֹא',name:'לא',ex:'no',ipa:'lo' },
    { word:'כֵּן',name:'כן',ex:'yes',ipa:'ken' },
    { word:'עַכְשָׁיו',name:'עכשיו',ex:'now',ipa:'ʔaxʃav' },
    { word:'פֹּה',name:'פה',ex:'here',ipa:'po' },
    { word:'שָׁם',name:'שם',ex:'there',ipa:'ʃam' },
    { word:'מְאֹד',name:'מאוד',ex:'very',ipa:'meʔod' },
  ],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 13: IPA TO NIKUD MAPPING
// ═══════════════════════════════════════════════════════════════════════════════

const IPA_TO_NIKUD = {
  'a': ['patach', 'kamatz', 'hataf_a'],
  'e': ['tzere', 'segol', 'hataf_e'],
  'ɛ': ['segol', 'hataf_e'],
  'i': ['chirik', 'chirik_m'],
  'o': ['cholam', 'cholam_m', 'kamatz', 'hataf_o'],
  'u': ['kubutz', 'shuruk'],
  'ə': ['shva'],
  'ɪ': ['chirik'],
  'ʊ': ['kubutz'],
  'æ': ['segol', 'patach'],
  'ʌ': ['patach'],
  'ɔ': ['kamatz'],
  'ɑ': ['kamatz'],
};

// ═══════════════════════════════════════════════════════════════════════════════
// PART 14: API FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

function getNikudForIpa(ipa) { return IPA_TO_NIKUD[ipa] || []; }
function getIpaVowelInfo(ipa) { return IPA_VOWELS[ipa] || null; }
function getIpaConsonantInfo(ipa) { return IPA_CONSONANTS[ipa] || null; }
function isGuttural(letter) { return HE_LETTERS[letter]?.type === 'guttural'; }
function needsGeresh(sound, dir) { return dir === 'he_to_en' ? !!GERESH.he_to_en[sound] : !!GERESH.en_to_he[sound]; }
function getGereshForm(sound, dir) { return dir === 'he_to_en' ? GERESH.he_to_en[sound]?.en : GERESH.en_to_he[sound]?.he; }
function getSilentPattern(pattern) { return SILENT.english[pattern] || null; }
function isExactMatch(ipa) { return IPA_VOWELS[ipa]?.quality === 'exact'; }
function isApproximate(ipa) { return IPA_VOWELS[ipa]?.quality === 'approx'; }

function applyNikud(letter, ipa, options = {}) {
  const nikudOptions = getNikudForIpa(ipa);
  if (!nikudOptions.length) return letter;
  if (isGuttural(letter) && ipa === 'ə') return letter + NIKUD.hataf_a.n;
  const nikudKey = nikudOptions[0];
  if (options.male && IPA_VOWELS[ipa]?.male) return letter + IPA_VOWELS[ipa].male;
  return letter + NIKUD[nikudKey].n;
}

function getBgdkptSound(letter, hasDagesh) {
  const info = BGDKPT[letter];
  return info ? (hasDagesh ? info.with : info.without) : null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// EXPORTS & TESTS
// ═══════════════════════════════════════════════════════════════════════════════

console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('UNIKEY V5 FULL - COMPLETE DATA EXTRACTION');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('DATA COUNTS:');
console.log('  UniKey class: ✅');
console.log('  UK_HE_VOWELS:', UK_HE_VOWELS.length);
console.log('  UK_HE_HATAF:', UK_HE_HATAF.length);
console.log('  UK_HE_MALE:', UK_HE_MALE.length);
console.log('  NIKUD:', Object.keys(NIKUD).length);
console.log('  HE_LETTERS:', Object.keys(HE_LETTERS).length);
console.log('  IPA_VOWELS:', Object.keys(IPA_VOWELS).length);
console.log('  IPA_CONSONANTS:', Object.keys(IPA_CONSONANTS).length);
console.log('  GERESH.he_to_en:', Object.keys(GERESH.he_to_en).length);
console.log('  GERESH.en_to_he:', Object.keys(GERESH.en_to_he).length);
console.log('  SILENT.english:', Object.keys(SILENT.english).length);
console.log('  BGDKPT:', Object.keys(BGDKPT).length);
console.log('  UK_EN_CONNECTORS:', Object.keys(UK_EN_CONNECTORS).length, 'categories');
console.log('  UK_HE_CONNECTORS:', Object.keys(UK_HE_CONNECTORS).length, 'categories');

console.log('\n═══════════════════════════════════════════════════════════════════════════════════\n');

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    UniKey, UK,
    UK_HE_VOWELS, UK_HE_HATAF, UK_HE_MALE, NIKUD, HE_LETTERS,
    IPA_VOWELS, IPA_CONSONANTS, GERESH, SILENT, MAPPIQ, BGDKPT,
    UK_EN_CONNECTORS, UK_HE_CONNECTORS, IPA_TO_NIKUD,
    getNikudForIpa, getIpaVowelInfo, getIpaConsonantInfo,
    isGuttural, needsGeresh, getGereshForm, getSilentPattern,
    isExactMatch, isApproximate, applyNikud, getBgdkptSound,
  };
}
