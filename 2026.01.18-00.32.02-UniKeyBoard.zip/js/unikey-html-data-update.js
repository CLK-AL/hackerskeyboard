// ═══════════════════════════════════════════════════════════════════════════════
// UNIKEY HTML DATA UPDATE - Replace existing IPA data in unikeyboard.html
// ═══════════════════════════════════════════════════════════════════════════════
// 
// Copy this entire data section to replace the existing IPA_VOWELS, 
// IPA_CONSONANTS, and NIKUD objects in unikeyboard.html
//
// ═══════════════════════════════════════════════════════════════════════════════

// === IPA VOWELS (Complete - Hebrew + English) ===
const IPA_VOWELS = {
  // Pure vowels
  'a':  { type: 'pure', name: 'open front', he: 'פַּתַח', he_mark: 'ַ', he_male: null, en: 'a', ex: { he: 'אַב', en: 'cat' } },
  'ɑ':  { type: 'pure', name: 'open back', he: 'קָמָץ', he_mark: 'ָ', he_male: 'ָא', en: 'a/ar', ex: { he: 'אָב', en: 'father' } },
  'ɛ':  { type: 'pure', name: 'open-mid front', he: 'סֶגוֹל', he_mark: 'ֶ', he_male: 'ֶא', en: 'e/ea', ex: { he: 'אֶת', en: 'bed' } },
  'e':  { type: 'pure', name: 'close-mid front', he: 'צֵירֵי', he_mark: 'ֵ', he_male: 'ֵא', en: 'ay/ei', ex: { he: 'בֵּית', en: 'say' } },
  'i':  { type: 'pure', name: 'close front', he: 'חִירִיק', he_mark: 'ִ', he_male: 'ִי', en: 'ee/ea', ex: { he: 'מִי', en: 'see' } },
  'o':  { type: 'pure', name: 'close-mid back', he: 'חוֹלָם', he_mark: 'ֹ', he_male: 'וֹ', en: 'o/oa', ex: { he: 'לֹא', en: 'go' } },
  'ɔ':  { type: 'pure', name: 'open-mid back', he: 'קָמָץ קָטָן', he_mark: 'ָ', he_male: null, en: 'aw/au', ex: { he: 'כָּל', en: 'law' } },
  'u':  { type: 'pure', name: 'close back', he: 'קֻבּוּץ/שׁוּרוּק', he_mark: 'ֻ', he_male: 'וּ', en: 'oo/u', ex: { he: 'הוּא', en: 'moon' } },
  'ə':  { type: 'reduced', name: 'schwa', he: 'שְׁוָא נָע', he_mark: 'ְ', he_male: null, en: 'a/u', ex: { he: 'בְּ', en: 'about' } },
  
  // Short vowels (English distinctions)
  'ɪ':  { type: 'short', name: 'near-close front', he: 'חִירִיק קָצָר', he_mark: 'ִ', he_male: null, en: 'i', ex: { he: 'אִם', en: 'sit' } },
  'ʊ':  { type: 'short', name: 'near-close back', he: 'קֻבּוּץ קָצָר', he_mark: 'ֻ', he_male: null, en: 'oo', ex: { he: 'קֻם', en: 'book' } },
  'æ':  { type: 'short', name: 'near-open front', he: '—', he_mark: null, he_male: null, en: 'a', ex: { he: '—', en: 'cat' } },
  'ʌ':  { type: 'short', name: 'open-mid back', he: '—', he_mark: null, he_male: null, en: 'u/o', ex: { he: '—', en: 'cup' } },
  'ɒ':  { type: 'short', name: 'open back rounded', he: '—', he_mark: null, he_male: null, en: 'o', ex: { he: '—', en: 'hot' } },
  
  // Long vowels (with length mark ː)
  'iː': { type: 'long', name: 'long close front', he: 'חִירִיק מָלֵא', he_mark: 'ִ', he_male: 'ִי', en: 'ee/ea', ex: { he: 'שִׁיר', en: 'see' } },
  'uː': { type: 'long', name: 'long close back', he: 'שׁוּרוּק', he_mark: 'ֻ', he_male: 'וּ', en: 'oo/ue', ex: { he: 'שׁוּק', en: 'moon' } },
  'ɑː': { type: 'long', name: 'long open back', he: 'קָמָץ', he_mark: 'ָ', he_male: 'ָא', en: 'ar/a', ex: { he: 'אָב', en: 'father' } },
  'ɔː': { type: 'long', name: 'long open-mid back', he: 'קָמָץ קָטָן', he_mark: 'ָ', he_male: null, en: 'or/aw', ex: { he: '—', en: 'saw' } },
  'ɜː': { type: 'long', name: 'long mid central', he: '—', he_mark: null, he_male: null, en: 'er/ir/ur', ex: { he: '—', en: 'bird' } },
  
  // Hataf vowels (ultra-short, gutturals only)
  'ă':  { type: 'hataf', name: 'ultra-short a', he: 'חֲטַף פַּתַח', he_mark: 'ֲ', he_male: null, en: '—', guttural: true, ex: { he: 'אֲנִי', en: '—' } },
  'ĕ':  { type: 'hataf', name: 'ultra-short e', he: 'חֲטַף סֶגוֹל', he_mark: 'ֱ', he_male: null, en: '—', guttural: true, ex: { he: 'אֱמֶת', en: '—' } },
  'ŏ':  { type: 'hataf', name: 'ultra-short o', he: 'חֲטַף קָמָץ', he_mark: 'ֳ', he_male: null, en: '—', guttural: true, ex: { he: 'חֳלִי', en: '—' } },
  
  // Hebrew diphthongs
  'aj': { type: 'diphthong', name: 'a+yod', he: 'פַּתַח+יוֹד', he_mark: 'ַי', he_male: 'ַיְ', en: 'i/igh/y', en_ipa: 'aɪ', ex: { he: 'בַּיִת', en: 'my' } },
  'ej': { type: 'diphthong', name: 'e+yod', he: 'צֵירֵי+יוֹד', he_mark: 'ֵי', he_male: 'ֵיְ', en: 'ay/ai/ei', en_ipa: 'eɪ', ex: { he: 'בֵּית', en: 'day' } },
  'aw': { type: 'diphthong', name: 'a+vav', he: 'פַּתַח+וָו', he_mark: 'ַו', he_male: 'ָו', en: 'ou/ow', en_ipa: 'aʊ', ex: { he: 'תָּו', en: 'now' } },
  'oj': { type: 'diphthong', name: 'o+yod', he: 'חוֹלָם+יוֹד', he_mark: 'ֹי', he_male: 'וֹי', en: 'oi/oy', en_ipa: 'ɔɪ', ex: { he: 'גּוֹי', en: 'boy' } },
  'uj': { type: 'diphthong', name: 'u+yod', he: 'שׁוּרוּק+יוֹד', he_mark: 'וּי', he_male: null, en: 'ui', ex: { he: 'גּוּי', en: 'ruin' } },
  
  // English diphthongs (with Hebrew equivalents)
  'aɪ': { type: 'diphthong', name: 'diphthong', he: 'פַּתַח+יוֹד', he_mark: null, he_male: null, he_equiv: 'aj', en: 'i_e/igh/y', ex: { he: 'עַיִן', en: 'my' } },
  'aʊ': { type: 'diphthong', name: 'diphthong', he: 'פַּתַח+וָו', he_mark: null, he_male: null, he_equiv: 'aw', en: 'ou/ow', ex: { he: 'אָו', en: 'now' } },
  'ɔɪ': { type: 'diphthong', name: 'diphthong', he: 'חוֹלָם+יוֹד', he_mark: null, he_male: null, he_equiv: 'oj', en: 'oi/oy', ex: { he: 'גּוֹי', en: 'boy' } },
  'eɪ': { type: 'diphthong', name: 'diphthong', he: 'צֵירֵי+יוֹד', he_mark: null, he_male: null, he_equiv: 'ej', en: 'a_e/ay/ai', ex: { he: 'יֵשׁ', en: 'day' } },
  'oʊ': { type: 'diphthong', name: 'diphthong', he: 'חוֹלָם', he_mark: null, he_male: null, he_equiv: 'o', en: 'o/oa/ow', ex: { he: 'אוֹ', en: 'go' } },
};

// === IPA CONSONANTS (Complete) ===
const IPA_CONSONANTS = {
  // Stops
  'p':  { name: 'voiceless bilabial', he: 'פּ', he_letters: ['פּ'], en: 'p/pp', ex: { he: 'פֹּה', en: 'pen' } },
  'b':  { name: 'voiced bilabial', he: 'בּ', he_letters: ['בּ'], en: 'b/bb', ex: { he: 'בַּיִת', en: 'bat' } },
  't':  { name: 'voiceless alveolar', he: 'ת/ט', he_letters: ['ת', 'ט'], en: 't/tt', ex: { he: 'תַּם', en: 'top' } },
  'd':  { name: 'voiced alveolar', he: 'ד', he_letters: ['ד'], en: 'd/dd', ex: { he: 'דָּג', en: 'dog' } },
  'k':  { name: 'voiceless velar', he: 'כּ/ק', he_letters: ['כּ', 'ק'], en: 'k/c/ck/ch/qu', ex: { he: 'כֹּל', en: 'cat' } },
  'g':  { name: 'voiced velar', he: 'ג', he_letters: ['ג'], en: 'g/gg', ex: { he: 'גַּם', en: 'go' } },
  'ʔ':  { name: 'glottal stop', he: 'א/ע', he_letters: ['א', 'ע'], en: '—', ex: { he: 'אָב', en: 'uh-oh' } },
  
  // Fricatives
  'f':  { name: 'voiceless labiodental', he: 'פ/ף', he_letters: ['פ', 'ף'], en: 'f/ff/ph/gh', ex: { he: 'סוֹף', en: 'fan' } },
  'v':  { name: 'voiced labiodental', he: 'ב/ו', he_letters: ['ב', 'ו'], en: 'v/ve', ex: { he: 'טוֹב', en: 'van' } },
  'θ':  { name: 'voiceless dental', he: '—', he_letters: [], en: 'th', ex: { he: '—', en: 'thin' } },
  'ð':  { name: 'voiced dental', he: '—', he_letters: [], en: 'th', ex: { he: '—', en: 'the' } },
  's':  { name: 'voiceless alveolar', he: 'ס/שׂ', he_letters: ['ס', 'שׂ'], en: 's/c/ss/sc/ce', ex: { he: 'סוּס', en: 'sun' } },
  'z':  { name: 'voiced alveolar', he: 'ז', he_letters: ['ז'], en: 'z/s/zz', ex: { he: 'זֶה', en: 'zoo' } },
  'ʃ':  { name: 'voiceless postalveolar', he: 'שׁ', he_letters: ['שׁ'], en: 'sh/ti/ci/ssi/si', ex: { he: 'שָׁם', en: 'she' } },
  'ʒ':  { name: 'voiced postalveolar', he: "ז'", he_letters: ["ז'"], en: 'si/su/ge', ex: { he: "ז'וּק", en: 'vision' } },
  'x':  { name: 'voiceless velar', he: 'כ/ח', he_letters: ['כ', 'ח'], en: 'ch/kh', ex: { he: 'לֶךְ', en: 'loch' } },
  'ħ':  { name: 'voiceless pharyngeal', he: 'ח', he_letters: ['ח'], en: '—', ex: { he: 'חַם', en: '—' } },
  'ʕ':  { name: 'voiced pharyngeal', he: 'ע', he_letters: ['ע'], en: '—', ex: { he: 'עַם', en: '—' } },
  'h':  { name: 'voiceless glottal', he: 'ה', he_letters: ['ה'], en: 'h', ex: { he: 'הוּא', en: 'hat' } },
  
  // Affricates
  'ts': { name: 'voiceless alveolar affricate', he: 'צ/ץ', he_letters: ['צ', 'ץ'], en: 'ts/tz/z', ex: { he: 'צַד', en: 'cats' } },
  'tʃ': { name: 'voiceless postalveolar affricate', he: "צ'", he_letters: ["צ'"], en: 'ch/tch/tu', ex: { he: "צ'יפּ", en: 'chat' } },
  'dʒ': { name: 'voiced postalveolar affricate', he: "ג'", he_letters: ["ג'"], en: 'j/dge/ge/gi', ex: { he: "ג'ינס", en: 'jam' } },
  
  // Nasals
  'm':  { name: 'bilabial nasal', he: 'מ/ם', he_letters: ['מ', 'ם'], en: 'm/mm/mb', ex: { he: 'מָה', en: 'man' } },
  'n':  { name: 'alveolar nasal', he: 'נ/ן', he_letters: ['נ', 'ן'], en: 'n/nn/kn/gn', ex: { he: 'נָא', en: 'no' } },
  'ŋ':  { name: 'velar nasal', he: '—', he_letters: [], en: 'ng/n', ex: { he: '—', en: 'sing' } },
  
  // Approximants
  'l':  { name: 'alveolar lateral', he: 'ל', he_letters: ['ל'], en: 'l/ll', ex: { he: 'לֹא', en: 'let' } },
  'ʁ':  { name: 'uvular fricative', he: 'ר', he_letters: ['ר'], en: 'r/rr', ex: { he: 'רַב', en: 'red' } },
  'r':  { name: 'alveolar approximant', he: 'ר', he_letters: ['ר'], en: 'r/rr/wr', ex: { he: 'רַב', en: 'red' } },
  'j':  { name: 'palatal approximant', he: 'י', he_letters: ['י'], en: 'y', ex: { he: 'יָד', en: 'yes' } },
  'w':  { name: 'labial-velar', he: 'ו', he_letters: ['ו'], en: 'w/wh', ex: { he: 'וָו', en: 'we' } },
};

// === NIKUD (Complete with IPA) ===
const NIKUD = {
  // תנועות גדולות (Full vowels)
  kamatz:   { n: 'ָ', name: 'קָמָץ', ipa: 'ɑ', ipa_alt: 'ɔ', male: 'ָא' },
  patach:   { n: 'ַ', name: 'פַּתַח', ipa: 'a', male: null },
  tzere:    { n: 'ֵ', name: 'צֵירֵי', ipa: 'e', male: 'ֵא' },
  segol:    { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ', male: 'ֶא' },
  chirik:   { n: 'ִ', name: 'חִירִיק', ipa: 'i', male: 'ִי' },
  cholam:   { n: 'ֹ', name: 'חוֹלָם', ipa: 'o', male: 'וֹ' },
  kubutz:   { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u', male: 'וּ' },
  
  // תנועות עם אם קריאה (With mater lectionis)
  chirik_m: { n: 'ִי', name: 'חִירִיק מָלֵא', ipa: 'i', ipa_long: 'iː' },
  cholam_m: { n: 'וֹ', name: 'חוֹלָם מָלֵא', ipa: 'o' },
  shuruk:   { n: 'וּ', name: 'שׁוּרוּק', ipa: 'u', ipa_long: 'uː' },
  
  // שווא וחטפים (Shva and Hataf)
  shva:     { n: 'ְ', name: 'שְׁוָא', ipa: 'ə', ipa_silent: '', variants: { na: true, nach: false } },
  hataf_a:  { n: 'ֲ', name: 'חֲטַף פַּתַח', ipa: 'ă', guttural_only: true },
  hataf_e:  { n: 'ֱ', name: 'חֲטַף סֶגוֹל', ipa: 'ĕ', guttural_only: true },
  hataf_o:  { n: 'ֳ', name: 'חֲטַף קָמָץ', ipa: 'ŏ', guttural_only: true },
  
  // דיפתונגים עבריים (Hebrew diphthongs)
  patach_yod: { n: 'ַי', name: 'פַּתַח+יוֹד', ipa: 'aj', en_equiv: 'aɪ' },
  tzere_yod:  { n: 'ֵי', name: 'צֵירֵי+יוֹד', ipa: 'ej', en_equiv: 'eɪ' },
  patach_vav: { n: 'ַו', name: 'פַּתַח+וָו', ipa: 'aw', en_equiv: 'aʊ' },
  cholam_yod: { n: 'וֹי', name: 'חוֹלָם+יוֹד', ipa: 'oj', en_equiv: 'ɔɪ' },
  
  // דגש ונקודות (Dagesh and dots)
  dagesh:   { n: 'ּ', name: 'דָּגֵשׁ', mod: 'double/hard' },
  shin_dot: { n: 'ׁ', name: 'נְקֻדַּת שִׁין', ipa: 'ʃ' },
  sin_dot:  { n: 'ׂ', name: 'נְקֻדַּת שִׂין', ipa: 's' },
  rafe:     { n: 'ֿ', name: 'רָפֶה', mod: 'soft' },
};

// === REVERSE INDEXES (Bidirectional lookup) ===
const IPA_TO_NIKUD = {
  'a':  ['patach'],
  'ɑ':  ['kamatz'],
  'ă':  ['hataf_a'],
  'e':  ['tzere'],
  'ɛ':  ['segol'],
  'ĕ':  ['hataf_e'],
  'i':  ['chirik', 'chirik_m'],
  'o':  ['cholam', 'cholam_m'],
  'ɔ':  ['kamatz'],  // kamatz katan
  'ŏ':  ['hataf_o'],
  'u':  ['kubutz', 'shuruk'],
  'ə':  ['shva'],
  'aj': ['patach_yod'],
  'ej': ['tzere_yod'],
  'aw': ['patach_vav'],
  'oj': ['cholam_yod'],
};

const NIKUD_TO_IPA = {};
Object.entries(NIKUD).forEach(([key, val]) => {
  if (val.ipa) {
    NIKUD_TO_IPA[val.n] = NIKUD_TO_IPA[val.n] || [];
    NIKUD_TO_IPA[val.n].push(val.ipa);
  }
});

const HE_LETTER_TO_IPA = {};
Object.entries(IPA_CONSONANTS).forEach(([ipa, data]) => {
  if (data.he_letters) {
    data.he_letters.forEach(letter => {
      HE_LETTER_TO_IPA[letter] = HE_LETTER_TO_IPA[letter] || [];
      HE_LETTER_TO_IPA[letter].push(ipa);
    });
  }
});

// === API Functions ===
function getNikudForIpa(ipa) {
  return IPA_TO_NIKUD[ipa] || [];
}

function getIpaForNikud(nikudMark) {
  return NIKUD_TO_IPA[nikudMark] || [];
}

function getIpaForHeLetter(letter) {
  return HE_LETTER_TO_IPA[letter] || [];
}

function getHebrewDiphthong(enIpa) {
  const mapping = { 'aɪ': 'aj', 'eɪ': 'ej', 'aʊ': 'aw', 'ɔɪ': 'oj' };
  return mapping[enIpa] || null;
}

function getEnglishDiphthong(heIpa) {
  const mapping = { 'aj': 'aɪ', 'ej': 'eɪ', 'aw': 'aʊ', 'oj': 'ɔɪ' };
  return mapping[heIpa] || null;
}

// === OUTPUT ===
console.log('═══════════════════════════════════════════════════════════════════════════════════');
console.log('HTML DATA UPDATE - Ready to copy to unikeyboard.html');
console.log('═══════════════════════════════════════════════════════════════════════════════════\n');

console.log('IPA_VOWELS entries:', Object.keys(IPA_VOWELS).length);
console.log('IPA_CONSONANTS entries:', Object.keys(IPA_CONSONANTS).length);
console.log('NIKUD entries:', Object.keys(NIKUD).length);
console.log('IPA_TO_NIKUD entries:', Object.keys(IPA_TO_NIKUD).length);
console.log('NIKUD_TO_IPA entries:', Object.keys(NIKUD_TO_IPA).length);
console.log('HE_LETTER_TO_IPA entries:', Object.keys(HE_LETTER_TO_IPA).length);

console.log('\nSample lookups:');
console.log('  getNikudForIpa("aj"):', getNikudForIpa('aj'));
console.log('  getIpaForNikud("ֵי"):', getIpaForNikud('ֵי'));
console.log('  getIpaForHeLetter("שׁ"):', getIpaForHeLetter('שׁ'));
console.log('  getHebrewDiphthong("aɪ"):', getHebrewDiphthong('aɪ'));
console.log('  getEnglishDiphthong("ej"):', getEnglishDiphthong('ej'));
