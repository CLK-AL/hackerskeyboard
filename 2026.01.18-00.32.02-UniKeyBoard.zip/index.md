# 📁 אינדקס קבצים מאורגן

> תאריך עדכון: 2026-01-18
> סה"כ: **83 קבצים** ב-**11 תיקיות**

---

## 🗂️ מבנה תיקיות

```
organized/
├── 📁 backup/          # גיבויים (5)
├── 📁 emoji/           # אמוג'י (7)
├── 📁 fonts/           # פונטים (1)
├── 📁 hebrew-data/     # נתוני עברית (4)
├── 📁 html/            # דפי HTML (1)
├── 📁 js/              # JavaScript כללי (1)
├── 📁 json/            # נתוני JSON (2)
├── 📁 jsx/             # קומפוננטות React (2)
├── 📁 md/              # תיעוד Markdown (9)
├── 📁 py/              # Python (1)
└── 📁 unikey/          # פרויקט UniKey (50)
    ├── 📁 v2/          # גרסה 2 (3)
    ├── 📁 v3/          # גרסה 3 (36)
    ├── 📁 v4/          # גרסה 4 (1)
    ├── 📁 v5/          # גרסה 5 (5)
    └── 📁 v6/          # גרסה 6 (5)
```

---

## 📁 md/ - תיעוד (9 קבצים)

| קובץ | תיאור |
|------|-------|
| README.md | תיעוד ראשי |
| index.md | אינדקס קבצים |
| KAN-STORIES-CATALOG.md | קטלוג סיפורי כאן |
| TODO-WEBXR-COMPLETE.md | משימות WebXR |
| todo-webxr-hebrew.md | משימות WebXR בעברית |
| V6-AGILE-DISCOVERY.md | תכנון V6 אג'ילי |
| v5-data-format-analysis.md | ניתוח פורמט V5 |
| hebrew-nikud-rules.md | חוקי ניקוד |
| hebrew-nikud-complete-rules.md | חוקי ניקוד מלאים |

---

## 📁 emoji/ - אמוג'י (7 קבצים)

| קובץ | תיאור |
|------|-------|
| emoji.txt | 3,943 אמוג'ים מתורגמים |
| emoji-dictionary.txt | מילון (2,696 רשומות) |
| emoji-data-inline.js | נתונים JS inline |
| generate-emoji-data.js | מחולל נתונים |
| generate-hebrew-txt.js | מחולל טקסט עברי |
| generate-compact.js | מחולל קומפקטי |
| parse-emoji-test.js | מפענח emoji-test |

---

## 📁 html/ - דפי HTML (1 קובץ)

| קובץ | תיאור |
|------|-------|
| unikeyboard.html | מקלדת אוניברסלית |

---

## 📁 jsx/ - קומפוננטות React (2 קבצים)

| קובץ | תיאור |
|------|-------|
| full-keyboard.jsx | מקלדת מלאה |
| keyboard-layout-selector.jsx | בורר פריסה |

---

## 📁 py/ - Python (1 קובץ)

| קובץ | תיאור |
|------|-------|
| emoji_loader.py | טוען אמוג'י |

---

## 📁 json/ - נתוני JSON (2 קבצים)

| קובץ | תיאור |
|------|-------|
| fonts.json | נתוני פונטים |
| emoji-data.json | נתוני אמוג'י |

---

## 📁 js/ - JavaScript כללי (1 קובץ)

| קובץ | תיאור |
|------|-------|
| unikey-html-data-update.js | עדכון נתוני HTML |

---

## 📁 hebrew-data/ - נתוני עברית (4 קבצים)

| קובץ | תיאור |
|------|-------|
| en.txt | נתונים אנגלית |
| he.txt | נתונים עברית |
| ipa.txt | נתוני IPA |
| symbols.txt | סמלים |

---

## 📁 fonts/ - פונטים (1 קובץ)

| קובץ | תיאור |
|------|-------|
| README.md | תיעוד פונטים |

---

## 📁 backup/ - גיבויים (5 קבצים)

| קובץ | תיאור |
|------|-------|
| 20251231-033154-unikeyboard.html | גיבוי מקלדת |
| backup-20251231-024300-unikeyboard.html | גיבוי מקלדת |
| unikey-v2-complete.js | גיבוי V2 |
| unikey-v2-design.js | גיבוי V2 עיצוב |
| unikeyboard.html | גיבוי מקלדת ישן |

---

## 📁 unikey/ - פרויקט UniKey (50 קבצים)

### v2/ (3 קבצים)
- unikey-v2-complete.js
- unikey-v2-design.js
- unikey-v2-mg-final.js

### v3/ (36 קבצים)
**תיעוד:**
- unikey-v3-architecture.md
- unikey-v3-design.md
- unikey-v3-summary.md

**מיפויים:**
- unikey-v3-keyboard-map.js
- unikey-v3-keyboard-map-complete.js
- unikey-v3-keyboard.js
- unikey-v3-complete-map.js
- unikey-v3-bidirectional-map.js

**IPA:**
- unikey-v3-ipa-centric.js
- unikey-v3-ipa-universal-map.js
- unikey-v3-full-ipa.js
- unikey-v3-bilingual-ipa-map.js
- unikey-v3-multilingual-ipa.js

**ניקוד:**
- unikey-v3-nikud-engine.js
- unikey-v3-nikud-options.js
- unikey-v3-auto-nikud.js
- unikey-v3-dagesh-mappiq.js

**הברות ותנועות:**
- unikey-v3-syllables.js
- unikey-v3-syllables-ipa.js
- unikey-v3-vowels-comparison.js
- unikey-v3-vowel-approximations.js

**נוסף:**
- unikey-v3-12-keys.js
- unikey-v3-architecture.js
- unikey-v3-complete-extracted.js
- unikey-v3-complete-space.js
- unikey-v3-data-comparison.js
- unikey-v3-detailed-design.js
- unikey-v3-final-model.js
- unikey-v3-mg-3versions.js
- unikey-v3-mg-ipa-mapping.js
- unikey-v3-mg-semantic.js
- unikey-v3-mg-vs-ivrita.js
- unikey-v3-silent-letters.js
- unikey-v3-unified.js
- unikey-v3-unified-keys.js
- unikey-v3-unique-sounds.js

### v4/ (1 קובץ)
- unikey-v4-phonetics.js

### v5/ (5 קבצים)
- unikey-v5-complete.js
- unikey-v5-complete-all.js
- unikey-v5-full.js
- unikey-v5-merged.js
- unikey-v5-package.zip

### v6/ (5 קבצים)
- unikey-v6-2025-ai.zip
- unikey-v6-complete-2025.zip
- unikey-v6-discovery.zip
- unikey-v6-kmp-discovery.zip
- unikey-v6-platform.zip

---

*נוצר אוטומטית ב-2026-01-18*
