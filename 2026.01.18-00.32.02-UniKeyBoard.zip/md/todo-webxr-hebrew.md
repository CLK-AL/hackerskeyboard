# TODO: WebXR PWA Hebrew Diacritics Keyboard

## 🎯 Project Goal
שדרוג UniKey V5 ל-WebXR PWA עם BabylonJS ו-3D CSS

---

## 📋 Phase 1: PWA Foundation

### manifest.json
- [ ] Create manifest with RTL support (`"dir": "rtl"`, `"lang": "he-IL"`)
- [ ] Set `"display": "standalone"` for XR immersion
- [ ] Add icons (192x192, 512x512)
- [ ] Add shortcuts for quick actions

### Service Worker
- [ ] Cache-first strategy for offline XR
- [ ] Cache UniKey assets (HTML, fonts, data)
- [ ] Offline fallback page

---

## 📋 Phase 2: BabylonJS Integration

### 3D Scene Setup
```javascript
// Replace Three.js with BabylonJS
const canvas = document.getElementById('renderCanvas');
const engine = new BABYLON.Engine(canvas, true);
const scene = new BABYLON.Scene(engine);
```

### Hebrew Text in 3D
- [ ] Use BabylonJS GUI for 3D text panels
- [ ] RTL text rendering with `textHorizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_RIGHT`
- [ ] Dynamic texture for niqqud display
- [ ] Font: "David Libre" or "Noto Sans Hebrew"

### Virtual Keyboard in 3D Space
- [ ] Create floating keyboard mesh
- [ ] Map UniKey 4,200+ phonetic keys to 3D buttons
- [ ] Glow effect on hover/select
- [ ] Hebrew letter + niqqud composition panel

---

## 📋 Phase 3: 3D CSS Integration

### CSS 3D Transforms
```css
.keyboard-3d {
  transform-style: preserve-3d;
  perspective: 1000px;
}

.key-3d {
  transform: translateZ(10px);
  transition: transform 0.2s;
}

.key-3d:hover {
  transform: translateZ(30px) scale(1.1);
}
```

### Hybrid Approach
- [ ] BabylonJS for XR immersive mode
- [ ] CSS 3D for inline/fallback mode
- [ ] Seamless transition between modes

---

## 📋 Phase 4: Hebrew Diacritics System

### Unicode Niqqud (from guide)
| Diacritic | Hebrew | Unicode | Key |
|-----------|--------|---------|-----|
| Dagesh | דָּגֵשׁ | U+05BC | ~ |
| Patach | פַּתַח | U+05B7 | 6 |
| Kamatz | קָמַץ | U+05B8 | 7 |
| Tzere | צֵרֵה | U+05B5 | 5 |
| Chirik | חִיּוּק | U+05B4 | 4 |
| Cholam | חוֹלָם | U+05B9 | O |
| Kubuts | קוּבּוּץ | U+05BB | 8 |
| Segol | סֶגוֹל | U+05B6 | 9 |
| Sheva | שְׁוָא | U+05B0 | 0 |
| Shin Dot | שִׁין | U+05C1 | W |
| Sin Dot | שִׂין | U+05C2 | Shift+W |

### Composition Rules
- [ ] Dagesh before vowel ordering
- [ ] Multi-diacritic stacking
- [ ] Visual preview of composed character

---

## 📋 Phase 5: WebXR Features

### Hand Tracking
- [ ] Pinch gesture for key selection
- [ ] Point gesture for hover
- [ ] Two-hand typing support

### Controllers
- [ ] Ray-based pointing
- [ ] Trigger for selection
- [ ] Thumbstick for keyboard position

### Session Management
```javascript
const session = await navigator.xr.requestSession('immersive-vr', {
  requiredFeatures: ['local-floor'],
  optionalFeatures: ['hand-tracking']
});
```

---

## 📋 Phase 6: UniKey Integration

### Migrate from UniKey V5
- [ ] 4,200+ phonetic mappings → 3D key labels
- [ ] 85+ IPA symbols → IPA 3D panel
- [ ] 19 Ivrita rules → MG mode in XR
- [ ] 12 PUA glyphs → MGHebrew font support
- [ ] Rhymes finder → 3D results display

### New XR-Specific Features
- [ ] Spatial text placement (write in air)
- [ ] Voice input + niqqud overlay
- [ ] Gesture shortcuts for common words
- [ ] Eye tracking for key selection (if available)

---

## 📋 Phase 7: Testing & Deployment

### Testing
- [ ] WebXR Emulator Chrome extension
- [ ] Quest browser testing
- [ ] Samsung Galaxy XR testing
- [ ] Fallback to 2D mode

### Deployment
- [ ] HTTPS required for WebXR
- [ ] GitHub Pages or Vercel
- [ ] PWA installability check

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│  WebXR Application Layer (BabylonJS)                    │
│  - Immersive 3D rendering                               │
│  - Hand tracking input                                  │
│  - 3D Hebrew keyboard mesh                              │
├─────────────────────────────────────────────────────────┤
│  UniKey Integration Layer                               │
│  - 4,200+ phonetic mappings                             │
│  - Niqqud composition engine                            │
│  - Ivrita MG processing                                 │
├─────────────────────────────────────────────────────────┤
│  3D CSS Fallback Layer                                  │
│  - CSS transforms for non-XR                            │
│  - Responsive 2D/3D hybrid                              │
├─────────────────────────────────────────────────────────┤
│  PWA Services                                           │
│  - Service Worker (offline)                             │
│  - IndexedDB (document storage)                         │
│  - manifest.json (installability)                       │
└─────────────────────────────────────────────────────────┘
```

---

## 📚 Resources

- BabylonJS Docs: https://doc.babylonjs.com/
- WebXR Device API: https://www.w3.org/TR/webxr/
- BabylonJS WebXR: https://doc.babylonjs.com/features/featuresDeepDive/webXR
- Hebrew Unicode: https://unicode.org/charts/PDF/U0590.pdf

---

## 🗓️ Timeline Estimate

| Phase | Duration | Dependencies |
|-------|----------|--------------|
| PWA Foundation | 1 day | - |
| BabylonJS Setup | 2 days | Phase 1 |
| 3D CSS Fallback | 1 day | - |
| Hebrew Diacritics | 2 days | UniKey V5 |
| WebXR Features | 3 days | Phase 2 |
| UniKey Migration | 2 days | Phase 4 |
| Testing | 2 days | All |
| **Total** | **~2 weeks** | |

