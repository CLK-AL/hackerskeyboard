# V5 JS Code Analysis → Recommended V6 Data Format

## V5 Core Data Structures

### 1. UK_HE_VOWELS (Hebrew Nikud)
```javascript
const UK_HE_VOWELS = [
  { n: 'ַ', name: 'פַּתַח', ipa: 'a' },
  { n: 'ָ', name: 'קָמָץ', ipa: 'ɑ' },
  { n: 'ֶ', name: 'סֶגוֹל', ipa: 'ɛ' },
  { n: 'ֵ', name: 'צֵירֵי', ipa: 'e' },
  { n: 'ִ', name: 'חִירִיק', ipa: 'i' },
  { n: 'ֹ', name: 'חוֹלָם', ipa: 'o' },
  { n: 'ֻ', name: 'קֻבּוּץ', ipa: 'u' },
  { n: 'ְ', name: 'שְׁוָא', ipa: 'ə' },
];
```

### 2. UK_EN_VOWELS (English syllables by consonant)
```javascript
const UK_EN_VOWELS = {
  a: [
    { syl:'a', ipa:'æ', ex:'cat' },
    { syl:'ai', ipa:'eɪ', ex:'rain' },
    { syl:'ar', ipa:'ɑːr', ex:'car' },
  ],
  b: [
    { syl:'ba', ipa:'bæ', ex:'bat' },
    { syl:'be', ipa:'biː', ex:'be' },
    { syl:'bl', ipa:'bl', ex:'blue' },
  ],
  // ...keyed by consonant
};
```

### 3. UniKey (Keyboard Key)
```javascript
UK({ 
  id:'t',           // physical key
  en:'t',           // English lowercase
  EN:'T',           // English uppercase
  he:'א',           // Hebrew letter
  ipa:'ʔ',          // IPA consonant
  syl:[...],        // Hebrew syllables (generated)
  enSyl:[...],      // English syllables (from UK_EN_VOWELS)
  mg:{...},         // MG pair data
  mgSyl:[...],      // MG syllables
})
```

### 4. Hebrew Syllable (from ukBuildHeSyl)
```javascript
{ text: 'בַּ', name: 'פַּתַח', ipa: 'ba', type: 'vowel' }
{ text: 'בָּ', name: 'קָמָץ', ipa: 'bɑ', type: 'vowel' }
{ text: 'בּוּ', name: 'שׁוּרוּק', ipa: 'bu', type: 'male' }
{ text: 'בּוֹ', name: 'חוֹלָם מָלֵא', ipa: 'bo', type: 'male' }
```

### 5. MG Pairs (from ukBuildMg)
```javascript
{ 
  he: ['הוא','היא'],     // Hebrew M/F
  en: ['he','she'],       // English M/F
  mf: 'הוא/היא',          // Display M-first
  fm: 'היא/הוא',          // Display F-first
  mf_en: 'he/she',
  fm_en: 'she/he',
  m: 'הוא', f: 'היא',
  m_en: 'he', f_en: 'she',
}
```

---

## Recommended V6 Text Format

### Format Spec: TSV-like with IPA as key

```
# Format: key<TAB>type<TAB>fields...<TAB># comment [parent]
```

---

### he-nikud.txt (Matches UK_HE_VOWELS)
```tsv
# Hebrew Nikud - Vowel points
# key	type	char	name	ipa
patach	vowel	ַ	פַּתַח	a
kamatz	vowel	ָ	קָמָץ	ɑ
segol	vowel	ֶ	סֶגוֹל	ɛ
tzere	vowel	ֵ	צֵירֵי	e
chirik	vowel	ִ	חִירִיק	i
cholam	vowel	ֹ	חוֹלָם	o
kubutz	vowel	ֻ	קֻבּוּץ	u
shva	vowel	ְ	שְׁוָא	ə
# Hatafim
hataf-a	hataf	ֲ	חֲטַף פַּתַח	a
hataf-e	hataf	ֱ	חֲטַף סֶגוֹל	ɛ
hataf-o	hataf	ֳ	חֲטַף קָמָץ	o
# Male (full spelling)
cholam-m	male	וֹ	חוֹלָם מָלֵא	o
shuruk	male	וּ	שׁוּרוּק	u
chirik-m	male	ִי	חִירִיק מָלֵא	i
tzere-m	male	ֵי	צֵירֵי מָלֵא	ej
```

---

### en-syllables.txt (Matches UK_EN_VOWELS)
```tsv
# English Syllables by consonant key
# parent	syl	ipa	ex
a	a	æ	cat
a	a	eɪ	take
a	ai	eɪ	rain
a	ay	eɪ	day
a	ar	ɑːr	car
a	aw	ɔː	saw
b	ba	bæ	bat
b	be	biː	be
b	bi	bɪ	bit
b	bl	bl	blue
b	br	br	brown
t	ta	tæ	tap
t	te	tiː	tea
t	th	θ	thin
t	th	ð	the
t	tr	tr	try
```

---

### he-syllables.txt (Matches ukBuildHeSyl output)
```tsv
# Hebrew Syllables: letter + nikud
# parent	text	name	ipa	type
א	אַ	פַּתַח	ʔa	vowel
א	אָ	קָמָץ	ʔɑ	vowel
א	אֲ	חֲטַף פַּתַח	ʔa	hataf
ב	בַּ	פַּתַח	ba	vowel
ב	בָּ	קָמָץ	bɑ	vowel
ב	בּוֹ	חוֹלָם מָלֵא	bo	male
ב	בּוּ	שׁוּרוּק	bu	male
# Without dagesh (soft bet = v)
ב.soft	בַ	פַּתַח	va	vowel
ב.soft	בָ	קָמָץ	vɑ	vowel
# Shin vs Sin
ש.shin	שַׁ	שִׁין פַּתַח	ʃa	vowel
ש.sin	שַׂ	שִׂין פַּתַח	sa	vowel
```

---

### ipa-syllables.txt (Universal IPA bridge)
```tsv
# IPA Syllables - CV/CVC patterns
# ipa	type	he	en
ba	cv	בַּ	ba
be	cv	בֵּ	be,bee
bi	cv	בִּ	bi,bee
bo	cv	בֹּ	bo,bow
bu	cv	בֻּ	bu,boo
am	cvc	עַם,שָׁם	am,ham,jam
im	cvc	מַיִם,יָמִים	him,swim
om	cvc	יוֹם,שָׁלוֹם	home,dome
```

---

### mg-pairs.txt (Matches ukBuildMg)
```tsv
# MG Pairs - Gender pairs with semantic keys
# mg-id	key	he-m	he-f	en-m	en-f	category
MG-1	h	הוא	היא	he	she	pronoun-subj
MG-2	l	אותו	אותה	him	her	pronoun-obj
MG-3	o	שלו	שלה	his	her	possessive
MG-4	t	הם	הן	they	they	pronoun-pl
MG-5	im	-ים	-ות	-s	-s	plural-suffix
MG-6	ed	-ֵד	-ֶת	-ed	-ed	verb-past
MG-7	y	אתה	את	you	you	pronoun-2s
```

---

### keyboard-map.txt (Matches UNIKEYS)
```tsv
# Keyboard Key Mapping
# key	en	EN	he	ipa	opts
t	t	T	א	ʔ	guttural
c	c	C	ב	v	dagesh=b
d	d	D	ג	g	
s	s	S	ד	d	
v	v	V	ה	h	guttural
u	u	U	ו	v	
z	z	Z	ז	z	
j	j	J	ח	ħ	guttural
y	y	Y	ט	t	
h	h	H	י	j	
f	f	F	כ	x	dagesh=k
k	k	K	ל	l	
n	n	N	מ	m	
b	b	B	נ	n	
x	x	X	ס	s	
g	g	G	ע	ʕ	guttural
p	p	P	פ	f	dagesh=p
e	e	E	צ	ts	
r	r	R	ק	k	
w	w	W	ר	ʁ	
a	a	A	ש	ʃ	shin
q	q	Q	ת	t	
```

---

## Kotlin Data Classes (Matching V5)

```kotlin
// Matches UK_HE_VOWELS array item
@Serializable
data class HeNikud(
    val key: String,    // "patach"
    val type: String,   // "vowel", "hataf", "male"
    val char: String,   // "ַ"
    val name: String,   // "פַּתַח"
    val ipa: String,    // "a"
)

// Matches UK_EN_VOWELS[x] array item
@Serializable
data class EnSyllable(
    val parent: String, // "a", "b", "t" (consonant key)
    val syl: String,    // "ai", "ba", "th"
    val ipa: String,    // "eɪ", "bæ", "θ"
    val ex: String,     // "rain", "bat", "thin"
)

// Matches ukBuildHeSyl output item
@Serializable
data class HeSyllable(
    val parent: String, // "א", "ב", "ב.soft"
    val text: String,   // "בַּ"
    val name: String,   // "פַּתַח"
    val ipa: String,    // "ba"
    val type: String,   // "vowel", "male", "hataf", "dagesh"
)

// Matches ukBuildMg output
@Serializable
data class MgPair(
    val mgId: String,   // "MG-1"
    val key: String,    // "h" (semantic key)
    val heM: String,    // "הוא"
    val heF: String,    // "היא"
    val enM: String,    // "he"
    val enF: String,    // "she"
    val category: String, // "pronoun-subj"
)

// Matches UNIKEYS entry
@Serializable
data class KeyboardKey(
    val key: String,    // "t" (physical key)
    val en: String,     // "t"
    val EN: String,     // "T"
    val he: String,     // "א"
    val ipa: String,    // "ʔ"
    val opts: Map<String, String> = emptyMap(), // {guttural, dagesh}
)
```

---

## Parser Code (Kotlin)

```kotlin
fun parseHeNikud(lines: List<String>): List<HeNikud> = 
    lines.filter { !it.startsWith("#") && it.isNotBlank() }
         .map { it.split("\t") }
         .map { HeNikud(it[0], it[1], it[2], it[3], it[4]) }

fun parseEnSyllables(lines: List<String>): Map<String, List<EnSyllable>> =
    lines.filter { !it.startsWith("#") && it.isNotBlank() }
         .map { it.split("\t") }
         .map { EnSyllable(it[0], it[1], it[2], it[3]) }
         .groupBy { it.parent }

fun parseHeSyllables(lines: List<String>): Map<String, List<HeSyllable>> =
    lines.filter { !it.startsWith("#") && it.isNotBlank() }
         .map { it.split("\t") }
         .map { HeSyllable(it[0], it[1], it[2], it[3], it[4]) }
         .groupBy { it.parent }

fun parseMgPairs(lines: List<String>): Map<String, MgPair> =
    lines.filter { !it.startsWith("#") && it.isNotBlank() }
         .map { it.split("\t") }
         .map { MgPair(it[0], it[1], it[2], it[3], it[4], it[5], it[6]) }
         .associateBy { it.mgId }
```

---

## File Structure Summary

```
data/
├── he-nikud.txt          # UK_HE_VOWELS + UK_HE_HATAF + UK_HE_MALE
├── en-syllables.txt      # UK_EN_VOWELS
├── he-syllables.txt      # ukBuildHeSyl output
├── ipa-syllables.txt     # Universal bridge
├── mg-pairs.txt          # ukBuildMg mappings
└── keyboard-map.txt      # UNIKEYS physical→logical
```

---

## Key Design Decisions

1. **TSV format** - Simple, matches JS object structure
2. **Parent column** - Groups items like V5's keyed objects
3. **Type column** - Distinguishes vowel/hataf/male/dagesh
4. **IPA as bridge** - Same as V5 architecture
5. **Separate files** - Mirrors V5's separate const declarations
6. **Comment lines** - # prefix, ignored by parser
7. **No nested objects** - Flat structure, parent references

This format:
- Maps 1:1 to V5 JS data structures
- Is human-readable and editable
- Parses to same runtime structures
- Serializes to MessagePack efficiently
