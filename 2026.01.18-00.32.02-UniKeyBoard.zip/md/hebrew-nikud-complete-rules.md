# כללי הניקוד העברי המלאים - מדריך לפי אות
# Complete Hebrew Nikud Rules - Per-Letter Reference

---

## א (Aleph / אָלֶף)

### Classification / סיווג
- **Category:** Guttural (גרונית)
- **Cannot take:** Dagesh (דגש)
- **Special:** Requires chataf vowels instead of simple shva

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Example | Status |
|------|-----------|-----------|---------|--------|
| ָ | Kamatz | קָמָץ | אָב | ✓ Valid |
| ַ | Patach | פַּתָח | אַף | ✓ Valid |
| ֵ | Tzere | צֵירֵי | אֵם | ✓ Valid |
| ֶ | Segol | סֶגּוֹל | אֶרֶץ | ✓ Valid |
| ִ | Chirik | חִירִיק | אִישׁ | ✓ Valid |
| ֹ | Cholam | חוֹלָם | אֹהֶל | ✓ Valid |
| ֻ | Kubutz | קֻבּוּץ | אֻמָּה | ✓ Valid |
| ֲ | Chataf Patach | חֲטַף פַּתָח | אֲנִי | ✓ **Required** |
| ֱ | Chataf Segol | חֲטַף סֶגּוֹל | אֱלֹהִים | ✓ **Required** |
| ֳ | Chataf Kamatz | חֲטַף קָמָץ | אֳנִיָּה | ✓ **Required** |
| ְ | Shva | שְׁוָא | — | ⚠ Rare (usually chataf) |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ּ | Dagesh | Gutturals cannot be doubled | גרוניות לא מוכפלות |
| ׁ | Shin dot | Only for ש | רק לשין |
| ׂ | Sin dot | Only for ש | רק לשין |
| ֿ | Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

### Rules / כללים
1. **EN:** When grammar requires vocal shva, use chataf vowels instead
2. **HE:** כאשר הדקדוק דורש שווא נע, משתמשים בחטפים במקומו
3. **EN:** Aleph often serves as a vowel letter (mater lectionis)
4. **HE:** אל״ף משמשת לעתים כאם קריאה

---

## ב (Bet/Vet / בֵּית)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Dual pronunciation:** בּ = /b/, ב = /v/
- **Takes:** Both Dagesh Lene and Dagesh Chazak

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Result | Status |
|------|-----------|-----------|--------|--------|
| ּ | Dagesh Lene | דָּגֵשׁ קַל | בּ = /b/ | ✓ Valid |
| ּ | Dagesh Chazak | דָּגֵשׁ חָזָק | בּ = /bb/ | ✓ Valid |
| ֿ | Rafe | רָפֶה | ב = /v/ | ✓ Valid (historical) |
| All vowels | כל התנועות | — | — | ✓ Valid |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ֱֲֳ | Chataf vowels | Not a guttural | לא גרונית |
| ׁׂ | Shin/Sin dots | Only for ש | רק לשין |

### Dagesh Rules / כללי דגש
1. **EN:** Dagesh Lene at word beginning → בּ /b/
2. **HE:** דגש קל בתחילת מילה → בּ /ב/
3. **EN:** After vowel within word → ב /v/ (no dagesh)
4. **HE:** אחרי תנועה בתוך מילה → ב /ו/ (ללא דגש)
5. **EN:** After silent shva → בּ /b/
6. **HE:** אחרי שווא נח → בּ /ב/

### Examples / דוגמאות
- בַּיִת (bayit) - house - with dagesh
- אָב (av) - father - without dagesh
- שַׁבָּת (shabbat) - Sabbath - dagesh chazak (gemination)

---

## ג (Gimel / גִּימֶל)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Historical pronunciation:** גּ = /g/, ג = /ɣ/ (merged in Modern Hebrew)
- **Modern Hebrew:** Both pronounced /g/

### Valid Marks / סימנים תקינים

| Mark | Name | Historical | Modern | Status |
|------|------|------------|--------|--------|
| ּ | Dagesh | גּ = /g/ | /g/ | ✓ Valid |
| ֿ | Rafe | ג = /ɣ/ | /g/ | ✓ Historical only |
| All vowels | כל התנועות | — | — | ✓ Valid |

### Invalid Marks / סימנים לא תקינים
- Chataf vowels (חטפים) - not a guttural
- Shin/Sin dots (נקודות שין/שׂין) - only for ש

---

## ד (Dalet / דָּלֶת)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Historical pronunciation:** דּ = /d/, ד = /ð/ (merged in Modern Hebrew)
- **Modern Hebrew:** Both pronounced /d/

### Valid Marks / סימנים תקינים

| Mark | Name | Historical | Modern | Status |
|------|------|------------|--------|--------|
| ּ | Dagesh | דּ = /d/ | /d/ | ✓ Valid |
| ֿ | Rafe | ד = /ð/ | /d/ | ✓ Historical only |
| All vowels | כל התנועות | — | — | ✓ Valid |

### Invalid Marks / סימנים לא תקינים
- Chataf vowels (חטפים) - not a guttural
- Shin/Sin dots (נקודות שין/שׂין) - only for ש

---

## ה (He / הֵא)

### Classification / סיווג
- **Category:** Guttural (גרונית)
- **Cannot take:** Dagesh (except Mappiq on final ה)
- **Special:** Mappiq (מַפִּיק) marks consonantal final ה

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Usage | Status |
|------|-----------|-----------|-------|--------|
| ָ | Kamatz | קָמָץ | הָאָרֶץ | ✓ Valid |
| ַ | Patach | פַּתָח | הַבַּיִת | ✓ Valid |
| ֵ | Tzere | צֵירֵי | הֵם | ✓ Valid |
| ֶ | Segol | סֶגּוֹל | הֶבֶל | ✓ Valid |
| ִ | Chirik | חִירִיק | הִיא | ✓ Valid |
| ֹ | Cholam | חוֹלָם | הוֹלֵךְ | ✓ Valid |
| ֻ | Kubutz | קֻבּוּץ | הֻקַּם | ✓ Valid |
| ֲ | Chataf Patach | חֲטַף פַּתָח | הֲלֹא | ✓ **Required** |
| ֱ | Chataf Segol | חֲטַף סֶגּוֹל | הֱיוֹת | ✓ **Required** |
| ֳ | Chataf Kamatz | חֲטַף קָמָץ | הֳמַר | ✓ **Required** |
| ּ | Mappiq | מַפִּיק | אַרְצָהּ | ✓ **Final ה only** |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ּ | Dagesh (non-final) | Gutturals cannot be doubled | גרוניות לא מוכפלות |
| ׁׂ | Shin/Sin dots | Only for ש | רק לשין |
| ֿ | Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

### Mappiq Rules / כללי מפיק
1. **EN:** Mappiq only on FINAL ה to indicate consonantal /h/
2. **HE:** מפיק רק על ה׳ סופית לציון עיצור /ה/
3. **EN:** Marks 3rd person feminine possessive: בֵּיתָהּ (her house)
4. **HE:** מסמן שייכות נקבה גוף שלישי: בֵּיתָהּ

### Examples / דוגמאות
- הָאָדָם (ha'adam) - the man - regular ה with vowel
- אַרְצָהּ (artzah) - her land - with mappiq
- גָּבְהָה (govhah) - height - silent final ה (no mappiq)

---

## ו (Vav / וָו)

### Classification / סיווג
- **Category:** Special - both consonant AND vowel letter
- **As consonant:** Takes all vowels, pronounced /v/
- **As vowel:** Shuruk (וּ) = /u/, Cholam male (וֹ) = /o/

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Function | Status |
|------|-----------|-----------|----------|--------|
| ּ | Shuruk | שׁוּרוּק | Vav IS the /u/ vowel | ✓ Special |
| ֹ | Cholam male | חוֹלָם מָלֵא | Vav IS the /o/ vowel | ✓ Special |
| ָ | Kamatz | קָמָץ | Consonant + vowel | ✓ Valid |
| ַ | Patach | פַּתָח | Consonant + vowel | ✓ Valid |
| ֵ | Tzere | צֵירֵי | Consonant + vowel | ✓ Valid |
| ֶ | Segol | סֶגּוֹל | Consonant + vowel | ✓ Valid |
| ִ | Chirik | חִירִיק | Consonant + vowel | ✓ Valid |
| ְ | Shva | שְׁוָא | Consonant + shva | ✓ Valid |
| ּ | Dagesh Chazak | דָּגֵשׁ חָזָק | Doubles the /v/ | ✓ Valid |

### Invalid Combinations / צירופים לא תקינים

| Combination | Reason (EN) | Reason (HE) |
|-------------|-------------|-------------|
| וּ + any vowel | Shuruk IS the vowel | השורוק הוא התנועה |
| וֹ + any vowel | Cholam male IS the vowel | החולם מלא הוא התנועה |
| Chataf vowels | Not a guttural | לא גרונית |
| Shin/Sin dots | Only for ש | רק לשין |

### Critical Rules / כללים קריטיים
1. **EN:** Shuruk (וּ) = vav with dot in center, IS the /u/ vowel
2. **HE:** שורוק (וּ) = וא״ו עם נקודה באמצע, היא התנועה /או/
3. **EN:** Cannot add another vowel to shuruk - it's not a consonant there
4. **HE:** אי אפשר להוסיף תנועה לשורוק - היא לא עיצור שם
5. **EN:** Cholam male (וֹ) = vav with dot above, IS the /o/ vowel
6. **HE:** חולם מלא (וֹ) = וא״ו עם נקודה למעלה, היא התנועה /או/

### Examples / דוגמאות
- שָׁלוֹם (shalom) - peace - cholam male (וֹ is /o/)
- שׁוּרָה (shurah) - row - shuruk (וּ is /u/)
- וַיֹּאמֶר (vayomer) - and he said - consonant /v/ with patach

---

## ז (Zayin / זַיִן)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Takes:** All vowels, Dagesh Chazak

### Valid Marks / סימנים תקינים

| Mark | Name | Status |
|------|------|--------|
| All vowels | כל התנועות | ✓ Valid |
| ּ | Dagesh Chazak | ✓ Valid |
| ְ | Shva | ✓ Valid |

### Invalid Marks / סימנים לא תקינים
- Chataf vowels - not a guttural
- Rafe - only for BeGeD KeFaT
- Shin/Sin dots - only for ש
- Dagesh Lene - only for BeGeD KeFaT (dagesh chazak is valid)

---

## ח (Chet / חֵית)

### Classification / סיווג
- **Category:** Guttural (גרונית)
- **Cannot take:** Dagesh (דגש)
- **Special:** Requires chataf vowels instead of simple shva

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Example | Status |
|------|-----------|-----------|---------|--------|
| ָ | Kamatz | קָמָץ | חָכָם | ✓ Valid |
| ַ | Patach | פַּתָח | חַי | ✓ Valid |
| ֵ | Tzere | צֵירֵי | חֵן | ✓ Valid |
| ֶ | Segol | סֶגּוֹל | חֶסֶד | ✓ Valid |
| ִ | Chirik | חִירִיק | חִיל | ✓ Valid |
| ֹ | Cholam | חוֹלָם | חוֹל | ✓ Valid |
| ֻ | Kubutz | קֻבּוּץ | חֻלָּה | ✓ Valid |
| ֲ | Chataf Patach | חֲטַף פַּתָח | חֲלוֹם | ✓ **Required** |
| ֱ | Chataf Segol | חֲטַף סֶגּוֹל | חֱזוֹן | ✓ **Required** |
| ֳ | Chataf Kamatz | חֲטַף קָמָץ | חֳלִי | ✓ **Required** |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ּ | Dagesh | Gutturals cannot be doubled | גרוניות לא מוכפלות |
| ׁׂ | Shin/Sin dots | Only for ש | רק לשין |
| ֿ | Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

---

## ט (Tet / טֵית)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Takes:** All vowels, Dagesh Chazak

### Valid Marks / סימנים תקינים
- All vowels (כל התנועות) ✓
- Dagesh Chazak (דגש חזק) ✓
- Shva (שווא) ✓

### Invalid Marks / סימנים לא תקינים
- Chataf vowels - not a guttural
- Rafe - only for BeGeD KeFaT
- Shin/Sin dots - only for ש

---

## י (Yod / יוֹד)

### Classification / סיווג
- **Category:** Regular consonant + vowel letter (עיצור רגיל + אם קריאה)
- **As consonant:** Takes all vowels, pronounced /y/
- **As vowel letter:** Part of chirik male (יִ), tzere male

### Valid Marks / סימנים תקינים

| Mark | Name | Function | Status |
|------|------|----------|--------|
| All vowels | כל התנועות | Consonant + vowel | ✓ Valid |
| ּ | Dagesh Chazak | Doubles the /y/ | ✓ Valid |
| ְ | Shva | Consonant + shva | ✓ Valid |

### Invalid Marks / סימנים לא תקינים
- Chataf vowels - not a guttural
- Rafe - only for BeGeD KeFaT
- Shin/Sin dots - only for ש

---

## כ/ך (Kaf / כָּף)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Dual pronunciation:** כּ = /k/, כ = /χ/ (khaf)
- **Final form:** ך (usually with shva nach)

### Valid Marks / סימנים תקינים

| Mark | Name | Result | Status |
|------|------|--------|--------|
| ּ | Dagesh Lene | כּ = /k/ | ✓ Valid |
| ּ | Dagesh Chazak | כּ = /kk/ | ✓ Valid |
| ֿ | Rafe | כ = /χ/ | ✓ Historical |
| All vowels | כל התנועות | — | ✓ Valid |

### Final Kaf (ך) / כ״ף סופית
- Usually takes shva nach (ךְ)
- Rarely takes other vowels
- Dagesh is rare but valid

### Examples / דוגמאות
- כֹּל (kol) - all - with dagesh
- מֶלֶךְ (melekh) - king - final kaf with shva
- בָּרוּךְ (barukh) - blessed - final kaf

---

## ל (Lamed / לָמֶד)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Takes:** All vowels, Dagesh Chazak

### Valid Marks / סימנים תקינים
- All vowels (כל התנועות) ✓
- Dagesh Chazak (דגש חזק) ✓
- Shva (שווא) ✓

### Invalid Marks / סימנים לא תקינים
- Chataf vowels - not a guttural
- Rafe - only for BeGeD KeFaT
- Shin/Sin dots - only for ש

---

## מ/ם (Mem / מֵם)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Final form:** ם (never takes vowels)

### Valid Marks / סימנים תקינים

| Form | Vowels | Dagesh | Notes |
|------|--------|--------|-------|
| מ | All ✓ | Chazak ✓ | Regular mem |
| ם | None ✗ | None ✗ | Always word-final, no vowels |

### Invalid Marks / סימנים לא תקינים
- Chataf vowels - not a guttural
- Rafe - only for BeGeD KeFaT
- Shin/Sin dots - only for ש
- Any vowel on final ם

---

## נ/ן (Nun / נוּן)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Final form:** ן (never takes vowels)

### Valid Marks / סימנים תקינים

| Form | Vowels | Dagesh | Notes |
|------|--------|--------|-------|
| נ | All ✓ | Chazak ✓ | Regular nun |
| ן | None ✗ | None ✗ | Always word-final, no vowels |

---

## ס (Samekh / סָמֶךְ)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Takes:** All vowels, Dagesh Chazak

### Valid Marks / סימנים תקינים
- All vowels (כל התנועות) ✓
- Dagesh Chazak (דגש חזק) ✓
- Shva (שווא) ✓

---

## ע (Ayin / עַיִן)

### Classification / סיווג
- **Category:** Guttural (גרונית)
- **Cannot take:** Dagesh (דגש)
- **Special:** Requires chataf vowels instead of simple shva

### Valid Marks / סימנים תקינים

| Mark | Name (EN) | Name (HE) | Example | Status |
|------|-----------|-----------|---------|--------|
| ָ | Kamatz | קָמָץ | עָם | ✓ Valid |
| ַ | Patach | פַּתָח | עַל | ✓ Valid |
| ֵ | Tzere | צֵירֵי | עֵץ | ✓ Valid |
| ֶ | Segol | סֶגּוֹל | עֶזְרָה | ✓ Valid |
| ִ | Chirik | חִירִיק | עִיר | ✓ Valid |
| ֹ | Cholam | חוֹלָם | עוֹלָם | ✓ Valid |
| ֻ | Kubutz | קֻבּוּץ | עֻזָּה | ✓ Valid |
| ֲ | Chataf Patach | חֲטַף פַּתָח | עֲבוֹדָה | ✓ **Required** |
| ֱ | Chataf Segol | חֲטַף סֶגּוֹל | עֱנוּת | ✓ **Required** |
| ֳ | Chataf Kamatz | חֲטַף קָמָץ | עֳנִי | ✓ **Required** |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ּ | Dagesh | Gutturals cannot be doubled | גרוניות לא מוכפלות |
| ׁׂ | Shin/Sin dots | Only for ש | רק לשין |
| ֿ | Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

---

## פ/ף (Pe/Fe / פֵּא)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Dual pronunciation:** פּ = /p/, פ = /f/
- **Final form:** ף (usually with kamatz)

### Valid Marks / סימנים תקינים

| Mark | Name | Result | Status |
|------|------|--------|--------|
| ּ | Dagesh Lene | פּ = /p/ | ✓ Valid |
| ּ | Dagesh Chazak | פּ = /pp/ | ✓ Valid |
| ֿ | Rafe | פ = /f/ | ✓ Historical |
| All vowels | כל התנועות | — | ✓ Valid |

### Final Pe (ף) / פ״א סופית
- Usually takes kamatz (ףָ) or no vowel
- Rarely takes other vowels

### Examples / דוגמאות
- פֹּה (po) - here - with dagesh
- סוֹף (sof) - end - without dagesh (fe)
- אַף (af) - nose/also - final pe

---

## צ/ץ (Tsade / צָדִי)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Final form:** ץ (usually with kamatz)

### Valid Marks / סימנים תקינים

| Form | Vowels | Dagesh | Notes |
|------|--------|--------|-------|
| צ | All ✓ | Chazak ✓ | Regular tsade |
| ץ | Limited | Rare | Usually kamatz or no vowel |

---

## ק (Qof / קוֹף)

### Classification / סיווג
- **Category:** Regular consonant (עיצור רגיל)
- **Takes:** All vowels, Dagesh Chazak

### Valid Marks / סימנים תקינים
- All vowels (כל התנועות) ✓
- Dagesh Chazak (דגש חזק) ✓
- Shva (שווא) ✓

### Special Note / הערה מיוחדת
- Qof occasionally takes chataf kamatz in rare cases: הַקֳּדָשִׁים
- קו״ף לעתים מקבלת חטף קמץ במקרים נדירים

---

## ר (Resh / רֵישׁ)

### Classification / סיווג
- **Category:** Semi-guttural (חצי-גרונית)
- **Cannot take:** Dagesh Chazak (cannot be doubled)
- **Takes:** Regular shva (not chataf)

### Valid Marks / סימנים תקינים

| Mark | Name | Status |
|------|------|--------|
| All vowels | כל התנועות | ✓ Valid |
| ְ | Shva | ✓ Valid (regular, not chataf) |

### Invalid Marks / סימנים לא תקינים

| Mark | Name | Reason (EN) | Reason (HE) |
|------|------|-------------|-------------|
| ּ | Dagesh | Resh cannot be doubled | ר׳ לא מוכפלת |
| ֱֲֳ | Chataf vowels | Takes regular shva | מקבלת שווא רגיל |
| ׁׂ | Shin/Sin dots | Only for ש | רק לשין |
| ֿ | Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

### Rules / כללים
1. **EN:** Resh behaves like gutturals for dagesh (cannot double)
2. **HE:** ר׳ מתנהגת כגרוניות לעניין דגש (לא מוכפלת)
3. **EN:** But takes regular shva, not chataf vowels
4. **HE:** אבל מקבלת שווא רגיל, לא חטפים

---

## ש (Shin/Sin / שִׁין)

### Classification / סיווג
- **Category:** UNIQUE - requires distinguishing dot
- **Two forms:** שׁ (shin) = /ʃ/, שׂ (sin) = /s/
- **Takes:** All vowels, Dagesh Chazak

### Required Marks / סימנים נדרשים

| Mark | Name (EN) | Name (HE) | Position | Sound |
|------|-----------|-----------|----------|-------|
| ׁ | Shin dot | נְקֻדַּת שִׁין | Upper right | /ʃ/ "sh" |
| ׂ | Sin dot | נְקֻדַּת שִׂין | Upper left | /s/ "s" |

### Valid Combinations / צירופים תקינים

**Shin (שׁ) forms:**
שָׁ שַׁ שֵׁ שֶׁ שִׁ שֹׁ שֻׁ שְׁ שּׁ

**Sin (שׂ) forms:**
שָׂ שַׂ שֵׂ שֶׂ שִׂ שֹׂ שֻׂ שְׂ שּׂ

### Invalid Marks / סימנים לא תקינים

| Mark | Reason (EN) | Reason (HE) |
|------|-------------|-------------|
| Chataf vowels | Not a guttural | לא גרונית |
| Rafe | Only for BeGeD KeFaT | רק לבגד״כפת |

### Critical Rules / כללים קריטיים
1. **EN:** Shin/sin dots are ONLY valid on ש - never on other letters
2. **HE:** נקודות שין/שׂין תקינות רק על ש - לעולם לא על אותיות אחרות
3. **EN:** In Biblical Hebrew, both forms must have the distinguishing dot
4. **HE:** בעברית מקראית, שתי הצורות חייבות לכלול את הנקודה המבחינה
5. **EN:** Special case: יִשָּׂשכָר has undotted shin (silent)
6. **HE:** מקרה מיוחד: יִשָּׂשכָר - שין בלי נקודה (שקטה)

---

## ת (Tav / תָּו)

### Classification / סיווג
- **Category:** BeGeD KeFaT (בגד״כפת)
- **Historical pronunciation:** תּ = /t/, ת = /θ/ (merged in Modern Hebrew)
- **Modern Hebrew:** Both pronounced /t/

### Valid Marks / סימנים תקינים

| Mark | Name | Historical | Modern | Status |
|------|------|------------|--------|--------|
| ּ | Dagesh Lene | תּ = /t/ | /t/ | ✓ Valid |
| ּ | Dagesh Chazak | תּ = /tt/ | /t/ | ✓ Valid |
| ֿ | Rafe | ת = /θ/ | /t/ | ✓ Historical |
| All vowels | כל התנועות | — | — | ✓ Valid |

---

## Final Letters Summary / סיכום אותיות סופיות

| Letter | Vowels | Dagesh | Common Form | אות | תנועות | דגש | צורה נפוצה |
|--------|--------|--------|-------------|-----|--------|-----|------------|
| ך | Limited | Rare | ךְ (shva) | ך | מוגבל | נדיר | ךְ |
| ם | Never | Never | ם (bare) | ם | אף פעם | אף פעם | ם |
| ן | Never | Never | ן (bare) | ן | אף פעם | אף פעם | ן |
| ף | Limited | Never | ףָ (kamatz) | ף | מוגבל | אף פעם | ףָ |
| ץ | Limited | Never | ץָ (kamatz) | ץ | מוגבל | אף פעם | ץָ |

---

## Complete Invalid Combinations / צירופים לא תקינים - רשימה מלאה

### Absolutely Invalid / לא תקין בהחלט

| Combination | Letters Affected | Reason |
|-------------|------------------|--------|
| Dagesh on gutturals | אהחע | Cannot be doubled |
| Dagesh on ר | ר | Cannot be doubled |
| Shin dot on non-ש | All except ש | Only for shin |
| Sin dot on non-ש | All except ש | Only for sin |
| Mappiq on non-final-ה | All except final ה | Only for final he |
| Chataf on non-gutturals | All except אהחע | Only for gutturals |
| Rafe on non-BeGeD KeFaT | All except בגדכפת | Only for BeGeD KeFaT |
| Two vowels on one letter | All | Violates syllable structure |
| Vowel on shuruk (וּ) | ו | Shuruk IS the vowel |
| Any vowel on ם or ן | םן | Final forms, no vowels |

### דגש על גרוניות | אהחע | לא מוכפלות
### דגש על ר | ר | לא מוכפלת
### נקודת שין על לא-ש | הכל חוץ מש | רק לשין
### נקודת שׂין על לא-ש | הכל חוץ מש | רק לשׂין
### מפיק על ה לא סופית | הכל חוץ מה סופית | רק לה סופית
### חטף על לא-גרוניות | הכל חוץ מאהחע | רק לגרוניות
### רפה על לא-בגדכפת | הכל חוץ מבגדכפת | רק לבגדכפת
### שתי תנועות על אות אחת | הכל | מפר מבנה הברה
### תנועה על שורוק | ו | השורוק הוא התנועה
### תנועה על ם או ן | םן | אותיות סופיות, ללא תנועות

---

## Cantillation Marks (Teamim) / טעמי המקרא

Cantillation marks apply to ALL letters and are not restricted by letter category.
טעמי המקרא חלים על כל האותיות ואינם מוגבלים לפי קטגוריית אות.

### Hierarchy / היררכיה

| Level | Hebrew | Marks |
|-------|--------|-------|
| 1 - Emperors | קיסרים | סוף פסוק, אתנח |
| 2 - Kings | מלכים | סגול, שלשלת, זקף קטן, זקף גדול, טפחא |
| 3 - Dukes | משנים | רביע, זרקא, פשטא, יתיב, תביר |
| 4 - Counts | שלישים | גרש, גרשיים, קרני פרה, תלישא גדולה, פזר |
| Servants | משרתים | מונח, מהפך, מרכא, דרגא, קדמא, תלישא קטנה |

---

*Document Version 2.0*
*גרסת מסמך 2.0*
*Based on Tiberian Masoretic tradition / מבוסס על מסורת הניקוד הטברייני*

---

## Appendix: Unit Conversion Reference / נספח: המרת יחידות

### Supported Units / יחידות נתמכות

| Unit | Name (EN) | Name (HE) | mm per unit | Use Case |
|------|-----------|-----------|-------------|----------|
| mm | millimeter | מילימטר | 1 | Physical/print |
| cm | centimeter | סנטימטר | 10 | Physical/print |
| in | inch | אינץ' | 25.4 | US print |
| px | pixel | פיקסל | 0.2646 | Screen (96 DPI) |
| pt | point | נקודה | 0.3528 | Typography |
| pc | pica | פיקה | 4.2333 | Typography |
| em | em | אם | 4.2333 | Relative to font |
| rem | root em | אם שורש | 4.2333 | Relative to root |

### Conversion Formulas / נוסחאות המרה

```javascript
// At 96 DPI, 16px base font
mm = px × (25.4 / 96)      // ~0.2646
px = mm × (96 / 25.4)      // ~3.7795
em = px / 16               // at 16px base
pt = px × (72 / 96)        // ~0.75
```

### Reference Values / ערכי ייחוס

| Dimension | mm | px | pt | em |
|-----------|-----|-----|-----|-----|
| Key width | 7.41 | 28.0 | 21.0 | 1.750 |
| Key height | 7.41 | 28.0 | 21.0 | 1.750 |
| Font size | 2.65 | 10.0 | 7.5 | 0.625 |
| Margin | 0.27 | 1.0 | 0.8 | 0.063 |
| Padding | 0.53 | 2.0 | 1.5 | 0.125 |
| Radius | 0.79 | 3.0 | 2.3 | 0.188 |
| Emoji size | 5.29 | 20.0 | 15.0 | 1.250 |

### Internal Storage / אחסון פנימי

All dimension values are stored internally in **millimeters (mm)** and converted to the selected display unit for UI presentation. CSS rendering uses `calc()` to convert mm to px dynamically.
