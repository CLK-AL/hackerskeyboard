# Hebrew Nikud Rules - Complete Letter Reference
# כללי הניקוד העברי - מדריך מלא לפי אותיות

---

## Overview / סקירה כללית

The Hebrew nikud (vowel pointing) system developed by the Tiberian Masoretes (6th-10th century CE) includes vowels, accents, and special marks. Not all marks apply to all letters.

מערכת הניקוד העברית שפותחה על ידי בעלי המסורה הטבריינים (המאות 6-10 לספירה) כוללת תנועות, טעמים וסימנים מיוחדים. לא כל הסימנים מתאימים לכל האותיות.

---

## Letter Categories / קטגוריות אותיות

### 1. Regular Consonants / עיצורים רגילים
**Letters:** ז ט ל מ נ ס צ ק ר
**אותיות:** ז ט ל מ נ ס צ ק ר

| Feature | Status | תכונה | סטטוס |
|---------|--------|-------|-------|
| All vowels | ✓ Valid | כל התנועות | ✓ תקין |
| Dagesh (chazak) | ✓ Valid (except ר) | דגש חזק | ✓ תקין (חוץ מר׳) |
| Shva | ✓ Valid | שווא | ✓ תקין |
| Chataf vowels | ✗ Invalid | חטפים | ✗ לא תקין |

**Note on Resh (ר):** Cannot take dagesh chazak (gemination) - treated as semi-guttural.
**הערה על ר׳:** לא מקבלת דגש חזק (הכפלה) - נחשבת כחצי-גרונית.

---

### 2. Guttural Letters / אותיות גרוניות
**Letters:** א ה ח ע
**אותיות:** א ה ח ע

| Feature | Status | תכונה | סטטוס |
|---------|--------|-------|-------|
| All vowels | ✓ Valid | כל התנועות | ✓ תקין |
| Dagesh | ✗ INVALID | דגש | ✗ לא תקין |
| Simple Shva | Rare/Avoided | שווא פשוט | נדיר/נמנע |
| Chataf Patach (ֲ) | ✓ Required | חטף פתח | ✓ נדרש |
| Chataf Segol (ֱ) | ✓ Required | חטף סגול | ✓ נדרש |
| Chataf Kamatz (ֳ) | ✓ Required | חטף קמץ | ✓ נדרש |

**Rule:** When grammar requires shva na (vocal shva), gutturals take chataf vowels instead.
**כלל:** כאשר הדקדוק דורש שווא נע, האותיות הגרוניות מקבלות חטפים במקומו.

**Examples / דוגמאות:**
- אֲנִי (ani) - I
- אֱלֹהִים (elohim) - God
- חֲלוֹם (chalom) - dream
- עֲבוֹדָה (avodah) - work

---

### 3. BeGeD KeFaT Letters / אותיות בג״ד כפ״ת
**Letters:** ב ג ד כ פ ת
**אותיות:** ב ג ד כ פ ת

These letters have TWO pronunciations based on dagesh lene:
לאותיות אלו שני הגיות בהתאם לדגש קל:

| Letter | With Dagesh | Without Dagesh | אות | עם דגש | בלי דגש |
|--------|-------------|----------------|-----|--------|---------|
| ב | /b/ (bet) | /v/ (vet) | ב | בּ | ב |
| ג | /g/ (gimel) | [ɣ]* | ג | גּ | ג |
| ד | /d/ (dalet) | [ð]* | ד | דּ | ד |
| כ | /k/ (kaf) | /χ/ (khaf) | כ | כּ | כ |
| פ | /p/ (pe) | /f/ (fe) | פ | פּ | פ |
| ת | /t/ (tav) | [θ]* | ת | תּ | ת |

*These distinctions are preserved only in Yemenite Hebrew. Modern Hebrew merged them.
*הבחנות אלו נשמרות רק בעברית תימנית. בעברית המודרנית הן התמזגו.

**Modern Hebrew preserves only:**
- בּ/ב (b/v)
- כּ/כ (k/kh)  
- פּ/פ (p/f)

**Dagesh rules for BeGeD KeFaT:**
1. At word beginning → Dagesh (usually)
2. After consonant/silent shva → Dagesh
3. After vowel → No dagesh (rafeh)

**כללי דגש לבג״ד כפ״ת:**
1. בתחילת מילה → דגש (בדרך כלל)
2. אחרי עיצור/שווא נח → דגש
3. אחרי תנועה → ללא דגש (רפה)

---

### 4. Shin/Sin (ש) - Unique Letter / אות ייחודית

**The ONLY letter with shin/sin dots:**
**האות היחידה עם נקודות שין/שׂין:**

| Form | Position | Sound | צורה | מיקום | הגייה |
|------|----------|-------|------|-------|-------|
| שׁ | Right dot | /ʃ/ "sh" | שׁין | נקודה ימנית | ש |
| שׂ | Left dot | /s/ "s" | שׂין | נקודה שמאלית | ס |

**All vowels work with both forms:**
**כל התנועות עובדות עם שתי הצורות:**

שׁ forms: שָׁ שַׁ שֵׁ שֶׁ שִׁ שֻׁ שְׁ
שׂ forms: שָׂ שַׂ שֵׂ שֶׂ שִׂ שְׂ

**Invalid:** Shin/sin dots on any other letter
**לא תקין:** נקודות שין/שׂין על כל אות אחרת

---

### 5. Vav (ו) - Special Vowel Forms / צורות תנועה מיוחדות

Vav uniquely serves as both consonant AND vowel letter:
וא״ו משמשת באופן ייחודי גם כעיצור וגם כאם קריאה:

| Form | Name | Sound | Usage | צורה | שם | הגייה | שימוש |
|------|------|-------|-------|------|-----|-------|-------|
| וּ | Shuruk | /u/ | Vav IS the vowel | וּ | שורוק | או | הוא״ו היא התנועה |
| וֹ | Cholam male | /o/ | Vav IS the vowel | וֹ | חולם מלא | או | הוא״ו היא התנועה |
| ו + vowel | Consonant | /v/ | Vav is consonant | ו + תנועה | עיצור | ו | הוא״ו עיצור |

**Critical rule:** Shuruk (וּ) cannot take additional vowels - it IS the vowel.
**כלל קריטי:** שורוק (וּ) לא יכול לקבל תנועות נוספות - הוא עצמו התנועה.

**Examples / דוגמאות:**
- שׁוּרָה (shurah) - row (shuruk = /u/)
- שָׁלוֹם (shalom) - peace (cholam male = /o/)
- וַיֹּאמֶר (vayomer) - and he said (vav = consonant /v/)

---

### 6. He (ה) - Mappiq / מפיק

**Mappiq (הּ) - ONLY on final ה:**
**מפיק (הּ) - רק על ה׳ סופית:**

| Form | Function | Example | צורה | תפקיד | דוגמה |
|------|----------|---------|------|-------|-------|
| הּ | Consonant /h/ | גָּבַהּ "her height" | הּ | עיצור ה׳ | גָּבַהּ |
| ה | Silent (vowel marker) | גָּבְהָה "height" | ה | שקטה (סימן תנועה) | גָּבְהָה |

**Usage:** Marks 3rd person feminine possessive suffix
**שימוש:** מסמן סיומת שייכות נקבה גוף שלישי

- אַרְצָהּ (artzah) - her land
- בֵּיתָהּ (beitah) - her house

**Invalid:** Mappiq on non-final ה or other letters
**לא תקין:** מפיק על ה׳ לא סופית או אותיות אחרות

---

### 7. Final Letters / אותיות סופיות
**Letters:** ך ם ן ף ץ
**אותיות:** ך ם ן ף ץ

| Letter | Vowels | Dagesh | Notes | אות | תנועות | דגש | הערות |
|--------|--------|--------|-------|-----|--------|-----|-------|
| ך | Limited | Rare | Usually שווא נח | ך | מוגבל | נדיר | בדרך כלל שווא נח |
| ם | None | None | Always word-final | ם | אין | אין | תמיד בסוף מילה |
| ן | None | None | Always word-final | ן | אין | אין | תמיד בסוף מילה |
| ף | Limited | None | Usually קמץ | ף | מוגבל | אין | בדרך כלל קמץ |
| ץ | Limited | None | Usually קמץ | ץ | מוגבל | אין | בדרך כלל קמץ |

---

## Vowel Marks / סימני התנועות

### A-Class Vowels / תנועות א

| Mark | Name | Sound | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ָ | Kamatz | /a/ or /o/ | קָמָץ | קמץ גדול |
| ַ | Patach | /a/ | פַּתָח | פתח |
| ֲ | Chataf Patach | /a/ reduced | חֲטָף פַּתָח | חטף פתח |
| ֳ | Chataf Kamatz | /o/ reduced | חֲטָף קָמָץ | חטף קמץ |

### E-Class Vowels / תנועות ע

| Mark | Name | Sound | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ֵ | Tzere | /e/ | צֵירֵי | צירה |
| ֶ | Segol | /e/ | סֶגּוֹל | סגול |
| ֱ | Chataf Segol | /e/ reduced | חֲטָף סֶגּוֹל | חטף סגול |

### I-Class Vowel / תנועת י

| Mark | Name | Sound | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ִ | Chirik | /i/ | חִירִיק | חיריק |

### O-Class Vowels / תנועות ו (או)

| Mark | Name | Sound | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ֹ | Cholam (chaser) | /o/ | חוֹלָם חָסֵר | חולם חסר |
| וֹ | Cholam male | /o/ | חוֹלָם מָלֵא | חולם מלא |

### U-Class Vowels / תנועות ו (או)

| Mark | Name | Sound | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ֻ | Kubutz | /u/ | קֻבּוּץ | קובוץ |
| וּ | Shuruk | /u/ | שׁוּרוּק | שורוק |

### Shva / שווא

| Mark | Name | Types | Hebrew | שם עברי |
|------|------|-------|--------|---------|
| ְ | Shva | Na (vocal) / Nach (silent) | שְׁוָא | שווא נע / שווא נח |

---

## Accent Marks / דגש ורפה

| Mark | Name | Function | Hebrew | תפקיד |
|------|------|----------|--------|-------|
| ּ | Dagesh Lene | Hardens BeGeD KeFaT | דָּגֵשׁ קַל | מקשה בג״ד כפ״ת |
| ּ | Dagesh Chazak | Doubles consonant | דָּגֵשׁ חָזָק | מכפיל עיצור |
| ֿ | Rafe | Softens (historical) | רָפֶה | מרפה (היסטורי) |
| ּ | Mappiq | Consonantal final ה | מַפִּיק | ה׳ עיצורית סופית |

---

## Cantillation Marks (Teamim) / טעמי המקרא

### Hierarchy / היררכיה

**Level 1 - Emperors / קיסרים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ׃ | Sof Pasuk | U+05C3 | End of verse |
| ֑ | Etnachta | U+0591 | Main mid-verse pause |

**Level 2 - Kings / מלכים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ֒ | Segol | U+0592 | Major division |
| ֓ | Shalshelet | U+0593 | Rare (4x in Torah) |
| ֔ | Zaqef Qatan | U+0594 | Common division |
| ֕ | Zaqef Gadol | U+0595 | Isolated zaqef |
| ֖ | Tifcha | U+0596 | Near sof pasuk |

**Level 3 - Dukes / משנים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ֗ | Revia | U+0597 | Default L3 |
| ֘ | Zarqa | U+0598 | Near segol |
| ֙ | Pashta | U+0599 | Near zaqef |
| ֚ | Yetiv | U+059A | Replaces pashta |
| ֛ | Tevir | U+059B | Near tifcha |

**Level 4 - Counts / שלישים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ֜ | Geresh | U+059C | Expulsion |
| ֝ | Geresh Muqdam | U+059D | Early geresh |
| ֞ | Gershayim | U+059E | Double geresh |
| ֟ | Qarne Farah | U+059F | Rare (1x in Torah) |
| ֠ | Telisha Gedolah | U+05A0 | Great detached |
| ֡ | Pazer | U+05A1 | Lavish |

**Conjunctives - Servants / משרתים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ֢ | Atnach Hafukh | U+05A2 | Reversed (poetic) |
| ֣ | Munach | U+05A3 | Default conjunctive |
| ֤ | Mahpach | U+05A4 | Turning |
| ֥ | Merkha | U+05A5 | Lengthener |
| ֦ | Merkha Kefula | U+05A6 | Double (5x in Torah) |
| ֧ | Darga | U+05A7 | Stairstep |
| ֨ | Qadma | U+05A8 | Preceding |
| ֩ | Telisha Qetana | U+05A9 | Small detached |
| ֪ | Yerah Ben Yomo | U+05AA | Day-old moon |

**Other / אחרים:**
| Mark | Name | Unicode | Function |
|------|------|---------|----------|
| ֫ | Ole | U+05AB | Ascending |
| ֬ | Iluy | U+05AC | Ascending-descending |
| ֭ | Shalshelet Gedolah | U+05AD | Great chain (poetic) |
| ֮ | Zinor | U+05AE | Pipe (poetic) |
| ֯ | Masora Circle | U+05AF | Masora mark |

---

## Invalid Combinations / צירופים לא תקינים

### Absolutely Invalid / לא תקין בהחלט

| Combination | Reason | צירוף | סיבה |
|-------------|--------|-------|------|
| Two vowels on one letter | Violates syllable structure | שתי תנועות על אות אחת | מפר מבנה הברה |
| Dagesh in אהחע | Gutturals can't double | דגש באהח״ע | גרוניות לא מוכפלות |
| Dagesh chazak in ר | Resh can't double | דגש חזק בר׳ | ר׳ לא מוכפלת |
| Shin dot on non-ש | Only for shin | נקודת שין על לא-ש | רק לשין |
| Sin dot on non-ש | Only for sin | נקודת שׂין על לא-ש | רק לשׂין |
| Mappiq on non-final-ה | Only final he | מפיק על ה׳ לא סופית | רק ה׳ סופית |
| Shuruk + vowel | Shuruk IS the vowel | שורוק + תנועה | השורוק הוא התנועה |
| Two consecutive vocal shva | First must be silent | שני שווא נע רצופים | הראשון חייב להיות נח |

### Highly Restricted / מוגבל מאוד

| Combination | When Valid | צירוף | מתי תקין |
|-------------|------------|-------|----------|
| Chataf on non-guttural | Very rare exceptions | חטף על לא-גרונית | חריגים נדירים מאוד |
| Dagesh lene on non-BeGeD KeFaT | Never (only chazak) | דגש קל על לא-בגד״כפת | אף פעם (רק חזק) |
| Vowel on final ם ן | Never occurs | תנועה על ם ן סופיות | לא קורה |

---

## Per-Letter Reference / מדריך לפי אות

### א (Aleph)
- **Type:** Guttural / גרונית
- **Dagesh:** ✗ Never / אף פעם
- **Chataf:** ✓ Required for reduced vowels / נדרש לתנועות מצומצמות
- **Common forms:** אָ אַ אֵ אֶ אִ אֻ אֹ אְ אֲ אֱ אֳ

### ב (Bet/Vet)
- **Type:** BeGeD KeFaT
- **Dagesh Lene:** בּ=/b/, ב=/v/
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** בּ ב בָּ בַּ בֵּ בִּ בֻּ בְּ בָ בַ בֵ בִ בְ

### ג (Gimel)
- **Type:** BeGeD KeFaT
- **Dagesh:** גּ=/g/, ג=[ɣ] (merged in Modern Hebrew)
- **Common forms:** גּ ג גָ גַ גֵ גִ גְ

### ד (Dalet)
- **Type:** BeGeD KeFaT
- **Dagesh:** דּ=/d/, ד=[ð] (merged in Modern Hebrew)
- **Common forms:** דּ ד דָ דַ דֵ דִ דְ

### ה (He)
- **Type:** Guttural / גרונית
- **Dagesh:** ✗ Never (but mappiq הּ for final consonantal ה)
- **Mappiq:** ✓ Only on final ה
- **Chataf:** ✓ Valid
- **Common forms:** הָ הַ הֵ הֶ הִ הֻ הְ הֲ הֱ הֳ הּ

### ו (Vav)
- **Type:** Special - consonant AND vowel letter
- **As consonant:** Takes all vowels normally
- **Shuruk (וּ):** /u/ vowel - vav IS the vowel
- **Cholam male (וֹ):** /o/ vowel - vav IS the vowel
- **Common forms:** וּ וֹ וָ וַ וֵ וִ וְ

### ז (Zayin)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** זּ זָ זַ זֵ זִ זְ

### ח (Chet)
- **Type:** Guttural / גרונית
- **Dagesh:** ✗ Never
- **Chataf:** ✓ Required
- **Common forms:** חָ חַ חֵ חֶ חִ חֻ חְ חֲ חֱ חֳ

### ט (Tet)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** טּ טָ טַ טֵ טִ טְ

### י (Yod)
- **Type:** Regular consonant / vowel letter
- **Dagesh Chazak:** ✓ Valid
- **As vowel letter:** Chirik male (יִ), Tzere male
- **Common forms:** יּ יָ יַ יֵ יֶ יִ יְ

### כ/ך (Kaf)
- **Type:** BeGeD KeFaT
- **Dagesh Lene:** כּ=/k/, כ=/χ/
- **Final ך:** Usually with שווא נח
- **Common forms:** כּ כ כָּ כַּ כֵּ כִּ כְּ כָ כַ כֵ כִ כְ ךָ ךְ

### ל (Lamed)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** לּ לָ לַ לֵ לִ לְ

### מ/ם (Mem)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Final ם:** No vowels
- **Common forms:** מּ מָ מַ מֵ מִ מְ

### נ/ן (Nun)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Final ן:** No vowels
- **Common forms:** נּ נָ נַ נֵ נִ נְ

### ס (Samekh)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** סּ סָ סַ סֵ סִ סְ

### ע (Ayin)
- **Type:** Guttural / גרונית
- **Dagesh:** ✗ Never
- **Chataf:** ✓ Required
- **Common forms:** עָ עַ עֵ עֶ עִ עְ עֲ עֱ עֳ

### פ/ף (Pe/Fe)
- **Type:** BeGeD KeFaT
- **Dagesh Lene:** פּ=/p/, פ=/f/
- **Final ף:** Usually with קמץ
- **Common forms:** פּ פ פָּ פַּ פֵּ פִּ פְּ פָ פַ פֵ פִ פְ ףָ

### צ/ץ (Tsade)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Final ץ:** Usually with קמץ
- **Common forms:** צּ צָ צַ צֵ צִ צְ ץָ

### ק (Qof)
- **Type:** Regular consonant
- **Dagesh Chazak:** ✓ Valid
- **Common forms:** קּ קָ קַ קֵ קִ קְ

### ר (Resh)
- **Type:** Semi-guttural / חצי-גרונית
- **Dagesh:** ✗ Never (cannot geminate)
- **Shva:** ✓ Regular shva (not chataf)
- **Common forms:** רָ רַ רֵ רֶ רִ רְ

### ש (Shin/Sin)
- **Type:** UNIQUE - requires shin/sin dot
- **שׁ (Shin):** Right dot = /ʃ/
- **שׂ (Sin):** Left dot = /s/
- **Dagesh Chazak:** ✓ Valid (שּׁ שּׂ)
- **Common שׁ forms:** שׁ שָׁ שַׁ שֵׁ שֶׁ שִׁ שֻׁ שְׁ
- **Common שׂ forms:** שׂ שָׂ שַׂ שֵׂ שֶׂ שִׂ שְׂ

### ת (Tav)
- **Type:** BeGeD KeFaT
- **Dagesh:** תּ=/t/, ת=[θ] (merged in Modern Hebrew)
- **Common forms:** תּ ת תָ תַ תֵ תִ תְ

---

## Summary Table / טבלת סיכום

| Letter | Dagesh | Chataf | Special | אות | דגש | חטף | מיוחד |
|--------|--------|--------|---------|-----|-----|-----|-------|
| א | ✗ | ✓ | Guttural | א | ✗ | ✓ | גרונית |
| ב | ✓ (b/v) | ✗ | BeGeD KeFaT | ב | ✓ | ✗ | בגד״כפת |
| ג | ✓ | ✗ | BeGeD KeFaT | ג | ✓ | ✗ | בגד״כפת |
| ד | ✓ | ✗ | BeGeD KeFaT | ד | ✓ | ✗ | בגד״כפת |
| ה | ✗ | ✓ | Guttural + Mappiq | ה | ✗ | ✓ | גרונית + מפיק |
| ו | ✓ | ✗ | Shuruk/Cholam | ו | ✓ | ✗ | שורוק/חולם |
| ז | ✓ | ✗ | Regular | ז | ✓ | ✗ | רגילה |
| ח | ✗ | ✓ | Guttural | ח | ✗ | ✓ | גרונית |
| ט | ✓ | ✗ | Regular | ט | ✓ | ✗ | רגילה |
| י | ✓ | ✗ | Vowel letter | י | ✓ | ✗ | אם קריאה |
| כ | ✓ (k/kh) | ✗ | BeGeD KeFaT | כ | ✓ | ✗ | בגד״כפת |
| ל | ✓ | ✗ | Regular | ל | ✓ | ✗ | רגילה |
| מ | ✓ | ✗ | Regular | מ | ✓ | ✗ | רגילה |
| נ | ✓ | ✗ | Regular | נ | ✓ | ✗ | רגילה |
| ס | ✓ | ✗ | Regular | ס | ✓ | ✗ | רגילה |
| ע | ✗ | ✓ | Guttural | ע | ✗ | ✓ | גרונית |
| פ | ✓ (p/f) | ✗ | BeGeD KeFaT | פ | ✓ | ✗ | בגד״כפת |
| צ | ✓ | ✗ | Regular | צ | ✓ | ✗ | רגילה |
| ק | ✓ | ✗ | Regular | ק | ✓ | ✗ | רגילה |
| ר | ✗ | ✗ | Semi-guttural | ר | ✗ | ✗ | חצי-גרונית |
| ש | ✓ | ✗ | Shin/Sin dots | ש | ✓ | ✗ | נקודות שין/שׂין |
| ת | ✓ | ✗ | BeGeD KeFaT | ת | ✓ | ✗ | בגד״כפת |

---

*Document version 1.0 - Based on Tiberian Masoretic tradition*
*גרסת מסמך 1.0 - מבוסס על מסורת הניקוד הטברייני*
