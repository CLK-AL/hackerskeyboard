# UniKey V6 - Unified WebXR AI Keyboard Platform

## 🎯 Product Vision

**V5 = Proof of Concept** (Hebrew keyboard, DOM-based, 14,594 lines)
**V6 = Production Platform** (Full UTF-8/CLDR, WebXR, AI-powered, distributed)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         UNIKEY V6 PLATFORM (2025)                            │
│        Unified WebXR AI Keyboard with Full i18n & Collaboration              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  PWA FRONTEND (KMP + Kotlin/JS + Pure JS)                            │   │
│  │  ├─ WebXR Keyboard (2D DOM + 3D BabylonJS 7 + Hand Tracking)        │   │
│  │  ├─ Full UTF-8 Locale Support (CLDR 45+)                             │   │
│  │  ├─ Y.js CRDT Collaborative Editing                                  │   │
│  │  └─ Offline-First Service Worker                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │ WebSocket / REST                             │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  KOTLIN/JVM AI SERVICES (Ktor 3 + LangChain4j + DJL)                 │   │
│  │  ├─ TTS: Chatterbox Multilingual (Resemble AI 2025)                 │   │
│  │  ├─ STT: Whisper Large V3 Turbo (whisper.cpp JNI)                   │   │
│  │  ├─ Hebrew: DictaBERT, Menaked, Phonikud, Joint (Dicta IL)          │   │
│  │  ├─ LLM: JLama + DeepSeek R1 Thinking 24B                           │   │
│  │  ├─ RAG: LangChain4j + ChromaDB + Claude 3.5                        │   │
│  │  ├─ Image: ComfyUI WebSocket API (SDXL, Flux)                       │   │
│  │  └─ Units: LocaleUnits v2 CLDR conversion engine                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                              │                                              │
│                              ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  DATA LAYER                                                          │   │
│  │  ├─ CLDR 45: All locales, units, number formats, calendars          │   │
│  │  ├─ UTF-8: Full Unicode 16.0 (154,998 characters)                   │   │
│  │  ├─ Emoji 16.0: 3,790+ emoji + skin tones + ZWJ sequences           │   │
│  │  ├─ IPA: Full phonetic alphabet + diacritics                        │   │
│  │  └─ Keyboards: 200+ locale layouts from CLDR                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  INTEGRATION POINTS:                                                        │
│  • WebSocket: Y.js sync, Chatterbox TTS streaming, Whisper STT streaming   │
│  • REST: RAG queries, unit conversion, batch operations                    │
│  • IndexedDB: Offline CLDR cache, user preferences                         │
│  • WebXR: Immersive keyboard, spatial audio TTS                            │
│  • ComfyUI: Image generation via WebSocket workflows                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 🎬 Full Media Generation Pipeline (KAN-442)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              UNIKEYBOARD V6 - FULL MEDIA GENERATION PIPELINE                │
│                   Apache Camel → ComfyUI/FastAPI/Gradio                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                     EMOJI-BASED PROMPT GENERATOR                     │   │
│  │   🌅🏔️🦋 + 🎨(style) + 😊(mood) + 🇮🇱(lang) → TargetType             │   │
│  └────────────────────────────┬────────────────────────────────────────┘   │
│                               │                                             │
│                               ▼                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      APACHE CAMEL ROUTING                            │   │
│  │  ┌───────────┐  ┌───────────┐  ┌───────────┐  ┌───────────┐        │   │
│  │  │ WSS:8188  │  │ HTTP:8000 │  │ HTTP:7860 │  │ HTTP:443  │        │   │
│  │  │ ComfyUI   │  │ FastAPI   │  │ Gradio    │  │ VHV/Dicta │        │   │
│  │  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘        │   │
│  └────────┼──────────────┼──────────────┼──────────────┼───────────────┘   │
│           │              │              │              │                    │
├───────────┼──────────────┼──────────────┼──────────────┼────────────────────┤
│           ▼              ▼              ▼              ▼                    │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                         AI MODEL PLUGINS                             │   │
│  ├─────────────────┬─────────────────┬─────────────────────────────────┤   │
│  │  🖼️ IMAGE        │  🎬 VIDEO        │  🎵 AUDIO                       │   │
│  │  FLUX.1 Krea    │  Wan 2.2 T2V    │  ACE-Step (Music Gen)          │   │
│  │  FLUX.1 Kontext │  Wan 2.2 I2V    │  Suno API                       │   │
│  │  FLUX.1 Fill    │  Wan 2.2 FLF2V  │  Demucs (Stem Separation)       │   │
│  │  FLUX.1 Redux   │  Wan 2.2 VACE   │  Basic-Pitch (MIDI Extract)    │   │
│  │  Qwen-Image     │  Wan 2.2 Animate│  VHV/Humdrum (Score)           │   │
│  │  Qwen-Edit-2511 │                 │                                 │   │
│  ├─────────────────┴─────────────────┴─────────────────────────────────┤   │
│  │  📝 TEXT/NLP (Hebrew-First)                                         │   │
│  │  Dicta IL: DictaLM-3.0 | dictabert-joint | menaked (SOTA Nikud)    │   │
│  │  Qwen3: 235B MoE | Qwen3-VL 256K | Qwen3-Omni (Audio/Video)        │   │
│  │  SillyTavern: Character Chat + RTL Hebrew UI                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  PIPELINE FLOWS:                                                            │
│  ─────────────────────────────────────────────────────────────────────────  │
│  🎨 Text→Image→Video:                                                       │
│     Emoji→Dicta(HE)→FLUX Krea(T2I)→Qwen-Edit→Wan I2V→Animate               │
│                                                                             │
│  🎵 Text→Music→Stems→MIDI→Score:                                            │
│     Emoji→Qwen3(Lyrics)→ACE-Step→Demucs(4-stem)→Basic-Pitch→VHV(**kern)    │
│                                                                             │
│  🎭 Character Animation:                                                    │
│     SillyTavern→Qwen-Image(Portrait)→Wan Animate(Pose)→Qwen3-Omni(Voice)   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 🛠️ Technology Stack (2025 Latest)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    V6 TECHNOLOGY STACK (2025 LATEST)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  FRONTEND                                                                   │
│  ├─ KMP Common (Kotlin 2.1+)                                               │
│  │   ├─ UniKeyState (StateFlow, coroutines)                                │
│  │   ├─ LocaleEngine (CLDR 45 parsing)                                     │
│  │   ├─ UnicodeData (Unicode 16.0, 154,998 codepoints)                     │
│  │   ├─ KeyboardLayouts (200+ locales from CLDR)                           │
│  │   └─ UnitConverter (LocaleUnits v2 integration)                         │
│  │                                                                          │
│  ├─ Kotlin/JS (Browser)                                                    │
│  │   ├─ Renderer2D (kotlinx.html DSL)                                      │
│  │   ├─ YjsIntegration (y-websocket)                                       │
│  │   ├─ ServiceWorkerBridge                                                │
│  │   └─ JsBridge (@JsExport)                                               │
│  │                                                                          │
│  └─ Pure JavaScript (WebXR)                                                │
│      ├─ BabylonJS 7.x Scene + VoxelKeyPanel                                │
│      ├─ WebXR HandTracker + ControllerInput                                │
│      ├─ SpatialAudio (Chatterbox TTS in 3D)                                │
│      └─ Y.js Awareness (cursor positions in XR)                            │
│                                                                             │
│  BACKEND (Kotlin/JVM - Ktor 3.x)                                           │
│  ├─ /api/tts - CHATTERBOX (Resemble AI 2025)                               │
│  │   ├─ 40+ languages, voice cloning, emotion control                      │
│  │   ├─ SSML support, streaming WebSocket                                  │
│  │   └─ Latency: <200ms first byte                                         │
│  │                                                                          │
│  ├─ /api/stt - WHISPER LARGE V3 TURBO                                      │
│  │   ├─ whisper.cpp via JNI (809M params)                                  │
│  │   ├─ 100+ languages, VAD, word timestamps                               │
│  │   └─ Latency: <50ms per chunk (streaming)                               │
│  │                                                                          │
│  ├─ /api/hebrew - DICTA IL SUITE                                           │
│  │   ├─ DictaBERT 2.0 - NER, POS, sentiment, QA                           │
│  │   ├─ Menaked (מנוקד) - nikud diacritization (98.7%)                    │
│  │   ├─ Phonikud (פוניקוד) - Hebrew → IPA phonetics                       │
│  │   └─ Joint - Combined NER + POS + Morphology                           │
│  │                                                                          │
│  ├─ /api/llm - LOCAL LLM (JLama + DJL)                                     │
│  │   ├─ DeepSeek R1 Thinking 24B (Q4_K_M, 14GB)                           │
│  │   ├─ Chain-of-thought reasoning with <think> tags                       │
│  │   └─ 128K context window                                                │
│  │                                                                          │
│  ├─ /api/rag - LANGCHAIN4J 0.36+                                           │
│  │   ├─ BGE-M3 embeddings (1024d, multilingual)                           │
│  │   ├─ ChromaDB vector store                                              │
│  │   └─ Claude 3.5 Sonnet for generation                                  │
│  │                                                                          │
│  ├─ /api/image - COMFYUI                                                   │
│  │   ├─ WebSocket API (localhost:8188)                                     │
│  │   └─ SDXL, Flux.1 workflows                                             │
│  │                                                                          │
│  ├─ /api/units - LOCALEUNITS v2                                            │
│  │   └─ CLDR-based, 21+ unit types                                         │
│  │                                                                          │
│  └─ /ws/yjs - Y.js Provider                                                │
│      └─ y-sweet or Hocuspocus                                              │
│                                                                             │
│  DATA                                                                       │
│  ├─ CLDR 45 (JSON) - 700+ locales                                          │
│  ├─ Unicode 16.0 (UCD) - 154,998 codepoints                                │
│  ├─ Emoji 16.0 - Full sequences + skin tones                               │
│  └─ Keyboard Layouts - CLDR + custom                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 🤖 AI Model Specifications (2025)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     AI MODEL SPECIFICATIONS (2025 LATEST)                    │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TTS: CHATTERBOX (Resemble AI - January 2025)                              │
│  ├─ Version: Chatterbox v1.0 (Apache 2.0, open weights)                    │
│  ├─ Languages: 40+ (Hebrew, Arabic, CJK, European, etc.)                   │
│  ├─ Features:                                                               │
│  │   • Emotion control (happy, sad, angry, neutral, excited)               │
│  │   • Voice cloning from 10s audio sample                                 │
│  │   • SSML support (prosody, breaks, emphasis)                            │
│  │   • Real-time streaming via WebSocket                                    │
│  ├─ Latency: <200ms first byte                                             │
│  ├─ Quality: 24kHz, 16-bit PCM or Opus                                     │
│  └─ Runtime: PyTorch / ONNX (GPU recommended)                              │
│                                                                             │
│  STT: WHISPER LARGE V3 TURBO (OpenAI - 2024)                               │
│  ├─ Version: large-v3-turbo (809M parameters)                              │
│  ├─ Languages: 100+ with auto-detection                                    │
│  ├─ Features:                                                               │
│  │   • Word-level timestamps                                                │
│  │   • Voice Activity Detection (VAD)                                      │
│  │   • Language detection confidence                                        │
│  │   • Streaming transcription                                              │
│  ├─ Runtime: whisper.cpp (GGML) via JNI bindings                           │
│  ├─ Latency: <50ms per chunk                                               │
│  └─ Hardware: CPU (AVX2) or CUDA/Metal                                     │
│                                                                             │
│  HEBREW NLP: DICTA IL SUITE (Hebrew University 2025 - LATEST)              │
│  │                                                                          │
│  ├─ DictaLM 3.0-24B-Thinking (FLAGSHIP - January 2025)                     │
│  │   ├─ Base: Mistral-Small-3.1-24B-Base-2503                              │
│  │   ├─ Size: 24B parameters (BF16), FP8 available                        │
│  │   ├─ Context: 128K tokens                                               │
│  │   ├─ Type: Reasoning model with <think> blocks                         │
│  │   ├─ Features: Tool calling (Hermes parser), Hebrew SOTA               │
│  │   ├─ Runtime: vLLM --reasoning_parser deepseek_r1                       │
│  │   ├─ License: Apache 2.0                                                │
│  │   ├─ Demo: chat.dicta.org.il                                           │
│  │   └─ HuggingFace: dicta-il/DictaLM-3.0-24B-Thinking                    │
│  │                                                                          │
│  ├─ DictaBERT-large-char-menaked (March 2025 - SOTA)                       │
│  │   ├─ Base: DictaBERT-large-char fine-tuned for nikud                   │
│  │   ├─ Size: 0.3B parameters (F32)                                        │
│  │   ├─ Task: Diacritization (nikud restoration)                          │
│  │   ├─ Accuracy: SOTA on all modern Hebrew benchmarks                    │
│  │   ├─ Beats commercial LLMs for vocalization                            │
│  │   ├─ Input: "שלום עולם" → "שָׁלוֹם עוֹלָם"                              │
│  │   ├─ Matres lectionis: Auto-removal or marked (*)                      │
│  │   ├─ License: CC BY 4.0                                                 │
│  │   └─ HuggingFace: dicta-il/dictabert-large-char-menaked                │
│  │                                                                          │
│  ├─ DictaBERT-joint (5 tasks in 1 forward pass)                            │
│  │   ├─ Size: 0.2B parameters (F32)                                        │
│  │   ├─ Tasks (all simultaneous):                                          │
│  │   │   • Prefix Segmentation (ב+שנת)                                     │
│  │   │   • Morphological Disambiguation                                    │
│  │   │   • Lemmatization (לימודיו → לימוד)                                 │
│  │   │   • Syntactical Parsing (Dependency Tree)                          │
│  │   │   • Named Entity Recognition (PER, ORG, LOC, TIMEX)                │
│  │   ├─ Output: JSON, UD (Universal Dependencies), IAHLT UD               │
│  │   ├─ Speed: 100x faster than sequential pipeline (0.0016s/ex)          │
│  │   ├─ Innovation: "Flipped Pipeline" - no error propagation             │
│  │   ├─ License: CC BY 4.0                                                 │
│  │   └─ HuggingFace: dicta-il/dictabert-joint                             │
│  │                                                                          │
│  ├─ DictaBERT-tiny-joint (Fast variant)                                    │
│  │   ├─ Size: ~14M parameters                                              │
│  │   └─ HuggingFace: dicta-il/dictabert-tiny-joint                        │
│  │                                                                          │
│  ├─ Phonikud (thewh1teagle - ONNX)                                         │
│  │   ├─ Task: Hebrew text → IPA phonetics with stress marks               │
│  │   ├─ Features: Vocal shva marking, stress position                     │
│  │   ├─ Size: ~50MB ONNX (INT8 quantized)                                  │
│  │   ├─ Pipeline: Nikud + phonetic marks → G2P → Piper TTS                │
│  │   └─ GitHub: thewh1teagle/phonikud-onnx                                │
│  │                                                                          │
│  └─ DictaLM Collection Variants                                            │
│      ├─ DictaLM-3.0-24B-Base (pretrained)                                 │
│      ├─ DictaLM-3.0-24B-Instruct (chat)                                   │
│      ├─ DictaLM-3.0-24B-Thinking (reasoning)                              │
│      ├─ DictaLM-3.0-24B-Base-FP8 (quantized)                              │
│      ├─ DictaLM-3.0-12B-Nemotron-Instruct (Mamba hybrid, fast)           │
│      └─ DictaLM-3.0-1.7B-Instruct (edge)                                  │
│                                                                             │
│  LLM: DEEPSEEK R1 THINKING 24B (DeepSeek - January 2025)                   │
│  ├─ Version: DeepSeek-R1-Distill-Qwen-24B                                  │
│  ├─ Parameters: 24B (Q4_K_M: 14GB, Q8_0: 26GB)                             │
│  ├─ Context: 128K tokens                                                   │
│  ├─ Features:                                                               │
│  │   • Chain-of-thought reasoning                                          │
│  │   • <think>...</think> reasoning traces                                 │
│  │   • Code generation, analysis, math                                     │
│  ├─ Runtime: JLama (pure Java) or llama.cpp JNI                           │
│  └─ License: MIT                                                           │
│                                                                             │
│  EMBEDDINGS: BGE-M3 (BAAI - 2024)                                          │
│  ├─ Version: BAAI/bge-m3                                                   │
│  ├─ Dimensions: 1024                                                       │
│  ├─ Languages: 100+ (multilingual)                                         │
│  ├─ Features: Dense + Sparse + ColBERT retrieval                          │
│  └─ Runtime: DJL (Deep Java Library)                                       │
│                                                                             │
│  RAG: LANGCHAIN4J 0.36+ (Java/Kotlin Native)                               │
│  ├─ Features: Kotlin DSL, streaming, function calling                     │
│  ├─ Vector Stores: ChromaDB, Milvus, Pinecone, Qdrant                     │
│  ├─ LLMs: Claude, OpenAI, Ollama, JLama                                   │
│  └─ Tools: Agents, RAG pipelines, memory                                   │
│                                                                             │
│  IMAGE: COMFYUI (Latest)                                                   │
│  ├─ API: WebSocket on localhost:8188                                       │
│  ├─ Models: SDXL, Flux.1 Dev/Schnell, custom LoRAs                        │
│  ├─ Workflows: JSON node graphs                                            │
│  └─ Use: Keyboard themes, emoji, icons, avatars                           │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 📐 Architecture Diagrams (PlantUML)

### System Overview (2025 Stack)

```plantuml
@startuml V6_System_Overview
!theme cyborg

title UniKey V6 - Full Platform Architecture (2025)

cloud "WebXR Device\n(Quest 3, Vision Pro)" as XR
actor "User" as User

node "PWA Frontend" as PWA {
  component [2D Keyboard\n(DOM)] as K2D
  component [3D Keyboard\n(BabylonJS 7)] as K3D
  component [Y.js CRDT\nEditor] as YJS
  database "IndexedDB\n(Offline Cache)" as IDB
}

node "Kotlin/JVM Services\n(Ktor 3)" as KT {
  component [Chatterbox TTS] as TTS
  component [Whisper V3 STT] as STT
  component [Dicta Hebrew NLP\nMenaked/Phonikud/Joint] as DICTA
  component [JLama\nDeepSeek R1 24B] as LLM
  component [LangChain4j RAG] as RAG
  component [LocaleUnits v2] as UNITS
}

node "External Services" as EXT {
  component [ComfyUI\n(SDXL/Flux)] as COMFY
  component [Claude 3.5 API] as CLAUDE
}

node "Data Layer" as DATA {
  database "CLDR 45\n(JSON)" as CLDR
  database "Unicode 16.0\n(UCD)" as UCD
  database "ChromaDB\n(Vectors)" as CHROMA
}

node "Collaboration" as COLLAB {
  component [y-sweet\nY.js Server] as HOCUS
}

User --> PWA : interact
XR --> K3D : WebXR
K2D --> IDB : cache
K3D --> IDB : cache
YJS --> HOCUS : WebSocket

PWA --> TTS : WS streaming
PWA --> STT : WS streaming
PWA --> DICTA : REST
PWA --> RAG : REST
PWA --> UNITS : REST
PWA --> COMFY : WS workflow

TTS --> CLDR : locale voices
DICTA --> CHROMA : embeddings
RAG --> CHROMA : retrieval
RAG --> CLAUDE : generation
RAG --> LLM : local inference
UNITS --> CLDR : conversions

K2D ..> K3D : shared state
K3D ..> YJS : text sync

@enduml
```

### Backend Services (Kotlin/JVM with AI)

```plantuml
@startuml V6_Backend_Kotlin
!theme cyborg

title V6 Kotlin/JVM Backend (Ktor 3 + AI Stack)

node "Ktor Application" {
  
  package "/api/tts" #LightGreen {
    class TTSRoutes {
      POST /synthesize
      WS /stream
      GET /voices
      GET /voices/{locale}
    }
    
    class ChatterboxService {
      +model: ChatterboxModel
      --
      +synthesize(text, locale, voice, emotion)
      +stream(text, voice): Flow<ByteArray>
      +cloneVoice(sample): VoiceId
      +getVoices(locale): List<Voice>
    }
    
    note right of ChatterboxService
      Chatterbox (Resemble AI 2025)
      40+ languages
      Emotion: happy, sad, angry...
      Voice cloning from 10s sample
    end note
  }
  
  package "/api/stt" #LightCoral {
    class STTRoutes {
      POST /transcribe
      WS /stream
      GET /models
    }
    
    class WhisperService {
      +whisper: WhisperCppJNI
      --
      +transcribe(audio, locale): Transcript
      +stream(audioFlow): Flow<Partial>
      +detectLanguage(audio): Language
    }
    
    note right of WhisperService
      Whisper Large V3 Turbo
      809M params, 100+ languages
      whisper.cpp via JNI
      <50ms latency streaming
    end note
  }
  
  package "/api/hebrew" #LightBlue {
    class HebrewRoutes {
      POST /nikud (Menaked)
      POST /phonetic (Phonikud)
      POST /ner (Joint)
      POST /pos (Joint)
      POST /sentiment (DictaBERT)
    }
    
    class DictaService {
      +menaked: MenakedModel
      +phonikud: PhonikudModel
      +joint: JointTaggerModel
      +dictabert: DictaBERTModel
      --
      +addNikud(text): String
      +toPhonetic(text): String
      +tagNER(text): List<Entity>
      +tagPOS(text): List<Token>
    }
    
    note right of DictaService
      Dicta IL Suite (Hebrew U)
      Menaked: 98.7% nikud accuracy
      Phonikud: Hebrew → IPA
      Joint: NER + POS combined
    end note
  }
  
  package "/api/llm" #LightYellow {
    class LLMRoutes {
      POST /chat
      POST /think
      WS /stream
    }
    
    class JLamaService {
      +model: DeepSeekR1_24B
      +djl: DJLRuntime
      --
      +chat(messages): Response
      +think(problem): ThinkingResponse
      +stream(prompt): Flow<Token>
    }
    
    note right of JLamaService
      DeepSeek R1 Thinking 24B
      JLama pure Java runtime
      <think> reasoning traces
      128K context
    end note
  }
  
  package "/api/rag" #LightPink {
    class RAGRoutes {
      POST /query
      POST /index
    }
    
    class LangChain4jService {
      +embedder: BGE_M3
      +store: ChromaDBStore
      +claude: ClaudeClient
      --
      +query(q, ctx): RAGResponse
      +index(docs): Unit
    }
    
    note right of LangChain4jService
      LangChain4j 0.36+
      BGE-M3 embeddings (1024d)
      Claude 3.5 Sonnet
    end note
  }
  
  package "/api/image" #LightGray {
    class ImageRoutes {
      POST /generate
      WS /workflow
    }
    
    class ComfyUIClient {
      +ws: WebSocketSession
      --
      +generate(prompt): Image
      +queueWorkflow(json): JobId
    }
  }
  
  package "/api/units" #Wheat {
    class UnitsRoutes {
      POST /convert
      GET /categories
    }
    
    class LocaleUnitsService {
      +cldr: CLDRData
      --
      +convert(val, from, to): Double
      +format(val, unit, locale): String
    }
  }
}

database "ChromaDB" as CHROMA
database "CLDR 45" as CLDR
database "Models\n(GGUF/ONNX)" as MODELS

ChatterboxService --> MODELS
WhisperService --> MODELS
DictaService --> MODELS
JLamaService --> MODELS
LangChain4jService --> CHROMA
LocaleUnitsService --> CLDR

@enduml
```

### Hebrew NLP Pipeline (Dicta Models)

```plantuml
@startuml V6_Hebrew_NLP
!theme cyborg

title V6 Hebrew NLP Pipeline (Dicta IL 2024)

participant "User" as U
participant "Frontend" as FE
participant "HebrewRoutes" as HR
participant "DictaService" as DS
participant "Menaked" as MEN
participant "Phonikud" as PHO
participant "Joint" as JNT
participant "DictaBERT" as DB

== Diacritization (Nikud) with Menaked ==

U -> FE : type "שלום עולם"
FE -> HR : POST /hebrew/nikud
HR -> DS : addNikud("שלום עולם")
DS -> MEN : predict diacritics

MEN -> MEN : Transformer encoder
MEN -> MEN : Per-character nikud classification
MEN --> DS : "שָׁלוֹם עוֹלָם"
note right: 98.7% accuracy

DS --> HR : vocalized text
HR --> FE : { text: "שָׁלוֹם עוֹלָם" }

== Phonetic Transcription with Phonikud ==

FE -> HR : POST /hebrew/phonetic
HR -> DS : toPhonetic("שָׁלוֹם עוֹלָם")
DS -> PHO : convert to IPA

PHO -> PHO : Handle loanwords, names
PHO -> PHO : Stress assignment (penultimate rule)
PHO --> DS : "ʃaˈlom oˈlam"

DS --> HR : IPA transcription
HR --> FE : { ipa: "ʃaˈlom oˈlam" }

== NER + POS with Joint Tagger ==

FE -> HR : POST /hebrew/ner
HR -> DS : tagNER("דוד גר בתל אביב")
DS -> JNT : joint tagging

JNT -> JNT : BERT encoder
JNT -> JNT : CRF layer (NER)
JNT -> JNT : Softmax (POS)
JNT --> DS : entities + tokens

DS --> HR : {
  entities: [
    {text: "דוד", type: "PER", start: 0, end: 3},
    {text: "תל אביב", type: "LOC", start: 7, end: 14}
  ],
  tokens: [
    {text: "דוד", pos: "PROPN", morph: {...}},
    {text: "גר", pos: "VERB", morph: {...}},
    ...
  ]
}

== Sentiment with DictaBERT ==

FE -> HR : POST /hebrew/sentiment
HR -> DS : sentiment("המוצר מעולה!")
DS -> DB : classify

DB -> DB : [CLS] embedding
DB -> DB : Fine-tuned classifier
DB --> DS : { label: "POSITIVE", score: 0.94 }

DS --> HR : sentiment result

@enduml
```

### TTS/STT with Chatterbox + Whisper V3

```plantuml
@startuml V6_TTS_STT_2025
!theme cyborg

title V6 TTS/STT Pipeline (Chatterbox + Whisper V3 Turbo)

actor "User" as U
participant "PWA" as PWA
participant "TTSRoutes" as TR
participant "ChatterboxService" as CB
participant "STTRoutes" as SR
participant "WhisperService" as WH
participant "SpatialAudio\n(WebXR)" as SA

== Chatterbox TTS (Streaming) ==

U -> PWA : type "שלום עולם"
PWA -> TR : WS /tts/stream
note right
  {
    text: "שלום עולם",
    locale: "he-IL",
    voice: "hebrew-male-warm",
    emotion: "friendly",
    speed: 1.0,
    ssml: false
  }
end note

TR -> CB : stream(request)
CB -> CB : Text normalization
CB -> CB : Phoneme encoding
CB -> CB : Acoustic model (transformer)
CB -> CB : HiFi-GAN vocoder

loop audio chunks (24kHz)
  CB --> TR : Flow<ByteArray>
  TR --> PWA : binary WebSocket frame
  PWA -> SA : playChunk(audio, position)
  SA -> U : 3D spatial audio
end

note over CB
  Chatterbox Features:
  • <200ms first byte latency
  • Emotion control
  • Voice cloning
  • SSML support
end note

== Whisper V3 Turbo STT (Streaming) ==

U -> PWA : hold mic button
PWA -> SR : WS /stt/stream
note right
  Audio: 16kHz PCM
  Chunked streaming
end note

SR -> WH : streamTranscribe()
WH -> WH : whisper.cpp (GGML)
WH -> WH : VAD (voice activity)

loop audio chunks
  U -> PWA : speak "הקלד טקסט"
  PWA -> SR : PCM chunk
  SR -> WH : process
  
  WH -> WH : Encoder forward
  WH -> WH : Beam search decode
  
  alt partial result
    WH --> SR : { partial: "הקלד", final: false }
    SR --> PWA : update UI
  end
end

WH -> WH : Final decode with timestamps
WH --> SR : {
  text: "הקלד טקסט",
  language: "he",
  confidence: 0.97,
  words: [
    { word: "הקלד", start: 0.2, end: 0.6 },
    { word: "טקסט", start: 0.7, end: 1.1 }
  ]
}

SR --> PWA : final transcript
PWA -> PWA : insertText("הקלד טקסט")

note over WH
  Whisper V3 Turbo:
  • 809M params
  • <50ms per chunk
  • Word timestamps
  • 100+ languages
end note

@enduml
```

### LLM with JLama + DeepSeek R1 Thinking

```plantuml
@startuml V6_JLama_DeepSeek
!theme cyborg

title V6 Local LLM: JLama + DeepSeek R1 Thinking 24B

participant "User" as U
participant "Frontend" as FE
participant "LLMRoutes" as LR
participant "JLamaService" as JL
participant "DJL Runtime" as DJL
participant "DeepSeek R1\n24B Q4_K_M" as DS

== Thinking Mode Query ==

U -> FE : "Explain patach vs kamatz\nin Hebrew phonology"
FE -> LR : POST /llm/think
note right
  {
    prompt: "Explain patach vs kamatz...",
    maxTokens: 2048,
    temperature: 0.7,
    enableThinking: true
  }
end note

LR -> JL : think(request)
JL -> DJL : loadModel("deepseek-r1-24b-q4_k_m")
note right: 14GB VRAM

DJL -> DS : forward pass

DS -> DS : <think>
note right #LightYellow
  Let me analyze Hebrew vowel phonology...
  
  1. Patach (פַּתַח) - U+05B7 ַ
     - Short 'a' sound [a]
     - Always pronounced /a/
     - Example: בַּיִת (bayit)
  
  2. Kamatz (קָמָץ) - U+05B8 ָ
     - Can be long 'a' [aː] OR short 'o' [o]
     - Kamatz gadol (long): open syllable
     - Kamatz katan (short): closed unaccented
  
  3. Key Distinction:
     - Patach = always /a/
     - Kamatz = context-dependent
     - Kamatz katan often in גָּדְ patterns
  
  I should explain this clearly...
</think>
end note

DS -> DS : Generate response
DS --> JL : {
  thinking: "Let me analyze...",
  response: "Patach (פַּתַח) and Kamatz (קָמָץ)...",
  tokens_used: 847
}

JL --> LR : ThinkingResponse
LR --> FE : {
  thinking: "...",
  answer: "...",
  latency_ms: 3200
}

FE -> U : display with collapsible\nthinking section

note over DS
  DeepSeek R1 Thinking 24B:
  • Chain-of-thought reasoning
  • <think> tags for traces
  • 128K context window
  • MIT license
end note

@enduml
```

### RAG with LangChain4j

```plantuml
@startuml V6_LangChain4j_RAG
!theme cyborg

title V6 RAG Pipeline (LangChain4j 0.36+ / Kotlin)

actor "User" as U
participant "PWA" as PWA
participant "RAGRoutes" as RR
participant "LangChain4jService" as LC4J
participant "BGE-M3\nEmbedder" as EMB
database "ChromaDB" as CHROMA
participant "Claude 3.5\nSonnet" as CLAUDE

== Kotlin DSL Configuration ==

note over LC4J
  ```kotlin
  val rag = langChain4j {
    embedder = BgeM3Embedder()
    vectorStore = ChromaStore(url)
    llm = claudeClient(apiKey)
    
    retriever {
      maxResults = 5
      minScore = 0.7
    }
  }
  ```
end note

== Query Flow ==

U -> PWA : "How do I type shva in nikud mode?"
PWA -> RR : POST /rag/query

RR -> LC4J : query(request)

LC4J -> EMB : embed(query)
EMB -> EMB : BGE-M3 forward (1024d)
EMB --> LC4J : queryVector

LC4J -> CHROMA : similaritySearch(
  vector = queryVector,
  k = 5,
  filter = { type: "keyboard" }
)

CHROMA --> LC4J : [
  { text: "Shva (שְׁוָא) U+05B0...", score: 0.89 },
  { text: "In nikud mode, press...", score: 0.85 },
  { text: "Hebrew vowel marks...", score: 0.82 }
]

LC4J -> CLAUDE : messages.create(
  model: "claude-3-5-sonnet",
  system: "Hebrew keyboard assistant",
  messages: [
    { role: "user", content: contextualPrompt }
  ]
)

CLAUDE --> LC4J : "To type a shva (שְׁוָא)..."

LC4J --> RR : {
  answer: "To type a shva...",
  sources: [...],
  confidence: 0.87
}

RR --> PWA : RAGResponse
PWA -> U : display answer with sources

@enduml
```

User --> PWA : interact
XR --> K3D : WebXR
K2D --> IDB : cache
K3D --> IDB : cache
YJS --> HOCUS : WebSocket

PWA --> TTS : REST/Stream
PWA --> STT : WebSocket
PWA --> NLP : REST
PWA --> RAG : REST
PWA --> UNITS : REST

TTS --> CLDR : locale voices
NLP --> CHROMA : embeddings
RAG --> CHROMA : retrieval
UNITS --> CLDR : conversions

K2D ..> K3D : shared state
K3D ..> YJS : text sync

@enduml
```

### Frontend Module Structure

```plantuml
@startuml V6_Frontend_Modules
!theme cyborg

title V6 Frontend Architecture (KMP + JS)

package "KMP Common (commonMain)" #LightBlue {
  
  package "core" {
    class UniKeyState {
      +locale: StateFlow<Locale>
      +mode: StateFlow<Mode>
      +keyboard: StateFlow<KeyboardLayout>
      +modifiers: StateFlow<Modifiers>
    }
    
    class LocaleEngine {
      +currentLocale: Locale
      +availableLocales: List<Locale>
      +loadLocale(tag: String)
      +getKeyboardLayout(): KeyboardLayout
      +getNumberFormat(): NumberFormat
      +getDateFormat(): DateFormat
    }
  }
  
  package "unicode" {
    class UnicodeData {
      +getCharacter(codepoint: Int): UnicodeChar
      +getBlock(codepoint: Int): UnicodeBlock
      +getScript(codepoint: Int): Script
      +searchByName(query: String): List<UnicodeChar>
    }
    
    class EmojiData {
      +getAllEmoji(): List<Emoji>
      +getSkinToneVariants(base: Emoji): List<Emoji>
      +getZwjSequences(): List<Emoji>
      +searchEmoji(query: String): List<Emoji>
    }
  }
  
  package "i18n" {
    class KeyboardLayouts {
      +getLayout(locale: String): KeyboardLayout
      +getAllLayouts(): Map<String, KeyboardLayout>
      +getDeadKeys(locale: String): Map<Char, Map<Char, Char>>
    }
    
    class UnitConverter {
      +convert(value: Double, from: Unit, to: Unit): Double
      +getUnitsForCategory(cat: UnitCategory): List<Unit>
      +formatUnit(value: Double, unit: Unit, locale: String): String
    }
  }
  
  package "nlp" {
    interface TextProcessor {
      +tokenize(text: String): List<Token>
      +detectLanguage(text: String): Language
      +toIpa(text: String, locale: String): String
    }
  }
}

package "Kotlin/JS (jsMain)" #LightYellow {
  
  class Renderer2D {
    +render(container: Element)
    +updateKeyboard(layout: KeyboardLayout)
    +showPopup(key: Key, options: PopupOptions)
  }
  
  class YjsIntegration {
    +doc: Y.Doc
    +provider: WebsocketProvider
    +awareness: Awareness
    +getText(): Y.Text
    +onSync(callback)
  }
  
  class AIClient {
    +tts(text: String, locale: String): AudioBuffer
    +stt(audio: Blob): String
    +embed(text: String): FloatArray
    +rag(query: String): String
  }
  
  object JsBridge {
    @JsExport
    +getState(): dynamic
    +setLocale(tag: String)
    +insertText(text: String)
    +speakText(text: String)
    +convertUnits(...)
  }
}

package "Pure JavaScript (WebXR)" #LightPink {
  
  class Renderer3D {
    +scene: BABYLON.Scene
    +xrHelper: WebXRDefaultExperience
    +keyPanel: VoxelKeyPanel
    +spatialAudio: SpatialAudioManager
  }
  
  class VoxelKeyPanel {
    +createKeyboard(layout: KeyboardLayout)
    +updateLabels(state: State)
    +onKeySelect(callback)
  }
  
  class HandTracker {
    +leftHand: XRHand
    +rightHand: XRHand
    +onPinch(callback)
    +onPoint(callback)
  }
  
  class SpatialAudioManager {
    +playTTS(audio: AudioBuffer, position: Vector3)
    +setListenerPosition(pos: Vector3)
  }
}

UniKeyState --> JsBridge
LocaleEngine --> KeyboardLayouts
UnicodeData --> EmojiData
JsBridge --> Renderer2D
JsBridge --> Renderer3D
YjsIntegration --> Renderer2D
AIClient --> Renderer3D : TTS audio

@enduml
```

### Backend Services Architecture

```plantuml
@startuml V6_Backend_Services
!theme cyborg

title V6 Python Backend Services

node "FastAPI Application" {
  
  package "/api/tts" #LightGreen {
    class TTSRouter {
      POST /synthesize
      POST /stream
      GET /voices
      GET /voices/{locale}
    }
    
    class TTSService {
      +zonos: ZonosHebrew
      +coqui: CoquiTTS
      +edge: EdgeTTS
      --
      +synthesize(text, locale, voice)
      +stream(text, locale, voice)
      +getVoices(locale)
    }
  }
  
  package "/api/stt" #LightCoral {
    class STTRouter {
      POST /transcribe
      WS /stream
      GET /models
    }
    
    class STTService {
      +whisper: WhisperModel
      +vosk: VoskModel
      --
      +transcribe(audio, locale)
      +streamTranscribe(ws, locale)
    }
  }
  
  package "/api/nlp" #LightBlue {
    class NLPRouter {
      POST /tokenize
      POST /embed
      POST /detect-language
      POST /to-ipa
    }
    
    class NLPService {
      +dictabert: DictaBERT
      +mbert: mBERT
      +embedder: SentenceTransformer
      --
      +tokenize(text, locale)
      +embed(text)
      +detectLanguage(text)
      +textToIpa(text, locale)
    }
  }
  
  package "/api/rag" #LightYellow {
    class RAGRouter {
      POST /query
      POST /index
      GET /collections
    }
    
    class RAGService {
      +chroma: ChromaDB
      +langchain: LangChain
      +claude: ClaudeAPI
      --
      +query(question, context)
      +index(documents)
      +retrieve(query, k)
    }
  }
  
  package "/api/units" #LightPink {
    class UnitsRouter {
      POST /convert
      GET /categories
      GET /units/{category}
      POST /format
    }
    
    class LocaleUnitsService {
      +cldr: CLDRData
      --
      +convert(value, from, to)
      +getCategories()
      +getUnits(category)
      +format(value, unit, locale)
    }
  }
  
  package "/ws/yjs" #LightGray {
    class YjsRouter {
      WS /sync/{room}
    }
    
    class HocuspocusProvider {
      +rooms: Map<String, Y.Doc>
      --
      +onConnect(ws, room)
      +onMessage(ws, msg)
      +broadcast(room, update)
    }
  }
}

database "ChromaDB" as CHROMA
database "CLDR JSON" as CLDR
database "Model Cache" as MODELS

TTSService --> MODELS
STTService --> MODELS
NLPService --> MODELS
NLPService --> CHROMA
RAGService --> CHROMA
LocaleUnitsService --> CLDR

@enduml
```

### Data Flow: Full Input Pipeline

```plantuml
@startuml V6_Input_Pipeline
!theme cyborg

title V6 Input Pipeline (Key Press → AI Processing)

participant "User" as U
participant "WebXR\nHandTracker" as HT
participant "VoxelKeyPanel" as VKP
participant "UniKeyState" as State
participant "Y.js Doc" as YJS
participant "AIClient" as AI
participant "TTS Service" as TTS
participant "NLP Service" as NLP
participant "SpatialAudio" as SA

== Key Selection (WebXR) ==

U -> HT : pinch gesture
HT -> VKP : onKeySelect(keyId)
VKP -> State : insertCharacter(char)
State -> YJS : doc.getText().insert(pos, char)

== Collaborative Sync ==

YJS -> YJS : local update
YJS --> YJS : broadcast to peers
note right: Y.js CRDT\nauto-merges

== AI Processing (on sentence end) ==

State -> State : detect sentence end
State -> AI : processText(sentence)

AI -> NLP : POST /tokenize
NLP --> AI : tokens[]

AI -> NLP : POST /to-ipa
NLP --> AI : ipaText

AI -> TTS : POST /synthesize
TTS --> AI : audioBuffer

AI -> SA : playTTS(audio, keyPosition)
SA -> U : spatial audio feedback

== Optional: RAG Query ==

U -> State : trigger RAG (voice command)
State -> AI : ragQuery(text)
AI -> AI : POST /api/rag/query
AI --> State : ragResponse
State -> VKP : showRagResult(response)

@enduml
```

### CLDR Integration

```plantuml
@startuml V6_CLDR_Integration
!theme cyborg

title V6 CLDR Data Integration

package "CLDR 44 Data" {
  
  database "cldr-json" {
    folder "main/{locale}" {
      file "numbers.json" as NUM
      file "units.json" as UNIT
      file "dates.json" as DATE
      file "characters.json" as CHAR
    }
    
    folder "keyboards/{locale}" {
      file "keyboard.json" as KB
    }
    
    folder "supplemental" {
      file "likelySubtags.json" as TAGS
      file "languageMatching.json" as MATCH
      file "measurementData.json" as MEASURE
    }
  }
}

package "LocaleEngine" {
  
  class CLDRLoader {
    +loadLocale(tag: String): LocaleData
    +loadKeyboard(tag: String): KeyboardLayout
    +loadUnits(tag: String): UnitData
  }
  
  class NumberFormatter {
    +format(value: Number, style: Style): String
    +parse(text: String): Number
  }
  
  class DateFormatter {
    +format(date: Date, style: Style): String
    +parse(text: String): Date
  }
  
  class UnitFormatter {
    +format(value: Number, unit: Unit): String
    +convert(value: Number, from: Unit, to: Unit): Number
  }
  
  class KeyboardLayoutParser {
    +parse(json: String): KeyboardLayout
    +getDeadKeys(): Map<Char, Map<Char, Char>>
    +getTransforms(): List<Transform>
  }
}

NUM --> NumberFormatter
UNIT --> UnitFormatter
DATE --> DateFormatter
KB --> KeyboardLayoutParser
TAGS --> CLDRLoader
MEASURE --> UnitFormatter

@enduml
```

### UTF-8 / Unicode Architecture

```plantuml
@startuml V6_Unicode_Architecture
!theme cyborg

title V6 Full Unicode 15.1 Support

package "Unicode Data" {
  
  database "UCD (Unicode Character Database)" {
    file "UnicodeData.txt" as UCD
    file "Blocks.txt" as BLOCKS
    file "Scripts.txt" as SCRIPTS
    file "emoji-data.txt" as EMOJI_DATA
    file "emoji-sequences.txt" as EMOJI_SEQ
    file "emoji-zwj-sequences.txt" as EMOJI_ZWJ
  }
}

package "UniKeyData (KMP)" {
  
  class UnicodeDatabase {
    +characters: Map<Int, UnicodeChar>
    +blocks: List<UnicodeBlock>
    +scripts: Map<String, Script>
    --
    +getChar(codepoint: Int): UnicodeChar
    +getBlock(codepoint: Int): UnicodeBlock
    +searchByName(query: String): List<UnicodeChar>
    +getCharsInBlock(block: UnicodeBlock): List<UnicodeChar>
  }
  
  class UnicodeChar {
    codepoint: Int
    name: String
    category: Category
    block: String
    script: String
    bidi: BidiClass
  }
  
  class EmojiDatabase {
    +emoji: List<Emoji>
    +skinToneBase: Set<Int>
    +zwjSequences: List<ZwjSequence>
    --
    +getEmoji(codepoint: Int): Emoji
    +getSkinVariants(emoji: Emoji): List<Emoji>
    +getZwjVariants(emoji: Emoji): List<Emoji>
    +searchEmoji(query: String): List<Emoji>
  }
  
  class Emoji {
    sequence: List<Int>
    name: String
    group: String
    subgroup: String
    hasSkinTones: Boolean
    hasHairStyles: Boolean
  }
}

package "Search Engine" {
  
  class UnifiedSearch {
    +search(query: String, filters: Filters): List<SearchResult>
    --
    Searches across:
    - Unicode characters by name/codepoint
    - Emoji by name/annotation
    - CLDR keywords
    - IPA symbols
  }
  
  class SearchResult {
    type: ResultType
    char: String
    codepoints: List<Int>
    name: String
    score: Float
  }
}

UCD --> UnicodeDatabase
BLOCKS --> UnicodeDatabase
SCRIPTS --> UnicodeDatabase
EMOJI_DATA --> EmojiDatabase
EMOJI_SEQ --> EmojiDatabase
EMOJI_ZWJ --> EmojiDatabase

UnicodeDatabase --> UnifiedSearch
EmojiDatabase --> UnifiedSearch

@enduml
```

### Y.js Collaboration Architecture

```plantuml
@startuml V6_Yjs_Collaboration
!theme cyborg

title V6 Y.js CRDT Collaboration

participant "User A\n(2D Browser)" as A
participant "User B\n(WebXR)" as B
participant "Y.js Doc\n(Client A)" as YA
participant "Y.js Doc\n(Client B)" as YB
participant "Hocuspocus\nServer" as Server
participant "Awareness\nChannel" as Aware

== Initial Sync ==

A -> YA : new Y.Doc()
B -> YB : new Y.Doc()
YA -> Server : connect(room)
YB -> Server : connect(room)
Server -> YA : sync state vector
Server -> YB : sync state vector

== Concurrent Editing ==

A -> YA : getText().insert(0, "Hello")
YA -> Server : update (A's changes)
Server -> YB : broadcast update
YB -> YB : apply (CRDT merge)
YB -> B : render updated text

B -> YB : getText().insert(5, " World")
YB -> Server : update (B's changes)
Server -> YA : broadcast update
YA -> YA : apply (CRDT merge)
YA -> A : render updated text

note over YA, YB
  Both see "Hello World"
  CRDT ensures consistency
end note

== Awareness (Cursor Positions) ==

A -> Aware : setLocalState({cursor: 5, user: "A"})
Aware -> Server : awareness update
Server -> Aware : broadcast
Aware -> B : render A's cursor in XR space

B -> Aware : setLocalState({cursor: 10, user: "B", xrPosition: Vector3})
Aware -> Server : awareness update
Server -> Aware : broadcast
Aware -> A : render B's cursor (avatar in 2D)

@enduml
```

### TTS/STT Pipeline

```plantuml
@startuml V6_TTS_STT_Pipeline
!theme cyborg

title V6 TTS/STT AI Pipeline

actor "User" as U
participant "PWA Frontend" as PWA
participant "AIClient" as AI
participant "TTS Service" as TTS
participant "STT Service" as STT
participant "NLP Service" as NLP
participant "SpatialAudio\n(WebXR)" as SA

== Text-to-Speech Flow ==

U -> PWA : type "שלום עולם"
PWA -> AI : speakText("שלום עולם")

AI -> NLP : POST /detect-language
NLP --> AI : {lang: "he", confidence: 0.98}

AI -> NLP : POST /to-ipa
NLP --> AI : {ipa: "ʃalom olam"}

AI -> TTS : POST /synthesize
note right
  {
    text: "שלום עולם",
    locale: "he-IL",
    voice: "zonos-hebrew-male",
    format: "wav"
  }
end note

TTS -> TTS : Zonos-Hebrew model
TTS --> AI : audioBuffer (WAV)

AI -> SA : playTTS(audio, position)
SA -> U : 3D spatial audio

== Speech-to-Text Flow ==

U -> PWA : press mic button
PWA -> AI : startSTT()

AI -> STT : WS /stream
note right
  WebSocket stream
  for real-time
end note

loop audio chunks
  U -> PWA : speak "הקלד טקסט"
  PWA -> AI : audioChunk
  AI -> STT : send chunk
  STT -> STT : Whisper streaming
  STT --> AI : partial: "הקלד"
  AI --> PWA : update UI
end

STT --> AI : final: "הקלד טקסט"
AI -> PWA : insertText("הקלד טקסט")
PWA -> PWA : insert at cursor

@enduml
```

### RAG Pipeline for Contextual Help

```plantuml
@startuml V6_RAG_Pipeline
!theme cyborg

title V6 RAG Pipeline (Contextual Help)

actor "User" as U
participant "PWA" as PWA
participant "AIClient" as AI
participant "RAG Service" as RAG
database "ChromaDB" as CHROMA
participant "Claude API" as CLAUDE
database "Knowledge Base" as KB

== Indexing Phase (Setup) ==

KB -> RAG : index documents
note right
  - Unicode documentation
  - CLDR specs
  - Keyboard shortcuts
  - Hebrew grammar rules
  - IPA guides
end note

RAG -> RAG : chunk documents
RAG -> RAG : embed chunks (sentence-transformers)
RAG -> CHROMA : store vectors

== Query Phase ==

U -> PWA : "How do I type a dagesh?"
PWA -> AI : ragQuery("How do I type a dagesh?")

AI -> RAG : POST /query
note right
  {
    query: "How do I type a dagesh?",
    context: {
      locale: "he-IL",
      mode: "nikud",
      recentKeys: ["ב", "ּ"]
    },
    k: 5
  }
end note

RAG -> RAG : embed query
RAG -> CHROMA : similarity search (k=5)
CHROMA --> RAG : top 5 chunks

RAG -> CLAUDE : generate response
note right
  System: You are a Hebrew keyboard assistant.
  Context: {retrieved chunks}
  User: How do I type a dagesh?
end note

CLAUDE --> RAG : response

RAG --> AI : {
  answer: "To type a dagesh (ּ), press...",
  sources: [...],
  relatedKeys: ["U+05BC"]
}

AI --> PWA : display help panel
PWA -> U : show contextual help in 2D/3D

@enduml
```

## 🗂️ Project Structure (KMP + Python)

```
unikey-v6/
├── settings.gradle.kts
├── build.gradle.kts
│
├── unikey-common/                    # KMP Common Module
│   ├── build.gradle.kts
│   └── src/commonMain/kotlin/com/unikey/
│       ├── core/
│       │   ├── UniKeyState.kt           [150 lines]
│       │   ├── Mode.kt                  [50 lines]
│       │   └── Locale.kt                [80 lines]
│       │
│       ├── unicode/
│       │   ├── UnicodeDatabase.kt       [300 lines]
│       │   ├── UnicodeChar.kt           [60 lines]
│       │   ├── EmojiDatabase.kt         [250 lines]
│       │   └── Emoji.kt                 [80 lines]
│       │
│       ├── i18n/
│       │   ├── LocaleEngine.kt          [200 lines]
│       │   ├── CLDRLoader.kt            [300 lines]
│       │   ├── KeyboardLayouts.kt       [400 lines]
│       │   ├── NumberFormatter.kt       [150 lines]
│       │   ├── DateFormatter.kt         [150 lines]
│       │   └── UnitConverter.kt         [250 lines]
│       │
│       ├── nlp/
│       │   ├── TextProcessor.kt         [100 lines] expect
│       │   ├── IpaConverter.kt          [300 lines]
│       │   └── LanguageDetector.kt      [100 lines]
│       │
│       └── search/
│           └── UnifiedSearch.kt         [200 lines]
│
├── unikey-js/                        # Kotlin/JS Browser Module
│   ├── build.gradle.kts
│   └── src/jsMain/kotlin/com/unikey/js/
│       ├── Renderer2D.kt                [400 lines]
│       ├── InputHandler.kt              [200 lines]
│       ├── YjsIntegration.kt            [250 lines]
│       ├── AIClient.kt                  [300 lines]
│       ├── ServiceWorkerBridge.kt       [100 lines]
│       ├── JsBridge.kt                  [200 lines]
│       └── Main.kt                      [80 lines]
│
├── web/                              # Pure JavaScript (WebXR)
│   ├── js/
│   │   ├── babylon/
│   │   │   ├── Renderer3D.js            [600 lines]
│   │   │   ├── VoxelKey.js              [250 lines]
│   │   │   ├── VoxelKeyPanel.js         [400 lines]
│   │   │   ├── TextTarget3D.js          [150 lines]
│   │   │   └── SpatialAudio.js          [200 lines]
│   │   │
│   │   ├── xr/
│   │   │   ├── XRManager.js             [350 lines]
│   │   │   ├── HandTracker.js           [300 lines]
│   │   │   └── ControllerInput.js       [200 lines]
│   │   │
│   │   ├── collab/
│   │   │   ├── YjsProvider.js           [200 lines]
│   │   │   └── AwarenessDisplay.js      [150 lines]
│   │   │
│   │   ├── bridge/
│   │   │   └── KotlinBridge.js          [100 lines]
│   │   │
│   │   └── app.js                       [200 lines]
│   │
│   ├── css/
│   │   ├── main.css                     [300 lines]
│   │   ├── keyboard.css                 [200 lines]
│   │   └── xr-overlay.css               [100 lines]
│   │
│   ├── index.html                       [80 lines]
│   ├── index-xr.html                    [100 lines]
│   ├── manifest.json                    [60 lines]
│   └── service-worker.js                [200 lines]
│
├── backend/                          # Python FastAPI Services
│   ├── pyproject.toml
│   ├── requirements.txt
│   │
│   └── app/
│       ├── main.py                      [100 lines]
│       ├── config.py                    [80 lines]
│       │
│       ├── routers/
│       │   ├── tts.py                   [200 lines]
│       │   ├── stt.py                   [200 lines]
│       │   ├── nlp.py                   [250 lines]
│       │   ├── rag.py                   [300 lines]
│       │   ├── units.py                 [150 lines]
│       │   └── yjs.py                   [150 lines]
│       │
│       ├── services/
│       │   ├── tts_service.py           [400 lines]
│       │   ├── stt_service.py           [350 lines]
│       │   ├── nlp_service.py           [400 lines]
│       │   ├── rag_service.py           [500 lines]
│       │   └── units_service.py         [300 lines]
│       │
│       ├── models/
│       │   ├── tts_models.py            [100 lines]
│       │   ├── stt_models.py            [80 lines]
│       │   └── nlp_models.py            [100 lines]
│       │
│       └── utils/
│           ├── cldr_loader.py           [200 lines]
│           └── audio_utils.py           [150 lines]
│
├── data/                             # Shared Data
│   ├── cldr/                         # CLDR 44 JSON
│   │   ├── main/                     # Per-locale data
│   │   ├── keyboards/                # Keyboard layouts
│   │   └── supplemental/             # Shared data
│   │
│   ├── unicode/                      # Unicode 15.1
│   │   ├── UnicodeData.json          # Character database
│   │   ├── Blocks.json               # Block definitions
│   │   ├── Scripts.json              # Script assignments
│   │   └── emoji/                    # Emoji data
│   │
│   └── kb/                           # RAG Knowledge Base
│       ├── unicode-docs/
│       ├── cldr-docs/
│       └── hebrew-grammar/
│
├── docker/
│   ├── Dockerfile.frontend
│   ├── Dockerfile.backend
│   └── docker-compose.yml
│
└── docs/
    ├── V6-AGILE-DISCOVERY.md         # This file
    ├── API.md                        # REST/WS API docs
    └── DEPLOYMENT.md                 # Deployment guide

=== LINE COUNT ESTIMATE ===

KMP Common (Kotlin):        ~2,600 lines
Kotlin/JS (Browser):        ~1,500 lines
Pure JS (WebXR):            ~3,200 lines
Python Backend:             ~3,500 lines
CSS:                          ~600 lines
HTML:                         ~240 lines
Service Worker:               ~200 lines
─────────────────────────────────────────
Total New Code:            ~11,840 lines

CLDR Data:                   ~50 MB
Unicode Data:                ~20 MB
Emoji Data:                   ~5 MB
```

### KMP ↔ Pure JS Bridge Flow

```plantuml
@startuml KMP_JS_Bridge
!theme cyborg

title KMP to Pure JS Bridge Architecture

participant "Pure JS\n(BabylonJS)" as JS
participant "KotlinBridge.js" as KB
participant "JsBridge\n(@JsExport)" as JB
participant "UniKeyState\n(StateFlow)" as State
participant "HebrewProcessor" as HP

== Initialization ==

JS -> KB : document.addEventListener('unikey-ready')
KB -> JB : UniKeyBridge available?
JB --> KB : yes
KB -> JS : window.unikey = bridge
JS -> JS : renderer3D.connectToKotlin()

== Get State ==

JS -> KB : window.unikey.getState()
KB -> JB : UniKeyBridge.getState()
JB -> State : state.value
State --> JB : UniKeyStateData
JB --> KB : dynamic { mode, language, ... }
KB --> JS : plain JS object

== Subscribe to Changes ==

JS -> KB : window.unikey.subscribe(callback)
KB -> JB : UniKeyBridge.subscribe(cb)
JB -> State : state.onEach { ... }
note right: StateFlow collects\nchanges via coroutines

State --> JB : new state emitted
JB --> KB : callback(jsState)
KB --> JS : callback invoked
JS -> JS : onStateChange(newState)
JS -> JS : keyPanel.updateFromState()

== Dispatch Action ==

JS -> KB : window.unikey.toggleModifier('shift')
KB -> JB : UniKeyBridge.toggleModifier('shift')
JB -> State : state.toggleModifier('shift')
State -> State : _state.update { ... }
State --> JB : StateFlow emits
note right: All subscribers\nnotified automatically

== Call Processor ==

JS -> KB : window.unikey.hebrewToIpa('שָׁלוֹם')
KB -> JB : UniKeyBridge.hebrewToIpa(text)
JB -> HP : HebrewProcessor.hebrewToIpa(text)
HP --> JB : "ʃalom"
JB --> KB : String
KB --> JS : "ʃalom"

== Search ==

JS -> KB : window.unikey.search('א', 'LETTERS')
KB -> JB : UniKeyBridge.search(query, mode)
JB -> JB : SearchEngine.searchUTF8()
JB --> KB : Array<dynamic>
KB --> JS : JS array of results

@enduml
```

### Build & Deploy Flow

```plantuml
@startuml Build_Deploy
!theme cyborg

title KMP Build & Deploy Pipeline

rectangle "Source" {
  [unikey-common/\nsrc/commonMain/\n*.kt] as Common
  [unikey-js/\nsrc/jsMain/\n*.kt] as JsMain
  [web/js/\n*.js] as PureJS
  [data/\n*.json] as Data
}

rectangle "Gradle Build" {
  [./gradlew build] as Build
  [Kotlin/JS IR\nCompiler] as KSIR
  [Webpack\nBundler] as WP
}

rectangle "Output" {
  [build/dist/js/\nunikey.js] as KotlinOut
  [web/dist/\nbundle.js] as Bundle
}

rectangle "Deploy" {
  [index.html] as HTML
  [PWA\nmanifest.json] as PWA
  [Service Worker] as SW
}

Common --> Build
JsMain --> Build
Data --> Build

Build --> KSIR
KSIR --> WP
WP --> KotlinOut

PureJS --> Bundle
KotlinOut --> Bundle

Bundle --> HTML
HTML --> PWA
HTML --> SW

note bottom of KotlinOut
  Contains:
  - UniKeyBridge (@JsExport)
  - All Kotlin classes
  - kotlinx runtime
end note

note bottom of Bundle
  Contains:
  - unikey.js (Kotlin)
  - BabylonJS
  - Renderer3D.js
  - VoxelKeyPanel.js
  - XRManager.js
end note

@enduml
```

### Mode State Machine

```plantuml
@startuml Mode_StateMachine
!theme cyborg

title UniKey Keyboard Modes (V5/V6)

[*] --> Letters : init

state Letters {
  [*] --> Hebrew
  Hebrew --> English : Caps
  English --> EnglishCaps : Caps
  EnglishCaps --> Hebrew : Caps
  
  Hebrew : he letters א-ת
  English : en letters a-z
  EnglishCaps : EN letters A-Z
}

Letters --> Nikud : mode=nikud
Letters --> IPA : mode=ipa
Letters --> Emoji : mode=emoji
Letters --> Symbol : mode=symbol
Letters --> MG : mode=mg
Letters --> Rhyme : mode=rhyme
Letters --> Bilingual : mode=bilingual

state Nikud {
  [*] --> NikudLetters
  NikudLetters --> NikudVowels : tab
  NikudVowels --> NikudTeamim : tab
  NikudTeamim --> NikudLetters : tab
  
  NikudLetters : אָ בּ גִ etc
  NikudVowels : ַ ָ ֵ ֶ ִ ֹ ֻ ְ
  NikudTeamim : טעמי המקרא
}

state IPA {
  [*] --> IPALive
  IPALive --> IPARhymes : tab
  IPARhymes --> IPAHeMap : tab
  IPAHeMap --> IPAEnMap : tab
  
  IPALive : real-time conversion
  IPARhymes : rhyme matching
  IPAHeMap : עב→IPA table
  IPAEnMap : EN→IPA table
}

state Emoji {
  [*] --> EmojiSmileys
  EmojiSmileys : 😀 category grid
  note right : skin tone variants
}

state Symbol {
  [*] --> SymbolGames
  SymbolGames : Unicode blocks
  note right : U+0000 - U+1FFFF
}

state MG {
  [*] --> MGSuffixes
  MGSuffixes --> MGGlyphs : section
  MGGlyphs --> MGNikud : section
  
  MGSuffixes : ים/ות patterns
  MGGlyphs : 12 PUA chars
  MGNikud : vowel patterns
}

state Rhyme {
  [*] --> RhymeInput
  RhymeInput : Hebrew↔English bridge
}

state Bilingual {
  [*] --> TreeEditor
  TreeEditor : HE|EN columns
}

Nikud --> Letters : mode=letters
IPA --> Letters : mode=letters
Emoji --> Letters : mode=letters
Symbol --> Letters : mode=letters
MG --> Letters : mode=letters
Rhyme --> Letters : mode=letters
Bilingual --> Letters : mode=letters

@enduml
```

### V5 Render Flow (DOM)

```plantuml
@startuml V5_Render_Flow
!theme cyborg

title V5 Rendering Pipeline (CSS/DOM)

participant "User" as U
participant "handleKeyPress()" as HKP
participant "State Variables" as State
participant "renderKeyboard()" as RK
participant "createKey()" as CK
participant "DOM" as DOM
participant "CSS Variables" as CSS

U -> HKP : click key
activate HKP

HKP -> State : modify state
note right
  currentMode
  currentLanguage
  nikudMode
  shiftHeld
  altHeld
  ctrlHeld
end note

HKP -> RK : re-render
activate RK

RK -> RK : get layout[language]
RK -> DOM : clear innerHTML

loop each row in layout
  RK -> CK : createKey(keyId)
  activate CK
  
  CK -> CK : getUniKeyDisplay()
  CK -> CK : calculate width/height
  CK -> CK : set bgColor based on state
  CK -> DOM : createElement('button')
  CK -> CSS : apply inline styles
  note right
    --key-w: 7.41mm
    --key-h: 7.41mm
    --key-font-size: 2.65mm
    --key-border-radius: 0.79mm
  end note
  CK -> DOM : btn.onclick = handleKeyPress
  CK --> RK : return button
  deactivate CK
  
  RK -> DOM : appendChild(button)
end

RK --> HKP : render complete
deactivate RK
deactivate HKP

@enduml
```

### V6 Render Flow (BabylonJS WebXR)

```plantuml
@startuml V6_Render_Flow
!theme cyborg

title V6 Rendering Pipeline (BabylonJS/WebXR)

participant "User" as U
participant "InputHandler" as IH
participant "UniKeyState" as State
participant "Renderer3D" as R3D
participant "VoxelKeyPanel" as VKP
participant "BabylonJS Scene" as Scene
participant "WebXR" as XR

U -> IH : pinch gesture / controller
activate IH

IH -> State : dispatch action
activate State
State -> State : update state
State -> R3D : notify subscribers
deactivate State

activate R3D
R3D -> R3D : buildKeyElements()
R3D -> VKP : createPanel(position)
activate VKP

loop each keyElement
  VKP -> VKP : createVoxelKey()
  note right
    Box mesh: 60x60x15mm
    Material: PBR
    DynamicTexture: label
  end note
  
  VKP -> Scene : add mesh
  VKP -> Scene : add ActionManager
  VKP -> XR : register for picking
end

VKP --> R3D : panel ready
deactivate VKP

R3D -> Scene : render()
deactivate R3D

Scene -> XR : frame loop
XR -> U : visual feedback

deactivate IH

@enduml
```

### Hand Tracking Flow

```plantuml
@startuml HandTracking_Flow
!theme cyborg

title V6 Hand Tracking Input Pipeline

actor "User Hand" as Hand
participant "WebXR\nHand Tracking" as XRHT
participant "HandTracker" as HT
participant "Ray Casting" as Ray
participant "VoxelKeyPanel" as VKP
participant "InputHandler" as IH
participant "UniKeyState" as State

Hand -> XRHT : physical gesture
activate XRHT

XRHT -> HT : joint positions
activate HT
note right
  INDEX_FINGER_TIP
  THUMB_TIP
  pinch strength
end note

HT -> HT : calculate pinch\nstrength > 0.8?
HT -> Ray : cast from index tip
activate Ray

Ray -> VKP : pickWithRay()
VKP --> Ray : hit mesh + metadata

alt hit.pickedMesh exists
  Ray -> VKP : highlight key
  note right
    emissiveColor = blue
    scale = 1.05
  end note
  
  alt pinch detected
    Ray -> IH : onKeySelect(keyElement)
    activate IH
    IH -> State : handleKeySelect()
    IH -> IH : haptic feedback
    deactivate IH
  end
end

deactivate Ray
deactivate HT
deactivate XRHT

@enduml
```

### Voxel Key Structure

```plantuml
@startuml VoxelKey_Structure
!theme cyborg

title VoxelKey 3D Mesh Composition

package "VoxelKey Mesh" {
  
  class KeyMesh {
    +id: string
    +position: Vector3
    +size: Vector3(60mm, 60mm, 15mm)
    +material: PBRMaterial
    +labelTexture: DynamicTexture
    +actionManager: ActionManager
    --
    +updateLabel(text)
    +setHighlight(bool)
    +setPressedState(bool)
  }
  
  class KeyMaterial {
    +albedoColor: Color3
    +metallic: float = 0.1
    +roughness: float = 0.8
    +emissiveColor: Color3
    --
    States:
    - normal: #2a2a4a
    - hover: #3a3a6a + emissive
    - pressed: #1a1a3a + scale 0.95
    - active: #2563eb (modifier on)
  }
  
  class LabelTexture {
    +size: 128x128
    +font: "48px David Libre"
    +textAlign: center
    +direction: rtl|ltr
    --
    +drawLabel(char, state)
    +drawBadge(type)
  }
  
  class KeyInteraction {
    +OnPickTrigger: select
    +OnPointerOver: highlight
    +OnPointerOut: unhighlight
    +OnLongPress: popup
  }
  
  KeyMesh *-- KeyMaterial
  KeyMesh *-- LabelTexture
  KeyMesh *-- KeyInteraction
}

@enduml
```

### Mode-Specific Components

```plantuml
@startuml Mode_Components
!theme cyborg

title Mode-Specific Rendering (V5→V6)

package "Letters Mode" {
  class LettersV5 {
    renderKeyboard()
    createKey()
    layout.main[][]
    --
    DOM buttons
    CSS flex layout
    inline styles
  }
  
  class LettersV6 {
    Renderer.render()
    VoxelKeyPanel
    KeyElement[][]
    --
    3D box meshes
    Spatial grid layout
    PBR materials
  }
  
  LettersV5 ..> LettersV6 : migrate
}

package "Nikud Mode" {
  class NikudV5 {
    renderNikudKeyboard()
    renderNikudDetailContent()
    hebrewNikudContexts{}
    --
    Grid of nikud options
    Detail panel popup
    Tab navigation
  }
  
  class NikudV6 {
    NikudPanel3D
    NikudPopup3D
    --
    Floating vowel grid
    3D detail popup
    Spatial tabs
  }
  
  NikudV5 ..> NikudV6 : migrate
}

package "IPA Mode" {
  class IPAV5 {
    renderIpaKeyboard()
    renderHebrewToIpa()
    renderEnglishToIpa()
    --
    Live parse panel
    IPA symbol grid
    Rhyme matcher
  }
  
  class IPAV6 {
    IPAPanel3D
    LiveParseDisplay3D
    --
    Floating IPA grid
    Real-time 3D text
    Visual rhyme lines
  }
  
  IPAV5 ..> IPAV6 : migrate
}

package "Emoji Mode" {
  class EmojiV5 {
    renderEmojis()
    renderEmojiCategories()
    filterEmojis()
    --
    Category tabs
    Grid of emojis
    Skin tone variants
  }
  
  class EmojiV6 {
    EmojiPanel3D
    EmojiSearch3D
    --
    Scrollable 3D grid
    Floating variants
    Voice search
  }
  
  EmojiV5 ..> EmojiV6 : migrate
}

package "Symbol Mode" {
  class SymbolV5 {
    renderSymbols()
    renderSymbolBlocks()
    searchSymbols()
    --
    Unicode block tabs
    Symbol grid
    Code search
  }
  
  class SymbolV6 {
    SymbolPanel3D
    BlockBrowser3D
    --
    3D block navigation
    Infinite scroll
    U+code display
  }
  
  SymbolV5 ..> SymbolV6 : migrate
}

package "MG Mode" {
  class MGV5 {
    renderMgHebrewGlyphsGrid()
    renderGenderSuffixGrid()
    ukBuildMgSyl()
    --
    PUA glyph grid
    Suffix patterns
    Ivrita integration
  }
  
  class MGV6 {
    MGPanel3D
    GenderPicker3D
    --
    3D suffix selector
    Visual MF toggle
    Ivrita in XR
  }
  
  MGV5 ..> MGV6 : migrate
}

@enduml
```

### Data Flow Comparison

```plantuml
@startuml Data_Flow_Compare
!theme cyborg

title Data Flow: V5 (Direct) vs V6 (Abstracted)

rectangle "V5 Data Flow" #LightCoral {
  
  (User Click) as UC5
  (handleKeyPress) as HKP5
  (Global State) as GS5
  (render*()) as R5
  (DOM Update) as DOM5
  
  UC5 --> HKP5
  HKP5 --> GS5 : direct modify
  GS5 --> R5 : function call
  R5 --> DOM5 : innerHTML
  
  note bottom of GS5
    let currentMode
    let currentLanguage
    let nikudMode
    (scattered variables)
  end note
}

rectangle "V6 Data Flow" #LightGreen {
  
  (User Gesture) as UG6
  (InputHandler) as IH6
  (UniKeyState) as State6
  (IRenderer) as IR6
  (Scene Update) as Scene6
  
  UG6 --> IH6
  IH6 --> State6 : dispatch()
  State6 --> IR6 : notify()
  IR6 --> Scene6 : mesh.update()
  
  note bottom of State6
    {
      mode: 'letters',
      language: 'hebrew',
      modifiers: {...},
      ...
    }
    (single source of truth)
  end note
}

@enduml
```

### CSS Variables → BabylonJS Materials

```plantuml
@startuml CSS_to_Babylon
!theme cyborg

title Styling: CSS Variables (V5) → Materials (V6)

package "V5: CSS Custom Properties" #LightCoral {
  
  class CSSVariables {
    --key-w: 7.41mm
    --key-h: 7.41mm
    --key-font-size: 2.65mm
    --key-margin: 0.27mm
    --key-padding: 0.53mm
    --key-border-radius: 0.79mm
    --key-bg-color: #2a2a4a
    --key-text-color: #ffffff
    --key-border-color: #3a3a5a
    --theme-accent-blue: #2563eb
  }
  
  class InlineStyles {
    btn.style.cssText = `
      width: var(--key-w);
      height: var(--key-h);
      background: linear-gradient();
      border-radius: var(--key-border-radius);
      box-shadow: 0 1px 0 0 rgba();
    `
  }
  
  CSSVariables --> InlineStyles
}

package "V6: BabylonJS Materials" #LightGreen {
  
  class MaterialConfig {
    KEY_WIDTH: 0.06  // 60mm in meters
    KEY_HEIGHT: 0.06
    KEY_DEPTH: 0.015 // 15mm depth
    KEY_GAP: 0.008
    KEY_CORNER_RADIUS: 0.004
  }
  
  class PBRMaterial {
    albedoColor: Color3(0.16, 0.16, 0.29)
    metallic: 0.1
    roughness: 0.8
    emissiveColor: Color3(0, 0, 0)
    --
    States:
    hover: emissive + 0.1
    pressed: albedo - 0.05
    active: albedo = blue
  }
  
  class DynamicTexture {
    size: 128x128
    font: "48px David Libre"
    fillStyle: "#ffffff"
    textAlign: "center"
    direction: "rtl"
  }
  
  MaterialConfig --> PBRMaterial
  MaterialConfig --> DynamicTexture
}

CSSVariables ..> MaterialConfig : convert\nmm → meters
InlineStyles ..> PBRMaterial : map\ncolors

@enduml
```

### UTF-8 Search Architecture

```plantuml
@startuml UTF8_Search
!theme cyborg

title UTF-8 Search Across All Modes

package "Search Input" {
  [Search Bar 2D] as SB2D
  [Search Panel 3D] as SB3D
  [Voice Input] as Voice
}

package "UniKeyData.searchUTF8()" {
  
  class SearchEngine {
    +query: string
    +mode: string
    +limit: number
    --
    +searchByCodepoint()
    +searchHebrew()
    +searchIPA()
    +searchUnicode()
    +searchEmoji()
  }
  
  database "Data Sources" {
    [UNIKEYS\n48 keys] as UK
    [HE_LETTERS\n27 letters] as HL
    [IPA_UNIKEYS\n85+ symbols] as IU
    [UNICODE_BLOCKS\n35 ranges] as UB
    [emojiData\n~3600 emoji] as ED
  }
  
  SearchEngine --> UK : he/en/ipa
  SearchEngine --> HL : letter info
  SearchEngine --> IU : IPA symbols
  SearchEngine --> UB : U+0000-U+1FFFF
  SearchEngine --> ED : names/chars
}

package "Results Display" {
  [Results Grid 2D] as RG2D
  [Results Panel 3D] as RG3D
  
  class SearchResult {
    type: hebrew|ipa|symbol|emoji
    char: string
    code: number
    name: string
    block?: string
  }
}

SB2D --> SearchEngine
SB3D --> SearchEngine
Voice --> SearchEngine

SearchEngine --> SearchResult
SearchResult --> RG2D
SearchResult --> RG3D

@enduml
```

---

## 🎮 Voxel Key Panel Specification

### Key Dimensions (3D Space)

```
┌─────────────────────────────────────────────────────────────────┐
│  VOXEL KEY SPECIFICATIONS                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Single Key (VoxelKey):                                        │
│  ┌──────────────────┐                                          │
│  │ ╔══════════════╗ │ ← DynamicTexture (label)                │
│  │ ║      א       ║ │   128x128 px                            │
│  │ ║              ║ │   Font: David Libre 48px                │
│  │ ╚══════════════╝ │                                          │
│  └──────────────────┘                                          │
│  Width:  60mm (0.06m)                                          │
│  Height: 60mm (0.06m)                                          │
│  Depth:  15mm (0.015m)                                         │
│  Gap:    8mm (0.008m)                                          │
│  Corner: 4mm radius (rounded box)                              │
│                                                                 │
│  Panel Layout:                                                  │
│  ┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐                    │
│  │ 1 │ 2 │ 3 │ 4 │ 5 │ 6 │ 7 │ 8 │ 9 │ 0 │ ← Row 0           │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                    │
│  │ / │ ' │ ק │ ר │ א │ ט │ ו │ ן │ ם │ פ │ ← Row 1           │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                    │
│  │ ש │ ד │ ג │ כ │ ע │ י │ ח │ ל │ ך │ ף │ ← Row 2           │
│  ├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                    │
│  │ ז │ ס │ ב │ ה │ נ │ מ │ צ │ ת │ ץ │   │ ← Row 3           │
│  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                    │
│                                                                 │
│  Panel Position: (0, 1.0m, -0.5m) from user                    │
│  Panel Tilt: -22.5° (angled toward user face)                  │
│  Total Width: ~680mm                                            │
│  Total Height: ~280mm                                           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Material States

```
┌─────────────────────────────────────────────────────────────────┐
│  VOXEL KEY MATERIAL STATES                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  NORMAL STATE:                                                  │
│  ├─ albedoColor: #2a2a4a (dark purple-gray)                    │
│  ├─ metallic: 0.1                                              │
│  ├─ roughness: 0.8                                             │
│  └─ emissiveColor: #000000                                     │
│                                                                 │
│  HOVER STATE (pointer/finger near):                            │
│  ├─ albedoColor: #3a3a6a (lighter)                             │
│  ├─ emissiveColor: #1a2a4a (subtle glow)                       │
│  ├─ scale: 1.02 (slight grow)                                  │
│  └─ outline: enabled                                           │
│                                                                 │
│  PRESSED STATE (pinch/trigger):                                │
│  ├─ albedoColor: #1a1a3a (darker)                              │
│  ├─ position.z: +5mm (push in)                                 │
│  ├─ scale: 0.98 (shrink)                                       │
│  └─ haptic: 50ms pulse                                         │
│                                                                 │
│  ACTIVE STATE (modifier on):                                   │
│  ├─ albedoColor: #2563eb (blue) for Shift                      │
│  ├─ albedoColor: #059669 (green) for Alt/MG                    │
│  ├─ albedoColor: #dc2626 (red) for Ctrl/IPA                    │
│  └─ emissiveColor: matching glow                               │
│                                                                 │
│  SYLLABLE BADGE:                                               │
│  ├─ Small sphere at top-right corner                           │
│  ├─ color: #4338ca (purple)                                    │
│  └─ indicates popup available                                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🖐️ Hand Tracking Specification

### Gesture Recognition

```
┌─────────────────────────────────────────────────────────────────┐
│  HAND TRACKING GESTURES                                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  POINTING (Key Selection):                                      │
│  ┌─────────┐                                                   │
│  │ ☝️ INDEX │ Extended index finger                             │
│  └─────────┘                                                   │
│  • Ray cast from INDEX_FINGER_TIP                              │
│  • Direction: finger.forward                                    │
│  • Range: 0.5m                                                  │
│  • Highlight key on intersection                                │
│                                                                 │
│  PINCH (Key Activation):                                        │
│  ┌─────────┐                                                   │
│  │ 🤏 PINCH │ Thumb + Index together                            │
│  └─────────┘                                                   │
│  • getPinchStrength() > 0.8                                    │
│  • Cooldown: 300ms between presses                             │
│  • Haptic feedback on activation                                │
│                                                                 │
│  LONG PINCH (Popup):                                           │
│  ┌─────────┐                                                   │
│  │ 🤏⏱️ HOLD │ Pinch held > 500ms                                │
│  └─────────┘                                                   │
│  • Opens syllable/IPA/MG popup                                 │
│  • Popup appears at key position                                │
│                                                                 │
│  SWIPE (Language Switch):                                       │
│  ┌─────────┐                                                   │
│  │ 👋 SWIPE │ Palm swipe left/right                             │
│  └─────────┘                                                   │
│  • Detected via wrist velocity                                  │
│  • Left: Hebrew → English                                      │
│  • Right: English → Hebrew                                     │
│                                                                 │
│  FIST (Cancel/Close):                                          │
│  ┌─────────┐                                                   │
│  │ ✊ FIST  │ All fingers closed                                │
│  └─────────┘                                                   │
│  • Close popup                                                  │
│  • Cancel current action                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Joint Tracking

```plantuml
@startuml Hand_Joints
!theme cyborg

title WebXR Hand Joint Mapping

class HandJoints {
  WRIST
  --
  THUMB_METACARPAL
  THUMB_PHALANX_PROXIMAL
  THUMB_PHALANX_DISTAL
  THUMB_TIP ← pinch detection
  --
  INDEX_FINGER_METACARPAL
  INDEX_FINGER_PHALANX_PROXIMAL
  INDEX_FINGER_PHALANX_INTERMEDIATE
  INDEX_FINGER_PHALANX_DISTAL
  INDEX_FINGER_TIP ← pointing ray
  --
  MIDDLE/RING/PINKY...
}

class PinchDetection {
  thumbTip: Vector3
  indexTip: Vector3
  --
  distance = |thumbTip - indexTip|
  pinchStrength = 1 - (distance / maxDist)
  isPinching = pinchStrength > 0.8
}

class PointingRay {
  origin: INDEX_FINGER_TIP.position
  direction: INDEX_FINGER_TIP.forward
  length: 0.5m
  --
  pickWithRay(ray) → mesh
}

HandJoints --> PinchDetection
HandJoints --> PointingRay

@enduml
```

---

## 📊 Gap Matrix: V5 → V6

### Component Migration Table

| V5 Component | Type | V6 Target | Gap | Effort |
|--------------|------|-----------|-----|--------|
| **State** |
| `currentMode` | var | `UniKeyState.mode` | Wrap in class | S |
| `currentLanguage` | var | `UniKeyState.language` | Wrap in class | S |
| `nikudMode` | var | `UniKeyState.modifiers.shift` | Unify modifier | S |
| `shiftHeld` | var | `UniKeyState.modifiers.shift` | Merge with nikud | S |
| `altHeld` | var | `UniKeyState.modifiers.alt` | Wrap | S |
| `ctrlHeld` | var | `UniKeyState.modifiers.ctrl` | Wrap | S |
| **Data** |
| `UNIKEYS` | const | `UniKeyData.unikeys` | Reference | S |
| `HE_LETTERS` | const | `UniKeyData.heLetters` | Reference | S |
| `NIKUD` | const | `UniKeyData.nikud` | Reference | S |
| `IPA_*` | const | `UniKeyData.ipa*` | Reference | S |
| `UNICODE_BLOCKS` | const | `UniKeyData.unicodeBlocks` | Reference | S |
| `layouts` | const | `UniKeyData.layouts` | Reference | S |
| **Functions** |
| `hebrewTextToIpa()` | func | `UniKeyData.hebrewToIpa()` | Wrap | S |
| `englishTextToIpa()` | func | `UniKeyData.englishToIpa()` | Wrap | S |
| `getRhymeEnding()` | func | `UniKeyData.getRhymeEnding()` | Wrap | S |
| `buildSyllable()` | func | `UniKeyData.buildSyllable()` | Wrap | S |
| `searchSymbols()` | func | `UniKeyData.searchUTF8()` | Extend | M |
| **Render** |
| `renderKeyboard()` | func | `Renderer2D.render()` | Rewrite | L |
| `renderKeyboard()` | func | `Renderer3D.render()` | New | L |
| `createKey()` | func | `KeyElement` class | Abstract | M |
| `createKey()` | func | `VoxelKey` mesh | New | L |
| **Input** |
| `handleKeyPress()` | func | `InputHandler.select()` | Abstract | M |
| click events | DOM | `InputXR` | New | L |
| - | - | `HandInput` | New | L |
| **Rendering** |
| CSS variables | style | `MaterialConfig` | Map | M |
| inline styles | style | `PBRMaterial` | Convert | M |
| DOM elements | node | `Mesh` nodes | New | L |
| **XR** |
| - | - | `XRManager` | New | L |
| - | - | `VoxelKeyPanel` | New | L |
| - | - | `HandTracker` | New | L |

**Legend:** S = Small (1-2h), M = Medium (4-8h), L = Large (1-2d)

### Mode-Specific Gaps

```
┌─────────────────────────────────────────────────────────────────┐
│  MODE GAP ANALYSIS                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  LETTERS MODE:                                                  │
│  V5: renderKeyboard() + createKey() + CSS                      │
│  V6: Renderer3D.render() + VoxelKey + Material                 │
│  Gap: 3D mesh creation, RTL layout in 3D                       │
│  Effort: Large                                                  │
│                                                                 │
│  NIKUD MODE:                                                    │
│  V5: renderNikudKeyboard() + detail panel + tabs               │
│  V6: NikudPanel3D + floating popup + spatial tabs              │
│  Gap: 3D vowel grid, popup positioning                         │
│  Effort: Large                                                  │
│                                                                 │
│  IPA MODE:                                                      │
│  V5: renderIpaKeyboard() + live parse + rhyme panel            │
│  V6: IPAPanel3D + real-time 3D text + visual rhymes            │
│  Gap: Live text in 3D, rhyme visualization                     │
│  Effort: Large                                                  │
│                                                                 │
│  EMOJI MODE:                                                    │
│  V5: renderEmojis() + category tabs + skin tones               │
│  V6: EmojiPanel3D + scrollable grid + variant picker           │
│  Gap: Large grid scrolling in 3D, variant UI                   │
│  Effort: Medium                                                 │
│                                                                 │
│  SYMBOL MODE:                                                   │
│  V5: renderSymbols() + block tabs + search                     │
│  V6: SymbolPanel3D + 3D block browser + search                 │
│  Gap: Unicode range navigation in 3D                           │
│  Effort: Medium                                                 │
│                                                                 │
│  MG MODE:                                                       │
│  V5: renderMgHebrewGlyphsGrid() + suffix grid + Ivrita         │
│  V6: MGPanel3D + gender picker + Ivrita integration            │
│  Gap: PUA font rendering in WebXR, gender UI                   │
│  Effort: Medium                                                 │
│                                                                 │
│  RHYME MODE:                                                    │
│  V5: Rhyme finder panel + cross-language matching              │
│  V6: RhymePanel3D + visual connections                         │
│  Gap: Spatial rhyme visualization                               │
│  Effort: Small                                                  │
│                                                                 │
│  BILINGUAL MODE:                                                │
│  V5: Tree editor + HE|EN columns                               │
│  V6: BilingualPanel3D + side-by-side 3D text                   │
│  Gap: Dual text editing in XR                                   │
│  Effort: Medium                                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Current V5 Architecture Analysis

### Code Statistics
```
Total Lines: 14,594
HTML Structure: ~2,400 lines
CSS Styles: ~1,300 lines  
JavaScript Logic: ~10,800 lines
```

### Current Class Structure

| Class/Object | Purpose | Lines | Reusable |
|--------------|---------|-------|----------|
| `UniKey` | Key data container (he/en/ipa/mg/syl) | 50 | ✅ Yes |
| `UNIKEYS` | 4,200+ phonetic mappings object | 3,100 | ✅ Yes |
| `HE_LETTERS` | Hebrew letter definitions | 50 | ✅ Yes |
| `NIKUD` | Vowel/diacritics definitions | 100 | ✅ Yes |
| `IPA_VOWELS` | IPA vowel mappings | 150 | ✅ Yes |
| `IPA_CONSONANTS` | IPA consonant mappings | 200 | ✅ Yes |
| `UNICODE_BLOCKS` | Symbol range definitions | 200 | ✅ Yes |
| `NUMBER_VARIANTS` | Digit variant options | 200 | ✅ Yes |
| `emojiData` | Loaded emoji dataset | dynamic | ✅ Yes |

### Current Function Categories

| Category | Functions | Purpose | V6 Status |
|----------|-----------|---------|-----------|
| **Rendering** | 25 | DOM manipulation | ❌ Replace with abstraction |
| **State** | 15 | Mode/modifier management | ✅ Reuse with adapter |
| **Data** | 40 | IPA/Hebrew conversions | ✅ Reuse directly |
| **Input** | 12 | Key handling | ⚠️ Adapt for XR |
| **Utility** | 20 | Unit conversion, helpers | ✅ Reuse directly |

---

## 🔍 Gap Analysis: V5 → V6 WebXR

### Current API (V5)

```javascript
// STATE
let currentMode = 'standard';     // Mode: standard|nikud|ipa|emoji|symbol|mg
let currentLanguage = 'hebrew';   // Language: hebrew|english
let nikudMode = false;            // Syllables mode
let capsLock = false;             // Caps state
let shiftHeld = false;            // Shift state
let altHeld = false;              // Alt (MG) state
let ctrlHeld = false;             // Ctrl (IPA) state

// RENDERING (DOM-coupled)
function renderKeyboard()          // Creates DOM buttons
function createKey(key)            // Creates single button element
function handleKeyPress(key)       // Handles click → insert
function insertAtCursor(char)      // DOM execCommand

// DATA (Pure functions - REUSABLE)
function hebrewTextToIpa(text)     // Hebrew → IPA
function englishTextToIpa(text)    // English → IPA
function getRhymeEnding(ipa)       // IPA rhyme analysis
function buildSyllable(letter, nikud) // Letter+nikud composition
```

### Needed API (V6)

```javascript
// ABSTRACTED STATE (Platform-independent)
class UniKeyState {
  mode: 'letters' | 'nikud' | 'ipa' | 'emoji' | 'symbol' | 'mg';
  language: 'hebrew' | 'english';
  modifiers: { shift: boolean, alt: boolean, ctrl: boolean };
  capsLock: boolean;
  numLock: boolean;
}

// ABSTRACTED RENDERING (UI-independent)
interface IKeyRenderer {
  renderKeyboard(layout: KeyLayout): void;
  renderKey(key: KeyData): IKeyElement;
  showPopup(key: string, options: any[]): void;
  hidePopup(): void;
}

// ABSTRACTED INPUT (XR-compatible)
interface IInputHandler {
  onKeySelect(key: string): void;
  onKeyHover(key: string): void;
  onKeyRelease(key: string): void;
  onGesture(gesture: GestureType): void;
}

// 3D KEY PANEL (New)
class Key3DPanel {
  position: Vector3;
  rotation: Quaternion;
  scale: Vector3;
  keys: Key3D[];
  layout: PanelLayout;
}
```

---

## 🏗️ V6 OOP Architecture

### Core Classes (KMP Common - Kotlin)

```
┌─────────────────────────────────────────────────────────────────┐
│                    KMP COMMON MODULE                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  UniKeyState (StateFlow)                                        │
│  ├─ mode: StateFlow<Mode>                                       │
│  ├─ language: StateFlow<Language>                               │
│  ├─ modifiers: StateFlow<Modifiers>                             │
│  └─ Observable pattern with coroutines                          │
│                                                                 │
│  UniKeyData (data classes)                                      │
│  ├─ unikeys: Map<String, UniKey>                                │
│  ├─ heLetters: Map<Char, HebrewLetter>                          │
│  └─ Pure data, no side effects                                  │
│                                                                 │
│  HebrewProcessor (pure functions)                               │
│  ├─ hebrewToIpa(text): String                                   │
│  ├─ buildSyllable(letter, nikud): Syllable                      │
│  └─ All V5 conversion logic                                     │
│                                                                 │
│  SearchEngine                                                   │
│  ├─ searchUTF8(query, mode): List<SearchResult>                 │
│  └─ Cross-mode character search                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    KOTLIN/JS MODULE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Renderer2D (kotlinx.html DSL)                                  │
│  ├─ render() → DOM via DSL                                      │
│  ├─ updateKey(keyId)                                            │
│  └─ showPopup(keyId, options)                                   │
│                                                                 │
│  InputHandler (DOM events)                                      │
│  ├─ onKeyClick(keyId)                                           │
│  ├─ onModifier(mod)                                             │
│  └─ Keyboard event handling                                     │
│                                                                 │
│  JsBridge (@JsExport)                                           │
│  ├─ Exposes Kotlin APIs to JS                                   │
│  ├─ getState() → dynamic                                        │
│  └─ subscribe(callback)                                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    PURE JAVASCRIPT (WebXR)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Renderer3D (BabylonJS)                                         │
│  ├─ Creates 3D scene                                            │
│  ├─ Calls window.unikey for state                               │
│  └─ Subscribes to Kotlin state changes                          │
│                                                                 │
│  VoxelKeyPanel                                                  │
│  ├─ 3D keyboard mesh layout                                     │
│  └─ VoxelKey instances                                          │
│                                                                 │
│  XRManager                                                      │
│  ├─ WebXR session handling                                      │
│  └─ VR/AR mode switching                                        │
│                                                                 │
│  HandTracker                                                    │
│  ├─ WebXR hand tracking                                         │
│  └─ Pinch gesture detection                                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Class Definitions (Kotlin)

```kotlin
// ═══════════════════════════════════════════════════════════════════════
// unikey-common/src/commonMain/kotlin/com/unikey/state/UniKeyState.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.state

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Mode {
    LETTERS, NIKUD, IPA, EMOJI, SYMBOL, MG, RHYME, BILINGUAL
}

enum class Language {
    HEBREW, ENGLISH
}

data class Modifiers(
    val shift: Boolean = false,
    val alt: Boolean = false,
    val ctrl: Boolean = false
)

data class UniKeyStateData(
    val mode: Mode = Mode.LETTERS,
    val language: Language = Language.HEBREW,
    val modifiers: Modifiers = Modifiers(),
    val capsLock: Boolean = false,
    val capsState: Int = 2, // 0=en, 1=EN, 2=he
    val searchQuery: String = "",
    val xrMode: String = "none"
)

class UniKeyState {
    private val _state = MutableStateFlow(UniKeyStateData())
    val state: StateFlow<UniKeyStateData> = _state.asStateFlow()
    
    // Convenience getters
    val mode: Mode get() = _state.value.mode
    val language: Language get() = _state.value.language
    val modifiers: Modifiers get() = _state.value.modifiers
    val isHebrew: Boolean get() = language == Language.HEBREW
    val isShift: Boolean get() = modifiers.shift
    val isAlt: Boolean get() = modifiers.alt
    val isCtrl: Boolean get() = modifiers.ctrl
    
    fun setMode(mode: Mode) {
        _state.update { it.copy(mode = mode) }
    }
    
    fun setLanguage(lang: Language) {
        _state.update { it.copy(language = lang) }
    }
    
    fun toggleModifier(mod: String) {
        _state.update { current ->
            val newMods = when (mod) {
                "shift" -> current.modifiers.copy(shift = !current.modifiers.shift)
                "alt" -> current.modifiers.copy(alt = !current.modifiers.alt)
                "ctrl" -> current.modifiers.copy(ctrl = !current.modifiers.ctrl)
                else -> current.modifiers
            }
            current.copy(modifiers = newMods)
        }
    }
    
    fun cycleCaps() {
        _state.update { current ->
            val newCapsState = (current.capsState + 1) % 3
            val newLang = if (newCapsState == 2) Language.HEBREW else Language.ENGLISH
            val newCapsLock = newCapsState == 1
            current.copy(
                capsState = newCapsState,
                language = newLang,
                capsLock = newCapsLock
            )
        }
    }
    
    fun setSearch(query: String) {
        _state.update { it.copy(searchQuery = query) }
    }
    
    fun setXRMode(mode: String) {
        _state.update { it.copy(xrMode = mode) }
    }
}

// ═══════════════════════════════════════════════════════════════════════
// unikey-common/src/commonMain/kotlin/com/unikey/data/UniKey.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.data

import kotlinx.serialization.Serializable

@Serializable
data class Syllable(
    val text: String,
    val ipa: String,
    val nikud: String = ""
)

@Serializable
data class MultiGender(
    val m: String,      // Male Hebrew
    val f: String,      // Female Hebrew
    val mf: String,     // Combined Hebrew
    val fm: String? = null,
    val m_en: String? = null,   // Male English
    val f_en: String? = null,   // Female English
    val mf_en: String? = null,  // Combined English
    val mf_short: String? = null,
    val fm_short: String? = null
)

@Serializable
data class UniKey(
    val id: String,
    val en: String,
    val EN: String = en.uppercase(),
    val he: String? = null,
    val heShift: String? = null,
    val shift: String? = null,
    val ipa: String? = null,
    val syl: List<Syllable> = emptyList(),
    val enSyl: List<Syllable> = emptyList(),
    val mg: MultiGender? = null
) {
    fun label(mode: String, modifiers: Modifiers): String {
        return when {
            modifiers.ctrl && ipa != null -> ipa
            modifiers.alt && mg != null -> {
                if (mode == "he") mg.mf else mg.mf_en ?: ""
            }
            modifiers.shift -> {
                if (mode == "he") "$he·" else "$en·"
            }
            mode == "he" -> he ?: en
            mode == "EN" -> EN
            else -> en
        }
    }
    
    fun getSyllables(mode: String): List<Syllable> {
        return if (mode == "he") syl else enSyl
    }
}

// ═══════════════════════════════════════════════════════════════════════
// unikey-common/src/commonMain/kotlin/com/unikey/data/UniKeyData.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class HebrewLetter(
    val char: Char,
    val name: String,
    val ipa: String,
    val type: String = "regular", // regular, guttural, bgdkpt
    val dageshIpa: String? = null
)

@Serializable
data class Nikud(
    val char: String,
    val name: String,
    val ipa: String,
    val type: String // vowel, hataf, shva, dagesh
)

@Serializable
data class IpaSymbol(
    val symbol: String,
    val name: String,
    val type: String, // vowel, consonant, diacritic
    val heEquiv: String? = null,
    val enExample: String? = null
)

object UniKeyData {
    // Loaded from JSON resources
    lateinit var unikeys: Map<String, UniKey>
    lateinit var heLetters: Map<Char, HebrewLetter>
    lateinit var nikud: Map<String, Nikud>
    lateinit var ipaSymbols: Map<String, IpaSymbol>
    lateinit var layouts: Map<String, KeyboardLayout>
    
    private val json = Json { ignoreUnknownKeys = true }
    
    fun initialize(
        unikeysJson: String,
        heLettersJson: String,
        nikudJson: String,
        ipaJson: String,
        layoutsJson: String
    ) {
        unikeys = json.decodeFromString(unikeysJson)
        heLetters = json.decodeFromString(heLettersJson)
        nikud = json.decodeFromString(nikudJson)
        ipaSymbols = json.decodeFromString(ipaJson)
        layouts = json.decodeFromString(layoutsJson)
    }
    
    fun getKey(id: String): UniKey? = unikeys[id]
    
    fun getKeyByHe(he: String): UniKey? = 
        unikeys.values.find { it.he == he }
    
    fun getKeyByEn(en: String): UniKey? = 
        unikeys.values.find { it.en == en }
    
    fun getLayout(language: Language): KeyboardLayout =
        layouts[language.name.lowercase()] ?: error("Layout not found")
}

@Serializable
data class KeyboardLayout(
    val main: List<List<String>>,
    val function: List<List<String>> = emptyList(),
    val nav: List<List<String>> = emptyList(),
    val numpad: List<List<String>> = emptyList()
)

// ═══════════════════════════════════════════════════════════════════════
// unikey-common/src/commonMain/kotlin/com/unikey/processor/HebrewProcessor.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.processor

import com.unikey.data.UniKeyData
import com.unikey.data.Syllable

object HebrewProcessor {
    
    // Hebrew consonant to IPA mapping
    private val consonantToIpa = mapOf(
        'א' to "ʔ", 'ב' to "v", 'ג' to "g", 'ד' to "d",
        'ה' to "h", 'ו' to "v", 'ז' to "z", 'ח' to "ħ",
        'ט' to "t", 'י' to "j", 'כ' to "x", 'ך' to "x",
        'ל' to "l", 'מ' to "m", 'ם' to "m", 'נ' to "n",
        'ן' to "n", 'ס' to "s", 'ע' to "ʕ", 'פ' to "f",
        'ף' to "f", 'צ' to "ts", 'ץ' to "ts", 'ק' to "k",
        'ר' to "ʁ", 'ש' to "ʃ", 'ת' to "t"
    )
    
    // Nikud to IPA vowel mapping
    private val nikudToIpa = mapOf(
        '\u05B8' to "a",  // Kamatz
        '\u05B7' to "a",  // Patach
        '\u05B5' to "e",  // Tzere
        '\u05B6' to "e",  // Segol
        '\u05B4' to "i",  // Chirik
        '\u05B9' to "o",  // Cholam
        '\u05BB' to "u",  // Kubutz
        '\u05B0' to "ə",  // Shva
    )
    
    fun hebrewToIpa(text: String): String {
        val result = StringBuilder()
        var i = 0
        
        while (i < text.length) {
            val char = text[i]
            
            when {
                char == ' ' || char == '\t' -> {
                    result.append(' ')
                }
                char in consonantToIpa -> {
                    result.append(consonantToIpa[char])
                }
                char.code in 0x05B0..0x05BC -> {
                    // Nikud
                    nikudToIpa[char]?.let { result.append(it) }
                }
            }
            i++
        }
        
        return result.toString()
    }
    
    fun englishToIpa(text: String): String {
        // Simplified English to IPA
        // Full implementation would use pronunciation dictionary
        return text.lowercase()
            .replace("sh", "ʃ")
            .replace("ch", "tʃ")
            .replace("th", "θ")
            .replace("ng", "ŋ")
    }
    
    fun buildSyllable(letter: Char, nikud: Char): Syllable {
        val ipa = (consonantToIpa[letter] ?: "") + (nikudToIpa[nikud] ?: "")
        return Syllable(
            text = "$letter$nikud",
            ipa = ipa,
            nikud = nikud.toString()
        )
    }
    
    fun isValidNikud(letter: Char, nikud: Char): Boolean {
        // Guttural letters have restrictions
        val gutturals = setOf('א', 'ה', 'ח', 'ע')
        if (letter in gutturals && nikud == '\u05BB') { // kubutz
            return false
        }
        return true
    }
    
    fun isGuttural(letter: Char): Boolean =
        letter in setOf('א', 'ה', 'ח', 'ע')
}

// ═══════════════════════════════════════════════════════════════════════
// unikey-common/src/commonMain/kotlin/com/unikey/search/SearchEngine.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.search

import com.unikey.data.UniKeyData
import com.unikey.data.UniKey
import com.unikey.data.IpaSymbol
import com.unikey.state.Mode

sealed class SearchResult {
    data class Hebrew(val key: UniKey) : SearchResult()
    data class Ipa(val symbol: IpaSymbol) : SearchResult()
    data class Codepoint(val char: String, val code: Int, val name: String) : SearchResult()
    data class Emoji(val char: String, val name: String) : SearchResult()
}

object SearchEngine {
    
    fun searchUTF8(query: String, mode: Mode = Mode.LETTERS, limit: Int = 50): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        val q = query.lowercase()
        
        // Search by codepoint (U+XXXX)
        if (query.startsWith("U+", ignoreCase = true)) {
            val code = query.drop(2).toIntOrNull(16)
            if (code != null) {
                val char = Char(code).toString()
                results.add(SearchResult.Codepoint(
                    char = char,
                    code = code,
                    name = "U+${code.toString(16).uppercase().padStart(4, '0')}"
                ))
            }
        }
        
        // Search Hebrew keys
        if (mode == Mode.LETTERS || mode == Mode.NIKUD) {
            UniKeyData.unikeys.values
                .filter { key ->
                    key.he?.contains(q) == true ||
                    key.ipa?.contains(q) == true ||
                    key.id == q
                }
                .take(limit - results.size)
                .forEach { results.add(SearchResult.Hebrew(it)) }
        }
        
        // Search IPA symbols
        if (mode == Mode.IPA || mode == Mode.LETTERS) {
            UniKeyData.ipaSymbols.values
                .filter { it.symbol.contains(q) || it.name.lowercase().contains(q) }
                .take(limit - results.size)
                .forEach { results.add(SearchResult.Ipa(it)) }
        }
        
        return results.take(limit)
    }
}

// ═══════════════════════════════════════════════════════════════════════
// unikey-js/src/jsMain/kotlin/com/unikey/js/JsBridge.kt
// ═══════════════════════════════════════════════════════════════════════

package com.unikey.js

import com.unikey.state.UniKeyState
import com.unikey.state.Mode
import com.unikey.state.Language
import com.unikey.data.UniKeyData
import com.unikey.processor.HebrewProcessor
import com.unikey.search.SearchEngine
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

@JsExport
@JsName("UniKeyBridge")
object JsBridge {
    private val state = UniKeyState()
    private val callbacks = mutableListOf<(dynamic) -> Unit>()
    
    init {
        // Forward state changes to JS callbacks
        state.state.onEach { newState ->
            val jsState = js("{}")
            jsState.mode = newState.mode.name
            jsState.language = newState.language.name
            jsState.shift = newState.modifiers.shift
            jsState.alt = newState.modifiers.alt
            jsState.ctrl = newState.modifiers.ctrl
            jsState.capsLock = newState.capsLock
            jsState.capsState = newState.capsState
            jsState.xrMode = newState.xrMode
            
            callbacks.forEach { it(jsState) }
        }.launchIn(GlobalScope)
    }
    
    @JsName("getState")
    fun getState(): dynamic {
        val s = state.state.value
        val result = js("{}")
        result.mode = s.mode.name
        result.language = s.language.name
        result.shift = s.modifiers.shift
        result.alt = s.modifiers.alt
        result.ctrl = s.modifiers.ctrl
        result.capsLock = s.capsLock
        result.capsState = s.capsState
        result.xrMode = s.xrMode
        return result
    }
    
    @JsName("setMode")
    fun setMode(mode: String) {
        state.setMode(Mode.valueOf(mode.uppercase()))
    }
    
    @JsName("setLanguage")
    fun setLanguage(lang: String) {
        state.setLanguage(Language.valueOf(lang.uppercase()))
    }
    
    @JsName("toggleModifier")
    fun toggleModifier(mod: String) {
        state.toggleModifier(mod)
    }
    
    @JsName("cycleCaps")
    fun cycleCaps() {
        state.cycleCaps()
    }
    
    @JsName("setXRMode")
    fun setXRMode(mode: String) {
        state.setXRMode(mode)
    }
    
    @JsName("subscribe")
    fun subscribe(callback: (dynamic) -> Unit) {
        callbacks.add(callback)
    }
    
    @JsName("hebrewToIpa")
    fun hebrewToIpa(text: String): String {
        return HebrewProcessor.hebrewToIpa(text)
    }
    
    @JsName("search")
    fun search(query: String, mode: String): dynamic {
        val results = SearchEngine.searchUTF8(
            query, 
            Mode.valueOf(mode.uppercase())
        )
        return results.map { result ->
            val obj = js("{}")
            when (result) {
                is com.unikey.search.SearchResult.Hebrew -> {
                    obj.type = "hebrew"
                    obj.id = result.key.id
                    obj.he = result.key.he
                    obj.ipa = result.key.ipa
                }
                is com.unikey.search.SearchResult.Ipa -> {
                    obj.type = "ipa"
                    obj.symbol = result.symbol.symbol
                    obj.name = result.symbol.name
                }
                is com.unikey.search.SearchResult.Codepoint -> {
                    obj.type = "codepoint"
                    obj.char = result.char
                    obj.code = result.code
                    obj.name = result.name
                }
                is com.unikey.search.SearchResult.Emoji -> {
                    obj.type = "emoji"
                    obj.char = result.char
                    obj.name = result.name
                }
            }
            obj
        }.toTypedArray()
    }
    
    @JsName("getKey")
    fun getKey(id: String): dynamic {
        val key = UniKeyData.getKey(id) ?: return null
        val result = js("{}")
        result.id = key.id
        result.en = key.en
        result.EN = key.EN
        result.he = key.he
        result.ipa = key.ipa
        return result
    }
}
```

### Pure JavaScript (BabylonJS/WebXR)

```javascript
// ═══════════════════════════════════════════════════════════════════════
// web/js/bridge/KotlinBridge.js - Bridge to Kotlin/JS
// ═══════════════════════════════════════════════════════════════════════

// Wait for Kotlin module to load
window.unikey = null;

function initUniKeyBridge() {
  // Kotlin/JS exports to window.UniKeyBridge
  if (typeof UniKeyBridge !== 'undefined') {
    window.unikey = {
      getState: () => UniKeyBridge.getState(),
      setMode: (m) => UniKeyBridge.setMode(m),
      setLanguage: (l) => UniKeyBridge.setLanguage(l),
      toggleModifier: (m) => UniKeyBridge.toggleModifier(m),
      cycleCaps: () => UniKeyBridge.cycleCaps(),
      setXRMode: (m) => UniKeyBridge.setXRMode(m),
      subscribe: (cb) => UniKeyBridge.subscribe(cb),
      hebrewToIpa: (t) => UniKeyBridge.hebrewToIpa(t),
      search: (q, m) => UniKeyBridge.search(q, m),
      getKey: (id) => UniKeyBridge.getKey(id),
    };
    console.log('UniKey bridge initialized');
    return true;
  }
  return false;
}

// Retry until Kotlin is loaded
const bridgeInterval = setInterval(() => {
  if (initUniKeyBridge()) {
    clearInterval(bridgeInterval);
    document.dispatchEvent(new Event('unikey-ready'));
  }
}, 100);

// ═══════════════════════════════════════════════════════════════════════
// web/js/babylon/Renderer3D.js - BabylonJS 3D Renderer
// ═══════════════════════════════════════════════════════════════════════

class Renderer3D {
  constructor(canvas) {
    this.canvas = canvas;
    this.engine = new BABYLON.Engine(canvas, true);
    this.scene = new BABYLON.Scene(this.engine);
    this.keyPanel = null;
    this.state = null;
    
    this.init();
  }
  
  init() {
    // Scene setup
    this.scene.clearColor = new BABYLON.Color4(0.05, 0.05, 0.1, 1);
    
    // Camera
    this.camera = new BABYLON.FreeCamera(
      'camera',
      new BABYLON.Vector3(0, 1.6, 0),
      this.scene
    );
    this.camera.attachControl(this.canvas, true);
    
    // Light
    new BABYLON.HemisphericLight(
      'light',
      new BABYLON.Vector3(0, 1, 0),
      this.scene
    );
    
    // Wait for Kotlin bridge
    document.addEventListener('unikey-ready', () => {
      this.connectToKotlin();
    });
    
    // Render loop
    this.engine.runRenderLoop(() => this.scene.render());
    window.addEventListener('resize', () => this.engine.resize());
  }
  
  connectToKotlin() {
    // Get initial state
    this.state = window.unikey.getState();
    
    // Subscribe to state changes
    window.unikey.subscribe((newState) => {
      this.state = newState;
      this.onStateChange(newState);
    });
    
    // Create keyboard panel
    this.keyPanel = new VoxelKeyPanel(this.scene, this.state);
    this.keyPanel.render();
  }
  
  onStateChange(state) {
    if (this.keyPanel) {
      this.keyPanel.updateFromState(state);
    }
  }
  
  onKeySelect(keyId) {
    // Forward to Kotlin for processing
    const key = window.unikey.getKey(keyId);
    if (key) {
      // Insert character based on state
      const state = this.state;
      let char = state.language === 'HEBREW' ? key.he : key.en;
      if (state.capsLock && state.language === 'ENGLISH') {
        char = key.EN;
      }
      this.textTarget?.insertText(char);
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════
// web/js/babylon/VoxelKeyPanel.js - 3D Keyboard Panel
// ═══════════════════════════════════════════════════════════════════════

class VoxelKeyPanel {
  constructor(scene, state) {
    this.scene = scene;
    this.state = state;
    this.keys = new Map();
    this.panel = null;
    
    // Key dimensions (meters)
    this.keyWidth = 0.06;
    this.keyHeight = 0.06;
    this.keyDepth = 0.015;
    this.keyGap = 0.008;
  }
  
  render() {
    // Create panel transform node
    this.panel = new BABYLON.TransformNode('keyPanel', this.scene);
    this.panel.position = new BABYLON.Vector3(0, 1.0, -0.5);
    this.panel.rotation = new BABYLON.Vector3(-Math.PI / 8, 0, 0);
    
    // Get layout from Kotlin (via bridge)
    const layout = this.getLayout();
    
    let yOffset = 0;
    layout.forEach(row => {
      let xOffset = -row.length * (this.keyWidth + this.keyGap) / 2;
      
      row.forEach(keyId => {
        const voxelKey = new VoxelKey(this.scene, {
          id: keyId,
          position: new BABYLON.Vector3(xOffset, yOffset, 0),
          size: { 
            width: this.keyWidth, 
            height: this.keyHeight, 
            depth: this.keyDepth 
          },
          state: this.state,
        });
        
        voxelKey.mesh.parent = this.panel;
        voxelKey.onSelect = (id) => this.onKeySelect(id);
        
        this.keys.set(keyId, voxelKey);
        xOffset += this.keyWidth + this.keyGap;
      });
      
      yOffset -= this.keyHeight + this.keyGap;
    });
  }
  
  getLayout() {
    // Hebrew layout (RTL)
    if (this.state.language === 'HEBREW') {
      return [
        ['1','2','3','4','5','6','7','8','9','0','-','='],
        ['/','\'','q','r','a','y','u','i','o','p','[',']'],
        ['s','d','g','k','g','h','j','l',';','\''],
        ['z','x','c','v','b','n','m',',','.','/'],
      ];
    }
    // English layout (LTR)
    return [
      ['1','2','3','4','5','6','7','8','9','0','-','='],
      ['q','w','e','r','t','y','u','i','o','p','[',']'],
      ['a','s','d','f','g','h','j','k','l',';','\''],
      ['z','x','c','v','b','n','m',',','.','/'],
    ];
  }
  
  updateFromState(state) {
    this.state = state;
    this.keys.forEach((voxelKey, id) => {
      voxelKey.updateLabel(state);
    });
  }
  
  onKeySelect(keyId) {
    // Handled by Renderer3D
  }
}
```

```
┌─────────────────────────────────────────────────────────────────┐
│                     UniKeyApp (Main Controller)                  │
│  - Coordinates state, rendering, and input                       │
│  - Platform detection (2D/XR)                                    │
│  - Mode switching                                                │
└─────────────────────────────────────────────────────────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        ▼                       ▼                       ▼
┌───────────────┐     ┌─────────────────┐     ┌─────────────────┐
│ UniKeyState   │     │ UniKeyData      │     │ UniKeyRenderer  │
│ (Observable)  │     │ (Pure Data)     │     │ (Abstract)      │
│               │     │                 │     │                 │
│ - mode        │     │ - UNIKEYS       │     │ + render()      │
│ - language    │     │ - HE_LETTERS    │     │ + update()      │
│ - modifiers   │     │ - NIKUD         │     │ + dispose()     │
│ - subscribe() │     │ - IPA_*         │     │                 │
└───────────────┘     │ - UNICODE_*     │     └────────┬────────┘
                      │ - heToIpa()     │              │
                      │ - enToIpa()     │     ┌────────┴────────┐
                      └─────────────────┘     │                 │
                                        ┌─────▼─────┐   ┌───────▼───────┐
                                        │ Renderer  │   │ Renderer      │
                                        │ 2D (CSS)  │   │ 3D (Babylon)  │
                                        └───────────┘   └───────────────┘
```

### Class Definitions

```javascript
// ═══════════════════════════════════════════════════════════════
// UNIKEY STATE - Observable state management
// ═══════════════════════════════════════════════════════════════

class UniKeyState {
  constructor() {
    this._state = {
      mode: 'letters',
      language: 'hebrew',
      modifiers: { shift: false, alt: false, ctrl: false },
      capsLock: false,
      numLock: true,
      activePopup: null,
      searchQuery: '',
    };
    this._listeners = [];
  }

  get state() { return { ...this._state }; }
  
  setState(partial) {
    this._state = { ...this._state, ...partial };
    this._notify();
  }

  setMode(mode) { this.setState({ mode }); }
  setLanguage(lang) { this.setState({ language: lang }); }
  toggleModifier(mod) { 
    this.setState({ 
      modifiers: { ...this._state.modifiers, [mod]: !this._state.modifiers[mod] }
    });
  }

  subscribe(listener) {
    this._listeners.push(listener);
    return () => this._listeners = this._listeners.filter(l => l !== listener);
  }

  _notify() {
    this._listeners.forEach(l => l(this._state));
  }
}

// ═══════════════════════════════════════════════════════════════
// UNIKEY DATA - Pure data layer (REUSED FROM V5)
// ═══════════════════════════════════════════════════════════════

class UniKeyData {
  constructor() {
    // Import all V5 data structures
    this.unikeys = UNIKEYS;           // 4,200+ mappings
    this.heLetters = HE_LETTERS;      // Hebrew letter defs
    this.nikud = NIKUD;               // Vowel definitions
    this.ipaVowels = IPA_VOWELS;      // IPA vowels
    this.ipaConsonants = IPA_CONSONANTS; // IPA consonants
    this.unicodeBlocks = UNICODE_BLOCKS; // Symbol ranges
  }

  // V5 functions wrapped as methods
  hebrewToIpa(text) { return hebrewTextToIpa(text); }
  englishToIpa(text) { return englishTextToIpa(text); }
  getRhymeEnding(ipa, syllables) { return getRhymeEnding(ipa, syllables); }
  buildSyllable(letter, nikud, opts) { return buildSyllable(letter, nikud, opts); }
  getUniKey(id) { return this.unikeys[id]; }
  getKeyByHe(he) { return Object.values(this.unikeys).find(k => k.he === he); }
  getKeyByEn(en) { return Object.values(this.unikeys).find(k => k.en === en); }
  
  // UTF-8 Search (NEW)
  searchUTF8(query, mode) {
    const results = [];
    const q = query.toLowerCase();
    
    if (mode === 'emoji' && this.emojiData) {
      results.push(...this.emojiData.filter(e => 
        e.name.toLowerCase().includes(q) || e.char === query
      ));
    }
    
    if (mode === 'symbol') {
      Object.entries(this.unicodeBlocks).forEach(([id, block]) => {
        for (let cp = block.start; cp <= block.end; cp++) {
          const char = String.fromCodePoint(cp);
          if (block.name.toLowerCase().includes(q) || char === query) {
            results.push({ char, name: block.name, code: cp });
          }
        }
      });
    }
    
    if (mode === 'hebrew' || mode === 'all') {
      Object.values(this.unikeys).forEach(uk => {
        if (uk.he && (uk.he.includes(q) || uk.ipa?.includes(q))) {
          results.push({ type: 'hebrew', ...uk });
        }
      });
    }
    
    return results;
  }
}

// ═══════════════════════════════════════════════════════════════
// KEY ELEMENT - Abstract key representation
// ═══════════════════════════════════════════════════════════════

class KeyElement {
  constructor(config) {
    this.id = config.id;
    this.label = config.label;
    this.sublabel = config.sublabel || '';
    this.width = config.width || 1;
    this.height = config.height || 1;
    this.type = config.type || 'standard'; // standard|special|modifier
    this.data = config.data || null;
  }

  getLabel(state) {
    const { language, modifiers } = state;
    if (this.data instanceof UniKey) {
      return this.data.label(language === 'hebrew' ? 'he' : 'en', modifiers);
    }
    return this.label;
  }
}

// ═══════════════════════════════════════════════════════════════
// ABSTRACT RENDERER - Base class for all renderers
// ═══════════════════════════════════════════════════════════════

class UniKeyRenderer {
  constructor(state, data) {
    this.state = state;
    this.data = data;
    this.keys = new Map(); // id → rendered element
    this.unsubscribe = state.subscribe(s => this.onStateChange(s));
  }

  // Abstract methods (must override)
  render() { throw new Error('Abstract method'); }
  renderKey(keyElement) { throw new Error('Abstract method'); }
  showPopup(keyId, options) { throw new Error('Abstract method'); }
  hidePopup() { throw new Error('Abstract method'); }
  dispose() { 
    this.unsubscribe?.();
    this.keys.clear();
  }

  onStateChange(newState) {
    this.render();
  }

  // Shared logic
  getLayout() {
    const { mode, language } = this.state.state;
    // Return appropriate layout based on mode
    return layouts[language]; // V5 layouts
  }
}

// ═══════════════════════════════════════════════════════════════
// 2D CSS RENDERER - HTML/CSS implementation
// ═══════════════════════════════════════════════════════════════

class Renderer2D extends UniKeyRenderer {
  constructor(state, data, containerId) {
    super(state, data);
    this.container = document.getElementById(containerId);
  }

  render() {
    // Use V5 renderKeyboard() logic adapted for class structure
    const layout = this.getLayout();
    this.container.innerHTML = '';
    // ... DOM creation logic
  }

  renderKey(keyElement) {
    const btn = document.createElement('button');
    btn.className = 'key';
    btn.textContent = keyElement.getLabel(this.state.state);
    btn.onclick = () => this.handleKeyClick(keyElement.id);
    return btn;
  }

  showPopup(keyId, options) {
    // Create floating popup
  }

  hidePopup() {
    // Remove popup
  }

  handleKeyClick(keyId) {
    // Delegate to input handler
  }
}

// ═══════════════════════════════════════════════════════════════
// 3D BABYLONJS RENDERER - WebXR implementation
// ═══════════════════════════════════════════════════════════════

class Renderer3D extends UniKeyRenderer {
  constructor(state, data, scene) {
    super(state, data);
    this.scene = scene;
    this.keyMeshes = new Map();
    this.panels = [];
  }

  render() {
    this.clearPanels();
    const layout = this.getLayout();
    
    // Create 3D keyboard panel
    const panel = this.createKeyPanel({
      position: new BABYLON.Vector3(0, 1.2, -0.8),
      rows: layout.main.length,
      cols: Math.max(...layout.main.map(r => r.length)),
    });
    
    layout.main.forEach((row, rowIdx) => {
      row.forEach((key, colIdx) => {
        const keyElement = new KeyElement({
          id: key,
          label: key,
          data: this.data.getUniKey(key),
        });
        const mesh = this.renderKey(keyElement, rowIdx, colIdx);
        panel.add(mesh);
      });
    });
    
    this.panels.push(panel);
  }

  renderKey(keyElement, row, col) {
    const keySize = 0.08;
    const gap = 0.01;
    
    // Create key mesh
    const mesh = BABYLON.MeshBuilder.CreateBox(keyElement.id, {
      width: keySize * keyElement.width,
      height: keySize * keyElement.height,
      depth: 0.02,
    }, this.scene);
    
    // Position in grid
    mesh.position = new BABYLON.Vector3(
      col * (keySize + gap),
      -row * (keySize + gap),
      0
    );
    
    // Add material
    const mat = new BABYLON.StandardMaterial(keyElement.id + '_mat', this.scene);
    mat.diffuseColor = new BABYLON.Color3(0.2, 0.4, 0.6);
    mesh.material = mat;
    
    // Add label texture
    this.addKeyLabel(mesh, keyElement);
    
    // Add interaction
    mesh.actionManager = new BABYLON.ActionManager(this.scene);
    mesh.actionManager.registerAction(
      new BABYLON.ExecuteCodeAction(
        BABYLON.ActionManager.OnPickTrigger,
        () => this.handleKeyClick(keyElement.id)
      )
    );
    
    this.keyMeshes.set(keyElement.id, mesh);
    return mesh;
  }

  addKeyLabel(mesh, keyElement) {
    // Dynamic texture for Hebrew/English text
    const texture = new BABYLON.DynamicTexture(
      keyElement.id + '_tex',
      { width: 128, height: 128 },
      this.scene
    );
    const ctx = texture.getContext();
    ctx.fillStyle = 'white';
    ctx.font = 'bold 40px David Libre, Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(keyElement.getLabel(this.state.state), 64, 64);
    texture.update();
    
    mesh.material.diffuseTexture = texture;
  }

  createKeyPanel(config) {
    const panel = new BABYLON.TransformNode('keyPanel', this.scene);
    panel.position = config.position;
    return panel;
  }

  showPopup(keyId, options) {
    // Create 3D floating popup panel
    const popup = this.createKeyPanel({
      position: this.keyMeshes.get(keyId).position.add(new BABYLON.Vector3(0, 0, -0.1)),
    });
    
    options.forEach((opt, i) => {
      const optMesh = this.renderKey(new KeyElement({
        id: `${keyId}_opt_${i}`,
        label: opt.label,
        data: opt,
      }), 0, i);
      popup.add(optMesh);
    });
    
    this.popup = popup;
  }

  hidePopup() {
    if (this.popup) {
      this.popup.dispose();
      this.popup = null;
    }
  }

  clearPanels() {
    this.panels.forEach(p => p.dispose());
    this.panels = [];
    this.keyMeshes.clear();
  }

  dispose() {
    super.dispose();
    this.clearPanels();
  }
}

// ═══════════════════════════════════════════════════════════════
// INPUT HANDLER - Abstract input handling
// ═══════════════════════════════════════════════════════════════

class UniKeyInputHandler {
  constructor(state, data, textTarget) {
    this.state = state;
    this.data = data;
    this.textTarget = textTarget; // Could be DOM element or 3D text mesh
  }

  handleKeySelect(keyId) {
    const s = this.state.state;
    
    // Special keys
    if (keyId === '{caps}') {
      this.cycleCaps();
      return;
    }
    if (keyId.match(/\{shift[lr]\}/)) {
      this.state.toggleModifier('shift');
      return;
    }
    if (keyId.match(/\{alt[lr]\}/)) {
      this.state.toggleModifier('alt');
      return;
    }
    if (keyId.match(/\{ctrl[lr]\}/)) {
      this.state.toggleModifier('ctrl');
      return;
    }
    
    // Regular keys
    const uk = this.data.getUniKey(keyId) || 
               this.data.getKeyByHe(keyId) || 
               this.data.getKeyByEn(keyId);
    
    if (s.modifiers.ctrl && uk?.ipa) {
      // Show IPA popup
      return { action: 'popup', type: 'ipa', key: keyId };
    }
    
    if (s.modifiers.alt && uk?.mg) {
      // Show MG popup
      return { action: 'popup', type: 'mg', key: keyId };
    }
    
    if (s.modifiers.shift && uk?.syl?.length > 0) {
      // Show syllables popup
      return { action: 'popup', type: 'syllable', key: keyId };
    }
    
    // Insert character
    const char = uk ? uk.label(s.language === 'hebrew' ? 'he' : 'en', s.modifiers) : keyId;
    this.insertText(char);
  }

  insertText(text) {
    // Abstract - override for DOM or 3D
    throw new Error('Abstract method');
  }

  cycleCaps() {
    // Implement V5 caps cycling logic
  }
}

class InputHandler2D extends UniKeyInputHandler {
  insertText(text) {
    document.execCommand('insertText', false, text);
  }
}

class InputHandler3D extends UniKeyInputHandler {
  constructor(state, data, textMesh) {
    super(state, data, textMesh);
    this.textContent = '';
  }

  insertText(text) {
    this.textContent += text;
    this.updateTextMesh();
  }

  updateTextMesh() {
    // Update 3D text display
  }
}

// ═══════════════════════════════════════════════════════════════
// XR HAND TRACKING - WebXR hand input
// ═══════════════════════════════════════════════════════════════

class XRHandTracker {
  constructor(scene, inputHandler) {
    this.scene = scene;
    this.inputHandler = inputHandler;
    this.hoveredKey = null;
    this.pinchThreshold = 0.7;
  }

  setup(xrHelper) {
    const featuresManager = xrHelper.baseExperience.featuresManager;
    this.handTracking = featuresManager.enableFeature(
      BABYLON.WebXRFeatureName.HAND_TRACKING,
      'latest',
      { xrInput: xrHelper.input }
    );

    this.handTracking.onHandAddedObservable.add(hand => {
      hand.onHandJointObservable.add(jointData => {
        this.processHandJoint(jointData);
      });
    });
  }

  processHandJoint(jointData) {
    // Index finger tip for pointing
    const indexTip = jointData.handMesh.getJointMesh(BABYLON.WebXRHandJoint.INDEX_FINGER_TIP);
    if (!indexTip) return;

    // Ray from index finger
    const ray = new BABYLON.Ray(indexTip.position, indexTip.forward, 1);
    const hit = this.scene.pickWithRay(ray);

    if (hit.pickedMesh?.metadata?.keyId) {
      this.hoveredKey = hit.pickedMesh.metadata.keyId;
      this.highlightKey(hit.pickedMesh);
      
      // Check for pinch gesture
      const pinchStrength = jointData.hand.getPinchStrength();
      if (pinchStrength > this.pinchThreshold) {
        this.inputHandler.handleKeySelect(this.hoveredKey);
      }
    } else {
      this.clearHighlight();
    }
  }

  highlightKey(mesh) {
    mesh.material.emissiveColor = new BABYLON.Color3(0.2, 0.5, 1);
  }

  clearHighlight() {
    // Reset all key materials
  }
}
```

---

## 📋 Gap Checklist

### Data Layer (Reuse from V5)
- [x] UniKey class - 4,200+ mappings
- [x] HE_LETTERS - Hebrew letter definitions
- [x] NIKUD - Vowel definitions
- [x] IPA_VOWELS/IPA_CONSONANTS - IPA mappings
- [x] UNICODE_BLOCKS - Symbol ranges
- [x] hebrewTextToIpa() - Hebrew → IPA
- [x] englishTextToIpa() - English → IPA
- [x] buildSyllable() - Letter+nikud composition
- [x] getRhymeEnding() - Rhyme analysis
- [ ] **NEW** UTF-8 search across all modes

### State Layer (Adapt from V5)
- [x] Mode management (8 modes)
- [x] Language switching (he/en)
- [x] Modifier states (shift/alt/ctrl)
- [ ] **NEW** Observable state pattern
- [ ] **NEW** State persistence (localStorage)

### Rendering Layer (Replace)
- [ ] **NEW** Abstract renderer interface
- [ ] **NEW** 2D CSS renderer (from V5 logic)
- [ ] **NEW** 3D BabylonJS renderer
- [ ] **NEW** 3D key panels (floating keyboards)
- [ ] **NEW** 3D popup menus
- [ ] **NEW** RTL text in 3D

### Input Layer (Extend)
- [x] Click/touch handling (V5)
- [ ] **NEW** Abstract input interface
- [ ] **NEW** XR controller input
- [ ] **NEW** Hand tracking (pinch/point)
- [ ] **NEW** Gaze-based selection

### XR Layer (New)
- [ ] **NEW** WebXR session management
- [ ] **NEW** Hand tracking feature
- [ ] **NEW** Controller input
- [ ] **NEW** Passthrough mode (AR)
- [ ] **NEW** Spatial audio feedback

---

## 🗂️ File Structure (V6 KMP + JS)

```
unikey-v6/
├── build.gradle.kts                 # Root build config
├── settings.gradle.kts              # Multi-module settings
├── gradle.properties                # Kotlin/JS settings
│
├── unikey-common/                   # KMP Common Module
│   ├── build.gradle.kts
│   └── src/
│       ├── commonMain/kotlin/com/unikey/
│       │   ├── state/
│       │   │   ├── UniKeyState.kt       [120 lines]
│       │   │   ├── Mode.kt              [20 lines]
│       │   │   └── Modifiers.kt         [30 lines]
│       │   │
│       │   ├── data/
│       │   │   ├── UniKey.kt            [80 lines]
│       │   │   ├── UniKeyData.kt        [150 lines]
│       │   │   ├── HebrewLetter.kt      [60 lines]
│       │   │   ├── Nikud.kt             [50 lines]
│       │   │   ├── IpaSymbol.kt         [40 lines]
│       │   │   └── MultiGender.kt       [70 lines]
│       │   │
│       │   ├── processor/
│       │   │   ├── HebrewProcessor.kt   [400 lines]
│       │   │   ├── IpaConverter.kt      [300 lines]
│       │   │   ├── SyllableBuilder.kt   [250 lines]
│       │   │   └── RhymeMatcher.kt      [150 lines]
│       │   │
│       │   ├── search/
│       │   │   └── SearchEngine.kt      [200 lines]
│       │   │
│       │   └── platform/
│       │       ├── TextTarget.kt        [30 lines] expect
│       │       └── Renderer.kt          [50 lines] expect
│       │
│       └── commonTest/kotlin/
│           └── HebrewProcessorTest.kt   [150 lines]
│
├── unikey-js/                       # Kotlin/JS Browser Module
│   ├── build.gradle.kts
│   └── src/
│       ├── jsMain/kotlin/com/unikey/js/
│       │   ├── Renderer2D.kt            [350 lines]
│       │   ├── InputHandler.kt          [200 lines]
│       │   ├── TextTarget2D.kt          [80 lines]
│       │   ├── JsBridge.kt              [150 lines] @JsExport
│       │   └── Main.kt                  [50 lines]
│       │
│       └── jsMain/resources/
│           └── index.html               [60 lines]
│
├── web/                             # Pure JavaScript (WebXR)
│   ├── js/
│   │   ├── babylon/
│   │   │   ├── Renderer3D.js            [500 lines]
│   │   │   ├── VoxelKey.js              [200 lines]
│   │   │   ├── VoxelKeyPanel.js         [300 lines]
│   │   │   └── TextTarget3D.js          [150 lines]
│   │   │
│   │   ├── xr/
│   │   │   ├── XRManager.js             [300 lines]
│   │   │   ├── HandTracker.js           [250 lines]
│   │   │   └── ControllerInput.js       [200 lines]
│   │   │
│   │   ├── bridge/
│   │   │   └── KotlinBridge.js          [100 lines]
│   │   │
│   │   └── app-xr.js                    [150 lines]
│   │
│   ├── css/
│   │   ├── main.css                     [200 lines]
│   │   └── keyboard.css                 [150 lines]
│   │
│   ├── index.html                       [50 lines] 2D mode
│   ├── index-xr.html                    [80 lines] 3D/XR mode
│   ├── manifest.json                    [40 lines]
│   └── service-worker.js                [100 lines]
│
├── data/                            # V5 Data (converted to Kotlin)
│   ├── unikeys.json                     [exported from V5]
│   ├── hebrew-letters.json
│   ├── ipa-symbols.json
│   ├── unicode-blocks.json
│   └── layouts.json
│
└── docs/
    ├── V6-AGILE-DISCOVERY.md            [this file]
    └── API.md

=== LINE COUNT ESTIMATE ===
KMP Common:     ~1,700 lines (Kotlin)
Kotlin/JS:        ~900 lines (Kotlin)
Pure JS (XR):   ~2,000 lines (JavaScript)
CSS:              ~350 lines
HTML:             ~200 lines
────────────────────────────
Total New Code: ~5,150 lines

V5 Data (JSON):  ~7,000 lines (converted)
```

### Gradle Configuration

```kotlin
// settings.gradle.kts
rootProject.name = "unikey-v6"

include(":unikey-common")
include(":unikey-js")

// build.gradle.kts (root)
plugins {
    kotlin("multiplatform") version "1.9.22" apply false
    kotlin("plugin.serialization") version "1.9.22" apply false
}

// unikey-common/build.gradle.kts
plugins {
    kotlin("multiplatform")
    kotlin("plugin.serialization")
}

kotlin {
    js(IR) {
        browser()
        binaries.executable()
    }
    
    // Future: JVM for Android, Native for iOS
    // jvm()
    // iosArm64()
    
    sourceSets {
        commonMain {
            dependencies {
                implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
                implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.2")
            }
        }
        commonTest {
            dependencies {
                implementation(kotlin("test"))
            }
        }
        jsMain {
            dependencies {
                implementation("org.jetbrains.kotlinx:kotlinx-html-js:0.11.0")
            }
        }
    }
}

// unikey-js/build.gradle.kts
plugins {
    kotlin("js")
}

kotlin {
    js(IR) {
        browser {
            webpackTask {
                outputFileName = "unikey.js"
            }
        }
        binaries.executable()
    }
}

dependencies {
    implementation(project(":unikey-common"))
    implementation("org.jetbrains.kotlinx:kotlinx-html-js:0.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core-js:1.7.3")
}
```

```
unikey-v6/
├── index.html                 # Entry point
├── manifest.json              # PWA manifest
├── service-worker.js          # Offline support
├── css/
│   ├── main.css               # 2D styles
│   └── 3d-fallback.css        # CSS 3D transforms
├── js/
│   ├── core/
│   │   ├── UniKeyState.js     # State management
│   │   ├── UniKeyData.js      # Data layer (V5 reuse)
│   │   └── UniKey.js          # Key class
│   ├── data/
│   │   ├── unikeys.js         # 4,200+ mappings (V5)
│   │   ├── hebrew.js          # HE_LETTERS, NIKUD (V5)
│   │   ├── ipa.js             # IPA_VOWELS, etc (V5)
│   │   └── unicode.js         # UNICODE_BLOCKS (V5)
│   ├── renderers/
│   │   ├── UniKeyRenderer.js  # Abstract base
│   │   ├── Renderer2D.js      # HTML/CSS
│   │   └── Renderer3D.js      # BabylonJS
│   ├── input/
│   │   ├── InputHandler.js    # Abstract base
│   │   ├── InputHandler2D.js  # DOM events
│   │   ├── InputHandler3D.js  # XR input
│   │   └── XRHandTracker.js   # Hand tracking
│   ├── xr/
│   │   ├── XRManager.js       # Session management
│   │   └── XRKeyboard.js      # 3D keyboard
│   └── app.js                 # Main app
└── assets/
    ├── fonts/                 # Hebrew fonts
    ├── icons/                 # PWA icons
    └── models/                # 3D models (optional)
```

---

## 🔄 Migration Path (Full Platform)

### Phase 1: Infrastructure Setup (2 days)
1. Create KMP Gradle multi-module project
2. Setup Python FastAPI backend structure
3. Configure Docker Compose for services
4. Setup ChromaDB and Hocuspocus

### Phase 2: CLDR/Unicode Data Layer (3 days)
1. Download and process CLDR 44 JSON
2. Parse Unicode 15.1 UCD into JSON
3. Process Emoji 15.1 sequences
4. Create Kotlin data classes
5. Implement CLDRLoader and UnicodeDatabase

### Phase 3: KMP Core (3 days)
1. Implement UniKeyState with StateFlow
2. Create LocaleEngine with 700+ locales
3. Port KeyboardLayouts from CLDR
4. Implement UnitConverter (LocaleUnits)
5. Create UnifiedSearch engine

### Phase 4: Kotlin/JS Browser (2 days)
1. Implement Renderer2D with kotlinx.html
2. Create InputHandler for DOM events
3. Setup Y.js integration
4. Create JsBridge @JsExport

### Phase 5: Pure JS WebXR (4 days)
1. Implement Renderer3D with BabylonJS
2. Create VoxelKeyPanel and VoxelKey
3. Setup XRManager for VR/AR
4. Implement HandTracker
5. Add SpatialAudio for TTS

### Phase 6: Python TTS/STT (3 days)
1. Setup Zonos-Hebrew TTS
2. Integrate Coqui/Edge-TTS
3. Setup Whisper STT
4. Implement streaming endpoints
5. Add locale-aware voice selection

### Phase 7: Python NLP/RAG (3 days)
1. Setup DictaBERT and mBERT
2. Implement sentence-transformers embeddings
3. Setup ChromaDB vector store
4. Implement LangChain RAG pipeline
5. Connect Claude API for generation

### Phase 8: Y.js Collaboration (2 days)
1. Setup Hocuspocus server
2. Implement awareness protocol
3. Add XR cursor sharing
4. Test multi-user sync

### Phase 9: PWA & Integration (2 days)
1. Create manifest.json with i18n
2. Implement service worker (offline CLDR cache)
3. Add IndexedDB for preferences
4. End-to-end testing

### Phase 10: Polish & Deploy (2 days)
1. Performance optimization
2. Quest 3 / Vision Pro testing
3. Docker deployment
4. Documentation

---

## 📊 Effort Estimate (Full Platform)

| Phase | Days | Tech Stack | Priority |
|-------|------|------------|----------|
| Infrastructure | 2 | Docker, Gradle | P0 |
| CLDR/Unicode Data | 3 | Kotlin, JSON | P0 |
| KMP Core | 3 | Kotlin Multiplatform | P0 |
| Kotlin/JS Browser | 2 | kotlinx.html | P0 |
| Pure JS WebXR | 4 | BabylonJS | P0 |
| Python TTS/STT | 3 | FastAPI, Whisper | P1 |
| Python NLP/RAG | 3 | LangChain, ChromaDB | P1 |
| Y.js Collaboration | 2 | Hocuspocus | P1 |
| PWA Integration | 2 | Service Worker | P0 |
| Polish & Deploy | 2 | Docker | P0 |
| **Total** | **26 days** | | |

### Line Count by Module

| Module | Language | Lines | Notes |
|--------|----------|-------|-------|
| unikey-common | Kotlin | ~2,600 | Core logic |
| unikey-js | Kotlin | ~1,500 | Browser |
| web (WebXR) | JavaScript | ~3,200 | BabylonJS |
| backend | Python | ~3,500 | AI services |
| CSS/HTML | CSS/HTML | ~840 | Styling |
| **Total** | | **~11,640** | New code |

### Data Sizes

| Data | Size | Format |
|------|------|--------|
| CLDR 44 | ~50 MB | JSON |
| Unicode 15.1 | ~20 MB | JSON |
| Emoji 15.1 | ~5 MB | JSON |
| RAG KB | ~10 MB | Markdown |
| **Total** | **~85 MB** | |

---

## ✅ Success Criteria

### Core Features
- [ ] **All 700+ CLDR locales** supported with keyboard layouts
- [ ] **Full Unicode 15.1** (149,813 characters) searchable
- [ ] **All Emoji 15.1** (3,790) with skin tones and ZWJ
- [ ] **2D/3D mode switch** seamless state preservation
- [ ] **WebXR hand tracking** works on Quest 3

### AI Integration
- [ ] **TTS** works for Hebrew, English, Arabic, + 20 languages
- [ ] **STT** real-time transcription <500ms latency
- [ ] **RAG** contextual help for Unicode/keyboard questions
- [ ] **Spatial audio** TTS positioned at key in XR

### Collaboration
- [ ] **Y.js sync** <100ms latency
- [ ] **Awareness** shows remote cursors
- [ ] **XR collaboration** sees other users' avatar hands

### PWA
- [ ] **Installable** on desktop and mobile
- [ ] **Offline mode** with cached CLDR data
- [ ] **60fps** in both 2D and 3D modes

### Performance Targets
- [ ] Initial load: <3s (2D), <5s (XR)
- [ ] Key press latency: <16ms
- [ ] TTS response: <500ms
- [ ] STT streaming: real-time
- [ ] Y.js sync: <100ms

---

## 🧪 Testing Matrix

### Platform Testing

| Platform | 2D | 3D | XR | TTS | STT |
|----------|----|----|----|----|-----|
| Chrome Desktop | ✓ | ✓ | - | ✓ | ✓ |
| Firefox Desktop | ✓ | ✓ | - | ✓ | ✓ |
| Safari Desktop | ✓ | ✓ | - | ✓ | ✓ |
| Chrome Android | ✓ | ✓ | - | ✓ | ✓ |
| Safari iOS | ✓ | ✓ | - | ✓ | ✓ |
| Quest 3 Browser | ✓ | ✓ | ✓ | ✓ | ✓ |
| Vision Pro | ✓ | ✓ | ✓ | ✓ | ✓ |

### Locale Testing (Subset)

| Locale | Keyboard | TTS | STT | Numbers | Units |
|--------|----------|-----|-----|---------|-------|
| he-IL | ✓ | ✓ | ✓ | ✓ | ✓ |
| en-US | ✓ | ✓ | ✓ | ✓ | ✓ |
| ar-SA | ✓ | ✓ | ✓ | ✓ | ✓ |
| zh-CN | ✓ | ✓ | ✓ | ✓ | ✓ |
| ja-JP | ✓ | ✓ | ✓ | ✓ | ✓ |
| ru-RU | ✓ | ✓ | ✓ | ✓ | ✓ |
| de-DE | ✓ | ✓ | ✓ | ✓ | ✓ |
| fr-FR | ✓ | ✓ | ✓ | ✓ | ✓ |

---

## 🚀 Deployment Architecture

```plantuml
@startuml V6_Deployment
!theme cyborg

title V6 Deployment Architecture

cloud "CDN (Cloudflare)" as CDN {
  [PWA Static Assets]
  [CLDR JSON Cache]
  [Unicode Data Cache]
}

node "Kubernetes Cluster" as K8S {
  
  node "Frontend Pod" {
    [Nginx] as NGINX
    [PWA Bundle] as PWA
  }
  
  node "Backend Pod (x3)" {
    [FastAPI] as API
    [Gunicorn] as GUN
  }
  
  node "AI Pod (GPU)" {
    [TTS Models] as TTS_M
    [STT Models] as STT_M
    [NLP Models] as NLP_M
  }
  
  node "Collab Pod" {
    [Hocuspocus] as HOCUS
  }
  
  database "PostgreSQL" as PG
  database "ChromaDB" as CHROMA
  database "Redis" as REDIS
}

actor "User" as U

U --> CDN : static assets
U --> NGINX : API requests
NGINX --> API : /api/*
NGINX --> HOCUS : /ws/yjs
API --> CHROMA : vectors
API --> REDIS : cache
API --> TTS_M : TTS
API --> STT_M : STT
API --> NLP_M : NLP
HOCUS --> REDIS : pub/sub

@enduml
```

### Docker Compose (Development)

```yaml
# docker-compose.yml
version: '3.8'

services:
  frontend:
    build:
      context: .
      dockerfile: docker/Dockerfile.frontend
    ports:
      - "3000:80"
    volumes:
      - ./web:/app/web
      - ./data:/app/data:ro
    depends_on:
      - backend
      - hocuspocus

  backend:
    build:
      context: .
      dockerfile: docker/Dockerfile.backend
    ports:
      - "8000:8000"
    volumes:
      - ./backend:/app/backend
      - ./data:/app/data:ro
      - model-cache:/app/models
    environment:
      - CUDA_VISIBLE_DEVICES=0
      - CHROMADB_HOST=chromadb
      - REDIS_HOST=redis
    depends_on:
      - chromadb
      - redis
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]

  hocuspocus:
    image: hocuspocus/hocuspocus:latest
    ports:
      - "1234:1234"
    environment:
      - REDIS_URL=redis://redis:6379

  chromadb:
    image: chromadb/chroma:latest
    ports:
      - "8001:8000"
    volumes:
      - chroma-data:/chroma/chroma

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  model-cache:
  chroma-data:
```

---

## ✅ Success Criteria

1. **2D Mode**: All V5 features work identically
2. **3D Mode**: Keyboard renders in BabylonJS scene
3. **XR Mode**: Hand tracking selects keys
4. **Search**: UTF-8 search works in all modes
5. **PWA**: Installable, works offline
6. **Performance**: 60fps on Quest 3

---

## 📐 Detailed Mode Diagrams

### Letters Mode: V5 DOM vs V6 Voxel

```plantuml
@startuml Letters_Mode_Comparison
!theme cyborg

title Letters Mode: V5 (DOM) vs V6 (Voxel3D)

rectangle "V5 Letters Mode (DOM)" #LightCoral {
  
  package "renderKeyboard()" {
    [layout[currentLanguage]] as Layout5
    [document.createElement('div')] as Div5
    [createKey(keyId)] as CK5
    [btn.style.cssText] as CSS5
    [btn.onclick] as Click5
  }
  
  Layout5 --> Div5 : iterate rows
  Div5 --> CK5 : iterate keys
  CK5 --> CSS5 : apply styles
  CK5 --> Click5 : bind event
  
  note bottom of CSS5
    width: var(--key-w)
    height: var(--key-h)
    background: linear-gradient()
    border-radius: var(--key-border-radius)
  end note
}

rectangle "V6 Letters Mode (Voxel3D)" #LightGreen {
  
  package "Renderer3D.render()" {
    [buildKeyElements()] as BKE6
    [createPanel(position)] as CP6
    [createVoxelKey(keyEl)] as CVK6
    [PBRMaterial] as MAT6
    [ActionManager] as AM6
  }
  
  BKE6 --> CP6 : create panel
  CP6 --> CVK6 : iterate keys
  CVK6 --> MAT6 : apply material
  CVK6 --> AM6 : register actions
  
  note bottom of MAT6
    albedoColor: Color3(0.16, 0.16, 0.29)
    metallic: 0.1
    roughness: 0.8
    DynamicTexture for label
  end note
}

CSS5 ..> MAT6 : style mapping

@enduml
```

### Nikud Mode: Syllable Popup Flow

```plantuml
@startuml Nikud_Mode_Flow
!theme cyborg

title Nikud Mode: Syllable Selection Flow

participant "User" as U
participant "Key (א)" as K
participant "State" as S
participant "Renderer" as R
participant "Popup" as P
participant "TextTarget" as T

== V5 Flow (DOM) ==

U -> K : click with Shift held
K -> S : check nikudMode = true
S -> R : openSyllablesPopup('t')
R -> P : create floating div
P -> P : populate with syllables
note right
  אָ אַ אֵ אֶ אִ אֹ אֻ אְ
  (from ukBuildHeSyl)
end note
U -> P : click syllable אָ
P -> T : insertAtCursor('אָ')
P -> R : close popup

== V6 Flow (Voxel3D) ==

U -> K : pinch with Shift active
K -> S : check modifiers.shift = true
S -> R : showPopup(keyId, options)
R -> P : create 3D panel
P -> P : create VoxelKey for each syllable
note right
  3D grid of syllable keys
  positioned above main key
end note
U -> P : pinch syllable אָ
P -> T : TextTarget3D.insertText('אָ')
P -> R : hidePopup()

@enduml
```

### IPA Mode: Live Conversion Pipeline

```plantuml
@startuml IPA_Mode_Pipeline
!theme cyborg

title IPA Mode: Real-time Conversion Pipeline

rectangle "V5 IPA Mode" #LightCoral {
  
  [Input Text\n"שָׁלוֹם"] as In5
  [hebrewTextToIpa()] as Conv5
  [IPA Output\n"ʃalom"] as Out5
  [DOM Display] as Disp5
  
  In5 --> Conv5
  Conv5 --> Out5
  Out5 --> Disp5
  
  note bottom of Conv5
    1. Parse nikud
    2. Map consonants
    3. Apply rules (dagesh, etc)
    4. Join IPA symbols
  end note
}

rectangle "V6 IPA Mode" #LightGreen {
  
  [Input Text\n"שָׁלוֹם"] as In6
  [UniKeyData.hebrewToIpa()] as Conv6
  [IPA Output\n"ʃalom"] as Out6
  [TextTarget3D] as Disp6
  [IPA Symbol Panel] as Panel6
  
  In6 --> Conv6
  Conv6 --> Out6
  Out6 --> Disp6
  Out6 --> Panel6 : highlight used
  
  note bottom of Panel6
    3D IPA keyboard
    Active symbols glow
    Tap to insert directly
  end note
}

Conv5 ..> Conv6 : reuse function

@enduml
```

### Emoji Mode: Category Navigation

```plantuml
@startuml Emoji_Mode_Nav
!theme cyborg

title Emoji Mode: Category & Variant Selection

state "Emoji Mode" as EM {
  
  state "Category Tabs" as CT {
    CT : 😀 Smileys
    CT : 👋 People  
    CT : 🐱 Animals
    CT : 🍎 Food
    CT : ⚽ Activities
    CT : 🌍 Travel
    CT : 💡 Objects
    CT : ❤️ Symbols
    CT : 🚩 Flags
  }
  
  state "Emoji Grid" as EG {
    EG : scrollable grid
    EG : filtered by category
    EG : search results
  }
  
  state "Variant Popup" as VP {
    VP : skin tone variants
    VP : 👋🏻👋🏼👋🏽👋🏾👋🏿
  }
  
  CT --> EG : select category
  EG --> VP : long press emoji
  VP --> EG : select variant
}

note right of EM
  V5: DOM grid + CSS scroll
  V6: 3D scrollable panel
      gesture-based selection
end note

@enduml
```

### Symbol Mode: Unicode Block Browser

```plantuml
@startuml Symbol_Mode_Browser
!theme cyborg

title Symbol Mode: Unicode Block Navigation

rectangle "UNICODE_BLOCKS Data" {
  
  collections "Block Definitions" as BD {
    BD : arrows: 0x2190-0x21FF
    BD : mathOperators: 0x2200-0x22FF
    BD : boxDrawing: 0x2500-0x257F
    BD : geometricShapes: 0x25A0-0x25FF
    BD : miscSymbols: 0x2600-0x26FF
    BD : dingbats: 0x2700-0x27BF
    BD : ...35 blocks total
  }
}

rectangle "V5 Symbol Browser" #LightCoral {
  [Category Tabs] as CT5
  [Block Dropdown] as BD5
  [Symbol Grid] as SG5
  [Search Input] as SI5
  
  CT5 --> BD5
  BD5 --> SG5
  SI5 --> SG5 : filter
}

rectangle "V6 Symbol Browser" #LightGreen {
  [3D Category Ring] as CR6
  [Block Panel] as BP6
  [Symbol Voxel Grid] as SVG6
  [Voice/Gesture Search] as VS6
  
  CR6 --> BP6 : rotate to select
  BP6 --> SVG6 : paginate
  VS6 --> SVG6 : filter
  
  note bottom of SVG6
    Infinite scroll in 3D
    U+code shown on hover
    Pinch to select
  end note
}

BD --> CT5
BD --> CR6

@enduml
```

### MG Mode: Multi-Gender Selection

```plantuml
@startuml MG_Mode_Selection
!theme cyborg

title MG Mode: Multi-Gender Suffix Selection

rectangle "Ivrita System" {
  
  package "19 Suffix Rules" {
    [Rule 1: ים/ות → ימ·ות] as R1
    [Rule 2: ה/- → ה·] as R2
    [Rule 3: ת/- → ת·] as R3
    [Rule 4: י/ת → י·ת] as R4
    [Rule 5: ן/נית → נ·ית] as R5
    [Rule 6: ו/ה → ו·ה] as R6
    [... 13 more rules]
  }
  
  package "12 PUA Glyphs" {
    [U+E000: ◌ימ·ות] as G1
    [U+E001: ◌ה·] as G2
    [U+E002: ◌ת·] as G3
    [U+E003: ◌י·ת] as G4
    [... 8 more glyphs]
  }
}

rectangle "V5 MG Mode" #LightCoral {
  [Suffix Grid] as SG5
  [Glyph Grid] as GG5
  [Pattern Grid] as PG5
  
  SG5 : click suffix → insert
  GG5 : display PUA chars
  PG5 : nikud patterns
}

rectangle "V6 MG Mode" #LightGreen {
  [3D Suffix Wheel] as SW6
  [Gender Toggle] as GT6
  [MG Key Labels] as MKL6
  
  SW6 : rotate to browse
  GT6 : ♂ ⚧ ♀ switch
  MKL6 : Alt+key shows MG
  
  note bottom of SW6
    Hand gesture: twist
    to rotate wheel
  end note
}

R1 --> SG5
R1 --> SW6
G1 --> GG5
G1 --> MKL6

@enduml
```

---

## 🎨 CSS to BabylonJS Style Mapping

### V5 CSS Variables

```css
/* V5: CSS Custom Properties (extracted) */
:root {
  /* Key Dimensions */
  --key-w: 7.41mm;           /* 28px at 96dpi */
  --key-h: 7.41mm;
  --key-margin: 0.27mm;      /* 1px */
  --key-padding: 0.53mm;     /* 2px */
  --key-border-radius: 0.79mm; /* 3px */
  --key-border-width: 0.26mm;  /* 1px */
  --key-font-size: 2.65mm;   /* 10px */
  
  /* Colors */
  --key-bg-color: #2a2a4a;
  --key-bg-special: #1a1a3a;
  --key-text-color: #ffffff;
  --key-border-color: #3a3a5a;
  --theme-accent-blue: #2563eb;
  --theme-accent-green: #059669;
  --theme-accent-red: #dc2626;
  --theme-accent-purple: #4338ca;
  
  /* Fonts */
  --key-font-family: 'David Libre', 'Heebo', sans-serif;
  --text-font-family: 'Heebo', sans-serif;
}
```

### V6 BabylonJS Material Config

```javascript
// V6: BabylonJS Material Configuration

const VOXEL_CONFIG = {
  // Dimensions (in meters - BabylonJS uses meters)
  key: {
    width: 0.06,      // 60mm
    height: 0.06,     // 60mm  
    depth: 0.015,     // 15mm
    gap: 0.008,       // 8mm
    cornerRadius: 0.004, // 4mm (for rounded box)
  },
  
  panel: {
    position: { x: 0, y: 1.0, z: -0.5 },
    rotation: { x: -Math.PI / 8, y: 0, z: 0 }, // -22.5° tilt
  },
  
  // Colors (BabylonJS Color3)
  colors: {
    keyBase: new BABYLON.Color3(0.165, 0.165, 0.29),      // #2a2a4a
    keySpecial: new BABYLON.Color3(0.102, 0.102, 0.227),  // #1a1a3a
    keyHover: new BABYLON.Color3(0.227, 0.227, 0.416),    // #3a3a6a
    keyPressed: new BABYLON.Color3(0.102, 0.102, 0.227),  // #1a1a3a
    accentBlue: new BABYLON.Color3(0.145, 0.388, 0.922),  // #2563eb
    accentGreen: new BABYLON.Color3(0.02, 0.588, 0.412),  // #059669
    accentRed: new BABYLON.Color3(0.863, 0.149, 0.149),   // #dc2626
    accentPurple: new BABYLON.Color3(0.263, 0.22, 0.792), // #4338ca
  },
  
  // Material properties
  material: {
    metallic: 0.1,
    roughness: 0.8,
    emissiveIntensity: {
      normal: 0,
      hover: 0.15,
      active: 0.25,
    },
  },
  
  // Label texture
  label: {
    textureSize: 128,
    font: 'bold 48px David Libre, Heebo, Arial',
    textColor: '#ffffff',
    bgColor: 'transparent', // Use material color
  },
};

// CSS → BabylonJS conversion helper
function cssColorToColor3(cssColor) {
  const hex = cssColor.replace('#', '');
  const r = parseInt(hex.substr(0, 2), 16) / 255;
  const g = parseInt(hex.substr(2, 2), 16) / 255;
  const b = parseInt(hex.substr(4, 2), 16) / 255;
  return new BABYLON.Color3(r, g, b);
}

function mmToMeters(mm) {
  return mm / 1000;
}
```

### Style State Mapping

```plantuml
@startuml Style_State_Mapping
!theme cyborg

title CSS States → BabylonJS Material States

rectangle "V5 CSS States" #LightCoral {
  
  class NormalState {
    background: linear-gradient(145deg, #2a2a4a, #1a1a3a)
    border: 1px solid #3a3a5a
    box-shadow: 0 1px 0 0 rgba(0,0,0,0.4)
  }
  
  class HoverState {
    background: linear-gradient(145deg, #3a3a6a, #2a2a5a)
    border-color: #8b5cf6
    transform: translateY(-2px)
    box-shadow: 0 4px 12px rgba(139,92,246,0.3)
  }
  
  class ActiveState {
    transform: translateY(0)
    background: #2563eb
  }
  
  class ModifierState {
    Shift: box-shadow: 0 0 0 2px #818cf8 (purple)
    Alt/MG: box-shadow: 0 0 0 2px #34d399 (green)
    Ctrl/IPA: box-shadow: 0 0 0 2px #f87171 (red)
  }
}

rectangle "V6 BabylonJS States" #LightGreen {
  
  class NormalMaterial {
    albedoColor: Color3(0.165, 0.165, 0.29)
    metallic: 0.1
    roughness: 0.8
    emissiveColor: Color3(0, 0, 0)
  }
  
  class HoverMaterial {
    albedoColor: Color3(0.227, 0.227, 0.416)
    emissiveColor: Color3(0.1, 0.15, 0.3)
    mesh.scaling: Vector3(1.02, 1.02, 1.02)
    outline: enabled
  }
  
  class ActiveMaterial {
    mesh.position.z: +0.005
    mesh.scaling: Vector3(0.98, 0.98, 0.98)
    haptic: 50ms pulse
  }
  
  class ModifierMaterial {
    Shift: albedoColor = accentPurple
    Alt/MG: albedoColor = accentGreen
    Ctrl/IPA: albedoColor = accentRed
    emissiveColor: matching * 0.3
  }
}

NormalState --> NormalMaterial : map
HoverState --> HoverMaterial : map
ActiveState --> ActiveMaterial : map
ModifierState --> ModifierMaterial : map

@enduml
```

---

## 🎮 WebXR Integration Details

### XR Session Flow

```plantuml
@startuml XR_Session_Flow
!theme cyborg

title WebXR Session Lifecycle

[*] --> CheckSupport

state CheckSupport {
  CheckSupport : navigator.xr.isSessionSupported()
  CheckSupport : immersive-vr
  CheckSupport : immersive-ar
}

CheckSupport --> NotSupported : no XR
CheckSupport --> Ready : XR available

state NotSupported {
  NotSupported : Fall back to 2D mode
  NotSupported : Show "VR not supported"
}

state Ready {
  Ready : createDefaultXRExperienceAsync()
  Ready : Enable hand tracking feature
  Ready : Show "Enter VR" button
}

Ready --> EnterVR : user clicks
Ready --> EnterAR : user clicks

state EnterVR {
  EnterVR : enterXRAsync('immersive-vr', 'local-floor')
  EnterVR : state.setXRMode('vr')
}

state EnterAR {
  EnterAR : enterXRAsync('immersive-ar', 'local-floor')
  EnterAR : state.setXRMode('ar')
  EnterAR : Enable passthrough
}

EnterVR --> InXR
EnterAR --> InXR

state InXR {
  
  state HandTracking {
    HandTracking : onHandAddedObservable
    HandTracking : Process joints
    HandTracking : Detect pinch
  }
  
  state ControllerInput {
    ControllerInput : onControllerAddedObservable
    ControllerInput : Trigger = select
    ControllerInput : Grip = modifier
    ControllerInput : Thumbstick = scroll
  }
  
  state Rendering {
    Rendering : VoxelKeyPanel visible
    Rendering : TextTarget3D visible
    Rendering : 60fps target
  }
  
  HandTracking --> Rendering
  ControllerInput --> Rendering
}

InXR --> ExitXR : user exits

state ExitXR {
  ExitXR : exitXRAsync()
  ExitXR : state.setXRMode('none')
}

ExitXR --> Ready

@enduml
```

### Controller Mapping

```plantuml
@startuml Controller_Mapping
!theme cyborg

title XR Controller Button Mapping

rectangle "Quest Controller" {
  
  package "Right Hand" {
    [Trigger] as RT
    [Grip] as RG
    [A Button] as RA
    [B Button] as RB
    [Thumbstick] as RTS
    [Thumbstick Press] as RTSP
  }
  
  package "Left Hand" {
    [Trigger] as LT
    [Grip] as LG
    [X Button] as LX
    [Y Button] as LY
    [Thumbstick] as LTS
    [Thumbstick Press] as LTSP
  }
}

rectangle "UniKey Actions" {
  
  [Select Key] as SK
  [Toggle Shift] as TS
  [Toggle Alt/MG] as TA
  [Toggle Ctrl/IPA] as TC
  [Scroll Panel] as SP
  [Cycle Caps] as CC
  [Delete/Backspace] as DEL
  [Enter] as ENT
}

RT --> SK : primary select
LT --> SK : secondary select

RG --> TS : hold for shift
LG --> TA : hold for Alt/MG

RA --> CC : cycle he/en/EN
RB --> DEL : backspace

LX --> TC : toggle IPA
LY --> ENT : enter/newline

RTS --> SP : scroll keyboard
LTS --> SP : scroll text

RTSP --> CC : quick caps
LTSP --> CC : quick caps

@enduml
```

---

## 📁 V6 Implementation Files

### File Structure with Line Estimates

```
unikey-v6/
├── index.html                     [50 lines]
├── index-xr.html                  [80 lines]
├── manifest.json                  [40 lines]
├── service-worker.js              [100 lines]
│
├── src/
│   ├── core/
│   │   ├── UniKeyState.js         [150 lines] - Observable state
│   │   ├── UniKeyData.js          [200 lines] - Data wrapper + search
│   │   └── UniKey.js              [80 lines]  - Key class (from V5)
│   │
│   ├── data/                      [~7000 lines total - from V5]
│   │   ├── unikeys.js             [200 lines] - UNIKEYS object
│   │   ├── hebrew.js              [500 lines] - HE_LETTERS, NIKUD
│   │   ├── ipa.js                 [1500 lines] - IPA_* mappings
│   │   ├── unicode.js             [300 lines] - UNICODE_BLOCKS
│   │   ├── layouts.js             [400 lines] - Keyboard layouts
│   │   ├── syllables.js           [800 lines] - Syllable builders
│   │   ├── mg.js                  [600 lines] - Multi-gender data
│   │   └── functions.js           [2700 lines] - Pure conversions
│   │
│   ├── render/
│   │   ├── IRenderer.js           [100 lines] - Abstract interface
│   │   ├── Renderer2D.js          [400 lines] - DOM renderer
│   │   ├── Renderer3D.js          [600 lines] - BabylonJS renderer
│   │   ├── KeyElement.js          [150 lines] - Key abstraction
│   │   ├── VoxelKey.js            [200 lines] - 3D key mesh
│   │   └── VoxelKeyPanel.js       [300 lines] - 3D keyboard panel
│   │
│   ├── input/
│   │   ├── InputHandler.js        [200 lines] - Key handling
│   │   ├── TextTarget2D.js        [80 lines]  - DOM text
│   │   ├── TextTarget3D.js        [150 lines] - 3D text display
│   │   └── HandInput.js           [250 lines] - Hand tracking
│   │
│   ├── xr/
│   │   ├── XRManager.js           [300 lines] - Session management
│   │   └── ControllerInput.js     [200 lines] - Controller mapping
│   │
│   ├── modes/                     [Mode-specific panels]
│   │   ├── LettersPanel.js        [150 lines]
│   │   ├── NikudPanel.js          [300 lines]
│   │   ├── IPAPanel.js            [350 lines]
│   │   ├── EmojiPanel.js          [250 lines]
│   │   ├── SymbolPanel.js         [250 lines]
│   │   ├── MGPanel.js             [300 lines]
│   │   └── SearchPanel.js         [200 lines]
│   │
│   └── app.js                     [250 lines] - Main controller
│
├── css/
│   ├── main.css                   [200 lines]
│   └── keyboard.css               [150 lines]
│
├── assets/
│   ├── fonts/                     [font files]
│   └── icons/                     [PWA icons]
│
└── docs/
    ├── V6-AGILE-DISCOVERY.md      [this file]
    └── API.md                     [200 lines]

Total New Code: ~5,500 lines
Reused V5 Data: ~7,000 lines
──────────────────────────────
Total V6:       ~12,500 lines
```

### Key File Templates

#### UniKeyState.js
```javascript
// src/core/UniKeyState.js
export class UniKeyState {
  constructor() {
    this._state = {
      mode: 'letters',
      language: 'hebrew',
      modifiers: { shift: false, alt: false, ctrl: false },
      capsLock: false,
      capsState: 2,
      searchQuery: '',
      xrMode: 'none',
    };
    this._listeners = new Set();
  }
  
  get state() { return { ...this._state }; }
  get isHebrew() { return this._state.language === 'hebrew'; }
  
  setState(partial) {
    const prev = { ...this._state };
    this._state = { ...this._state, ...partial };
    this._notify(prev, this._state);
  }
  
  subscribe(fn) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }
  
  _notify(prev, next) {
    this._listeners.forEach(fn => fn(next, prev));
  }
}
```

#### VoxelKey.js
```javascript
// src/render/VoxelKey.js
export class VoxelKey {
  constructor(scene, config) {
    this.scene = scene;
    this.config = config;
    this.mesh = null;
    this.material = null;
    this.labelTexture = null;
    
    this.create();
  }
  
  create() {
    const { width, height, depth } = this.config.size;
    
    // Create box mesh
    this.mesh = BABYLON.MeshBuilder.CreateBox(this.config.id, {
      width, height, depth,
    }, this.scene);
    
    // PBR Material
    this.material = new BABYLON.PBRMaterial(this.config.id + '_mat', this.scene);
    this.material.albedoColor = VOXEL_CONFIG.colors.keyBase;
    this.material.metallic = VOXEL_CONFIG.material.metallic;
    this.material.roughness = VOXEL_CONFIG.material.roughness;
    this.mesh.material = this.material;
    
    // Label texture
    this.labelTexture = new BABYLON.DynamicTexture(
      this.config.id + '_tex',
      { width: 128, height: 128 },
      this.scene
    );
    this.material.albedoTexture = this.labelTexture;
    
    // Action manager
    this.mesh.actionManager = new BABYLON.ActionManager(this.scene);
    this.setupActions();
  }
  
  updateLabel(text, rtl = true) {
    const ctx = this.labelTexture.getContext();
    ctx.clearRect(0, 0, 128, 128);
    ctx.fillStyle = '#ffffff';
    ctx.font = VOXEL_CONFIG.label.font;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.direction = rtl ? 'rtl' : 'ltr';
    ctx.fillText(text, 64, 64);
    this.labelTexture.update();
  }
  
  setHighlight(active) {
    if (active) {
      this.material.emissiveColor = VOXEL_CONFIG.colors.keyHover.scale(0.3);
      this.mesh.scaling = new BABYLON.Vector3(1.02, 1.02, 1.02);
    } else {
      this.material.emissiveColor = BABYLON.Color3.Black();
      this.mesh.scaling = BABYLON.Vector3.One();
    }
  }
  
  setupActions() {
    this.mesh.actionManager.registerAction(
      new BABYLON.ExecuteCodeAction(
        BABYLON.ActionManager.OnPointerOverTrigger,
        () => this.setHighlight(true)
      )
    );
    this.mesh.actionManager.registerAction(
      new BABYLON.ExecuteCodeAction(
        BABYLON.ActionManager.OnPointerOutTrigger,
        () => this.setHighlight(false)
      )
    );
  }
  
  dispose() {
    this.mesh?.dispose();
    this.material?.dispose();
    this.labelTexture?.dispose();
  }
}
```

---

## 🧪 Testing Checklist

### 2D Mode Tests
- [ ] All 8 modes render correctly
- [ ] Caps cycles: HE → en → EN → HE
- [ ] Shift toggles syllable mode
- [ ] Alt toggles MG mode
- [ ] Ctrl toggles IPA mode
- [ ] Popups appear and work
- [ ] Text insertion works
- [ ] RTL text direction correct

### 3D Mode Tests
- [ ] Keyboard panel renders
- [ ] Keys have correct labels
- [ ] Hover highlight works
- [ ] Click/pick selects key
- [ ] Popups appear in 3D
- [ ] TextTarget3D shows text
- [ ] RTL text renders correctly
- [ ] 60fps maintained

### XR Mode Tests
- [ ] VR session starts
- [ ] AR session starts
- [ ] Hand tracking detected
- [ ] Pinch selects key
- [ ] Controller input works
- [ ] Haptic feedback fires
- [ ] Exit XR works

### Cross-Mode Tests
- [ ] State persists across mode changes
- [ ] Search works in all modes
- [ ] PWA installable
- [ ] Offline mode works


---

## 📐 Detailed Per-Mode PlantUML Diagrams

### Letters Mode: CSS DOM vs BabylonJS WebXR

```plantuml
@startuml Letters_CSS_vs_Babylon
!theme cerulean
skinparam packageStyle rectangle

title Letters Mode: V5 CSS/DOM vs V6 BabylonJS/WebXR

package "V5: CSS/DOM Implementation" #FFE4E1 {
  
  rectangle "createKey(key)" #FFCCCC {
    (btn = document.createElement('button'))
    (btn.style.cssText = inline styles)
    (btn.textContent = label)
    (btn.onclick = handleKeyPress)
  }
  
  rectangle "CSS Variables" #FFB6C1 {
    (--key-w: 7.41mm → 28px)
    (--key-h: 7.41mm → 28px)
    (--key-font-size: 2.65mm)
    (--key-bg-color: #2a2a4a)
    (--key-border-radius: 0.79mm)
  }
  
  rectangle "Layout: Flexbox" #FFC0CB {
    (display: flex)
    (gap: 2px)
    (dir: rtl | ltr)
    (justify-content: center)
  }
  
  rectangle "States: CSS Pseudo" #FFD1DC {
    (:hover → bgColor change)
    (:active → translateY)
    (class toggle for active)
  }
}

package "V6: BabylonJS/WebXR Implementation" #E0FFE0 {
  
  rectangle "VoxelKey.create()" #90EE90 {
    (mesh = MeshBuilder.CreateBox())
    (material = new PBRMaterial())
    (texture = new DynamicTexture())
    (actionManager = new ActionManager())
  }
  
  rectangle "Material Config" #98FB98 {
    (keyWidth: 0.06m = 6cm)
    (keyHeight: 0.06m = 6cm)
    (keyDepth: 0.015m = 1.5cm)
    (albedoColor: Color3(0.16, 0.16, 0.29))
  }
  
  rectangle "Layout: TransformNode" #7CFC00 {
    (position: Vector3(x, y, z))
    (parent: panelNode)
    (gap: 0.008m between keys)
    (RTL: negative x offset)
  }
  
  rectangle "States: Material" #ADFF2F {
    (hover → emissiveColor glow)
    (press → scale 0.95 + z offset)
    (active → albedoColor change)
  }
}

"CSS Variables" -[#red,dashed]-> "Material Config" : convert mm→meters
"Flexbox" -[#red,dashed]-> "TransformNode" : 2D→3D layout
"CSS Pseudo" -[#red,dashed]-> "Material" : style→material

note bottom of "V5: CSS/DOM Implementation"
  **Limitations:**
  - 2D only
  - No depth perception
  - Mouse/touch input only
  - Screen-bound
end note

note bottom of "V6: BabylonJS/WebXR Implementation"
  **Features:**
  - Full 3D environment
  - Physical key depth
  - Hand tracking input
  - Spatial presence
end note

@enduml
```

### Nikud Mode: Popup Comparison

```plantuml
@startuml Nikud_Popup_Compare
!theme cerulean

title Nikud Mode Popup: V5 DOM vs V6 3D Panel

package "V5: DOM Popup" #FFE4E1 {
  
  rectangle "openSyllablesPopup(key)" {
    (div.popup-container)
    (position: fixed)
    (left: rect.left + 'px')
    (top: rect.bottom + 'px')
    (z-index: 1000)
  }
  
  rectangle "Popup Content" {
    (forEach syllable:)
    (  button.syllable-option)
    (  onclick → insertAtCursor)
    (  textContent = syl.text)
  }
  
  rectangle "Popup Styling" {
    (background: #1a1a2e)
    (border-radius: 8px)
    (display: flex; gap: 4px)
    (box-shadow: 0 4px 20px)
  }
  
  rectangle "Close Logic" {
    (click outside → close)
    (Escape key → close)
    (selection → close)
  }
}

package "V6: 3D Floating Panel" #E0FFE0 {
  
  rectangle "showPopup3D(keyId, options)" {
    (panel = new TransformNode())
    (position = key.getAbsolutePosition())
    (offset = Vector3(0, 0, -0.1))
    (lookAt camera)
  }
  
  rectangle "3D Popup Content" {
    (forEach option:)
    (  mesh = MeshBuilder.CreateBox())
    (  texture = DynamicTexture())
    (  OnPickTrigger → handleSelect)
  }
  
  rectangle "3D Popup Material" {
    (PBRMaterial)
    (albedoColor: Color3(0.1, 0.15, 0.3))
    (emissiveColor on hover)
    (transparency: 0.9)
  }
  
  rectangle "Close Logic" {
    (pick outside → close)
    (fist gesture → close)
    (selection → close)
    (timeout → close)
  }
}

"DOM Popup" -[#red,dashed]-> "3D Floating Panel" : migrate

note right of "3D Popup Content"
  **Syllable Options:**
  - בָּ בַּ בֵּ בֶּ בִּ בֹּ בֻּ
  - Each on separate voxel
  - Hand pinch to select
  - Visual nikud marks
end note

@enduml
```

### IPA Mode: Conversion Flow

```plantuml
@startuml IPA_Flow
!theme cerulean

title IPA Mode: Conversion & Display Flow

package "Data Layer (100% Reuse)" #E6E6FA {
  database "IPA_VOWELS" {
    14 vowel mappings
    a ɑ æ e ɛ i ɪ o ɔ u ʊ ə...
  }
  
  database "IPA_CONSONANTS" {
    28 consonant mappings
    b d f g h j k l m n p...
  }
  
  database "IPA_UNIKEYS" {
    85+ IPA symbols
    Full phonetic set
  }
  
  rectangle "hebrewTextToIpa(text)" {
    Input: "שָׁלוֹם"
    Output: "ʃaˈlom"
  }
  
  rectangle "englishTextToIpa(text)" {
    Input: "hello"
    Output: "həˈloʊ"
  }
}

package "V5 Display" #FFE4E1 {
  rectangle "IPA Popup DOM" {
    (Grid of IPA symbols)
    (Click → insert symbol)
    (Search filter)
  }
  
  rectangle "Live Parser" {
    (textarea input)
    (real-time conversion)
    (display IPA below)
  }
}

package "V6 Display" #E0FFE0 {
  rectangle "IPA Popup 3D" {
    (VoxelKey grid panel)
    (Organized by type)
    (Hand pinch select)
    (Voice search)
  }
  
  rectangle "Live Parser 3D" {
    (TextTarget3D input)
    (Real-time in XR)
    (3D IPA display)
    (Audio playback)
  }
}

"IPA_VOWELS" --> "hebrewTextToIpa"
"IPA_CONSONANTS" --> "hebrewTextToIpa"
"IPA_VOWELS" --> "englishTextToIpa"
"IPA_CONSONANTS" --> "englishTextToIpa"

"hebrewTextToIpa" --> "V5 Display"
"hebrewTextToIpa" --> "V6 Display"

note bottom
  **IPA Functions Reused:**
  - hebrewTextToIpa() 
  - englishTextToIpa()
  - getRhymeEnding()
  - doTheyRhyme()
  - All mappings intact
end note

@enduml
```

### Emoji Mode: Grid Comparison

```plantuml
@startuml Emoji_Grid
!theme cerulean

title Emoji Mode: V5 Grid vs V6 3D Panel

package "V5: CSS Grid" #FFE4E1 {
  
  rectangle "Category Tabs" {
    (display: flex)
    (button per category)
    (active state styling)
  }
  
  rectangle "Emoji Grid" {
    (display: grid)
    (grid-template-columns: repeat(8, 1fr))
    (gap: 4px)
    (overflow-y: auto)
  }
  
  rectangle "Skin Tone Picker" {
    (5 tone buttons)
    (position: relative to emoji)
    (click → apply modifier)
  }
  
  rectangle "Search" {
    (input[type=text])
    (filter emojiData)
    (instant results)
  }
}

package "V6: 3D Emoji Panel" #E0FFE0 {
  
  rectangle "3D Category Tabs" {
    (Curved panel above grid)
    (Icon meshes per category)
    (Gaze/point to select)
  }
  
  rectangle "Scrollable 3D Grid" {
    (VoxelEmoji meshes)
    (Larger: 0.08m × 0.08m)
    (Scroll via gesture)
    (Lazy load visible)
  }
  
  rectangle "3D Variant Picker" {
    (Radial popup)
    (5 tones around base)
    (Pinch to confirm)
  }
  
  rectangle "Voice Search" {
    (Speech recognition)
    (Natural language)
    (Instant 3D results)
  }
}

"CSS Grid" -[#red,dashed]-> "3D Grid" : layout change
"Skin Tone Picker" -[#red,dashed]-> "3D Variant Picker" : UX change
"Search" -[#red,dashed]-> "Voice Search" : input mode

note right of "Scrollable 3D Grid"
  **Performance:**
  - Only render visible
  - Pool emoji meshes
  - Texture atlas for common
  - LOD for distant
end note

@enduml
```

### MG Mode: Gender Suffix System

```plantuml
@startuml MG_System
!theme cerulean

title Multi-Gender Mode: V5 vs V6 Implementation

package "MG Data (100% Reuse)" #E6E6FA {
  
  rectangle "unikey.mg Object" {
    m: "תלמיד"
    f: "תלמידה"  
    mf: "תלמיד/ה"
    fm: "תלמידה/ים"
    m_en: "student (m)"
    f_en: "student (f)"
  }
  
  rectangle "12 PUA Glyphs" {
    U+E000: ־ה/ים (suffix)
    U+E001: ־ות/ים (plural)
    ...
    U+E00B: custom
  }
  
  rectangle "19 Ivrita Rules" {
    Rule 1: ים→ות
    Rule 2: ה→ים/ות
    ...
    Rule 19: exceptions
  }
  
  rectangle "AlefMultiGndr Font" {
    PUA rendering
    OpenType features
    Ligature support
  }
}

package "V5: DOM Display" #FFE4E1 {
  
  rectangle "Key Display" {
    (Green background)
    (MG suffix text)
    (alt held indicator)
  }
  
  rectangle "Suffix Grid" {
    (renderGenderSuffixGrid())
    (Click → insert suffix)
    (Notation selector)
  }
  
  rectangle "Converter" {
    (Ivrita.js integration)
    (textarea input/output)
    (Mode: neutral/m/f)
  }
}

package "V6: 3D MG Panel" #E0FFE0 {
  
  rectangle "VoxelKey MG" {
    (Green emissive glow)
    (Dual label: ים/ות)
    (Pinch opens picker)
  }
  
  rectangle "3D Gender Picker" {
    (Radial menu)
    (♂ Male option)
    (♀ Female option)
    (⚧ Combined option)
  }
  
  rectangle "XR Converter" {
    (Voice input)
    (Real-time display)
    (3D notation toggle)
    (Hand gesture mode)
  }
}

"unikey.mg" --> "V5: DOM Display"
"unikey.mg" --> "V6: 3D MG Panel"
"12 PUA Glyphs" --> "Key Display"
"12 PUA Glyphs" --> "VoxelKey MG"

note bottom of "MG Data"
  **MG Integration:**
  - Ivrita.js library
  - AlefMultiGndr font
  - 12 custom Unicode glyphs
  - 19 transformation rules
  - All reused in V6
end note

@enduml
```

### Symbol Mode: Unicode Browser

```plantuml
@startuml Symbol_Browser
!theme cerulean

title Symbol Mode: Unicode Block Navigation

package "UNICODE_BLOCKS (100% Reuse)" #E6E6FA {
  
  database "35 Block Definitions" {
    MAHJONG: U+1F000-1F02F
    DOMINO: U+1F030-1F09F
    CARDS: U+1F0A0-1F0FF
    CHESS: U+2654-265F
    DICE: U+2680-2685
    ARROWS: U+2190-21FF
    MATH_OPS: U+2200-22FF
    GREEK: U+0370-03FF
    CURRENCY: U+20A0-20CF
    ...
  }
  
  rectangle "generateBlockSymbols(blockId)" {
    for cp = start to end:
      yield String.fromCodePoint(cp)
  }
  
  rectangle "searchSymbols(query)" {
    match by char
    match by U+code
    match by block name
  }
}

package "V5: Tab Navigation" #FFE4E1 {
  
  rectangle "Category Tabs" {
    (Games | Math | Arrows | ...)
    (Click → show blocks)
  }
  
  rectangle "Block Tabs" {
    (Sub-categories)
    (Click → render symbols)
  }
  
  rectangle "Symbol Grid" {
    (CSS grid layout)
    (Hover → show U+code)
    (Click → insert)
  }
}

package "V6: 3D Block Browser" #E0FFE0 {
  
  rectangle "3D Category Ring" {
    (Circular panel)
    (Icon per category)
    (Rotate to browse)
  }
  
  rectangle "Block Carousel" {
    (Horizontal scroll)
    (Gesture navigation)
    (Block previews)
  }
  
  rectangle "3D Symbol Grid" {
    (VoxelSymbol meshes)
    (Infinite scroll)
    (Hover → 3D tooltip)
    (Search integration)
  }
}

"UNICODE_BLOCKS" --> "V5: Tab Navigation"
"UNICODE_BLOCKS" --> "V6: 3D Block Browser"

note right of "3D Symbol Grid"
  **U+ Display:**
  Hover shows:
  - Character enlarged
  - U+XXXX code
  - Block name
  - Copy button
end note

@enduml
```

### Rhyme Mode: Visualization

```plantuml
@startuml Rhyme_Visual
!theme cerulean

title Rhyme Mode: V5 Text vs V6 Spatial Visualization

package "Rhyme Functions (100% Reuse)" #E6E6FA {
  
  rectangle "getRhymeEnding(ipa, syllables)" {
    Extract final syllable(s)
    Return rhyme pattern
  }
  
  rectangle "doTheyRhyme(ipa1, ipa2, opts)" {
    Compare endings
    Match quality: exact/close
    Return boolean + score
  }
  
  rectangle "findRhymingWords(analyzed)" {
    Group by rhyme ending
    Cross-language matches
    Return rhyme groups
  }
  
  database "IPA_RHYME_ENDINGS" {
    50+ common patterns
    Hebrew endings
    English endings
  }
}

package "V5: Text Display" #FFE4E1 {
  
  rectangle "Input" {
    (Word input field)
    (Syllable count selector)
    (Search button)
  }
  
  rectangle "Results" {
    (Two columns: HE | EN)
    (List of rhyming words)
    (IPA shown in small text)
  }
}

package "V6: Spatial Visualization" #E0FFE0 {
  
  rectangle "3D Input" {
    (Voice input option)
    (Virtual keyboard)
    (Gesture syllable select)
  }
  
  rectangle "3D Rhyme Web" {
    (Central word node)
    (Rhyming words orbit)
    (Lines connect rhymes)
    (Color = match quality)
    (Size = frequency)
  }
  
  rectangle "Audio Preview" {
    (Tap word → hear IPA)
    (Spatial audio position)
    (Compare pronunciations)
  }
}

"getRhymeEnding" --> "V5: Text Display"
"getRhymeEnding" --> "V6: Spatial Visualization"
"doTheyRhyme" --> "Results"
"doTheyRhyme" --> "3D Rhyme Web"

note bottom of "3D Rhyme Web"
  **Visual Elements:**
  - Nodes = words
  - Lines = rhyme connections
  - Green = exact match
  - Yellow = close match
  - Animated on discovery
end note

@enduml
```

---

## 🎮 VoxelKey Hand Tracking Interaction

```plantuml
@startuml VoxelKey_HandTracking
!theme cerulean

title VoxelKey Hand Tracking: Complete Interaction Flow

actor "User" as User
participant "Hand" as Hand
participant "WebXR\nHand Tracking" as XRHT
participant "HandInput" as HI  
participant "Ray\nCasting" as Ray
participant "VoxelKey" as VK
participant "InputHandler" as IH
participant "UniKeyState" as State
participant "Haptics" as Hap

== Pointing Phase ==

User -> Hand : Extend index finger
Hand -> XRHT : Report joint positions
XRHT -> HI : onHandJointObservable

note over HI
  Tracked Joints:
  - INDEX_FINGER_TIP
  - THUMB_TIP  
  - WRIST (for gesture)
end note

HI -> HI : Get INDEX_FINGER_TIP position
HI -> HI : Get finger forward direction
HI -> Ray : Create ray(origin, direction, 0.5m)

Ray -> VK : pickWithRay()

alt Ray hits VoxelKey
  VK --> Ray : PickingInfo {mesh, point}
  Ray --> HI : hit detected
  
  HI -> VK : setHighlight(true)
  VK -> VK : emissiveColor = highlight
  VK -> VK : scale = 1.02
  
  note over VK
    Visual Feedback:
    - Blue glow
    - Slight scale up
    - Cursor change
  end note
  
else No hit
  HI -> VK : setHighlight(false) [all keys]
end

== Pinch Detection ==

User -> Hand : Pinch thumb + index
Hand -> XRHT : Joint positions updated
XRHT -> HI : thumb/index positions

HI -> HI : Calculate distance\nthumb_tip ↔ index_tip
HI -> HI : pinchStrength = 1 - (dist / maxDist)

alt pinchStrength > 0.8
  
  HI -> HI : Check cooldown (300ms)
  
  alt cooldown passed
    
    HI -> VK : setPressedState(true)
    VK -> VK : scale = 0.95
    VK -> VK : position.z += 0.005
    
    HI -> Hap : triggerHaptic(50ms, 0.5)
    Hap -> User : Vibration feedback
    
    HI -> IH : handleKeySelect(keyElement)
    IH -> State : Process key action
    
    note over State
      Actions:
      - Insert char
      - Toggle modifier
      - Open popup
      - Switch mode
    end note
    
    HI -> HI : lastPinchTime = now()
    
    HI -> VK : setPressedState(false)
    VK -> VK : scale = 1.0
    VK -> VK : position.z -= 0.005
    
  else cooldown active
    note over HI : Ignore rapid pinch
  end
  
end

== Long Press (Popup) ==

User -> Hand : Hold pinch > 500ms
HI -> HI : Detect long press

alt key.hasPopup()
  HI -> IH : showPopup3D(keyId, options)
  
  note over IH
    Popup Types:
    - Syllables (nikudMode)
    - IPA symbols (ctrlMode)
    - MG options (altMode)
  end note
end

@enduml
```

---

## 📊 CSS-to-BabylonJS Property Mapping

```
┌──────────────────────────────────────────────────────────────────────────┐
│                CSS PROPERTY → BABYLONJS EQUIVALENT                        │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  DIMENSIONS                                                              │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: width: 28px (7.41mm)      → Babylon: mesh.width = 0.06 (meters)   │
│  CSS: height: 28px              → Babylon: mesh.height = 0.06           │
│  CSS: (no depth)                → Babylon: mesh.depth = 0.015           │
│  CSS: gap: 2px                  → Babylon: position offset 0.008m       │
│  CSS: border-radius: 3px        → Babylon: CreateRoundedBox radius      │
│                                                                          │
│  COLORS                                                                  │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: background: #2a2a4a       → Babylon: material.albedoColor         │
│  CSS: color: #ffffff            → Babylon: DynamicTexture fillStyle     │
│  CSS: border-color: #3a3a5a     → Babylon: (edge highlighting)          │
│  CSS: box-shadow               → Babylon: GlowLayer / emissiveColor    │
│                                                                          │
│  STATES                                                                  │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: :hover { background }    → Babylon: OnPointerOver + emissive     │
│  CSS: :active { transform }    → Babylon: OnPick + scale + position    │
│  CSS: .active { blue bg }      → Babylon: albedoColor = blue           │
│                                                                          │
│  LAYOUT                                                                  │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: display: flex            → Babylon: TransformNode parent         │
│  CSS: flex-direction: row      → Babylon: x-axis positioning           │
│  CSS: flex-direction: column   → Babylon: y-axis positioning           │
│  CSS: justify-content: center  → Babylon: centered x offset            │
│  CSS: dir="rtl"                → Babylon: negative x + ctx.direction   │
│                                                                          │
│  TEXT                                                                    │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: font-family: 'Heebo'     → Babylon: DynamicTexture font string   │
│  CSS: font-size: 10px          → Babylon: "48px" on 128x128 texture    │
│  CSS: text-align: center       → Babylon: ctx.textAlign = 'center'     │
│  CSS: direction: rtl           → Babylon: ctx.direction = 'rtl'        │
│                                                                          │
│  POSITIONING                                                             │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: position: fixed          → Babylon: world-space Vector3          │
│  CSS: left/top: Npx            → Babylon: position = Vector3(x,y,z)    │
│  CSS: z-index: 1000            → Babylon: renderingGroupId             │
│  CSS: transform: rotate        → Babylon: rotation = Vector3/Quaternion│
│                                                                          │
│  ANIMATION                                                               │
│  ─────────────────────────────────────────────────────────────────────── │
│  CSS: transition: all 0.15s    → Babylon: Animation / ease functions   │
│  CSS: transform: scale(0.95)   → Babylon: mesh.scaling = Vector3       │
│  CSS: transform: translateY    → Babylon: mesh.position.y +=           │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 🔢 Numerical Conversion Reference

```
┌──────────────────────────────────────────────────────────────────────────┐
│                    V5 CSS → V6 BABYLON UNIT CONVERSION                    │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  BASE CONVERSION: 1mm = 0.001m                                           │
│                                                                          │
│  KEY DIMENSIONS                                                          │
│  ─────────────────────────────────────────────────────────────────────── │
│  V5 --key-w:     7.41mm    →  V6 KEY_WIDTH:    0.06m   (6cm, rounded)   │
│  V5 --key-h:     7.41mm    →  V6 KEY_HEIGHT:   0.06m   (6cm, rounded)   │
│  V5 (no depth)             →  V6 KEY_DEPTH:    0.015m  (1.5cm, new)     │
│  V5 --key-margin: 0.27mm   →  V6 KEY_GAP:      0.008m  (8mm, scaled)    │
│  V5 --key-border-radius:   →  V6 CORNER_RADIUS: 0.005m (5mm)            │
│                                                                          │
│  PANEL POSITIONING (XR Ergonomics)                                       │
│  ─────────────────────────────────────────────────────────────────────── │
│  Panel height from floor:   1.0m   (chest level, seated user)           │
│  Panel distance from user:  0.5m   (arm's reach)                        │
│  Panel tilt angle:         -22.5°  (π/8 rad, toward face)               │
│  Total panel width:        ~0.68m  (10 keys + gaps)                     │
│  Total panel height:       ~0.28m  (4 rows + gaps)                      │
│                                                                          │
│  INTERACTION DISTANCES                                                   │
│  ─────────────────────────────────────────────────────────────────────── │
│  Pointer ray length:        0.5m   (comfortable reach)                  │
│  Popup offset from key:     0.1m   (10cm in front)                      │
│  Hover detection threshold: 0.001m (1mm precision)                      │
│                                                                          │
│  TEXTURE SIZES                                                           │
│  ─────────────────────────────────────────────────────────────────────── │
│  Key label texture:         128×128 pixels                              │
│  Font size on texture:      48px (scales to key size)                   │
│  Popup label texture:       256×64 pixels                               │
│  Search bar texture:        512×64 pixels                               │
│                                                                          │
│  TIMING                                                                  │
│  ─────────────────────────────────────────────────────────────────────── │
│  Pinch threshold:           0.8 (80% closed)                            │
│  Pinch cooldown:            300ms                                       │
│  Long press duration:       500ms                                       │
│  Hover delay:               0ms (instant)                               │
│  Press animation:           100ms                                       │
│  Popup animation:           200ms                                       │
│  Haptic pulse:              50ms                                        │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## ✅ Complete Migration Checklist

### Phase 1: Extract V5 Data (Day 1)
- [ ] Create `src/data/unikeys.js` - Export UNIKEYS
- [ ] Create `src/data/hebrew.js` - Export HE_LETTERS, NIKUD
- [ ] Create `src/data/ipa.js` - Export IPA_VOWELS, IPA_CONSONANTS, IPA_UNIKEYS
- [ ] Create `src/data/unicode.js` - Export UNICODE_BLOCKS
- [ ] Create `src/data/layouts.js` - Export layouts
- [ ] Create `src/data/functions.js` - Export all pure functions
- [ ] Verify all exports work with ES modules

### Phase 2: Core Classes (Day 2-3)
- [ ] Create `UniKeyState` with observable pattern
- [ ] Create `UniKeyData` wrapper class
- [ ] Create `KeyElement` abstraction
- [ ] Create `IRenderer` interface
- [ ] Unit tests for state management

### Phase 3: 2D Renderer (Day 4-5)
- [ ] Implement `Renderer2D` class
- [ ] Port `createKey()` logic
- [ ] Port popup system
- [ ] Port all 8 modes
- [ ] Verify feature parity with V5

### Phase 4: BabylonJS Setup (Day 6)
- [ ] Create scene, camera, lights
- [ ] Implement `VoxelKey` class
- [ ] Implement `VoxelKeyPanel` class
- [ ] Test basic rendering

### Phase 5: 3D Renderer (Day 7-9)
- [ ] Implement `Renderer3D` class
- [ ] Hebrew RTL in DynamicTexture
- [ ] 3D popup panels
- [ ] All modes in 3D
- [ ] `TextTarget3D` for text display

### Phase 6: XR Integration (Day 10-12)
- [ ] Implement `XRManager`
- [ ] Implement `HandInput`
- [ ] Implement `ControllerInput`
- [ ] Test VR session
- [ ] Test AR session (if supported)
- [ ] Quest 3 testing

### Phase 7: Polish (Day 13-14)
- [ ] Unified `searchUTF8()` function
- [ ] PWA manifest
- [ ] Service worker
- [ ] Performance optimization
- [ ] Final testing all modes

---

## 📚 Historical Context & Foundation Systems

This section documents the extensive R&D foundation that UniKey V6 builds upon, compiled from months of development across 200+ Jira issues and extensive conversation history.

### 🎹 UniKey V5 Foundation (Proof of Concept)

UniKey V5 was a 14,594-line single HTML file demonstrating core Hebrew keyboard capabilities:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         UNIKEY V5 ARCHITECTURE                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  8 KEYBOARD MODES:                                                          │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐               │
│  │ ⌨️ Letters      │ │ בּ Nikud        │ │ 🔊 IPA          │               │
│  │ Hebrew phonetic │ │ Vowel points + │ │ Hebrew↔English  │               │
│  │ input           │ │ cantillation   │ │ phonetic bridge │               │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘               │
│  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐               │
│  │ 🎵 Rhymes       │ │ 😀 Emoji        │ │ ∑ Symbol        │               │
│  │ Cross-language  │ │ Picker + skin  │ │ Unicode symbols │               │
│  │ rhyme finder    │ │ tone variants  │ │                 │               │
│  └─────────────────┘ └─────────────────┘ └─────────────────┘               │
│  ┌─────────────────┐ ┌─────────────────┐                                   │
│  │ 🌐 Tree         │ │ ⚧ MG/Ivrita    │                                   │
│  │ Bilingual UTF-8 │ │ 19 rules +     │                                   │
│  │ explorer        │ │ 12 PUA glyphs  │                                   │
│  └─────────────────┘ └─────────────────┘                                   │
│                                                                             │
│  PHONETIC DATA STRUCTURES (49 UK_* objects):                               │
│  ├─ UK_HE_VOWELS, UK_HE_HATAF, UK_HE_MALE - Hebrew nikud mappings         │
│  ├─ HE_LETTERS - 27 Hebrew letters with IPA, bgdkpt rules                 │
│  ├─ IPA_VOWELS, IPA_CONSONANTS - Bidirectional phonetic mapping           │
│  ├─ UK_EN_CONNECTORS, UK_HE_CONNECTORS - Common words with IPA            │
│  └─ UniKey class - Shift (syllables), Alt (MG), Ctrl (IPA) modes          │
│                                                                             │
│  IVRITA/MULTI-GENDER HEBREW:                                               │
│  ├─ 19 gender-inclusive notation rules from IVRITA-RULES.md               │
│  ├─ 12 PUA glyphs for MGHebrew font (U+E000–U+E00B)                       │
│  └─ Both MGHebrew font and Ivrita.js library integration                   │
│                                                                             │
│  269 FUNCTIONS covering:                                                    │
│  ├─ Phonetic mapping (Hebrew ↔ English ↔ IPA)                             │
│  ├─ Nikud insertion and validation                                         │
│  ├─ Cross-language rhyme matching (for poetry)                             │
│  ├─ Emoji skin tone handling                                               │
│  └─ Character tree navigation                                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🌍 LocaleUnits Framework (CLDR Integration)

Comprehensive unit conversion system with ICU4J integration:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    LOCALEUNITS FRAMEWORK (v2 - v10)                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  CORE ARCHITECTURE:                                                         │
│  ├─ UnitValue<T> sealed interface - Type-safe unit representation          │
│  ├─ BaseUnitValue<T> abstract class - Common functionality                 │
│  ├─ DataNode composition - Units as first-class data types                 │
│  └─ Caffeine caching - TTL + size-based eviction for performance           │
│                                                                             │
│  21+ UNIT TYPES:                                                            │
│  ┌───────────────────┬───────────────────┬───────────────────┐             │
│  │ CurrencyUnit      │ MeasureUnit       │ PhoneUnit         │             │
│  │ ISO 4217          │ CLDR, RFC 8428    │ E.164             │             │
│  │ ICU4J             │ ICU4J             │ libphonenumber    │             │
│  ├───────────────────┼───────────────────┼───────────────────┤             │
│  │ AddressUnit       │ CountryUnit       │ LanguageUnit      │             │
│  │ 249 countries     │ ISO 3166-1        │ BCP 47            │             │
│  │ libaddressinput   │ ICU4J             │ ICU4J             │             │
│  ├───────────────────┼───────────────────┼───────────────────┤             │
│  │ TemporalUnit      │ PersonUnit        │ GeoUnit           │             │
│  │ 13 CLDR calendars │ CLDR PersonName   │ RFC 5870          │             │
│  │ ICU4J             │ ICU4J             │ MaxMind           │             │
│  ├───────────────────┼───────────────────┼───────────────────┤             │
│  │ EmailUnit         │ IpUnit            │ ColorUnit         │             │
│  │ RFC 5322          │ IPv4/IPv6         │ Perceptual Oklch  │             │
│  │ Commons Validator │ MaxMind GeoIP2    │ Custom            │             │
│  ├───────────────────┼───────────────────┼───────────────────┤             │
│  │ VCardUnit         │ CalendarUnit      │ CityUnit          │             │
│  │ RFC 6350          │ RFC 5545          │ GeoNames          │             │
│  │ ez-vcard          │ iCal4j            │ Custom            │             │
│  ├───────────────────┼───────────────────┼───────────────────┤             │
│  │ DomainUnit        │ TreeIndex         │ UIComponent       │             │
│  │ RFC 1035          │ Hierarchical O(1) │ 12+ platforms     │             │
│  │ Commons Validator │ Custom BiMap      │ React/Blazor/etc  │             │
│  └───────────────────┴───────────────────┴───────────────────┘             │
│                                                                             │
│  CLDR/ICU4J INTEGRATION:                                                    │
│  ├─ MeasureUnit.getAvailableTypes() - No reflection needed                 │
│  ├─ MeasureFormat - Locale-aware unit formatting                           │
│  ├─ ULocale - Full locale support (700+ locales)                           │
│  ├─ PluralRules - Grammatically correct pluralization                      │
│  ├─ RuleBasedNumberFormat - Spellout, ordinals, duration                   │
│  └─ UnicodeRangeMapper - Script detection → locale mapping                 │
│                                                                             │
│  VALIDATION FRAMEWORK:                                                      │
│  ├─ Jakarta Validation annotations                                         │
│  ├─ 20+ CLDR handler types                                                 │
│  ├─ Apache Commons validators integration                                   │
│  └─ Custom constraints per unit type                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🗣️ Hebrew TTS Pipeline

Comprehensive Hebrew Text-to-Speech solution with multiple backends:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      HEBREW TTS PIPELINE OPTIONS                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PIPELINE FLOW:                                                             │
│                                                                             │
│  Hebrew Text → Menaked (nikud) → Phonikud (IPA) → TTS Engine → Audio       │
│       │              │               │               │                      │
│       ▼              ▼               ▼               ▼                      │
│  "שלום עולם"   "שָׁלוֹם עוֹלָם"   "ʃaˈlom oˈlam"   [audio bytes]          │
│                                                                             │
│  TTS ENGINE COMPARISON:                                                     │
│  ┌────────────────┬──────────┬─────────┬────────────┬──────────────┐       │
│  │ Engine         │ Emotion  │ Clone   │ License    │ Hebrew       │       │
│  ├────────────────┼──────────┼─────────┼────────────┼──────────────┤       │
│  │ Zonos-Hebrew   │ ★★★★★   │ ✅ 5-30s│ Apache 2.0*│ ✅ Native    │       │
│  │ ChatterBox     │ ★★★★☆   │ ✅ 5s   │ MIT        │ ✅ 40+ langs │       │
│  │ Piper-Hebrew   │ ★☆☆☆☆   │ ❌      │ NC*        │ ✅ shaul.onnx│       │
│  │ MMS-TTS Hebrew │ ★☆☆☆☆   │ ❌      │ NC         │ ✅ Basic     │       │
│  │ ElevenLabs     │ ★★★★★   │ ✅      │ Paid API   │ ✅           │       │
│  └────────────────┴──────────┴─────────┴────────────┴──────────────┘       │
│  * SASPEECH dataset is non-commercial                                       │
│                                                                             │
│  ZONOS-HEBREW (notmax123):                                                  │
│  ├─ Model: notmax123/Zonos-Hebrew                                          │
│  ├─ Base: Zyphra/Zonos-v0.1-transformer                                    │
│  ├─ Training: SASPEECH Gold (~4h manual, 44.1kHz)                          │
│  ├─ Emotion: happiness, sadness, fear, anger, neutral                      │
│  ├─ Quality: 44kHz native output                                           │
│  ├─ Phonemizer: Phonikud (NOT eSpeak-NG)                                   │
│  └─ VRAM: 6GB+ recommended                                                 │
│                                                                             │
│  CHATTERBOX + PHONIKUD:                                                     │
│  ├─ Model: Resemble AI Chatterbox v1.0                                     │
│  ├─ Languages: 40+ including Hebrew                                        │
│  ├─ Emotion: Exaggeration slider (0-1)                                     │
│  ├─ Latency: <200ms TTFB streaming                                         │
│  ├─ Phonemizer: Phonikud for Hebrew quality                                │
│  └─ License: MIT (clean commercial path)                                   │
│                                                                             │
│  PIPER-HEBREW (thewh1teagle):                                              │
│  ├─ Model: phonikud-tts-checkpoints/shaul.onnx                            │
│  ├─ Voice: Shaul Amsterdamski (SASPEECH)                                   │
│  ├─ RTF: ~0.2 desktop, ~1.0 Raspberry Pi                                   │
│  └─ Best for: Edge deployment, offline                                     │
│                                                                             │
│  DICTALM EMOTION ANALYSIS:                                                  │
│  ├─ Input: Hebrew text                                                      │
│  ├─ Output: Emotion vector for TTS conditioning                            │
│  ├─ DictaLM 3.0 → analyze → emotion + prosody → Zonos/Chatterbox          │
│  └─ Vowelization: DictaLM can also add nikud                               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🧠 Hebrew NLP Stack (Dicta IL 2025)

Complete Hebrew language processing pipeline:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     HEBREW NLP STACK (DICTA IL 2025)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PROCESSING PIPELINE:                                                       │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────┐         │
│  │ Input: Raw Hebrew Text                                         │         │
│  │ "בשנת 1948 השלים אפרים קישון את לימודיו"                        │         │
│  └───────────────────────────┬───────────────────────────────────┘         │
│                              ▼                                              │
│  ┌───────────────────────────────────────────────────────────────┐         │
│  │ DictaBERT-large-char-menaked (Nikud Restoration)               │         │
│  │ Output: "בִּשְׁנַת 1948 הִשְׁלִים אֶפְרַיִם קִישׁוֹן..."          │         │
│  │ • SOTA on all modern Hebrew benchmarks (2025)                  │         │
│  │ • Beats commercial LLMs                                        │         │
│  │ • Auto matres lectionis handling                               │         │
│  └───────────────────────────┬───────────────────────────────────┘         │
│                              ▼                                              │
│  ┌───────────────────────────────────────────────────────────────┐         │
│  │ DictaBERT-joint (5 Tasks Simultaneous)                         │         │
│  │ • Prefix Segmentation: ב+שנת                                   │         │
│  │ • Morphology: Gender=Fem, Number=Sing                          │         │
│  │ • Lemmatization: לימודיו → לימוד                                │         │
│  │ • Syntax: Dependency tree                                      │         │
│  │ • NER: {אפרים קישון: PER}, {1948: TIMEX}                       │         │
│  │ "Flipped Pipeline" = 100x faster, no error propagation         │         │
│  └───────────────────────────┬───────────────────────────────────┘         │
│                              ▼                                              │
│  ┌───────────────────────────────────────────────────────────────┐         │
│  │ Phonikud ONNX (G2P)                                            │         │
│  │ Output IPA: "biʃˈnat 1948 hiʃˈlim efˈrajim kiˈʃon..."          │         │
│  │ • Stress marking (ˈ)                                           │         │
│  │ • Vocal shva distinction                                       │         │
│  │ • Loanword handling                                            │         │
│  └───────────────────────────┬───────────────────────────────────┘         │
│                              ▼                                              │
│  ┌───────────────────────────────────────────────────────────────┐         │
│  │ DictaLM 3.0-24B-Thinking (Reasoning)                           │         │
│  │ • Chain-of-thought Hebrew reasoning                            │         │
│  │ • Translation he↔en                                            │         │
│  │ • Cultural context understanding                               │         │
│  │ • Poetry/literary analysis                                     │         │
│  │ • Tool calling via Hermes parser                               │         │
│  └───────────────────────────────────────────────────────────────┘         │
│                                                                             │
│  MODEL HIERARCHY:                                                           │
│  ┌──────────────────────────────────────────────────────────────────┐      │
│  │ dicta-il/DictaLM-3.0-24B-Thinking    │ Flagship reasoning       │      │
│  │ dicta-il/DictaLM-3.0-24B-Instruct    │ Chat/instructions        │      │
│  │ dicta-il/DictaLM-3.0-12B-Nemotron    │ Mamba hybrid (fast)      │      │
│  │ dicta-il/DictaLM-3.0-1.7B-Instruct   │ Edge deployment          │      │
│  ├──────────────────────────────────────────────────────────────────┤      │
│  │ dicta-il/dictabert-large-char-menaked│ SOTA nikud              │      │
│  │ dicta-il/dictabert-joint             │ 5-task unified           │      │
│  │ dicta-il/dictabert-tiny-joint        │ Fast variant             │      │
│  └──────────────────────────────────────────────────────────────────┘      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 📝 Y.js/Hocuspocus Collaboration (CRDT)

Real-time collaborative editing with AI enrichment:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   Y.JS/HOCUSPOCUS CRDT ARCHITECTURE                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ARCHITECTURE OVERVIEW:                                                     │
│                                                                             │
│  ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐       │
│  │ Browser Client  │     │ Browser Client  │     │ y-py AI Worker  │       │
│  │ ProseMirror +   │     │ ProseMirror +   │     │ DictaBERT      │       │
│  │ y-prosemirror   │     │ y-prosemirror   │     │ DictaLM        │       │
│  └────────┬────────┘     └────────┬────────┘     └────────┬────────┘       │
│           │                       │                       │                 │
│           └───────────────────────┼───────────────────────┘                 │
│                                   │ Y.Doc sync (WebSocket)                  │
│                                   ▼                                         │
│           ┌───────────────────────────────────────────────┐                 │
│           │           Hocuspocus Server                    │                 │
│           │  ├─ WebSocket Hub (live Y.Doc state)          │                 │
│           │  ├─ Presence/Awareness (cursors, selections)  │                 │
│           │  ├─ Webhooks → Apache Camel (debounced)       │                 │
│           │  └─ Redis scaling for multi-instance          │                 │
│           └───────────────────────┬───────────────────────┘                 │
│                                   │                                         │
│                                   ▼                                         │
│           ┌───────────────────────────────────────────────┐                 │
│           │           Storage Layer                        │                 │
│           │  ├─ S3/MinIO (y-sweet snapshots, cold)        │                 │
│           │  ├─ PostgreSQL + pgvector (index, embeddings) │                 │
│           │  └─ ChromaDB (RAG vectors)                    │                 │
│           └───────────────────────────────────────────────┘                 │
│                                                                             │
│  Y-PY AI PIPELINE (Hocuspocus Client):                                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ y-py connects directly as Hocuspocus WebSocket client               │   │
│  │ • Real-time Y.Doc sync (no webhooks needed!)                        │   │
│  │ • Observes text changes                                             │   │
│  │ • Runs AI enrichment:                                               │   │
│  │   ├─ DictaBERT-joint: NER, POS, morphology                         │   │
│  │   ├─ DictaLM: Summarization, translation                           │   │
│  │   └─ e5-large: Embeddings → pgvector                               │   │
│  │ • Writes results back to Y.Doc (annotations map)                    │   │
│  │ • Clients see AI highlights in real-time                            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  LIBRARIES (All MIT):                                                       │
│  ├─ Yjs - Core CRDT implementation                                         │
│  ├─ Hocuspocus - WebSocket server with webhooks                            │
│  ├─ y-prosemirror - ProseMirror binding                                    │
│  ├─ y-py - Python CRDT bindings (Rust core)                                │
│  ├─ pycrdt-websocket - Python WebSocket server                             │
│  └─ y-sweet - S3-native persistence                                        │
│                                                                             │
│  KEY INSIGHT: Limitations → Features                                        │
│  ├─ y-sweet (no webhooks) → Pure storage, Camel adds events               │
│  ├─ Hocuspocus (JS only) → Routes to polyglot workers                     │
│  ├─ y-py (batch) → Background AI processing, async writeback              │
│  └─ DictaBERT (latency) → Progressive enhancement UX                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🥽 BabylonJS WebXR Integration

VR/AR hand tracking and spatial interaction:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    BABYLONJS WEBXR INTEGRATION                               │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  WEBXR COMPONENTS:                                                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ XRManager                                                           │   │
│  │ ├─ Session management (immersive-vr, immersive-ar)                 │   │
│  │ ├─ Feature detection (hand-tracking, anchors, planes)              │   │
│  │ ├─ Reference space handling (local, bounded-floor)                 │   │
│  │ └─ State machine: NOT_IN_XR → IN_XR → EXITING                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ HandTracker                                                         │   │
│  │ ├─ 25 joints per hand (XRHand API)                                 │   │
│  │ ├─ Pinch gesture detection (thumb-index distance)                  │   │
│  │ ├─ Point gesture (index extended, others curled)                   │   │
│  │ ├─ Hand mesh visualization (StandardMaterial)                      │   │
│  │ └─ Haptic feedback on key press                                    │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ VoxelKeyPanel                                                       │   │
│  │ ├─ 3D key grid (BoxGeometry per key)                               │   │
│  │ ├─ DynamicTexture for Hebrew RTL text                              │   │
│  │ ├─ Hover state (scale + color change)                              │   │
│  │ ├─ Press animation (depth offset)                                  │   │
│  │ └─ Spatial audio feedback (positional TTS)                         │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  UNITY 3D SERVER ↔ BABYLON CLIENT:                                          │
│  ┌───────────────────────────────────────────────────────────────────┐     │
│  │ Unity (Server)          │  Babylon.js (Client)                    │     │
│  │ ├─ Physics simulation   │  ├─ Visual rendering                    │     │
│  │ ├─ Spatial state        │  ├─ WebXR session                       │     │
│  │ ├─ Multiplayer sync     │  ├─ Hand/controller input               │     │
│  │ └─ RealSense input      │  └─ UI overlays                         │     │
│  │                         │                                          │     │
│  │ FM Point Protocol (particle system streaming)                      │     │
│  └───────────────────────────────────────────────────────────────────┘     │
│                                                                             │
│  FEATURE MATRIX:                                                            │
│  ┌────────────────────┬─────────┬─────────┬─────────┐                      │
│  │ Feature            │ Quest 3 │ Vision  │ Browser │                      │
│  │                    │         │ Pro     │ Desktop │                      │
│  ├────────────────────┼─────────┼─────────┼─────────┤                      │
│  │ Hand Tracking      │ ✅      │ ✅      │ ❌      │                      │
│  │ Controllers        │ ✅      │ ❌      │ ❌      │                      │
│  │ Spatial Anchors    │ ✅      │ ✅      │ ❌      │                      │
│  │ Passthrough        │ ✅      │ ✅      │ ❌      │                      │
│  │ Eye Tracking       │ ✅      │ ✅      │ ❌      │                      │
│  │ Mouse Fallback     │ ❌      │ ❌      │ ✅      │                      │
│  └────────────────────┴─────────┴─────────┴─────────┘                      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🧠 Reasoning Models (DeepSeek R1 & DictaLM Thinking)

Chain-of-thought reasoning for complex tasks:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      REASONING MODELS (THINKING)                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  DEEPSEEK R1 THINKING 24B:                                                  │
│  ├─ Architecture: Distilled from DeepSeek-R1                               │
│  ├─ Base: Qwen-24B                                                          │
│  ├─ Parameters: 24B (Q4_K_M: 14GB, Q8_0: 26GB)                             │
│  ├─ Context: 128K tokens                                                    │
│  ├─ Format: <think>reasoning</think>answer                                 │
│  ├─ Runtime: JLama (pure Java) or llama.cpp                                │
│  └─ License: MIT                                                            │
│                                                                             │
│  DICTALM 3.0-24B-THINKING (Hebrew SOTA):                                    │
│  ├─ Architecture: Mistral-Small-3.1-24B-Base                               │
│  ├─ Parameters: 24B (BF16, FP8 available)                                  │
│  ├─ Context: 128K tokens                                                    │
│  ├─ Training: Extended Hebrew + reasoning corpus                           │
│  ├─ Format: <think>חשיבה</think>תשובה                                      │
│  ├─ Runtime: vLLM --reasoning_parser deepseek_r1                           │
│  ├─ Tool Calling: Hermes parser                                            │
│  └─ License: Apache 2.0                                                     │
│                                                                             │
│  THINKING USE CASES:                                                        │
│  ├─ Poetry translation with cultural nuance                                │
│  │   Input: Translate Hebrew poem preserving rhyme scheme                  │
│  │   <think> Analyze: ABAB rhyme, metaphors, cultural refs...</think>      │
│  │   Output: Adapted English version with preserved structure              │
│  │                                                                          │
│  ├─ Code analysis with explanation                                         │
│  │   <think> Parse AST, identify patterns, security issues...</think>      │
│  │   Output: Detailed review with fixes                                    │
│  │                                                                          │
│  ├─ Hebrew morphological analysis                                          │
│  │   <think> Root: ש-ל-מ, binyan: hif'il, meaning shift...</think>         │
│  │   Output: Complete linguistic breakdown                                 │
│  │                                                                          │
│  └─ RAG query refinement                                                   │
│      <think> Query ambiguous, need context on X, Y...</think>              │
│      Output: Clarified answer with sources                                 │
│                                                                             │
│  VRAM ALLOCATION (32GB GPU):                                                │
│  ├─ DictaLM 3.0-24B Q8: ~24GB                                              │
│  ├─ DictaBERT-joint: ~1GB                                                  │
│  ├─ Zonos-Hebrew: ~6GB                                                     │
│  └─ Buffer: ~1GB                                                            │
│                                                                             │
│  ALTERNATIVE: DictaLM 3.0-12B-Nemotron                                      │
│  ├─ Architecture: Mamba-2 hybrid (faster inference)                        │
│  ├─ Context: 128K                                                           │
│  ├─ VRAM: ~12GB FP16                                                        │
│  └─ Best for: Real-time applications                                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🎨 ComfyUI Image Generation

WebSocket-based image generation workflows:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     COMFYUI IMAGE GENERATION                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ARCHITECTURE:                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                 ComfyUI Server (localhost:8188)                    │    │
│  │  ├─ Stable Diffusion Models (SDXL, SD 1.5)                        │    │
│  │  ├─ Flux.1 Dev/Schnell                                            │    │
│  │  ├─ LoRA Models (custom styles)                                   │    │
│  │  ├─ ControlNet (pose, depth, canny)                               │    │
│  │  └─ Workflows (JSON node graphs)                                  │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                              ↕ WebSocket + HTTP                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                 MCP Server (Ktor + Camel)                          │    │
│  │  MCP Tools:                                                        │    │
│  │  ├─ comfyui_generate_image(prompt, workflow)                      │    │
│  │  ├─ comfyui_get_models()                                          │    │
│  │  ├─ comfyui_queue_status()                                        │    │
│  │  └─ comfyui_get_history()                                         │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                              ↕                                              │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                 Matrix Bot / AI Agent                              │    │
│  │  ├─ Receives image requests                                        │    │
│  │  ├─ Calls ComfyUI via MCP                                         │    │
│  │  ├─ Monitors generation progress                                   │    │
│  │  └─ Uploads images to Matrix room                                 │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  KOTLIN CLIENT IMPLEMENTATION:                                              │
│  ```kotlin                                                                  │
│  class ComfyUIClient(baseUrl: String = "http://localhost:8188") {          │
│      suspend fun queuePrompt(workflow: ComfyUIWorkflow): QueueResponse     │
│      fun monitorProgress(promptId: String): Flow<GenerationProgress>       │
│      suspend fun getImage(promptId: String): ByteArray                     │
│  }                                                                          │
│  ```                                                                        │
│                                                                             │
│  USE CASES FOR UNIKEY V6:                                                   │
│  ├─ Keyboard themes (generate background images)                           │
│  ├─ Custom emoji generation                                                │
│  ├─ Avatar creation for Y.js awareness                                     │
│  ├─ Icon generation for modes                                              │
│  └─ Visual feedback in VR (generated textures)                             │
│                                                                             │
│  COMFYUI NODES FOR TTS INTEGRATION:                                         │
│  ├─ TTS Audio Suite (Chatterbox, F5-TTS, RVC)                              │
│  ├─ ComfyUI-Zonos (emotion control)                                        │
│  └─ Custom Zonos-Hebrew node (Phonikud integration)                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 🔮 Qwen3 Multimodal Family

Vision-Language and Omni models for comprehensive AI:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      QWEN3 MULTIMODAL FAMILY                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  QWEN3-VL (Vision-Language):                                                │
│  ├─ Sizes: 2B, 4B, 8B, 30B-A3B (MoE), 235B-A22B                           │
│  ├─ Context: 256K → 1M tokens                                              │
│  ├─ Input: text, images, video (hours-long)                                │
│  ├─ Output: text only                                                       │
│  ├─ Features:                                                               │
│  │   • Visual Agent: Operates PC/mobile GUIs                               │
│  │   • Visual Coding: HTML/CSS/JS from images                              │
│  │   • OCR: 32 languages (low light, blur, tilt)                           │
│  │   • 3D grounding: Object positions, viewpoints                          │
│  │   • Second-level video indexing                                         │
│  └─ Best for: Document processing, GUI automation, OCR                     │
│                                                                             │
│  QWEN3-OMNI (Full Multimodal):                                              │
│  ├─ Sizes: 7B, 30B-A3B (MoE)                                               │
│  ├─ Input: text, images, audio, video                                      │
│  ├─ Output: text + SPEECH (native TTS!)                                    │
│  ├─ Languages: 119 text, 19 speech input, 10 speech output                 │
│  ├─ Features:                                                               │
│  │   • Real-time voice chat                                                │
│  │   • Built-in STT + TTS                                                  │
│  │   • Streaming responses (234ms latency)                                 │
│  │   • Audio understanding (40+ min)                                       │
│  │   • Music analysis                                                      │
│  └─ Best for: Voice assistants, real-time interaction                      │
│                                                                             │
│  INTEGRATION WITH HEBREW STACK:                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ Hebrew Input → Qwen3-Omni (STT) → English text                      │   │
│  │                     ↓                                                │   │
│  │ English text → DictaLM 3.0 (translation) → Hebrew text              │   │
│  │                     ↓                                                │   │
│  │ Hebrew text → Phonikud (nikud) → Zonos/Piper (TTS) → Audio          │   │
│  │                                                                      │   │
│  │ OR for vision:                                                       │   │
│  │ Hebrew document → Qwen3-VL (OCR) → DictaLM (analysis)               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  MODEL SELECTION MATRIX:                                                    │
│  ┌────────────────────┬───────────────┬───────────────┐                    │
│  │ Task               │ Best Model    │ Alternative   │                    │
│  ├────────────────────┼───────────────┼───────────────┤                    │
│  │ Hebrew LLM         │ DictaLM 3.0   │ Qwen3 + trans │                    │
│  │ Hebrew Nikud       │ DictaBERT-mena│ DictaLM       │                    │
│  │ Hebrew NLP         │ DictaBERT-join│ -             │                    │
│  │ Hebrew TTS         │ Zonos-Hebrew  │ Chatterbox    │                    │
│  │ Vision/OCR         │ Qwen3-VL      │ Qwen3-Omni    │                    │
│  │ Real-time voice    │ Qwen3-Omni    │ Whisper+Piper │                    │
│  │ GUI automation     │ Qwen3-VL      │ -             │                    │
│  │ Reasoning          │ DictaLM Think │ DeepSeek R1   │                    │
│  └────────────────────┴───────────────┴───────────────┘                    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 📊 Jira Project Summary (KAN)

Development tracking across 380+ issues in 24 epics:

#### Epic Index (24 Epics)

| Epic | Key | Description | Stories |
|------|-----|-------------|---------|
| 📄 Document Formats | KAN-2 | DOCX, PDF, EPUB, HTML converters | 15+ |
| 🔌 Communication Protocols | KAN-3 | WebDAV, CalDAV, XMPP, Matrix, gRPC | 30+ |
| 🌍 LocaleUnits | KAN-4 | i18n Framework (CLDR, ICU4J) | 20+ |
| 🖥️ UI Abstraction | KAN-5 | Cross-Platform Components (12+ platforms) | 25+ |
| 🎵 Music Publishing | KAN-6 | Songs & Videos (Suno, Pixverse) | 10+ |
| ⚙️ Infrastructure | KAN-7 | Camel, Auth, Database | 15+ |
| 🇮🇱 Hebrew Language & AI | KAN-8 | TTS/STT, NLP, DictaLM, DictaBERT | 46+ |
| 🎹 UniKey Keyboard | KAN-9 | V5/V6 Phonetic, Nikud, IPA | 8+ |
| 🎵 Music/MusicXML | KAN-10 | VHV, OSMD, Verovio, Y.js CRDT | 12+ |
| 🌐 3D Visualization | KAN-46 | Babylon.js, Cesium, WebXR | 15+ |
| 🎧 Audio Engine | KAN-45 | JUCE, VST3, WebRTC | 10+ |
| 🎮 Unity DOTS | KAN-111 | ECS, Burst, Jobs | 20+ |
| 📁 GGUF Model Catalog | KAN-171 | Local AI Models | 12+ |
| 📂 File Manager | KAN-179 | Ktor WebDAV/Syncfusion + MinIO | 15+ |
| 🤖 Matrix AI Hub | KAN-228 | Trixnity MCP Gateway (LLM/VLM as Users) | 18+ |
| 🔲 Apiform → DOTSform | KAN-237 | Property-Centric 2D/3D Architecture | 10+ |
| 📅 XR-Date Archive | KAN-252 | Restored from Gmail (33 issues) | 33 |
| 📆 KMP Calendar/Contacts | KAN-289 | gRPC Primary, CalDAV/CardDAV Sync | 12+ |
| 🌐 OpenAPI Web Scraper | KAN-364 | Framework for API extraction | 8+ |
| 📦 Free Merged | KAN-417 | Consolidated tracking container | 10+ |

---

#### 🇮🇱 KAN-8: Hebrew Language & AI Models (46+ Stories)

**TTS (Text-to-Speech) Pipeline:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-436 | Comfy Cloud — ACE-Step v1 ComfyUI Demo Song (Hebrew/English) | To Do |
| KAN-428 | Evaluate Hebrew TTS quality: Chatterbox vs Zonos | To Do |
| KAN-418 | Unified Hebrew TTS Server (Fork Chatterbox + Add Zonos) | To Do |
| KAN-419-427 | Unified Hebrew TTS Server subtasks (9 tasks) | To Do |
| KAN-413 | Basic Hebrew Diacritization (dicta-onnx / renikud-v2) | To Do |
| KAN-412 | HE Nikud TTS Pipeline | To Do |
| KAN-408 | Israwave - Ultra-Fast Hebrew TTS | To Do |
| KAN-403 | Zonos Hebrew TTS - High-Quality 44kHz Voice Cloning | To Do |
| KAN-402 | ChatterBox Multilingual TTS - Voice Cloning with Hebrew | To Do |
| KAN-401 | Phonikud-TTS with Piper | To Do |
| KAN-400 | Phonikud G2P ONNX - Hebrew Text to Phoneme | To Do |

**STT (Speech-to-Text) Pipeline:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-407 | Hebrew Speech Datasets - ILSpeech, SASpeech, ivrit.ai | To Do |
| KAN-405 | Whisper Hebrew IPA - Speech to Phoneme | To Do |
| KAN-404 | ivrit.ai Whisper Hebrew STT | To Do |
| KAN-399 | Hebrew-English Speech Processing System | To Do |

**🎯 Master Orchestration (UNIFIED PIPELINE):**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-442 | **UniKeyboard V6 - Emoji Prompt → Full Media Pipeline (Camel/ComfyUI/Dicta/Qwen/FLUX/Wan)** | To Do |

> **KAN-442** is the master orchestration story that unifies all AI model plugins through Apache Camel routing:
> - **Text→Image→Video**: Emoji→Dicta→FLUX.1 Krea→Wan I2V→Animate
> - **Text→Music→Stems→MIDI→Score**: Emoji→ACE-Step→Demucs→Basic-Pitch→VHV/Humdrum
> - **Character Animation**: SillyTavern→Qwen-Image→Wan Animate→Qwen3-Omni (voice)
> - **API Gateway**: WSS to ComfyUI (8188), FastAPI (8000), Gradio (7860), VHV, SillyTavern

**LLM & NLP Models:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-439 | **Qwen3 - Hybrid Thinking LLMs (235B/32B/14B/8B Dense + MoE)** | To Do |
| KAN-438 | **Qwen3-Omni - End-to-End Omni-Modal (Text/Image/Audio/Video → Text+Speech)** | To Do |
| KAN-437 | **Qwen3-VL - Multimodal Vision-Language (235B/32B/8B/4B/2B)** | To Do |
| KAN-410 | DictaLM 3.0 - Sovereign Hebrew LLM (24B-Thinking, 12B, 1.7B) — **SOTA Hebrew** | To Do |
| KAN-413 | DictaBERT-large-char-menaked — **SOTA Hebrew Nikud (diacritization)** | To Do |
| KAN-34 | DictaBERT-joint — 5 Hebrew NLP tasks (NER, POS, Syntax, Lemma, Segment) | To Do |
| KAN-70 | Configure Apache Camel 4.x AI components with Hebrew NLP | To Do |
| KAN-65 | Qwen-VL-3B integration for Hebrew manuscript analysis | To Do |
| KAN-55 | Vision-Language model for Hebrew document understanding | To Do |
| KAN-54 | Build MPC Ktor agent with Playwright, JSoup, RAG | To Do |
| KAN-35 | Wake word detection for Hebrew voice assistant | To Do |
| KAN-33 | Integrate DictaLM 2.0 for Hebrew text generation | To Do |

**Avatar & Character Integration:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-434 | DAZ Studio VRM Avatar Pipeline | To Do |
| KAN-433 | Character Creator VRM Export | To Do |
| KAN-432 | VRM Avatar Standard Integration | To Do |
| KAN-431 | SillyTavern Hebrew STT Integration | To Do |
| KAN-430 | SillyTavern Hebrew TTS Lip Sync | To Do |
| KAN-429 | SillyTavern RTL Hebrew UI Support | To Do |

**MCP Architecture:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-390-388 | Kotlin → Proto → Python schema generation pipeline (3 stories) | To Do |
| KAN-387-381 | MCP architecture stories (7 stories) | To Do |

**Platform Integration:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-119 | NVIDIA Isaac ROS: AI Vision, Speech & IoT Platform (HE/EN) | To Do |
| KAN-61 | Hebrew voice assistant PWA with Web Speech API | To Do |

---

#### 🔌 KAN-3: Communication Protocols (30+ Stories)

**CRDT & Real-time Collaboration:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-397 | ProseMirror + Hocuspocus → y-py AI Pipeline (XHTML/MusicXML) | To Do |
| KAN-396 | Hocuspocus + y-py AI Pipeline - Real-time Collaboration with Hebrew NLP | To Do |
| KAN-395 | KMP Yrs Wrapper (JS/WASM) | To Do |
| KAN-392 | Yjs/y-py Collaborative MusicXML | To Do |
| KAN-363 | Agent Collaboration Protocol - AI agents as CRDT participants | To Do |
| KAN-359 | Yrs WebSocket Service - Rust CRDT service with Camel endpoints | To Do |

**Protocol Adapters:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-100 | Implement Protobuf format datanode for binary serialization | To Do |
| KAN-97 | Implement LDAP protocol adapter with ApacheDS | To Do |
| KAN-96 | Implement S3 protocol adapter with MinIO | To Do |
| KAN-88 | Implement gRPC protocol adapter with Protocol Buffers | To Do |
| KAN-87 | Implement SSE (Server-Sent Events) protocol adapter with Ktor | To Do |
| KAN-86 | Implement XMPP protocol adapter with Smack library | To Do |
| KAN-84 | Implement WebSocket protocol adapter for real-time collaboration | To Do |
| KAN-83 | Implement HTTP/REST protocol adapter with Ktor client | To Do |
| KAN-71 | Implement SMTP/IMAP email protocol datanode with Apache James | To Do |

**DAV & Storage Protocols:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-64 | Setup Matrix Synapse homeserver with mautrix bridges | To Do |
| KAN-58 | Implement unified storage layer with Sardine WebDAV, Bedework CalDAV/CardDAV, MinIO S3 | To Do |
| KAN-41 | Implement Google Calendar bridge via CalDAV adapter | To Do |
| KAN-39 | Implement Matrix protocol client for federated messaging | To Do |
| KAN-21 | Implement XMPP client with Smack library | To Do |
| KAN-20 | Implement WebDAV file operations with Sardine and MinIO | To Do |
| KAN-19 | Implement CardDAV client with contact sync | To Do |
| KAN-18 | Implement CalDAV client with Bedework integration | To Do |

**Core Infrastructure:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-1 | Implement virtual_inbox actor for protocol switching backed by Apache Camel MulticastDefinition | To Do |

---

#### 🌐 KAN-46: 3D Visualization (15+ Stories)

| Key | Summary | Status |
|-----|---------|--------|
| KAN-281 | [XD-93] XR WebXR Integration | To Do |
| KAN-242 | Babylon.js thin client point cloud and widget renderer | To Do |
| KAN-218 | Test: Babylon.js Project Creation | To Do |
| KAN-204 | React File Manager PWA (Syncfusion EJ2 + Babylon.js) | To Do |
| KAN-203 | 3D Plugin - Viewer (Babylon.js / Unity WebGL / Unity MAUI) | To Do |
| KAN-116 | Build ECS to Babylon.js scene sync via WebSocket | To Do |
| KAN-50 | Integrate Cesium globe with Babylon.js 3D scenes | To Do |

---

#### ⚙️ Infrastructure & Gateway Stories

**Ktor & API Gateway:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-361 | Ktor API Gateway - Client WebSocket and REST with Camel integration | To Do |
| KAN-328 | Ktor gRPC Server Implementation | To Do |
| KAN-300 | Server Module - Ktor Application Setup | To Do |
| KAN-174 | MCP-LangChain Tool Registry Bridge | To Do |
| KAN-165 | Phase 2: Camel + DJL + JLama + LangChain4j + Qwen-VL Agent | To Do |
| KAN-163 | Ktor MCP Registry - Keycloak OIDC Role-Based Tool Access | To Do |
| KAN-160 | Kotlin Edge Layer - Ktor/Camel/Playwright/KMP | To Do |
| KAN-141 | Ktor Gateway: JWT Auth, WebSocket Manager, MQTT Bridge | To Do |

**AI & Vector Search:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-234 | JLama Local LLM - Pure Java Inference | To Do |
| KAN-152 | Multimodal NER & Cognitive Embeddings | To Do |
| KAN-149 | Local BERT Vector Index: CLDR/DictaBERT/pgvector/PostGIS/AGE/NER | To Do |
| KAN-148 | RAG BERT Index: TIKA/docx4j/Flexmark/POI → XHTML AST → Vector Store | To Do |

**IoT & Embedded:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-130 | micro-ROS Integration for Embedded IoT Devices | To Do |

**Image & Media Generation:**

| Key | Summary | Status |
|-----|---------|--------|
| KAN-441 | **Wan 2.1/2.2 - T2V/I2V/FLF2V/VACE/Animate (14B/5B/1.3B, ComfyUI)** | To Do |
| KAN-440 | **FLUX.1 Family - T2I/Edit/Inpaint/Outpaint/Redux (Krea/Kontext/Fill)** | To Do |
| KAN-169 | Qwen-Image-Edit - T2I/Edit/Multi-Image (20B, Monthly Updates, ComfyUI) | To Do |
| KAN-167 | E2E Test: Suno Browser Audio → Qwen-Omni Transcribe | To Do |

---

#### 📊 Summary Statistics

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       JIRA PROJECT SUMMARY (KAN)                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  TOTAL ISSUES:     390+                                                     │
│  TOTAL EPICS:      24                                                       │
│  TOTAL STORIES:    300+                                                     │
│  TOTAL TASKS:      50+                                                      │
│  TOTAL BUGS:       30+                                                      │
│                                                                             │
│  TOP EPICS BY SIZE:                                                         │
│  ├─ KAN-8:  🇮🇱 Hebrew Language & AI (46+ stories)                          │
│  ├─ KAN-3:  🔌 Communication Protocols (30+ stories)                        │
│  ├─ KAN-252: 📅 XR-Date Archive (33 issues)                                │
│  ├─ KAN-5:  🖥️ UI Abstraction (25+ stories)                                 │
│  └─ KAN-111: 🎮 Unity DOTS (20+ stories)                                   │
│                                                                             │
│  KEY TECHNOLOGY AREAS:                                                      │
│  ├─ Hebrew TTS/STT: 20+ stories (Zonos, Chatterbox, Whisper)               │
│  ├─ CRDT/Y.js: 10+ stories (Hocuspocus, y-py, ProseMirror)                 │
│  ├─ Protocol Adapters: 15+ stories (WebDAV, gRPC, Matrix)                  │
│  ├─ 3D/WebXR: 15+ stories (Babylon.js, Cesium, Unity)                      │
│  ├─ AI/RAG: 15+ stories (DictaLM, Qwen3, pgvector)                         │
│  ├─ Multimodal: 5+ stories (Qwen3-VL, Qwen3-Omni)                          │
│  ├─ Media Gen: 4+ stories (FLUX.1 Krea T2I, Wan 2.2 Video)                 │
│  └─ Orchestration: KAN-442 (Camel→ComfyUI→FastAPI→Gradio→VHV)             │
│                                                                             │
│  PROJECT URL: https://vrdate.atlassian.net/browse/KAN                       │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

**Document Version:** 3.6 (UniKeyboard V6 Master Orchestration)  
**Last Updated:** January 17, 2026  
**Total Lines:** 7,500+  
**PlantUML Diagrams:** 44+  
**Historical Context Sections:** 10  
**Jira Stories Cataloged:** 115+  
**AI Stack:** Dicta IL 2025 (SOTA Nikud, DictaLM-3.0, dictabert-joint) + Qwen3 (235B MoE, VL 256K, Omni) + FLUX.1 (Krea T2I, Kontext Edit, Fill Inpaint) + Wan 2.2 (T2V/I2V/FLF2V/VACE/Animate) + Qwen-Image (T2I/Edit-2511)  
**Orchestration:** Apache Camel → ComfyUI WSS → FastAPI → Gradio → VHV/Humdrum  
**Data Versions:** CLDR 45, Unicode 16.0, Emoji 16.0  
