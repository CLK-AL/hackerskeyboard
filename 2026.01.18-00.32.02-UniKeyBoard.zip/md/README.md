# UniKeyBoard Project - Backup 2024-12-30

## 📁 Main Files

| File | Description | Size |
|------|-------------|------|
| `unikeyboard.html` | Complete keyboard application | 576 KB |
| `unikey-v2-design.js` | UniKey v2 OOP design document | 12 KB |
| `unikey-v2-complete.js` | UniKey v2 complete implementation | 31 KB |

## 🔧 Supporting Files

| File | Description |
|------|-------------|
| `emoji-data-inline.js` | Inline emoji data |
| `emoji-data.json` | Full emoji database |
| `fonts.json` | Font configurations |
| `hebrew-nikud-rules.md` | Hebrew nikud documentation |
| `hebrew-nikud-complete-rules.md` | Complete nikud rules |

## 🏗️ Architecture (UniKey v2)

```
┌─────────────────────────────────────────────────────────────────┐
│                        UniKey v2                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   NumberKey                    LetterKey                        │
│   ┌─────────┐                  ┌─────────┐                      │
│   │    5    │                  │    a    │                      │
│   └────┬────┘                  └────┬────┘                      │
│        │                            │                           │
│        ▼                            ▼                           │
│   ┌─────────────┐              ┌─────────────┐                  │
│   │  VARIANTS   │              │ IPA_PHONEMES│                  │
│   │ ⑤ ❺ 5️⃣ Ⅴ ⁵  │              │    /a/      │                  │
│   │ ₅ 五 ㊄      │              │             │                  │
│   └─────────────┘              └──────┬──────┘                  │
│                                       │                         │
│                    ┌──────────────────┼──────────────────┐      │
│                    ▼                  ▼                  ▼      │
│              Hebrew Nikud      Hebrew Plain      English        │
│              ַ פַּתַח            א ע              a, ah, ar      │
│              ֲ חֲטַף                              (father)       │
└─────────────────────────────────────────────────────────────────┘
```

## ⌨️ Keyboard Modifiers

| Modifier | Numbers | Letters |
|----------|---------|---------|
| Normal | `5` | `a` |
| Shift | `%` | `a·` (syllables) |
| Alt | `⑤` (circled) | `ו/ה` (MG) |
| Ctrl | `5` | `/a/` (IPA) |
| Right-click | Full popup | — |

## 💾 Backup Location

`backup-20251230-200636/`

