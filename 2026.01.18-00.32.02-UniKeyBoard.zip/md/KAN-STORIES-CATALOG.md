# KAN Project Stories Catalog

**Project:** TomAR (KAN)  
**Total Stories:** 170+  
**Generated:** 2026-01-17  
**Base URL:** https://vrdate.atlassian.net/browse/

---

## 📊 Summary

| Category | Count |
|----------|-------|
| Infrastructure & Core | 25+ |
| Document Processing | 15+ |
| LocaleUnits & Formats | 25+ |
| Protocol Adapters | 20+ |
| Hebrew NLP & AI | 30+ |
| Music & Media | 20+ |
| Unity/3D/XR | 35+ |
| File Manager & Plugins | 25+ |

---

## 🏗️ Infrastructure & Core

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-9](https://vrdate.atlassian.net/browse/KAN-9) | Implement Ktor Edge Server with WebSocket, SSE, and REST endpoints | To Do |
| [KAN-10](https://vrdate.atlassian.net/browse/KAN-10) | Configure Apache Camel 4.x EventBus with Kotlin DSL core routes | To Do |
| [KAN-11](https://vrdate.atlassian.net/browse/KAN-11) | Configure PostgreSQL with JSONB, TimescaleDB, PostGIS, and Apache AGE extensions | To Do |
| [KAN-13](https://vrdate.atlassian.net/browse/KAN-13) | Configure TimescaleDB for events, metrics, and audit logs | To Do |
| [KAN-14](https://vrdate.atlassian.net/browse/KAN-14) | Implement Apache AGE graph for contacts and relationships | To Do |
| [KAN-15](https://vrdate.atlassian.net/browse/KAN-15) | Implement virtual_inbox actor with Camel Multicast EIP | To Do |
| [KAN-16](https://vrdate.atlassian.net/browse/KAN-16) | Setup Phase Two Keycloak for OAuth 2.0 / OIDC authentication | To Do |
| [KAN-17](https://vrdate.atlassian.net/browse/KAN-17) | Configure PostgreSQL with PostGIS and Exposed ORM | To Do |
| [KAN-42](https://vrdate.atlassian.net/browse/KAN-42) | Create Docker Compose infrastructure for local development | To Do |
| [KAN-43](https://vrdate.atlassian.net/browse/KAN-43) | PostgreSQL DataNode Storage: JSONB + PostGIS + TimescaleDB + Apache AGE | To Do |
| [KAN-44](https://vrdate.atlassian.net/browse/KAN-44) | Identity Federation: Keycloak OIDC + ApacheDS + Matrix + XMPP + Bedework + Certbot | To Do |
| [KAN-207](https://vrdate.atlassian.net/browse/KAN-207) | Cloud Infrastructure - Config/Auth/Observability Stack | To Do |
| [KAN-361](https://vrdate.atlassian.net/browse/KAN-361) | Ktor API Gateway - Client WebSocket and REST with Camel integration | To Do |
| [KAN-365](https://vrdate.atlassian.net/browse/KAN-365) | Project README and Documentation | To Do |
| [KAN-373](https://vrdate.atlassian.net/browse/KAN-373) | PostgreSQL + Apache AGE Ingestion Service | To Do |

---

## 📄 Document Processing

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-22](https://vrdate.atlassian.net/browse/KAN-22) | Production-harden DOCX to EPUB converter with Hebrew support | To Do |
| [KAN-23](https://vrdate.atlassian.net/browse/KAN-23) | Production-harden PDF extraction with PDFBox 3.x | To Do |
| [KAN-24](https://vrdate.atlassian.net/browse/KAN-24) | Implement Camel document processing routes with multicast | To Do |
| [KAN-73](https://vrdate.atlassian.net/browse/KAN-73) | Implement HTML/XHTML as canonical source-of-truth format datanode | To Do |
| [KAN-74](https://vrdate.atlassian.net/browse/KAN-74) | Implement JSON format datanode with kotlinx.serialization | To Do |
| [KAN-75](https://vrdate.atlassian.net/browse/KAN-75) | Implement YAML format datanode with SnakeYAML and kaml | To Do |
| [KAN-76](https://vrdate.atlassian.net/browse/KAN-76) | Implement CSV/TSV format datanode with type detection | To Do |
| [KAN-77](https://vrdate.atlassian.net/browse/KAN-77) | Implement XLSX spreadsheet format datanode with Apache POI | To Do |
| [KAN-78](https://vrdate.atlassian.net/browse/KAN-78) | Implement PPTX presentation format datanode with Apache POI | To Do |
| [KAN-79](https://vrdate.atlassian.net/browse/KAN-79) | Implement Markdown format datanode with FlexMark GFM | To Do |
| [KAN-85](https://vrdate.atlassian.net/browse/KAN-85) | Implement XML format datanode with DOM4J and XPath | To Do |
| [KAN-93](https://vrdate.atlassian.net/browse/KAN-93) | Implement PlantUML diagram format datanode with rendering | To Do |
| [KAN-94](https://vrdate.atlassian.net/browse/KAN-94) | Implement AsciiDoc format datanode with AsciidoctorJ | To Do |
| [KAN-95](https://vrdate.atlassian.net/browse/KAN-95) | Implement ZIP/TAR archive format datanode with Commons Compress | To Do |
| [KAN-103](https://vrdate.atlassian.net/browse/KAN-103) | Implement Mermaid diagram format datanode with rendering | To Do |
| [KAN-148](https://vrdate.atlassian.net/browse/KAN-148) | RAG BERT Index: TIKA/docx4j/Flexmark/POI → XHTML AST → Vector Store | To Do |

---

## 🌍 LocaleUnits & Data Types

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-25](https://vrdate.atlassian.net/browse/KAN-25) | Production-harden LocaleUnits core framework (16+ unit types) | To Do |
| [KAN-26](https://vrdate.atlassian.net/browse/KAN-26) | Implement VCardNode with RFC 6350 compliance | To Do |
| [KAN-27](https://vrdate.atlassian.net/browse/KAN-27) | Implement CalendarNode with RFC 5545 compliance | To Do |
| [KAN-28](https://vrdate.atlassian.net/browse/KAN-28) | Implement UIComponent enum with BiMap O(1) lookups | To Do |
| [KAN-29](https://vrdate.atlassian.net/browse/KAN-29) | Implement jsoup Element extensions for UIComponent detection | To Do |
| [KAN-37](https://vrdate.atlassian.net/browse/KAN-37) | Define DataNode sealed class hierarchy with domain extensions | To Do |
| [KAN-38](https://vrdate.atlassian.net/browse/KAN-38) | Port LocaleUnits to Kotlin Multiplatform (JVM, JS, iOS) | To Do |
| [KAN-62](https://vrdate.atlassian.net/browse/KAN-62) | Integrate complete CLDR API with all measurement units and LM/BERT model mappings | To Do |
| [KAN-66](https://vrdate.atlassian.net/browse/KAN-66) | Implement GeoJSON KMP library with MaxMind GeoIP2 integration | To Do |
| [KAN-67](https://vrdate.atlassian.net/browse/KAN-67) | Implement perceptual color science with Oklch and CMYK mixing | To Do |
| [KAN-82](https://vrdate.atlassian.net/browse/KAN-82) | Implement FontUnitValue with Google Fonts and FontConfig per language | To Do |
| [KAN-107](https://vrdate.atlassian.net/browse/KAN-107) | CSS/Bootstrap Registry - Type-Safe Enums for Styling, Spacing, Grid, and Cross-Format Mapping | To Do |
| [KAN-108](https://vrdate.atlassian.net/browse/KAN-108) | Implement SvgUnitValue with SvgTag enum and vector graphics primitives | To Do |
| [KAN-109](https://vrdate.atlassian.net/browse/KAN-109) | Implement HtmlUnitValue with style attributes and SVG AST embedding | To Do |
| [KAN-110](https://vrdate.atlassian.net/browse/KAN-110) | Implement UriUnitValue with QR code SVG generation and logo embedding | To Do |
| [KAN-338](https://vrdate.atlassian.net/browse/KAN-338) | unit-value-core: Interface, Proto, PatchEngine | To Do |
| [KAN-339](https://vrdate.atlassian.net/browse/KAN-339) | unit-value-phone: PhoneValue (libphonenumber) | To Do |
| [KAN-340](https://vrdate.atlassian.net/browse/KAN-340) | unit-value-currency: CurrencyValue (JSR 354 Moneta) | To Do |
| [KAN-341](https://vrdate.atlassian.net/browse/KAN-341) | unit-value-datetime: DateTimeValue (Instant + CLDR Calendars) | To Do |
| [KAN-342](https://vrdate.atlassian.net/browse/KAN-342) | unit-value-measure: MeasureValue (ICU4J CLDR) | To Do |
| [KAN-343](https://vrdate.atlassian.net/browse/KAN-343) | unit-value-address: AddressValue (libaddressinput) | To Do |
| [KAN-344](https://vrdate.atlassian.net/browse/KAN-344) | unit-value-person: PersonNameValue (ICU4J) | To Do |
| [KAN-345](https://vrdate.atlassian.net/browse/KAN-345) | unit-value-geo: GeoValue (GeoJSON WGS84) | To Do |
| [KAN-346](https://vrdate.atlassian.net/browse/KAN-346) | unit-value-color: ColorValue (colormath) | To Do |
| [KAN-347](https://vrdate.atlassian.net/browse/KAN-347) | unit-value-locale: LocaleValue (ICU4J ULocale) | To Do |
| [KAN-348](https://vrdate.atlassian.net/browse/KAN-348) | unit-value-email: EmailValue (Apache Commons) | To Do |
| [KAN-349](https://vrdate.atlassian.net/browse/KAN-349) | unit-value-vcard: VCardValue (ez-vcard) - Complex Composite | To Do |
| [KAN-350](https://vrdate.atlassian.net/browse/KAN-350) | unit-value-calendar: CalendarValue (ical4j) - Complex Composite | To Do |
| [KAN-355](https://vrdate.atlassian.net/browse/KAN-355) | unit-value-xhtml: Element Factories + Inline Edit Behavior | To Do |
| [KAN-356](https://vrdate.atlassian.net/browse/KAN-356) | unit-value-string: StringValue (Unity FixedStrings) | To Do |

---

## 🔌 Protocol Adapters

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-12](https://vrdate.atlassian.net/browse/KAN-12) | Implement PostGIS vector tiles with Cesium for Israel MVP | To Do |
| [KAN-18](https://vrdate.atlassian.net/browse/KAN-18) | Implement CalDAV client with Bedework integration | To Do |
| [KAN-19](https://vrdate.atlassian.net/browse/KAN-19) | Implement CardDAV client with contact sync | To Do |
| [KAN-20](https://vrdate.atlassian.net/browse/KAN-20) | Implement WebDAV file operations with Sardine and MinIO | To Do |
| [KAN-21](https://vrdate.atlassian.net/browse/KAN-21) | Implement XMPP client with Smack library | To Do |
| [KAN-39](https://vrdate.atlassian.net/browse/KAN-39) | Implement Matrix protocol client for federated messaging | To Do |
| [KAN-41](https://vrdate.atlassian.net/browse/KAN-41) | Implement Google Calendar bridge via CalDAV adapter | To Do |
| [KAN-58](https://vrdate.atlassian.net/browse/KAN-58) | Implement unified storage layer with Sardine WebDAV, Bedework CalDAV/CardDAV, and MinIO S3 | To Do |
| [KAN-64](https://vrdate.atlassian.net/browse/KAN-64) | Setup Matrix Synapse homeserver with mautrix bridges for federated IM | To Do |
| [KAN-71](https://vrdate.atlassian.net/browse/KAN-71) | Implement SMTP/IMAP email protocol datanode with Apache James | To Do |
| [KAN-83](https://vrdate.atlassian.net/browse/KAN-83) | Implement HTTP/REST protocol adapter with Ktor client | To Do |
| [KAN-84](https://vrdate.atlassian.net/browse/KAN-84) | Implement WebSocket protocol adapter for real-time collaboration | To Do |
| [KAN-86](https://vrdate.atlassian.net/browse/KAN-86) | Implement XMPP protocol adapter with Smack library | To Do |
| [KAN-87](https://vrdate.atlassian.net/browse/KAN-87) | Implement SSE (Server-Sent Events) protocol adapter with Ktor | To Do |
| [KAN-88](https://vrdate.atlassian.net/browse/KAN-88) | Implement gRPC protocol adapter with Protocol Buffers | To Do |
| [KAN-96](https://vrdate.atlassian.net/browse/KAN-96) | Implement S3 protocol adapter with MinIO for object storage | To Do |
| [KAN-97](https://vrdate.atlassian.net/browse/KAN-97) | Implement LDAP protocol adapter with ApacheDS for directory services | To Do |
| [KAN-98](https://vrdate.atlassian.net/browse/KAN-98) | Implement OAuth 2.0 / OIDC protocol adapter with Keycloak | To Do |
| [KAN-178](https://vrdate.atlassian.net/browse/KAN-178) | WebDAV Server - Core protocol implementation | To Do |
| [KAN-229](https://vrdate.atlassian.net/browse/KAN-229) | Trixnity Appservice - Matrix Bot/Bridge Setup | To Do |
| [KAN-352](https://vrdate.atlassian.net/browse/KAN-352) | dav4jvm CalDAV/CardDAV Sync (Calendar + Contacts) | To Do |
| [KAN-353](https://vrdate.atlassian.net/browse/KAN-353) | WebDAV File Storage (Sardine + MinIO) | To Do |
| [KAN-354](https://vrdate.atlassian.net/browse/KAN-354) | Camel File Processing Routes (WebDAV → XHTML → gRPC Patch) | To Do |
| [KAN-358](https://vrdate.atlassian.net/browse/KAN-358) | Camel-Matrix Component - Route adapter for Matrix rooms | To Do |

---

## 🇮🇱 Hebrew NLP & AI

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-33](https://vrdate.atlassian.net/browse/KAN-33) | Integrate DictaLM 2.0 for Hebrew text generation | To Do |
| [KAN-34](https://vrdate.atlassian.net/browse/KAN-34) | Integrate DictaBERT-joint for 5 Hebrew NLP tasks | To Do |
| [KAN-35](https://vrdate.atlassian.net/browse/KAN-35) | Enhance Hebrew voice assistant with wake word detection | To Do |
| [KAN-55](https://vrdate.atlassian.net/browse/KAN-55) | Integrate Qwen-VL-3B via DJL for Hebrew manuscript analysis | To Do |
| [KAN-61](https://vrdate.atlassian.net/browse/KAN-61) | Build Hebrew voice assistant PWA with Web Speech API and RTL support | To Do |
| [KAN-65](https://vrdate.atlassian.net/browse/KAN-65) | Implement pure DJL Qwen-VL-3B integration for Hebrew manuscript analysis | To Do |
| [KAN-70](https://vrdate.atlassian.net/browse/KAN-70) | Configure Apache Camel 4.x AI components with Hebrew NLP models | To Do |
| [KAN-126](https://vrdate.atlassian.net/browse/KAN-126) | Hebrew ASR Node (DictaLM/Whisper) for Voice Commands | To Do |
| [KAN-127](https://vrdate.atlassian.net/browse/KAN-127) | English ASR + Bilingual Language Detection (HE/EN) | To Do |
| [KAN-128](https://vrdate.atlassian.net/browse/KAN-128) | Bilingual TTS Node (Hebrew/English Voice Synthesis) | To Do |
| [KAN-129](https://vrdate.atlassian.net/browse/KAN-129) | Voice Command Interface (Intent Parsing + Action Routing) | To Do |
| [KAN-149](https://vrdate.atlassian.net/browse/KAN-149) | Local BERT Vector Index: CLDR/DictaBERT/pgvector/PostGIS/AGE/NER | To Do |
| [KAN-151](https://vrdate.atlassian.net/browse/KAN-151) | Perceptual Color & Font Semantics: Visual Understanding Layer | To Do |
| [KAN-152](https://vrdate.atlassian.net/browse/KAN-152) | Multimodal NER & Cognitive Embeddings: Visual Context + 896d Vectors | To Do |
| [KAN-153](https://vrdate.atlassian.net/browse/KAN-153) | Universal Emotion: HSL Color Wheel + Emoji Faces (Language-Agnostic AI) | To Do |
| [KAN-232](https://vrdate.atlassian.net/browse/KAN-232) | BERT Joint Models - Multi-task NLP (NER+POS+DEP) | To Do |
| [KAN-396](https://vrdate.atlassian.net/browse/KAN-396) | Hocuspocus + y-py AI Pipeline - Real-time Collaboration with Hebrew NLP (DictaBERT/DictaLM) | To Do |
| [KAN-399](https://vrdate.atlassian.net/browse/KAN-399) | Hebrew-English Speech Processing System (TTS + STT) | To Do |
| [KAN-400](https://vrdate.atlassian.net/browse/KAN-400) | Phonikud G2P ONNX - Hebrew Text to Phoneme Conversion | To Do |
| [KAN-401](https://vrdate.atlassian.net/browse/KAN-401) | Phonikud-TTS with Piper - Lightweight Hebrew Speech Synthesis | To Do |
| [KAN-402](https://vrdate.atlassian.net/browse/KAN-402) | ChatterBox Multilingual TTS - Voice Cloning with Hebrew Support | To Do |
| [KAN-403](https://vrdate.atlassian.net/browse/KAN-403) | Zonos Hebrew TTS - High-Quality 44kHz Voice Cloning | To Do |
| [KAN-404](https://vrdate.atlassian.net/browse/KAN-404) | ivrit.ai Whisper Hebrew STT - Speech to Text Recognition | To Do |
| [KAN-405](https://vrdate.atlassian.net/browse/KAN-405) | Whisper Hebrew IPA - Speech to Phoneme Transcription | To Do |
| [KAN-406](https://vrdate.atlassian.net/browse/KAN-406) | ByT5 Hebrew G2P - End-to-End Neural Phoneme Conversion | To Do |
| [KAN-407](https://vrdate.atlassian.net/browse/KAN-407) | Hebrew Speech Datasets - ILSpeech, SASpeech, ivrit.ai Collections | To Do |
| [KAN-408](https://vrdate.atlassian.net/browse/KAN-408) | Israwave - Ultra-Fast Hebrew TTS (WaveNet-quality) | To Do |
| [KAN-409](https://vrdate.atlassian.net/browse/KAN-409) | dicta-onnx - Hebrew Diacritics (Nikud) Addition | To Do |
| [KAN-410](https://vrdate.atlassian.net/browse/KAN-410) | DictaLM 3.0 - Sovereign Hebrew LLM Collection (24B/12B/1.7B) | To Do |
| [KAN-412](https://vrdate.atlassian.net/browse/KAN-412) | HE Nikud TTS | To Do |
| [KAN-413](https://vrdate.atlassian.net/browse/KAN-413) | Basic Hebrew Diacritization (dicta-onnx / renikud-v2) | To Do |
| [KAN-418](https://vrdate.atlassian.net/browse/KAN-418) | Unified Hebrew TTS Server (Fork Chatterbox + Add Zonos) | To Do |

---

## 🤖 AI & LLM Integration

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-172](https://vrdate.atlassian.net/browse/KAN-172) | MCP Local GGUF Model Zoo Manager | To Do |
| [KAN-173](https://vrdate.atlassian.net/browse/KAN-173) | GGUF MCP Server: Universal Local Model Gateway for Any LLM | To Do |
| [KAN-174](https://vrdate.atlassian.net/browse/KAN-174) | MCP-LangChain Tool Registry Bridge | To Do |
| [KAN-175](https://vrdate.atlassian.net/browse/KAN-175) | YAML Model Registry: Declarative GGUF/MCP Configuration | To Do |
| [KAN-230](https://vrdate.atlassian.net/browse/KAN-230) | AI Service Registry - vCard + ServiceCategory Taxonomy | To Do |
| [KAN-231](https://vrdate.atlassian.net/browse/KAN-231) | Camel LangChain4j Agent Routes - LLM with Tools | To Do |
| [KAN-234](https://vrdate.atlassian.net/browse/KAN-234) | JLama Local LLM - Pure Java Inference (No External API) | To Do |
| [KAN-235](https://vrdate.atlassian.net/browse/KAN-235) | MCP Tool Provider - Expose AI Services as MCP Tools | To Do |
| [KAN-381](https://vrdate.atlassian.net/browse/KAN-381) | Implement MCP Server architecture exposing all AI tools | To Do |
| [KAN-382](https://vrdate.atlassian.net/browse/KAN-382) | Deploy federated MCP architecture with independent service ports | To Do |
| [KAN-383](https://vrdate.atlassian.net/browse/KAN-383) | Implement MCP mesh where services call each other directly | To Do |
| [KAN-384](https://vrdate.atlassian.net/browse/KAN-384) | Build Apache Camel AI routes as MCP backbone | To Do |
| [KAN-385](https://vrdate.atlassian.net/browse/KAN-385) | Expose AI capabilities via multiple protocols (REST, Kafka, Telegram, File) | To Do |
| [KAN-386](https://vrdate.atlassian.net/browse/KAN-386) | Design MCP tools as protocol-agnostic APIs with unified implementation | To Do |
| [KAN-411](https://vrdate.atlassian.net/browse/KAN-411) | HuggingFace Model Conversion Script (HF → GGUF/ONNX/OpenVINO) | To Do |
| [KAN-437](https://vrdate.atlassian.net/browse/KAN-437) | Qwen3-VL - Multimodal Vision-Language Model (235B/32B/8B/4B/2B) | To Do |
| [KAN-438](https://vrdate.atlassian.net/browse/KAN-438) | Qwen3-Omni - End-to-End Omni-Modal Model (Text/Image/Audio/Video → Text+Speech) | To Do |
| [KAN-439](https://vrdate.atlassian.net/browse/KAN-439) | Qwen3 - Hybrid Thinking LLMs (235B/32B/14B/8B/4B Dense + MoE) | To Do |

---

## 🎵 Music & Audio

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-31](https://vrdate.atlassian.net/browse/KAN-31) | Complete Suno AI API integration for music generation | To Do |
| [KAN-32](https://vrdate.atlassian.net/browse/KAN-32) | Implement music video storyboard generator with AI prompts | To Do |
| [KAN-40](https://vrdate.atlassian.net/browse/KAN-40) | Setup music distribution pipeline to streaming platforms | To Do |
| [KAN-47](https://vrdate.atlassian.net/browse/KAN-47) | Build JUCE VST3 host with C API for cross-platform export | To Do |
| [KAN-48](https://vrdate.atlassian.net/browse/KAN-48) | DawDreamer WebRTC for browser music streaming with Suno AI | To Do |
| [KAN-60](https://vrdate.atlassian.net/browse/KAN-60) | Implement MusicXML as canonical protocol mapping for cross-DAW compatibility | To Do |
| [KAN-68](https://vrdate.atlassian.net/browse/KAN-68) | Build JUCE audio DSP module with cross-platform C API bridges | To Do |
| [KAN-69](https://vrdate.atlassian.net/browse/KAN-69) | Revive Frinika DAW with GraalVM 25 CE and ProxyMusic MusicXML integration | To Do |
| [KAN-72](https://vrdate.atlassian.net/browse/KAN-72) | Implement MIDI protocol datanode with Java Sound API | To Do |
| [KAN-80](https://vrdate.atlassian.net/browse/KAN-80) | Implement SRT/VTT subtitle format datanode for lyrics sync | To Do |
| [KAN-89](https://vrdate.atlassian.net/browse/KAN-89) | Implement MP3/WAV/FLAC audio format datanode with metadata | To Do |
| [KAN-287](https://vrdate.atlassian.net/browse/KAN-287) | DawDreamer + iZotope Stem Mixing Pipeline for Suno AI Output | To Do |
| [KAN-288](https://vrdate.atlassian.net/browse/KAN-288) | DawDreamer MusicXML Integration for Score-Based Rendering | To Do |
| [KAN-391](https://vrdate.atlassian.net/browse/KAN-391) | MusicXML → XHTML/EPUB Sheet Music Rendering with Verovio + SMuFL | To Do |
| [KAN-392](https://vrdate.atlassian.net/browse/KAN-392) | Yjs/y-py Collaborative MusicXML Editing with Real-Time Sync | To Do |
| [KAN-397](https://vrdate.atlassian.net/browse/KAN-397) | ProseMirror + Hocuspocus → y-py AI Pipeline (XHTML/MusicXML Editors) | To Do |
| [KAN-398](https://vrdate.atlassian.net/browse/KAN-398) | Music Format Conversion Pipeline (MusicXML ↔ Humdrum ↔ MIDI) | To Do |
| [KAN-436](https://vrdate.atlassian.net/browse/KAN-436) | Comfy Cloud — ACE-Step v1 ComfyUI Demo Song (Hebrew/English) | To Do |

---

## 🎬 Media & Generative AI

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-90](https://vrdate.atlassian.net/browse/KAN-90) | Implement PNG/JPEG/SVG image format datanode with EXIF | To Do |
| [KAN-91](https://vrdate.atlassian.net/browse/KAN-91) | Implement MP4/WebM video format datanode with FFmpeg | To Do |
| [KAN-168](https://vrdate.atlassian.net/browse/KAN-168) | Full Creative Pipeline: txt2img + txt2music + txt2video via Browser Automation | To Do |
| [KAN-233](https://vrdate.atlassian.net/browse/KAN-233) | Generative AI Routes - Music/Video/Image (Suno, PixVerse, FLUX) | To Do |
| [KAN-236](https://vrdate.atlassian.net/browse/KAN-236) | Matrix Media Handler - Upload/Download for AI I/O | To Do |
| [KAN-440](https://vrdate.atlassian.net/browse/KAN-440) | FLUX.1 Family - T2I/Edit/Inpaint/Outpaint/Redux (Krea/Kontext/Fill, ComfyUI) | To Do |
| [KAN-441](https://vrdate.atlassian.net/browse/KAN-441) | Wan 2.1/2.2 - T2V/I2V/FLF2V/VACE/Animate (14B/5B/1.3B, ComfyUI) | To Do |
| [KAN-442](https://vrdate.atlassian.net/browse/KAN-442) | UniKeyboard V6 - Emoji Prompt → Full Media Pipeline (Camel/ComfyUI/Dicta/Qwen/FLUX/Wan) | To Do |

---

## 🕹️ Unity & 3D Systems

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-49](https://vrdate.atlassian.net/browse/KAN-49) | Implement ZUI semantic scale transitions with LOD system | To Do |
| [KAN-50](https://vrdate.atlassian.net/browse/KAN-50) | Integrate Cesium globe with Babylon.js 3D scenes | To Do |
| [KAN-51](https://vrdate.atlassian.net/browse/KAN-51) | Implement shader-first procedural materials library | To Do |
| [KAN-112](https://vrdate.atlassian.net/browse/KAN-112) | Setup Unity DOTS project with Entities 1.3.x packages | To Do |
| [KAN-113](https://vrdate.atlassian.net/browse/KAN-113) | Define IComponentData structs mirroring DataNode types | To Do |
| [KAN-114](https://vrdate.atlassian.net/browse/KAN-114) | Implement Burst-compiled audio systems with JUCE bridge | To Do |
| [KAN-115](https://vrdate.atlassian.net/browse/KAN-115) | Implement EntityQuery patterns for LOD and spatial systems | To Do |
| [KAN-116](https://vrdate.atlassian.net/browse/KAN-116) | Build ECS to Babylon.js scene sync via WebSocket | To Do |
| [KAN-117](https://vrdate.atlassian.net/browse/KAN-117) | Sync DataNode entities between PostgreSQL and ECS | To Do |
| [KAN-118](https://vrdate.atlassian.net/browse/KAN-118) | Integrate Unity DOTS Physics for collision and picking | To Do |
| [KAN-203](https://vrdate.atlassian.net/browse/KAN-203) | 3D Plugin - Viewer (Babylon.js / Unity WebGL / Unity MAUI) | To Do |
| [KAN-205](https://vrdate.atlassian.net/browse/KAN-205) | Unity File Manager App (Standalone + WebGL) | To Do |
| [KAN-238](https://vrdate.atlassian.net/browse/KAN-238) | Define IComponentData structs for universal property mapping | To Do |
| [KAN-239](https://vrdate.atlassian.net/browse/KAN-239) | Map Camel EIP patterns to DOTS Systems | To Do |
| [KAN-240](https://vrdate.atlassian.net/browse/KAN-240) | RealSense to DOTS particle system point cloud pipeline | To Do |
| [KAN-241](https://vrdate.atlassian.net/browse/KAN-241) | FM Point real-time streaming protocol specification | To Do |
| [KAN-242](https://vrdate.atlassian.net/browse/KAN-242) | Babylon.js thin client point cloud and widget renderer | To Do |
| [KAN-243](https://vrdate.atlassian.net/browse/KAN-243) | VR asset library for data node visualization | To Do |
| [KAN-244](https://vrdate.atlassian.net/browse/KAN-244) | KMP property system with multi-target code generation | To Do |
| [KAN-245](https://vrdate.atlassian.net/browse/KAN-245) | Widget abstraction layer for 2D and 3D framework mapping | To Do |
| [KAN-246](https://vrdate.atlassian.net/browse/KAN-246) | Apiform to DOTSform bridge layer | To Do |
| [KAN-247](https://vrdate.atlassian.net/browse/KAN-247) | Unity Asset Store toolkit stack for DOTSform | To Do |
| [KAN-248](https://vrdate.atlassian.net/browse/KAN-248) | Computer Vision stack - OpenCV and Dlib integration with DOTS | To Do |
| [KAN-249](https://vrdate.atlassian.net/browse/KAN-249) | 3D Document visualization - MegaBook and MegaFiers integration | To Do |
| [KAN-250](https://vrdate.atlassian.net/browse/KAN-250) | Atavism X multiplayer infrastructure (ALTERNATIVE OPTION) | To Do |
| [KAN-251](https://vrdate.atlassian.net/browse/KAN-251) | uMMORPG Mirror networking - lightweight multiplayer alternative | To Do |

---

## 🥽 XR & Virtual Reality

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-253](https://vrdate.atlassian.net/browse/KAN-253) | [XD-2] Universal UX | To Do |
| [KAN-254](https://vrdate.atlassian.net/browse/KAN-254) | [XD-25] XR Concept | To Do |
| [KAN-255](https://vrdate.atlassian.net/browse/KAN-255) | [XD-28] Environments for Development, QA, Production & End-Users | To Do |
| [KAN-256](https://vrdate.atlassian.net/browse/KAN-256) | [XD-33] XR Font | To Do |
| [KAN-257](https://vrdate.atlassian.net/browse/KAN-257) | [XD-34] XR Glyph | To Do |
| [KAN-258](https://vrdate.atlassian.net/browse/KAN-258) | [XD-36] XR Spacial Audio | To Do |
| [KAN-259](https://vrdate.atlassian.net/browse/KAN-259) | [XD-41] XR AI 3D | To Do |
| [KAN-260](https://vrdate.atlassian.net/browse/KAN-260) | [XD-55] XR Teleport | To Do |
| [KAN-261](https://vrdate.atlassian.net/browse/KAN-261) | [XD-56] XR Tracking | To Do |
| [KAN-262](https://vrdate.atlassian.net/browse/KAN-262) | [XD-59] XR AI Eye | To Do |
| [KAN-263](https://vrdate.atlassian.net/browse/KAN-263) | [XD-60] XR Controllers | To Do |
| [KAN-264](https://vrdate.atlassian.net/browse/KAN-264) | [XD-63] XR Methodology | To Do |
| [KAN-265](https://vrdate.atlassian.net/browse/KAN-265) | [XD-67] XR Arcviz | To Do |
| [KAN-266](https://vrdate.atlassian.net/browse/KAN-266) | [XD-68] XR Nature | To Do |
| [KAN-267](https://vrdate.atlassian.net/browse/KAN-267) | [XD-70] XR Templates | To Do |
| [KAN-268](https://vrdate.atlassian.net/browse/KAN-268) | [XD-72] XR Night Club | To Do |
| [KAN-269](https://vrdate.atlassian.net/browse/KAN-269) | [XD-73] XR Cinema | To Do |
| [KAN-270](https://vrdate.atlassian.net/browse/KAN-270) | [XD-74] XR MMORPG | To Do |
| [KAN-271](https://vrdate.atlassian.net/browse/KAN-271) | [XD-75] XR Drive | To Do |
| [KAN-272](https://vrdate.atlassian.net/browse/KAN-272) | [XD-78] XR FX | To Do |
| [KAN-273](https://vrdate.atlassian.net/browse/KAN-273) | [XD-79] XR Terrain | To Do |
| [KAN-274](https://vrdate.atlassian.net/browse/KAN-274) | [XD-81] XR SCI-FI | To Do |
| [KAN-275](https://vrdate.atlassian.net/browse/KAN-275) | [XD-82] XR Pilot | To Do |
| [KAN-276](https://vrdate.atlassian.net/browse/KAN-276) | [XD-84] XR Chat Dialog | To Do |
| [KAN-277](https://vrdate.atlassian.net/browse/KAN-277) | [XD-89] XR Weather | To Do |
| [KAN-278](https://vrdate.atlassian.net/browse/KAN-278) | [XD-90] XR Animations | To Do |
| [KAN-279](https://vrdate.atlassian.net/browse/KAN-279) | [XD-91] XR MMORPG Monsters | To Do |
| [KAN-280](https://vrdate.atlassian.net/browse/KAN-280) | [XD-92] XR Survival | To Do |
| [KAN-281](https://vrdate.atlassian.net/browse/KAN-281) | [XD-93] XR WebXR | To Do |
| [KAN-282](https://vrdate.atlassian.net/browse/KAN-282) | [XD-94] XR Crowdfunding | To Do |
| [KAN-283](https://vrdate.atlassian.net/browse/KAN-283) | [XD-95] XR Discovery | To Do |
| [KAN-284](https://vrdate.atlassian.net/browse/KAN-284) | [XD-96] XR Appbook | To Do |
| [KAN-285](https://vrdate.atlassian.net/browse/KAN-285) | [XD-97] XR Paint | To Do |

---

## 🤖 Isaac ROS & Robotics

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-119](https://vrdate.atlassian.net/browse/KAN-119) | NVIDIA Isaac ROS: AI Vision, Speech & IoT Platform (HE/EN) | To Do |
| [KAN-120](https://vrdate.atlassian.net/browse/KAN-120) | WSL2 + Docker + Isaac ROS Development Environment Setup | To Do |
| [KAN-121](https://vrdate.atlassian.net/browse/KAN-121) | Isaac ROS Visual SLAM (cuVSLAM) Integration | To Do |
| [KAN-122](https://vrdate.atlassian.net/browse/KAN-122) | Isaac ROS Object Detection Pipeline (RT-DETR/YOLO/TensorRT) | To Do |
| [KAN-123](https://vrdate.atlassian.net/browse/KAN-123) | Isaac ROS Depth Estimation (ESS Stereo + Point Cloud) | To Do |
| [KAN-124](https://vrdate.atlassian.net/browse/KAN-124) | Isaac ROS nvblox 3D Reconstruction and Mapping | To Do |
| [KAN-125](https://vrdate.atlassian.net/browse/KAN-125) | Isaac ROS 6DoF Pose Estimation (FoundationPose/CenterPose) | To Do |
| [KAN-130](https://vrdate.atlassian.net/browse/KAN-130) | micro-ROS Integration for Embedded IoT Devices | To Do |
| [KAN-131](https://vrdate.atlassian.net/browse/KAN-131) | MQTT Bridge for IoT Sensors and Cloud Integration | To Do |
| [KAN-132](https://vrdate.atlassian.net/browse/KAN-132) | Multi-Sensor Fusion Pipeline (IMU/Camera/GPS/Encoders) | To Do |
| [KAN-133](https://vrdate.atlassian.net/browse/KAN-133) | Isaac Sim Integration (Simulation + ROS 2 Bridge) | To Do |
| [KAN-134](https://vrdate.atlassian.net/browse/KAN-134) | Synthetic Data Generation Pipeline (Isaac Sim Replicator) | To Do |
| [KAN-135](https://vrdate.atlassian.net/browse/KAN-135) | Jetson Edge Deployment Pipeline | To Do |
| [KAN-136](https://vrdate.atlassian.net/browse/KAN-136) | Isaac ROS AprilTag Detection (Fiducial Localization) | To Do |
| [KAN-137](https://vrdate.atlassian.net/browse/KAN-137) | Nav2 Integration with Isaac ROS Perception | To Do |
| [KAN-138](https://vrdate.atlassian.net/browse/KAN-138) | KMP Core: MessagePack Models & Serialization (RosMessages, Telemetry, Navigation) | To Do |
| [KAN-139](https://vrdate.atlassian.net/browse/KAN-139) | KMP ROS Client: Multi-Protocol Transport (WebSocket, MQTT, REST) | To Do |
| [KAN-140](https://vrdate.atlassian.net/browse/KAN-140) | KMP Security: Keycloak PKCE Auth & JWT ROS Permissions | To Do |
| [KAN-141](https://vrdate.atlassian.net/browse/KAN-141) | Ktor Gateway: JWT Auth, WebSocket Manager, MQTT Bridge | To Do |
| [KAN-142](https://vrdate.atlassian.net/browse/KAN-142) | FastAPI ROS Bridge: Python ROS 2 Node with Nav2 & Perception | To Do |
| [KAN-143](https://vrdate.atlassian.net/browse/KAN-143) | Keycloak Config: Realm, Clients, ROS Claims & Organizations | To Do |
| [KAN-144](https://vrdate.atlassian.net/browse/KAN-144) | Infrastructure: Docker Compose, Mosquitto, CI/CD Pipelines | To Do |
| [KAN-145](https://vrdate.atlassian.net/browse/KAN-145) | Isaac ROS: VSLAM, Object Detection, Depth & nvblox Integration | To Do |
| [KAN-146](https://vrdate.atlassian.net/browse/KAN-146) | Mobile Apps: iOS SwiftUI & Android Compose with KMP Integration | To Do |
| [KAN-147](https://vrdate.atlassian.net/browse/KAN-147) | Web Dashboard: React Fleet Monitor, Telemetry Charts & Map View | To Do |

---

## 📁 File Manager & PWA

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-30](https://vrdate.atlassian.net/browse/KAN-30) | Create PWA shell with offline support and browser storage | To Do |
| [KAN-52](https://vrdate.atlassian.net/browse/KAN-52) | Create JSON Forms KMP abstraction with reactive scope | To Do |
| [KAN-63](https://vrdate.atlassian.net/browse/KAN-63) | Build property-based PWA with Cesium globe and country-code sharding | To Do |
| [KAN-180](https://vrdate.atlassian.net/browse/KAN-180) | Syncfusion File Manager API | To Do |
| [KAN-181](https://vrdate.atlassian.net/browse/KAN-181) | Keycloak P2 Integration - Auth & Org Resolver | To Do |
| [KAN-182](https://vrdate.atlassian.net/browse/KAN-182) | vCard/iCal Sync - Identity Provisioning | To Do |
| [KAN-183](https://vrdate.atlassian.net/browse/KAN-183) | File Versioning - Timestamp Prefix | To Do |
| [KAN-184](https://vrdate.atlassian.net/browse/KAN-184) | MinIO Backend - Multi-Tenant S3 Storage | To Do |
| [KAN-185](https://vrdate.atlassian.net/browse/KAN-185) | KMP File Manager + Editors (Kotlin/JS) | To Do |
| [KAN-187](https://vrdate.atlassian.net/browse/KAN-187) | PWA Shell - Service Worker + Tab Management | To Do |
| [KAN-188](https://vrdate.atlassian.net/browse/KAN-188) | Editor Registry - Extension to Editor Mapping | To Do |
| [KAN-189](https://vrdate.atlassian.net/browse/KAN-189) | XHTML Form Editor - JSON Schema Renderer | To Do |
| [KAN-190](https://vrdate.atlassian.net/browse/KAN-190) | Syncfusion Kotlin/JS Bindings | To Do |
| [KAN-191](https://vrdate.atlassian.net/browse/KAN-191) | Media Editors - Image/Audio/Video | To Do |
| [KAN-192](https://vrdate.atlassian.net/browse/KAN-192) | PIM Editors - vCard & iCal | To Do |
| [KAN-193](https://vrdate.atlassian.net/browse/KAN-193) | Plugin System Core - Registry & Dynamic Routes | To Do |
| [KAN-194](https://vrdate.atlassian.net/browse/KAN-194) | XLSX Plugin - Spreadsheet Editor (Syncfusion + POI) | To Do |
| [KAN-195](https://vrdate.atlassian.net/browse/KAN-195) | DOCX Plugin - Document Editor (Syncfusion + POI) | To Do |
| [KAN-196](https://vrdate.atlassian.net/browse/KAN-196) | PDF Plugin - Viewer (Syncfusion + PDFBox) | To Do |
| [KAN-197](https://vrdate.atlassian.net/browse/KAN-197) | Markdown Plugin - Editor (Ace + Flexmark) | To Do |
| [KAN-198](https://vrdate.atlassian.net/browse/KAN-198) | Code Plugin - Editor (Ace) | To Do |
| [KAN-199](https://vrdate.atlassian.net/browse/KAN-199) | Syncfusion .NET Server Microservice | To Do |
| [KAN-200](https://vrdate.atlassian.net/browse/KAN-200) | Blazor WASM File Manager + Editors | To Do |
| [KAN-201](https://vrdate.atlassian.net/browse/KAN-201) | ASP.NET Core File Manager API | To Do |
| [KAN-202](https://vrdate.atlassian.net/browse/KAN-202) | MAUI File Manager + Editors (Native Desktop/Mobile) | To Do |
| [KAN-204](https://vrdate.atlassian.net/browse/KAN-204) | React File Manager PWA (Syncfusion EJ2 + Babylon.js) | To Do |

---

## 🔧 DevOps & Testing

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-56](https://vrdate.atlassian.net/browse/KAN-56) | Package enterprise automation scripts (10 installers, 15 templates) | To Do |
| [KAN-57](https://vrdate.atlassian.net/browse/KAN-57) | Create Docusaurus documentation with interactive API Forms | To Do |
| [KAN-210](https://vrdate.atlassian.net/browse/KAN-210) | Setup: Build Docker Image | To Do |
| [KAN-211](https://vrdate.atlassian.net/browse/KAN-211) | Test: Core Services (GitLab, Docmost, PlantUML, MinIO) | To Do |
| [KAN-212](https://vrdate.atlassian.net/browse/KAN-212) | Test: Java/Kotlin Stack (GraalVM, JBang, Gradle, Maven) | To Do |
| [KAN-213](https://vrdate.atlassian.net/browse/KAN-213) | Test: Python Stack (3.13, Poetry, FastAPI) | To Do |
| [KAN-214](https://vrdate.atlassian.net/browse/KAN-214) | Test: .NET/C# Stack (9.0, 8.0, EF Core) | To Do |
| [KAN-215](https://vrdate.atlassian.net/browse/KAN-215) | Test: Node.js Stack (22, pnpm, npm packages) | To Do |
| [KAN-216](https://vrdate.atlassian.net/browse/KAN-216) | Test: JHipster with All Blueprints | To Do |
| [KAN-217](https://vrdate.atlassian.net/browse/KAN-217) | Test: PostgreSQL Extensions (TimescaleDB, AGE, pgvector) | To Do |
| [KAN-218](https://vrdate.atlassian.net/browse/KAN-218) | Test: Babylon.js Project Creation | To Do |
| [KAN-219](https://vrdate.atlassian.net/browse/KAN-219) | Test: Unity C# Tooling (Scripts, Libraries) | To Do |
| [KAN-220](https://vrdate.atlassian.net/browse/KAN-220) | Test: SSL/TLS Certificates (Certbot) | To Do |
| [KAN-221](https://vrdate.atlassian.net/browse/KAN-221) | Test: Backup and Restore (MinIO S3) | To Do |
| [KAN-222](https://vrdate.atlassian.net/browse/KAN-222) | Test: PlantUML Rendering (Native Image) | To Do |
| [KAN-223](https://vrdate.atlassian.net/browse/KAN-223) | Test: JDL Multi-Blueprint Generation (Java, Kotlin, Python, .NET) | To Do |
| [KAN-224](https://vrdate.atlassian.net/browse/KAN-224) | Test: JDL Microservices Architecture (Gateway + Services) | To Do |
| [KAN-225](https://vrdate.atlassian.net/browse/KAN-225) | Test: Domain Model JDL - Units, XHTML AST, CLDR, RFC, ISO, ApiFormat, ApiForms | To Do |
| [KAN-226](https://vrdate.atlassian.net/browse/KAN-226) | Architecture: KMP Client for JHipster Kotlin Backend | To Do |
| [KAN-227](https://vrdate.atlassian.net/browse/KAN-227) | Setup: OpenAPI KMP Client with Gradle Version Catalog | To Do |

---

## 📊 API & Schema Generation

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-36](https://vrdate.atlassian.net/browse/KAN-36) | Production-harden TreeIndex with O(1) lookup and TreeMap word indexing | To Do |
| [KAN-53](https://vrdate.atlassian.net/browse/KAN-53) | Implement country-code sharding with Matrix federation | To Do |
| [KAN-54](https://vrdate.atlassian.net/browse/KAN-54) | Build MPC Ktor agent with Playwright, JSoup, and RAG | To Do |
| [KAN-59](https://vrdate.atlassian.net/browse/KAN-59) | Design enterprise datanode architecture separating protocols from format processing | To Do |
| [KAN-99](https://vrdate.atlassian.net/browse/KAN-99) | Implement OpenAPI/Swagger format datanode for API specs | To Do |
| [KAN-100](https://vrdate.atlassian.net/browse/KAN-100) | Implement Protobuf format datanode for binary serialization | To Do |
| [KAN-101](https://vrdate.atlassian.net/browse/KAN-101) | Implement Parquet/Avro format datanode for columnar analytics | To Do |
| [KAN-102](https://vrdate.atlassian.net/browse/KAN-102) | Implement SQLite database format datanode with introspection | To Do |
| [KAN-104](https://vrdate.atlassian.net/browse/KAN-104) | Implement LaTeX/TeX format datanode for math typesetting | To Do |
| [KAN-105](https://vrdate.atlassian.net/browse/KAN-105) | Implement RSS/Atom feed format datanode for syndication | To Do |
| [KAN-177](https://vrdate.atlassian.net/browse/KAN-177) | Base Schema Library - Kotlin + Proto + Python codegen | To Do |
| [KAN-206](https://vrdate.atlassian.net/browse/KAN-206) | Protobuf Schema + Wire/C# Code Gen (KMP-MAUI-Unity) | To Do |
| [KAN-208](https://vrdate.atlassian.net/browse/KAN-208) | WASM Per Extension - Unified UI + Backend (Rust/Kt WASM) | To Do |
| [KAN-351](https://vrdate.atlassian.net/browse/KAN-351) | OpenAPI + AsyncAPI Generation from UnitValue Proto | To Do |
| [KAN-366](https://vrdate.atlassian.net/browse/KAN-366) | OpenAPI Parser with CSS Selector Extensions | To Do |
| [KAN-367](https://vrdate.atlassian.net/browse/KAN-367) | Unity Asset Store OpenAPI Spec Definition | To Do |
| [KAN-368](https://vrdate.atlassian.net/browse/KAN-368) | Dynamic HTML Extractor with Jsoup | To Do |
| [KAN-369](https://vrdate.atlassian.net/browse/KAN-369) | Generic Scraper with Playwright Pagination | To Do |
| [KAN-370](https://vrdate.atlassian.net/browse/KAN-370) | JBang CLI with Clikt Subcommands | To Do |
| [KAN-371](https://vrdate.atlassian.net/browse/KAN-371) | CSS Selector Validator CLI | To Do |
| [KAN-387](https://vrdate.atlassian.net/browse/KAN-387) | Generate OpenAPI, AsyncAPI, and MCP schemas from single Kotlin source | To Do |
| [KAN-388](https://vrdate.atlassian.net/browse/KAN-388) | Define equivalent API schemas in Kotlin and Python with MCP tool generation | To Do |
| [KAN-389](https://vrdate.atlassian.net/browse/KAN-389) | Configure Wire (Square) to generate Kotlin from Proto with multi-schema output | To Do |
| [KAN-390](https://vrdate.atlassian.net/browse/KAN-390) | Implement Kotlin → Proto → Python schema generation pipeline | To Do |

---

## 🎭 SillyTavern & Avatar Systems

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-429](https://vrdate.atlassian.net/browse/KAN-429) | SillyTavern RTL Support (dir=auto) | To Do |
| [KAN-430](https://vrdate.atlassian.net/browse/KAN-430) | SillyTavern VRM Avatar with Hebrew TTS Lip Sync | To Do |
| [KAN-431](https://vrdate.atlassian.net/browse/KAN-431) | SillyTavern Browser STT for Hebrew Voice Input | To Do |
| [KAN-432](https://vrdate.atlassian.net/browse/KAN-432) | Character Creator 4 to VRM Photorealistic Avatar Pipeline | To Do |
| [KAN-433](https://vrdate.atlassian.net/browse/KAN-433) | DAZ Studio M4/V4 Legacy Assets to VRM Conversion Pipeline | To Do |
| [KAN-434](https://vrdate.atlassian.net/browse/KAN-434) | Daz Studio V4/M4 Legacy to VRM Avatar Pipeline | To Do |

---

## 📝 Collaboration & Real-Time

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-81](https://vrdate.atlassian.net/browse/KAN-81) | Implement GeoJSON format datanode with PostGIS integration | To Do |
| [KAN-92](https://vrdate.atlassian.net/browse/KAN-92) | Implement TOML configuration format datanode | To Do |
| [KAN-359](https://vrdate.atlassian.net/browse/KAN-359) | Yrs WebSocket Service - Rust CRDT service with Camel-consumable endpoints | To Do |
| [KAN-360](https://vrdate.atlassian.net/browse/KAN-360) | PowerSync Camel Routes - Sync bucket to Camel message bridge | To Do |
| [KAN-362](https://vrdate.atlassian.net/browse/KAN-362) | Document Routing DSL - Content-based routing by doc type and room | To Do |
| [KAN-363](https://vrdate.atlassian.net/browse/KAN-363) | Agent Collaboration Protocol - AI agents as CRDT participants | To Do |
| [KAN-393](https://vrdate.atlassian.net/browse/KAN-393) | KMP Yrs Wrapper - Idiomatic Kotlin API over Yrs4J/yswift/yjs | To Do |
| [KAN-394](https://vrdate.atlassian.net/browse/KAN-394) | KMP Yrs Wrapper - Kotlin API over Yrs4J/yswift/yjs (Experimental) | To Do |
| [KAN-395](https://vrdate.atlassian.net/browse/KAN-395) | KMP Yrs Wrapper - Kotlin/JS + WASM Only (yjs/ywasm) | To Do |

---

## 📌 Free/Placeholder Slots

| Key | Summary | Status |
|-----|---------|--------|
| [KAN-154](https://vrdate.atlassian.net/browse/KAN-154) | [FREE] ex-ROS2 Vision-DOM | To Do |
| [KAN-176](https://vrdate.atlassian.net/browse/KAN-176) | [FREE] ex-Omni Media Robot | To Do |
| [KAN-186](https://vrdate.atlassian.net/browse/KAN-186) | [FREE] | To Do |
| [KAN-209](https://vrdate.atlassian.net/browse/KAN-209) | [FREE] ex-GitLab DevStack | To Do |
| [KAN-337](https://vrdate.atlassian.net/browse/KAN-337) | [FREE] | To Do |
| [KAN-357](https://vrdate.atlassian.net/browse/KAN-357) | [FREE] | To Do |
| [KAN-374](https://vrdate.atlassian.net/browse/KAN-374) | [FREE] | To Do |
| [KAN-375](https://vrdate.atlassian.net/browse/KAN-375) | [FREE] | To Do |
| [KAN-376](https://vrdate.atlassian.net/browse/KAN-376) | [FREE] | To Do |
| [KAN-377](https://vrdate.atlassian.net/browse/KAN-377) | [FREE] | To Do |
| [KAN-378](https://vrdate.atlassian.net/browse/KAN-378) | [FREE] | To Do |
| [KAN-379](https://vrdate.atlassian.net/browse/KAN-379) | [FREE] | To Do |
| [KAN-380](https://vrdate.atlassian.net/browse/KAN-380) | [FREE] | To Do |
| [KAN-414](https://vrdate.atlassian.net/browse/KAN-414) | [FREE] TTS-Ready Phonemization (phonikud-onnx + phonemize) | To Do |
| [KAN-415](https://vrdate.atlassian.net/browse/KAN-415) | [FREE] Local Hebrew TTS (phonikud + Piper) | To Do |
| [KAN-416](https://vrdate.atlassian.net/browse/KAN-416) | [FREE] High-Quality TTS & Voice Cloning (Zonos / ChatterBox) | To Do |

---

## 📈 Statistics

- **Total Cataloged Stories:** 170+
- **Total Project Issues:** 390+
- **Categories:** 15+
- **Key Technology Stacks:**
  - Kotlin Multiplatform (JVM/JS/iOS)
  - Apache Camel 4.x
  - Unity DOTS / Babylon.js
  - PostgreSQL + TimescaleDB + Apache AGE
  - Hebrew NLP (DictaLM/DictaBERT)
  - Syncfusion UI Components
  - ComfyUI / FLUX / Wan / Qwen

---

*Generated from Jira KAN Project - https://vrdate.atlassian.net*
