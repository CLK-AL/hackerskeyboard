# 📁 אינדקס קבצים - Outputs Directory

> תאריך עדכון: 2026-01-18
> סה"כ: **82 קבצים** | **5.1 MB**

---

## 📊 סיכום לפי סוג

| סוג | כמות | גודל |
|-----|------|------|
| JavaScript (.js) | 47 | 1.2 MB |
| Markdown (.md) | 12 | 420 KB |
| HTML (.html) | 4 | 2.4 MB |
| ZIP (.zip) | 6 | 1.2 MB |
| JSON (.json) | 2 | 140 KB |
| Python (.py) | 1 | 9 KB |
| Text (.txt) | 5 | 432 KB |
| JSX (.jsx) | 2 | 162 KB |

---

## 🗂️ מבנה תיקיות

```
outputs/
├── 📄 קבצים ראשיים (72)
├── 📁 backup-20251230-200636/ (3)
├── 📁 fonts/ (1)
└── 📁 hebrew-data/ (4)
```

---

## 📝 תיעוד (Documentation)

| קובץ | גודל | תיאור |
|------|------|-------|
| [README.md](README.md) | 3 KB | תיעוד ראשי |
| [index.md](index.md) | - | אינדקס קבצים (קובץ זה) |
| [KAN-STORIES-CATALOG.md](KAN-STORIES-CATALOG.md) | 43 KB | קטלוג סיפורי כאן |
| [TODO-WEBXR-COMPLETE.md](TODO-WEBXR-COMPLETE.md) | 22 KB | משימות WebXR מלא |
| [todo-webxr-hebrew.md](todo-webxr-hebrew.md) | 6 KB | משימות WebXR בעברית |
| [V6-AGILE-DISCOVERY.md](V6-AGILE-DISCOVERY.md) | 282 KB | תכנון V6 אג'ילי |
| [v5-data-format-analysis.md](v5-data-format-analysis.md) | 9 KB | ניתוח פורמט נתונים V5 |

---

## 🎹 מקלדת (Keyboard)

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikeyboard.html](unikeyboard.html) | 576 KB | מקלדת אוניברסלית - גרסה ראשית |
| [full-keyboard.jsx](full-keyboard.jsx) | 145 KB | קומפוננטת מקלדת מלאה |
| [keyboard-layout-selector.jsx](keyboard-layout-selector.jsx) | 13 KB | בורר פריסת מקלדת |

---

## 😀 אמוג'י (Emoji)

| קובץ | גודל | תיאור |
|------|------|-------|
| [emoji.txt](emoji.txt) | 287 KB | 3,943 אמוג'ים מתורגמים לעברית |
| [emoji-dictionary.txt](emoji-dictionary.txt) | 62 KB | מילון תרגום (2,696 רשומות) |
| [emoji_loader.py](emoji_loader.py) | 9 KB | טוען אמוג'י Python |
| [emoji-data.json](emoji-data.json) | 108 KB | נתוני אמוג'י JSON |
| [emoji-data-inline.js](emoji-data-inline.js) | 74 KB | נתוני אמוג'י JS inline |
| [generate-emoji-data.js](generate-emoji-data.js) | 6 KB | מחולל נתוני אמוג'י |
| [generate-hebrew-txt.js](generate-hebrew-txt.js) | 15 KB | מחולל טקסט עברי |
| [generate-compact.js](generate-compact.js) | 4 KB | מחולל קומפקטי |
| [parse-emoji-test.js](parse-emoji-test.js) | 10 KB | מפענח emoji-test |

---

## 🔤 ניקוד עברי (Hebrew Nikud)

| קובץ | גודל | תיאור |
|------|------|-------|
| [hebrew-nikud-rules.md](hebrew-nikud-rules.md) | 18 KB | חוקי ניקוד |
| [hebrew-nikud-complete-rules.md](hebrew-nikud-complete-rules.md) | 25 KB | חוקי ניקוד מלאים |

---

## ⌨️ UniKey V2

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v2-complete.js](unikey-v2-complete.js) | 31 KB | גרסה מלאה |
| [unikey-v2-design.js](unikey-v2-design.js) | 12 KB | עיצוב |
| [unikey-v2-mg-final.js](unikey-v2-mg-final.js) | 10 KB | גרסה סופית MG |

---

## ⌨️ UniKey V3

### תיעוד V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-architecture.md](unikey-v3-architecture.md) | 5 KB | ארכיטקטורה |
| [unikey-v3-design.md](unikey-v3-design.md) | 11 KB | עיצוב |
| [unikey-v3-summary.md](unikey-v3-summary.md) | 4 KB | סיכום |

### מיפויים V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-keyboard-map.js](unikey-v3-keyboard-map.js) | 12 KB | מיפוי מקלדת |
| [unikey-v3-keyboard-map-complete.js](unikey-v3-keyboard-map-complete.js) | 13 KB | מיפוי מקלדת מלא |
| [unikey-v3-keyboard.js](unikey-v3-keyboard.js) | 12 KB | מקלדת |
| [unikey-v3-complete-map.js](unikey-v3-complete-map.js) | 23 KB | מיפוי מלא |
| [unikey-v3-bidirectional-map.js](unikey-v3-bidirectional-map.js) | 25 KB | מיפוי דו-כיווני |

### IPA V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-ipa-centric.js](unikey-v3-ipa-centric.js) | 27 KB | IPA מרכזי |
| [unikey-v3-ipa-universal-map.js](unikey-v3-ipa-universal-map.js) | 19 KB | מיפוי IPA אוניברסלי |
| [unikey-v3-full-ipa.js](unikey-v3-full-ipa.js) | 21 KB | IPA מלא |
| [unikey-v3-bilingual-ipa-map.js](unikey-v3-bilingual-ipa-map.js) | 23 KB | מיפוי IPA דו-לשוני |
| [unikey-v3-multilingual-ipa.js](unikey-v3-multilingual-ipa.js) | 16 KB | IPA רב-לשוני |

### ניקוד V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-nikud-engine.js](unikey-v3-nikud-engine.js) | 20 KB | מנוע ניקוד |
| [unikey-v3-nikud-options.js](unikey-v3-nikud-options.js) | 16 KB | אפשרויות ניקוד |
| [unikey-v3-auto-nikud.js](unikey-v3-auto-nikud.js) | 10 KB | ניקוד אוטומטי |
| [unikey-v3-dagesh-mappiq.js](unikey-v3-dagesh-mappiq.js) | 18 KB | דגש ומפיק |

### הברות V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-syllables.js](unikey-v3-syllables.js) | 12 KB | הברות |
| [unikey-v3-syllables-ipa.js](unikey-v3-syllables-ipa.js) | 20 KB | הברות IPA |

### תנועות V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-vowels-comparison.js](unikey-v3-vowels-comparison.js) | 15 KB | השוואת תנועות |
| [unikey-v3-vowel-approximations.js](unikey-v3-vowel-approximations.js) | 20 KB | קירובי תנועות |

### נוסף V3
| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v3-12-keys.js](unikey-v3-12-keys.js) | 6 KB | 12 מקשים |
| [unikey-v3-architecture.js](unikey-v3-architecture.js) | 20 KB | ארכיטקטורה JS |
| [unikey-v3-complete-extracted.js](unikey-v3-complete-extracted.js) | 26 KB | חילוץ מלא |
| [unikey-v3-complete-space.js](unikey-v3-complete-space.js) | 11 KB | מרחב מלא |
| [unikey-v3-data-comparison.js](unikey-v3-data-comparison.js) | 19 KB | השוואת נתונים |
| [unikey-v3-detailed-design.js](unikey-v3-detailed-design.js) | 31 KB | עיצוב מפורט |
| [unikey-v3-final-model.js](unikey-v3-final-model.js) | 12 KB | מודל סופי |
| [unikey-v3-mg-3versions.js](unikey-v3-mg-3versions.js) | 13 KB | MG 3 גרסאות |
| [unikey-v3-mg-ipa-mapping.js](unikey-v3-mg-ipa-mapping.js) | 19 KB | מיפוי MG IPA |
| [unikey-v3-mg-semantic.js](unikey-v3-mg-semantic.js) | 12 KB | MG סמנטי |
| [unikey-v3-mg-vs-ivrita.js](unikey-v3-mg-vs-ivrita.js) | 12 KB | MG מול עברית |
| [unikey-v3-silent-letters.js](unikey-v3-silent-letters.js) | 14 KB | אותיות שקטות |
| [unikey-v3-unified.js](unikey-v3-unified.js) | 9 KB | מאוחד |
| [unikey-v3-unified-keys.js](unikey-v3-unified-keys.js) | 10 KB | מקשים מאוחדים |
| [unikey-v3-unique-sounds.js](unikey-v3-unique-sounds.js) | 18 KB | צלילים ייחודיים |

---

## ⌨️ UniKey V4

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v4-phonetics.js](unikey-v4-phonetics.js) | 21 KB | פונטיקה |

---

## ⌨️ UniKey V5

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v5-complete.js](unikey-v5-complete.js) | 32 KB | מלא |
| [unikey-v5-complete-all.js](unikey-v5-complete-all.js) | 198 KB | מלא - הכל |
| [unikey-v5-full.js](unikey-v5-full.js) | 31 KB | מלא |
| [unikey-v5-merged.js](unikey-v5-merged.js) | 25 KB | ממוזג |
| [unikey-v5-package.zip](unikey-v5-package.zip) | 214 KB | חבילה |

---

## ⌨️ UniKey V6

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-v6-2025-ai.zip](unikey-v6-2025-ai.zip) | 237 KB | 2025 AI |
| [unikey-v6-complete-2025.zip](unikey-v6-complete-2025.zip) | 59 KB | מלא 2025 |
| [unikey-v6-discovery.zip](unikey-v6-discovery.zip) | 208 KB | גילוי |
| [unikey-v6-kmp-discovery.zip](unikey-v6-kmp-discovery.zip) | 224 KB | גילוי KMP |
| [unikey-v6-platform.zip](unikey-v6-platform.zip) | 231 KB | פלטפורמה |

---

## 🔧 כלים (Tools)

| קובץ | גודל | תיאור |
|------|------|-------|
| [unikey-html-data-update.js](unikey-html-data-update.js) | 15 KB | עדכון נתוני HTML |

---

## 📊 נתונים (Data)

| קובץ | גודל | תיאור |
|------|------|-------|
| [fonts.json](fonts.json) | 29 KB | נתוני פונטים |

---

## 📁 תיקיית fonts/

| קובץ | גודל | תיאור |
|------|------|-------|
| [fonts/README.md](fonts/README.md) | 12 KB | תיעוד פונטים |

---

## 📁 תיקיית hebrew-data/

| קובץ | גודל | תיאור |
|------|------|-------|
| [hebrew-data/en.txt](hebrew-data/en.txt) | 23 KB | נתונים אנגלית |
| [hebrew-data/he.txt](hebrew-data/he.txt) | 21 KB | נתונים עברית |
| [hebrew-data/ipa.txt](hebrew-data/ipa.txt) | 19 KB | נתוני IPA |
| [hebrew-data/symbols.txt](hebrew-data/symbols.txt) | 72 KB | סמלים |

---

## 📁 תיקיית backup-20251230-200636/

| קובץ | גודל | תיאור |
|------|------|-------|
| [backup-20251230-200636/unikey-v2-complete.js](backup-20251230-200636/unikey-v2-complete.js) | 31 KB | גיבוי V2 מלא |
| [backup-20251230-200636/unikey-v2-design.js](backup-20251230-200636/unikey-v2-design.js) | 12 KB | גיבוי V2 עיצוב |
| [backup-20251230-200636/unikeyboard.html](backup-20251230-200636/unikeyboard.html) | 576 KB | גיבוי מקלדת |

---

## 🗄️ גיבויים (Backups)

| קובץ | גודל | תיאור |
|------|------|-------|
| [20251231-033154-unikeyboard.html](20251231-033154-unikeyboard.html) | 613 KB | גיבוי מקלדת |
| [backup-20251231-024300-unikeyboard.html](backup-20251231-024300-unikeyboard.html) | 576 KB | גיבוי מקלדת |

---

## 📈 סטטיסטיקות

- **סה"כ קבצים:** 82
- **סה"כ גודל:** ~5.1 MB
- **תיקיות משנה:** 3
- **גרסאות UniKey:** V2, V3, V4, V5, V6

---

*נוצר אוטומטית ב-2026-01-18*
