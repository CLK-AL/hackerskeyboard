# TODO: WebXR PWA Hebrew Diacritics Keyboard
## שדרוג UniKey V5 עם BabylonJS + 3D CSS

---

## 🎯 Project Goal
שילוב UniKey V5 (4,200+ mappings) עם WebXR PWA למקלדת עברית מנוקדת ב-3D

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│  WebXR Application Layer (BabylonJS)                    │
│  - Immersive 3D rendering                               │
│  - Hand tracking input (gesture-based text selection)   │
├─────────────────────────────────────────────────────────┤
│  Custom Hebrew Diacritics Input Layer                   │
│  - Niqqud composition (multi-step char + vowel)         │
│  - Unicode handling for combining characters            │
│  - UniKey 4,200+ phonetic mappings                      │
├─────────────────────────────────────────────────────────┤
│  3D CSS Fallback Layer                                  │
│  - CSS transforms for non-XR browsers                   │
│  - Responsive 2D/3D hybrid                              │
├─────────────────────────────────────────────────────────┤
│  Progressive Web App Services (PWA)                     │
│  - Service Worker (offline capability)                  │
│  - IndexedDB (document storage)                         │
│  - Installability (manifest.json)                       │
├─────────────────────────────────────────────────────────┤
│  Browser APIs                                           │
│  - WebXR Device API                                     │
│  - Web Storage API                                      │
│  - Input handling (keyboard, hand tracking)             │
└─────────────────────────────────────────────────────────┘
```

---

## 📋 Phase 1: PWA Foundation

### manifest.json
```json
{
  "name": "Hebrew XR Text Editor - UniKey",
  "short_name": "HebrewXR",
  "description": "WebXR application for Hebrew text with full niqqud support",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "orientation": "portrait-primary",
  "dir": "rtl",
  "lang": "he-IL",
  "theme_color": "#1a4a6b",
  "background_color": "#0f2d3d",
  "icons": [
    {
      "src": "/icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ],
  "screenshots": [
    {
      "src": "/screenshots/narrow.png",
      "sizes": "540x720",
      "type": "image/png",
      "form_factor": "narrow"
    }
  ],
  "categories": ["productivity", "education"],
  "shortcuts": [
    {
      "name": "New Document",
      "short_name": "New",
      "description": "Create a new Hebrew document",
      "url": "/?action=new",
      "icons": [{ "src": "/icons/new-192.png", "sizes": "192x192" }]
    }
  ]
}
```

**Critical settings:**
- `"display": "standalone"` - fullscreen without browser chrome (XR immersion)
- `"dir": "rtl"` - right-to-left text direction
- `"lang": "he-IL"` - Hebrew language for accessibility

### Service Worker (service-worker.js)
```javascript
const CACHE_NAME = 'hebrew-xr-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/js/app.js',
  '/js/hebrew-diacritics.js',
  '/js/webxr-handler.js',
  '/js/unikey-data.js',
  '/lib/babylon.min.js',
  '/models/scene.glb',
  '/fonts/david-libre.woff2',
  '/fonts/noto-sans-hebrew.woff2'
];

// Install event - cache assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(response => {
      if (response) return response;
      return fetch(event.request).catch(() => {
        return caches.match('/offline.html');
      });
    })
  );
});

// Activate event - clean old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
```

---

## 📋 Phase 2: Hebrew Diacritics System

### Unicode Niqqud Characters (U+0591–U+05C7)

| Diacritic | Hebrew Name | Unicode | Description |
|-----------|------------|---------|-------------|
| Dagesh/Mappiq | דָּגֵשׁ | U+05BC | Doubling/hardening |
| Patach | פַּתַח | U+05B7 | Short 'a' |
| Kamatz | קָמַץ | U+05B8 | Long 'a' or 'o' |
| Tzere | צֵרֵה | U+05B5 | Long 'e' |
| Chirik | חִיּוּק | U+05B4 | 'i' sound |
| Cholam | חוֹלָם | U+05B9 | 'o' sound |
| Kubuts | קוּבּוּץ | U+05BB | 'u' sound |
| Segol | סֶגוֹל | U+05B6 | Short 'e' |
| Sheva | שְׁוָא | U+05B0 | Silent/mobile |
| Chataf Segol | חֲטַף סֶגוֹל | U+05B1 | Reduced 'e' |
| Chataf Patach | חֲטַף פַּתַח | U+05B2 | Reduced 'a' |
| Chataf Kamatz | חֲטַף קָמַץ | U+05B3 | Reduced 'o' |
| Shin Dot | שִׁין | U+05C1 | Right dot (sh) |
| Sin Dot | שִׂין | U+05C2 | Left dot (s) |
| Sof Pasuq | סוֹף פָּסוּק | U+05C3 | Verse end ׃ |

### Cantillation Marks (טעמי המקרא)

| Mark | Unicode | Name |
|------|---------|------|
| ֑ | U+0591 | Etnachta |
| ֒ | U+0592 | Segol Accent |
| ֓ | U+0593 | Shalshelet |
| ֔ | U+0594 | Zaqef Qatan |
| ֕ | U+0595 | Zaqef Gadol |
| ֖ | U+0596 | Tipeha |
| ֗ | U+0597 | Revia |
| ֘ | U+0598 | Zarqa |
| ֙ | U+0599 | Pashta |
| ֚ | U+059A | Yetiv |
| ֛ | U+059B | Tevir |
| ֜ | U+059C | Geresh |
| ֝ | U+059D | Gershayim |
| ֞ | U+059E | Qarne Parah |
| ֟ | U+059F | Telisha Gedola |
| ֠ | U+05A0 | Telisha Qetana |
| ֡ | U+05A1 | Merkha |
| ֢ | U+05A2 | Merkha Kefula |
| ֣ | U+05A3 | Darga |
| ֤ | U+05A4 | Qadma |
| ֥ | U+05A5 | Azla |
| ֦ | U+05A6 | Maysla |
| ֧ | U+05A7 | Mahpach |
| ֨ | U+05A8 | Merkha Muqaf |
| ֩ | U+05A9 | Munah |
| ֪ | U+05AA | Othay |
| ֫ | U+05AB | Iluy |
| ֬ | U+05AC | Dechi |

### HebrewDiacriticsHandler Class
```javascript
class HebrewDiacriticsHandler {
  constructor() {
    this.diacritics = {
      // Vowels (niqqud)
      'patach': '\u05B7',      // ַ
      'kamatz': '\u05B8',      // ָ
      'tzere': '\u05B5',       // ֵ
      'chirik': '\u05B4',      // ִ
      'cholam': '\u05B9',      // ֹ
      'kubuts': '\u05BB',      // ֻ
      'segol': '\u05B6',       // ֶ
      'sheva': '\u05B0',       // ְ
      'chataf-segol': '\u05B1', // ֱ
      'chataf-patach': '\u05B2', // ֲ
      'chataf-kamatz': '\u05B3', // ֳ
      
      // Consonant modifiers
      'dagesh': '\u05BC',      // ּ
      'mappiq': '\u05BC',      // ּ
      'shin-dot': '\u05C1',    // ׁ
      'sin-dot': '\u05C2',     // ׂ
      
      // Cantillation
      'sof-pasuq': '\u05C3',   // ׃
      'etnachta': '\u0591',    // ֑
      // ... all 30+ cantillation marks
    };

    this.hebrewLetters = {
      'א': 'aleph', 'ב': 'bet', 'ג': 'gimmel', 'ד': 'dalet',
      'ה': 'he', 'ו': 'vav', 'ז': 'zayin', 'ח': 'chet',
      'ט': 'tet', 'י': 'yud', 'כ': 'kaf', 'ך': 'kaf-final',
      'ל': 'lamed', 'מ': 'mem', 'ם': 'mem-final', 'נ': 'nun',
      'ן': 'nun-final', 'ס': 'samekh', 'ע': 'ayin', 'פ': 'pe',
      'ף': 'pe-final', 'צ': 'tzade', 'ץ': 'tzade-final',
      'ק': 'kof', 'ר': 'resh', 'ש': 'shin', 'ת': 'tav'
    };
  }

  addDiacritic(character, diacriticName) {
    if (!this.hebrewLetters[character]) return character;
    const diacritic = this.diacritics[diacriticName];
    if (!diacritic) return character;
    return character + diacritic;
  }

  addDagesh(character) {
    return this.addDiacritic(character, 'dagesh');
  }

  vocalizeCharacter(character, includeDagesh = false, vowelName) {
    let result = character;
    if (includeDagesh) result = this.addDagesh(result);
    if (vowelName) result = this.addDiacritic(result, vowelName);
    return result;
  }

  stripDiacritics(text) {
    return text.replace(/[\u0591-\u05C7]/g, '');
  }

  hasDiacritics(character) {
    if (character.length === 1) return false;
    return character.slice(1).split('').some(char => {
      const code = char.charCodeAt(0);
      return code >= 0x0591 && code <= 0x05C7;
    });
  }
}
```

---

## 📋 Phase 3: Text Composition System

### HebrewTextComposer Class
```javascript
class HebrewTextComposer {
  constructor(diacriticsHandler) {
    this.diacriticsHandler = diacriticsHandler;
    this.text = '';
    this.cursorPosition = 0;
    this.changeListeners = [];
  }

  insertCharacter(character) {
    this.text = this.text.slice(0, this.cursorPosition) + 
                character + 
                this.text.slice(this.cursorPosition);
    this.cursorPosition += character.length;
    this.notifyChange();
  }

  addDiacriticToPrevious(diacriticName) {
    if (this.cursorPosition === 0) return;
    
    let charIndex = this.cursorPosition - 1;
    while (charIndex > 0 && this.isDiacritic(this.text[charIndex])) {
      charIndex--;
    }
    
    const character = this.text[charIndex];
    const diacritic = this.diacriticsHandler.diacritics[diacriticName];
    const modifiedChar = character + diacritic;
    
    this.text = this.text.slice(0, charIndex) + 
                modifiedChar + 
                this.text.slice(charIndex + 1);
    this.notifyChange();
  }

  isDiacritic(char) {
    const code = char.charCodeAt(0);
    return code >= 0x0591 && code <= 0x05C7;
  }

  deleteBackward() {
    if (this.cursorPosition === 0) return;
    let deleteCount = 1;
    let checkPos = this.cursorPosition - 2;
    while (checkPos >= 0 && this.isDiacritic(this.text[checkPos])) {
      deleteCount++;
      checkPos--;
    }
    this.text = this.text.slice(0, this.cursorPosition - deleteCount) + 
                this.text.slice(this.cursorPosition);
    this.cursorPosition -= deleteCount;
    this.notifyChange();
  }

  // IndexedDB Storage
  async saveDocument(documentName) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('HebrewXRDocs', 1);
      request.onsuccess = () => {
        const db = request.result;
        const transaction = db.transaction(['documents'], 'readwrite');
        const store = transaction.objectStore('documents');
        const document = {
          name: documentName,
          text: this.text,
          textWithoutDiacritics: this.diacriticsHandler.stripDiacritics(this.text),
          createdAt: new Date(),
          modifiedAt: new Date(),
          metadata: {
            characterCount: this.text.length,
            wordCount: this.text.split(/\s+/).length
          }
        };
        store.put(document);
        resolve(document);
      };
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains('documents')) {
          const store = db.createObjectStore('documents', { keyPath: 'name' });
          store.createIndex('modifiedAt', 'modifiedAt', { unique: false });
        }
      };
    });
  }

  notifyChange() {
    this.changeListeners.forEach(listener => listener(this.text));
  }

  onChange(listener) {
    this.changeListeners.push(listener);
  }
}
```

---

## 📋 Phase 4: BabylonJS Integration (Replace Three.js)

### Scene Setup
```javascript
class HebrewXRApp {
  constructor() {
    this.canvas = document.getElementById('renderCanvas');
    this.engine = new BABYLON.Engine(this.canvas, true);
    this.scene = new BABYLON.Scene(this.engine);
    
    this.diacriticsHandler = new HebrewDiacriticsHandler();
    this.textComposer = new HebrewTextComposer(this.diacriticsHandler);
    
    this.init();
  }

  async init() {
    // Camera
    this.camera = new BABYLON.UniversalCamera(
      "camera", 
      new BABYLON.Vector3(0, 1.6, 0), 
      this.scene
    );
    
    // Light
    const light = new BABYLON.HemisphericLight(
      "light", 
      new BABYLON.Vector3(0, 1, 0), 
      this.scene
    );
    
    // Create keyboard
    this.createHebrewKeyboard();
    
    // Create text display
    this.createTextDisplay();
    
    // Setup WebXR
    await this.setupWebXR();
    
    // Render loop
    this.engine.runRenderLoop(() => {
      this.scene.render();
    });
  }

  async setupWebXR() {
    const xrHelper = await this.scene.createDefaultXRExperienceAsync({
      floorMeshes: [],
      optionalFeatures: true
    });
    
    // Hand tracking
    const featuresManager = xrHelper.baseExperience.featuresManager;
    featuresManager.enableFeature(BABYLON.WebXRFeatureName.HAND_TRACKING, "latest", {
      xrInput: xrHelper.input
    });
  }

  createHebrewKeyboard() {
    // Create keyboard panel
    const advancedTexture = BABYLON.GUI.AdvancedDynamicTexture.CreateFullscreenUI("UI");
    
    const keyboard = new BABYLON.GUI.StackPanel();
    keyboard.width = "800px";
    keyboard.horizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_CENTER;
    keyboard.verticalAlignment = BABYLON.GUI.Control.VERTICAL_ALIGNMENT_BOTTOM;
    advancedTexture.addControl(keyboard);
    
    // Hebrew letter rows
    const rows = [
      ['א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ז', 'ח', 'ט'],
      ['י', 'כ', 'ל', 'מ', 'נ', 'ס', 'ע', 'פ', 'צ'],
      ['ק', 'ר', 'ש', 'ת', 'ך', 'ם', 'ן', 'ף', 'ץ']
    ];
    
    rows.forEach(row => {
      const rowPanel = new BABYLON.GUI.StackPanel();
      rowPanel.isVertical = false;
      rowPanel.height = "60px";
      
      row.forEach(letter => {
        const button = BABYLON.GUI.Button.CreateSimpleButton(letter, letter);
        button.width = "60px";
        button.height = "50px";
        button.color = "white";
        button.background = "#2d6b82";
        button.fontSize = 24;
        button.onPointerUpObservable.add(() => {
          this.textComposer.insertCharacter(letter);
        });
        rowPanel.addControl(button);
      });
      
      keyboard.addControl(rowPanel);
    });
    
    // Niqqud row
    const vowelRow = new BABYLON.GUI.StackPanel();
    vowelRow.isVertical = false;
    vowelRow.height = "50px";
    
    const vowels = [
      { label: 'ַ', name: 'patach' },
      { label: 'ָ', name: 'kamatz' },
      { label: 'ֵ', name: 'tzere' },
      { label: 'ִ', name: 'chirik' },
      { label: 'ֻ', name: 'kubuts' },
      { label: 'ֶ', name: 'segol' },
      { label: 'ְ', name: 'sheva' },
      { label: 'ּ', name: 'dagesh' }
    ];
    
    vowels.forEach(vowel => {
      const btn = BABYLON.GUI.Button.CreateSimpleButton(vowel.name, vowel.label);
      btn.width = "50px";
      btn.height = "40px";
      btn.color = "white";
      btn.background = "#c6504d";
      btn.fontSize = 28;
      btn.onPointerUpObservable.add(() => {
        this.textComposer.addDiacriticToPrevious(vowel.name);
      });
      vowelRow.addControl(btn);
    });
    
    keyboard.addControl(vowelRow);
  }

  createTextDisplay() {
    // Dynamic texture for Hebrew text
    const textPlane = BABYLON.MeshBuilder.CreatePlane("textDisplay", {
      width: 2,
      height: 1
    }, this.scene);
    textPlane.position = new BABYLON.Vector3(0, 1.5, -2);
    
    const textTexture = BABYLON.GUI.AdvancedDynamicTexture.CreateForMesh(textPlane);
    
    const textBlock = new BABYLON.GUI.TextBlock();
    textBlock.text = "ברוכים הבאים";
    textBlock.color = "white";
    textBlock.fontSize = 48;
    textBlock.fontFamily = "David Libre";
    textBlock.textHorizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_RIGHT;
    textTexture.addControl(textBlock);
    
    this.textComposer.onChange(text => {
      textBlock.text = text || "ברוכים הבאים";
    });
  }
}
```

---

## 📋 Phase 5: 3D CSS Fallback Layer

### CSS 3D Transforms
```css
/* 3D Keyboard Container */
.keyboard-3d-container {
  perspective: 1000px;
  perspective-origin: center center;
}

.keyboard-3d {
  transform-style: preserve-3d;
  transform: rotateX(-15deg);
  transition: transform 0.3s ease;
}

.keyboard-3d:hover {
  transform: rotateX(-5deg);
}

/* 3D Key Styling */
.key-3d {
  transform-style: preserve-3d;
  transform: translateZ(5px);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.3);
}

.key-3d:hover {
  transform: translateZ(15px) scale(1.05);
  box-shadow: 0 8px 15px rgba(0,0,0,0.4);
}

.key-3d:active {
  transform: translateZ(2px) scale(0.98);
  box-shadow: 0 2px 3px rgba(0,0,0,0.3);
}

/* Hebrew Text Display */
.text-display-3d {
  transform: translateZ(20px) rotateX(5deg);
  background: linear-gradient(135deg, #1a4a6b, #0f2d3d);
  padding: 20px;
  border-radius: 10px;
  direction: rtl;
  font-family: "David Libre", serif;
}

/* Niqqud Key Special Styling */
.key-3d.niqqud {
  background: linear-gradient(135deg, #c6504d, #8b3a3a);
  font-size: 1.5em;
}

/* RTL Layout */
.keyboard-row {
  display: flex;
  flex-direction: row-reverse;
  justify-content: center;
  gap: 5px;
}
```

### Hybrid Mode Detection
```javascript
class HybridRenderer {
  constructor() {
    this.mode = 'css3d'; // 'css3d' | 'webxr' | 'babylonjs'
    this.detectCapabilities();
  }

  async detectCapabilities() {
    // Check WebXR support
    if (navigator.xr) {
      const isVRSupported = await navigator.xr.isSessionSupported('immersive-vr');
      const isARSupported = await navigator.xr.isSessionSupported('immersive-ar');
      
      if (isVRSupported || isARSupported) {
        this.mode = 'webxr';
        return;
      }
    }
    
    // Check WebGL support
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    
    if (gl) {
      this.mode = 'babylonjs';
      return;
    }
    
    // Fallback to CSS 3D
    this.mode = 'css3d';
  }

  render() {
    switch (this.mode) {
      case 'webxr':
        return new HebrewXRApp();
      case 'babylonjs':
        return new BabylonJSApp();
      case 'css3d':
        return new CSS3DApp();
    }
  }
}
```

---

## 📋 Phase 6: UniKey Integration

### Migrate from UniKey V5
- [ ] 4,200+ phonetic mappings → 3D key labels
- [ ] 85+ IPA symbols → IPA 3D panel
- [ ] 19 Ivrita rules → MG mode in XR
- [ ] 12 PUA glyphs → MGHebrew font support
- [ ] Rhymes finder → 3D results display

### UniKey Data Integration
```javascript
// Import UniKey phonetic data
import { phoneticMappings } from './unikey-data.js';

class UniKeyXRIntegration {
  constructor(textComposer) {
    this.textComposer = textComposer;
    this.mappings = phoneticMappings; // 4,200+ mappings
  }

  handlePhoneticInput(latinKey) {
    const hebrewChar = this.mappings[latinKey];
    if (hebrewChar) {
      this.textComposer.insertCharacter(hebrewChar);
    }
  }
}
```

---

## 📋 Phase 7: RTL Rendering Rules

### WebGL/Canvas RTL
```javascript
// Canvas RTL text rendering
ctx.direction = 'rtl';
ctx.textAlign = 'right';
ctx.textBaseline = 'middle';

// BabylonJS RTL
textBlock.textHorizontalAlignment = BABYLON.GUI.Control.HORIZONTAL_ALIGNMENT_RIGHT;
```

### Dagesh Before Vowel Rule
```javascript
enforceNiqqudOrder(letterWithMarks) {
  const letter = letterWithMarks[0];
  const marks = letterWithMarks.slice(1);
  
  let dagesh = '';
  let vowel = '';
  let other = '';
  
  for (const mark of marks) {
    const code = mark.charCodeAt(0);
    if (code === 0x05BC) {
      dagesh = mark;
    } else if ([0x05B7, 0x05B8, 0x05B5, 0x05B4, 0x05BB, 0x05B6, 0x05B0].includes(code)) {
      vowel = mark;
    } else {
      other += mark;
    }
  }
  
  // Correct order: letter + dagesh + vowel + other
  return letter + dagesh + vowel + other;
}
```

---

## 📋 Phase 8: Testing & Deployment

### Testing Without XR Hardware
```javascript
async function testWithFallback() {
  const isARSupported = await navigator.xr?.isSessionSupported('immersive-ar');
  
  if (!isARSupported) {
    console.log('Running in inline mode for testing');
    // Use WebXR Emulator Chrome extension
    // Or CSS 3D fallback
  }
}
```

### HTML Head Tags
```html
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1a4a6b">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
```

---

## 📚 Resources

| Resource | URL |
|----------|-----|
| BabylonJS Docs | https://doc.babylonjs.com/ |
| BabylonJS WebXR | https://doc.babylonjs.com/features/featuresDeepDive/webXR |
| WebXR Device API | https://www.w3.org/TR/webxr/ |
| Hebrew Unicode Block | https://unicode.org/charts/PDF/U0590.pdf |
| Niqqud Wikipedia | https://en.wikipedia.org/wiki/Niqqud |
| PWA Capabilities | https://web.dev/learn/pwa/capabilities |
| WebXR Emulator | Chrome Extension |

---

## 🗓️ Timeline

| Phase | Task | Duration |
|-------|------|----------|
| 1 | PWA Foundation | 1 day |
| 2 | Hebrew Diacritics System | 2 days |
| 3 | Text Composition | 1 day |
| 4 | BabylonJS Integration | 3 days |
| 5 | 3D CSS Fallback | 1 day |
| 6 | UniKey Migration | 2 days |
| 7 | RTL & Testing | 2 days |
| **Total** | | **~2 weeks** |

---

## ✅ Checklist

### PWA
- [ ] manifest.json with RTL
- [ ] Service Worker
- [ ] Offline support
- [ ] Icons (192, 512)

### Hebrew
- [ ] All niqqud (U+05B0-U+05BD)
- [ ] Cantillation marks (U+0591-U+05AF)
- [ ] Dagesh ordering
- [ ] RTL rendering

### BabylonJS
- [ ] Scene setup
- [ ] WebXR session
- [ ] Hand tracking
- [ ] GUI keyboard
- [ ] Dynamic text

### 3D CSS
- [ ] Perspective container
- [ ] Key transforms
- [ ] Hover effects
- [ ] RTL layout

### UniKey
- [ ] 4,200+ mappings
- [ ] IPA panel
- [ ] Ivrita MG
- [ ] PUA glyphs

